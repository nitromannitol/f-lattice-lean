# True old-alternate reflection pairs the remaining W1 SHORT rows

20 November 2026. Hand continuation for the bounded central intersection,
in a fixed proper W1 two-run SHORT saved-last-1 or saved-last-3 record.
Use the earlier exact static supplier test and its one-candidate/two-lift
reduction. The actual saved standards and the old alternate are assumed
to cover their own period quotients. Only vertically unique old rows
are covered by the pairing statement. This is not a zero-defect claim.

## 1. The exact row pairing

Use e=q=(d,n), f=V_q, v=−2p, B=(1/2,−1/2), T=T_q,
K=s_q(p), alpha=K/T and beta=2/T. The central coordinates of an
address a are a−v−B=x e+y f. In both saved records the actual old
alternate D reflects about the coordinate sum

       R=v+2e+f+(1,−1).

To check the creation chart, write q=2A+B_old with its actual
proper parents and let delta=det(A,B_old). The independently
checked native even-alt reflection vector, before arbitrary
external translations, is
2A+(1−delta)B_old+f+(1,−1), in the restored raw frame.
For saved3 p=A and delta=−1, while for saved1 p=q−A and
delta=+1. Both give R. This is reflection of the genuine
finite support, not symmetry of a containing rectangle alone.

The transformation of a candidate address is a'=R−a−e.
It preserves physical parity and takes (x,y) to
(1+2alpha−x, 1+beta−y). Its transverse grade is
t(a')=L+2−T−t(a), with L=d+n. Thus the full interval of
vertically unique grades is preserved. The residual central
strip M_t<y<=1−M_t on the physical step-beta mesh is also
preserved, since its lower included level is M_t+beta.
It exchanges the two genuine lifts:
       a in D     iff a'+e in D,
       a+e in D   iff a' in D.
Old cover gives at least one of a,a+e when a is the previous
lemma's candidate. Hence if a' is also a candidate, at least
one of the two is already paid by a literal D site; both are paid
by D precisely when both lifts occur. Standard sources may pay
either one independently.

In fact if BOTH distinct paired rows have positive-x candidates,
they are necessarily the addresses related by a'=R−a−e, not
different lifts in the same row. To see this, their horizontal
coordinates x,x' satisfy
       x+x' = 1+2alpha mod Z,
since in either row legal coordinates differ by integer
translations along e. Their sum lies in (2b,2u], with the
previous b=min(1,2alpha) and the same u on both paired rows:

 * saved3: b=2alpha and u=1+eta, eta=(n+E)/T<alpha.
   The neighboring sums 2alpha and 2+2alpha are strictly
   outside (2b,2u].
 * saved1: b=1 and u=2alpha+eta, eta=(n+2+E)/T<1−alpha.
   Again 2alpha and 2+2alpha are outside (2b,2u].

The eta inequalities follow from the already checked proper
R2 s endpoints: K>n+E and T−K>n+2+E, respectively, including
the low-sector odd correction E. Hence only the exact sum
1+2alpha is possible. In particular each pair of distinct
eligible unique rows has at most one residual positive-x site
after actual D payment; if only one row has a candidate this
bound holds trivially. This does not assert the surviving site
is absent or paid by the standards.

## 2. The midpoint row is paid outright

The pair map fixes
       a_* = −p+B+(e+f)/2.
It is integral because q has two odd coordinates. Its grade is
(L+2−T)/2 and its central coordinates are
(x_*,y_*)=(1/2+alpha,(1+beta)/2).
Its grade lies in the vertically unique interval, using the
record's T>=2L. This is a single physical-parity row, not a
claim on the other parity at an incompatible grade.

There is no alternate candidate on the same positive half of
this row if a_* is outside its candidate interval. Indeed
x_*−1=alpha−1/2 is negative for saved3 and strictly below
b=1 for saved1. Also x_*+1>u:
for saved3, u<1+alpha; for saved1, u<1+alpha as well.
All further site coordinates differ by integer shifts of x.
Thus if a_* is outside the candidate interval the earlier
standard and far-D bounds already pay this row on the positive
half; if there is a candidate it must be a_*. The true old
reflection exchanges a_* and a_*+e. Since cover guarantees at
least one on this unique row, both occur, and the a_* candidate
is paid. Its negative child-reflection partner is then paid
whenever applying the child symmetry. No new D support
assumption was used.

## 3. Extra standard columns from exact integer rounding

The genuine G2 copy P+v has centered p grades
s_p=Kx−2y and t_p=x−Ky. For x=2alpha+r/T with r a positive
odd integer and r alpha<1, and beta<=y<=alpha, one gets
 s_p<=2T_p+alpha r<2T_p+1,   t_p<=r/T<1/K<=1/2.
Here K²−T T_p=2. The integer s grade and half-integer
t grade give respectively <=2T_p and <=0. The same lower
bounds as in the original shifted P period cell proof remain
valid (s_p>-1, t_p>-T_p-1/2). Hence genuine closed P-cell
occupancy pays these extra sites on the actual mesh.

For saved3, g=T−2K is a positive even integer. Since
T/K=2+g/K<=1+g (K>=2 and g>=2), odd r<T/K implies
r<=g−1 and the new x columns are below 1. The genuine lower
Q ray and upper Q column handle all y outside the remaining
beta<=y<=alpha range, just as in the earlier near-column
proof. Thus the cutoff b can be increased to
(2K+r_max)/T for saved3, with r_max the largest positive odd
integer strictly less than T/K. The increase is at least one
physical column. For saved1, r=1 supplies an extra P column
within beta<=y<=alpha, not an all-y assertion outside x=1.
The sum argument in §1 used the earlier possibly wider
candidate bands; passing to narrower bands cannot create a
different reflected pairing.

Only the named vertically unique rows are asserted; high-slope
even transverse grades beyond that interval and any surviving
single candidate still need actual suppliers. Short suffixes
and other run/phase combinations are outside scope.
