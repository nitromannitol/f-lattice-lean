# All-word native quotient coverage: hand-proof package

Start with **F_LATTICE_ALL_WORD_NATIVE_QUOTIENT_COVER_INDUCTION_20261120.md**. Its table identifies the proof for each of the four actual outputs at each digit. The literal base and final transition theorems are included, along with exact source geometry, the necessary earlier proof archives, and the first-switch counterexamples to raw mask equality. All proof files are in this one folder.

The theorem is that every actual native support meets every class modulo its own two periods, for the exact live recursion and every word. This is a statement over the genuine finite support, distinct from recurrence/height recognition and from correctness of a historically capped/float implementation. No numerical enumeration was used to establish any new coverage step.

Mandatory chronology note: a saved-last-3 starting standard E1 can be corrected. Read **F_LATTICE_W1_SHORT_SAVED3_CORRECTED_SEED_CHRONOLOGY_ERRATUM_20261120.md** with any older fixed or finite SHORT note. The proof uses the older, genuine covered E1 as its seed and never claims it is the ordinary union from P. Local reciprocal saved2 has the same genuine earlier seed issue. The final all-word induction orders actual chronological covers accordingly.

Some included research notes are narrower interim results; follow the largest theorem and final assembly when their scope differs. In particular a pure reciprocal helper differs in cardinality from its partner, and an initial switch can have unequal native masks even when the two current quotient images agree. The final successor proofs use genuine finite local carriers, not a supposed global native equality through that switch.

Independent hand review checked the final ordinary-even digit2 sources (including literal gauge endpoint and common deck subtraction), finite saved2 SHORT/LONG (including the actual E1 slots and smallest literal lengths), literal starting masks and true exceptional deck moves, and the exact dispatcher/chronological ordering. These are mathematical checks, not an assertion of external peer review.
