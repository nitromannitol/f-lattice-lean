# W1 SHORT saved-last-1: corrected old W0 alternates on odd sites and even sites through slope 1/2

20 November 2026. Hand proof. Use all standing earlier-own-cover and authentic frame hypotheses of F_LATTICE_W1_SHORT_SAVED1_ORDINARY_ALL_ODD_AND_LOW_EVEN_EVENTUAL_COVER_20261120.md. In the saved-last-1 history, with genuine proper c=q-p and b=2p-q, replace the ordinary old D by a corrected W0 even ALT. Assume the old odd alternate consumed in its helpers has a strict actual creator, so is enclosed by its own restored R2. Then every fixed residual site on physical-odd parity, or on physical-even parity for q slope at most 1/2, is paid. Together with the moving localization and fixed finite box, this proves eventual quotient coverage on these parities. This note does not cover a literal non-strict G3 donor, high-sector physically even sites, finite short suffixes, or the entire recurrence problem.

## Coordinates and reductions

Keep the same p,c,b,q, alpha, lambda=1-alpha, gamma=2alpha-1, T,K, G=s_q(b), H=s_q(c), J=s_c(b), e=q,f=V_q, v=-2p, B=(1/2,-1/2), and the actual old D reflection R=v+2e+f+2B. At a remaining positive fixed address a with x=1+delta, put A=a+e, z=R-A. The previous proof pays the address if the actual P+v or Q rays already supply it, and otherwise either delta>gamma, or r=T*delta>m_q+2 and y>alpha. The first case includes any longitudinal P failure; the second includes transverse failure after the Q column. Here m_X is the centered longitudinal margin n_X on even sites, |d_X-2n_X| on odd. Since r and m_q are odd, the stricter r>=m_q+4 holds in the second case. Also
  H*delta+2y>m_c,   delta<1,    0<y<1.
These are the exact inequalities proved in the preceding ordinary note. The unchanged b slots 1/2 and c slots 4/5 still exclude the adverse z by that proof, which checked each literal slot without using the other two b sources.

The true 3-run of the old corrected D has q=2hc+g with h>=2 and b=2(h-1)c+g, where g is the genuine selected even parent at the last saved W0 record ending 1 or 2. For this note c,g are strict proper. Write m=h-1, eta=1-2h*lambda, G_g=eta*T=s_q(g), J_g=s_c(g). Then g=eta*e+h*beta*f where beta=2/T, so G_g^2-T*T_g=8h^2, G_g-T_g=2h*J_g, J_g=lambda*G_g+4h/T. Also lambda<1/(2h), gamma>1/2, J_g>=4d_c+2n_c and J_g>=3d_g+n_g. The latter inequalities follow by evaluating the positive grade on proper c and g with their minimum components.

## Protected RIGHT and LEFT standard prefixes

The genuine W0 RIGHT helper enters slot 0 with outer translation zero, and contains g@0 and c at g+2ic for i=0,...,m-1. The actual LEFT helper enters slot 3. Its formal standard H boxes are the sourcewise reflections of those of RIGHT about R. This is exactly the reviewed corrected G1/G2 prefix pairing, and uses only the outer standard H enclosure, not reflection of cropped actual support. Thus exclude the RIGHT standard H sets at both z and A; this excludes both actual helper prefixes at z.

At z, of coordinates z-B=-delta*e+(1-y)*f, c at g+2ic has longitudinal grade
  -H*delta+2(1-y)-J_g-2i*T_c < -m_c.
Here J_g>=4d_c+2n_c and m_c<=d_c. At A, all these c copies have the same centered transverse grade as the ordinary c@b because the differences of offsets are integer multiples of 2c, and their s grades are at least that of c@b because their offsets are no further longitudinally than b. The exact reflected-slot-5 proof in the ordinary note ruled out c@b at A by either its lower transverse or its upper longitudinal facet, so it applies to every one of these RIGHT standard copies.

For g@0 at A the two centered grades are
  s_g=G_g*(1-gamma+delta)-4h*(y-beta),
  t_g=2+2h*delta-G_g*y.
These use t_g(e)=2h, s_g(f)=-4h and t_g(f)=-G_g. If y>=alpha then
  T_g+t_g <= 2+2h*delta-(2h-1)*J_g-4h/T < -M_g,
where M_g is the centered upper standard t margin, at most (d_g+n_g)/2. We used G_g*alpha-T_g=(2h-1)*J_g+4h/T, delta<1 and J_g>=3d_g+n_g. If y<alpha then delta>gamma, and
  s_g>G_g-4h*alpha+8h/T > T_g+m_g,
since G_g-T_g=2h*J_g and alpha<1. Thus g@0 misses A.

At z, s_g=-eta*r-4h*(1-y). If delta>gamma>1/2 then G_g*delta>G_g/2>m_g by the proper-grade bound G_g>=3d_g+n_g. Otherwise r>=m_q+4. The deviation satisfies |m_g-eta*m_q|<=2h(3d+n)/T<2, since h<d/(2d_c), d_c>=2, and 3d^2+dn<4T. Thus s_g<-m_g+2, and on the true parity mesh its only possible H grade is the lower edge -m_g. On even physical parity this grade forces z=0: at absolute s=0 the possibilities are j*V_g on this physical parity, and the transverse standard H interval excludes j not zero. On high-sector physical-odd sites absolute s=d_g-n_g forces z=(0,1) by the same argument, with sites (0,1)+j*V_g and t in [n_g-T_g,d_g]. To see the parity restriction, V_g/2 is the primitive step of the grade line (d_g,n_g coprime and both odd), and it changes physical parity. On balanced and lower physical-odd sites, d_g-2n_g and d-2n have the same weak nonnegative sign (no strict unimodular Farey crossing at slope 1/2), so m_g=eta*m_q-2h(3d+n)/T<=eta*m_q and there is no possible lower-edge site. In the endpoint possibilities z=0 or z=(0,1), use s_q(z-B)=-r: these give respectively r=n=m_q or r=2n-d=m_q, contrary to r>=m_q+4. Thus g@0 misses z on every stated parity.

## G3 train grades

The independently audited W0 even-prefix table gives actual G2 origins zero (RIGHT) and 2m(c+V_c) (LEFT), and G3 steps V_c and -V_c. Including the genuine W0 outer translations zero and 2c+2V_c-b gives all the LONG origins, j=1,...,2m:
  saved anchor last 1: RIGHT 2c-g+jV_c; LEFT 2c-g+(2m+2-j)V_c;
  saved anchor last 2: RIGHT V_g+(j-1)V_c; LEFT V_g+(2m+1-j)V_c.
Indeed the W0 K3 values are respectively (2c-g,0) and (V_g-V_c,V_g-V_c-2c+g). The genuine A6 shift restores the unflipped G2 at zero, with no imputed extra G3 shift; the exact LONG count uses the independently checked corrected-prefix/four-head-endpoint dossier.

As s_c(V_c)=0, all heads in both tracks have the same grade shift for a given anchor. At a last-1 anchor it is 2T_c-J_g, and its true birth-phase-1 pALT horizontal base is 2-2T_c+J_g. At a last-2 anchor the shift is s_c(V_g)=2 and its true phase-0 base is zero. In either case shift plus base is 2, and the donor's actual longitudinal lower bound after removing its base is -m_c. At z the required base-removed grade is therefore -H*delta-2y, which is strictly less than -m_c by the standing reduction. Thus neither actual G3 train supplies z. Unlike the standard prefix exclusion, this G3 computation uses the real two origin lists directly, and assumes no symmetry of the old alternate.

There is no additional ordinary seventh donor in the corrected W0 D. We have therefore excluded z from every literal operand of D. The actual reflection excludes A, and since earlier coverage gives one of a and A on the exact row, a is paid. This closes the claimed proper-old-donor corrected cases.
