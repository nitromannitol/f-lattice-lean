# Native quotient cover of all literal standard and alternate initializers

20 November 2026. Hand proof by exhibiting representatives. This provides the literal base of the stronger native-cover induction, separate from the transition lemmas.

Use the exact native periods U=(d,n) at even rational type and U=2(d,n) at odd type, V=(n-d,n+d), B=(1/2,-1/2). The real cell B+[0,1]U+[0,1]V meets every integral class modulo the two periods: independently reduce the two real coefficients by integers. To prove native quotient cover it suffices to pay all its integral points by actual native sites, allowing a genuine deck translation of a point on an edge. The raw or centered literal supports below are from the first-mixed staircase/ladder donor dossiers and the original pure standard formulas in the 19 November recovery audit. The small root is checked with its actual staircase, not an extrapolated doubled ladder.

## Reciprocal even staircase, standard and alternate, d odd >=3

Here q=(d,1), U=(d,1), V=(1-d,d+1). The centered period cell has x in [3/2-d,d+1/2], y in [-1/2,d+3/2], x+y in [0,d+3]. The two extreme sum vertices are half integral, so physical sites have 2-d<=x<=d, 0<=y<=d+1 and 1<=x+y<=d+2. These are inside the genuine literal standard staircase.

Its restored literal reciprocal alternate has body
  4-2d<=x<=d, 0<=y<=d, 2-d<=x+y<=d+2,
and actual top rail y=d+1 with 4-d<=x<=3 (also its bottom rail and stated additions). The preceding cell points with y<=d lie in this body. For y=d+1, write x,y from B+uU+vV, u,v in [0,1]. Then u+(d+1)v=d+3/2, giving 1/2<=u<=1 and exact x range
  3/2-d/2 <= x <= 3/2+(d-1)/(2(d+1))<2.
For d>=5 the integral points therefore have 4-d<=x<=1 and the real top rail supplies all. For d=3 the only possible off-rail point is (0,4); subtract the genuine V=(-2,4) to obtain (2,0), an actual body site. Thus the literal reciprocal even ALT covers every class, including the root.

## Reciprocal odd doubled ladder, standard and alternate, b even >=4

Here p=(b,1), U=(2b,2), V=(1-b,b+1). The centered period cell has x in [3/2-b,2b+1/2], y in [-1/2,b+5/2], and sum in [0,2b+4]. Opposite sum extrema are again half-integral. Physical sites satisfy
  2-b<=x<=2b, 0<=y<=b+2, 1<=x+y<=2b+3.
The genuine literal standard doubled ladder contains this body except its two deleted edge strips y=0,x>=b and y=b+2,x<=2. There are no cell sites in the first deleted strip because y=0 implies u<=1/4 and x<=1/2+b/2<b. By exact centered-cell symmetry with sum vector U+V+2B=(b+2,b+2), no cell site is in the other deleted strip either. Thus the true standard covers.

For the literal reciprocal odd ALT use the authenticated consumed frame RAW+(1,1). Its actual body is
  2-b<=x<=2b-1, 0<=y<=b+3, 1<=x+y<=2b+3,
with deletions y<=1,x>=b+1 and y>=b+2,x<=0, plus the genuine (0,0),(b+1,b+3). All cell points need only the following repairs.

* If x=2b, then u>=1-1/(4b) and v<=1/(2(b-1)) from the x coordinate, because its deficit from the right vertex x=2b+1/2 is 1/2. Thus 1<y<=3/2+(b+1)/(2(b-1))<3, so y=2. Subtract U to reach the actual origin addition.
* If y<=1,x>=b+1, then y=1 because y=0 implies x<b. Moreover u<=3/4, so x<=3b/2 by integrality. Add V to get y'=b+2 and 2<=x'=x+1-b<=b/2+1. This lies in the actual undeleted body: x'>0 avoids the upper deletion and x'+y'<=3b/2+3<=2b+3.
* If y>=b+2,x<=0, then y=b+2. Subtract V to obtain y'=1 and 1<=x'=x+b-1<=b-1. This lies in the actual undeleted body, below the bottom deleted x range.

No other cell point leaves the genuine alternate body. Each repair uses a true period and a named native site, so the reciprocal odd ALT covers its actual quotient.

## Remaining near-one literals and the root odd type

The already verified actual integral quarter-turn of the literal entire masks exchanges the reciprocal even staircase with the near-one odd staircase (including root odd (2,1)), and the reciprocal odd doubled ladder with the near-one even doubled ladder. This includes the corresponding two alternate masks with their actual restored gauges, rails, deleted strips and added corners, not just their official H/R2 enclosures. See the literal standard/ALT matching in the pure first-switch source dossier §§1–2 and the bare first-1 seed check in F_LATTICE_RECIPROCAL_EXACT_AFTER_FIRST_DIGIT_ONE_3RUN_COVER_20261120.md. In both types the quarter-turn sends U to the reciprocal V and V to minus the reciprocal U, so actual quotient cover transfers, regardless of translated gauges.

The two improper temporarily retained endpoint atoms likewise cover their own native quotient if needed: (1,0) has U=(2,0), V=(-1,1), index 2, and the six-site rectangle contains (0,0),(1,0) in its two distinct classes; (1,1) has U=(1,1), V=(0,2), index 2, and the four-site square contains the same two representatives. This proves the literal base but does not identify the two endpoint atoms as equal supports or replace either in a live helper.
