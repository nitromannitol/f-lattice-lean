# Proper saved1 W1 SHORT: ordinary W0 old ALT closure on both odd sectors and through slope one half on even sites

20 November 2026. Hand proof under the earlier actual source cover, enclosure and frame premises; no mathematical program or solver.

Let the saved W1 corrected even standard have proper saved-last-1, old odd/even p,q with det(p,q)=-1 and old q alternate D coming from an ORDINARY birth in phase W0. The earlier source from the seventh old operand must have its own authentic proper-creator R2 or an independently verified analogous bound. Write u=q-p and b=2p-q, so q=2u+b with det(u,b)=+1 and genuine strict proper earlier standards of these types. Set α=K/T=s_q(p)/T>1/2, θ=1-α, γ=2α-1, G=γT=s_q(b), H=θT=s_q(u), J=s_u(b). With e=q, f=V_q, v=-2p, B=(1/2,-1/2), a fixed residual address a satisfies a-v-B=xe+yf with x=1+δ and
  0<δ≤γ+(n+2+E)/T,   M_t<y≤1-M_t.
Use the central one-candidate proof and nonempty-row extension; the old alternate only needs to supply some one of a and a+e here, since old enclosure excludes every other horizontal source site on this literal row. The full old reflection sends a+e to z=R-a-e at z-B=-δ e+(1-y)f. We prove payment of every fixed residual on either physical-odd parity sector and on physical-even sites with n≤d/2. If true P+v or the true upper/lower Q rays already pay a, nothing else is needed. Otherwise we exclude z from all old D operands, hence exclude a+e and force a in the actual D head.

For a standard g let m_g denote its actual centered s margin (n_g on even physical sites or |d_g-2n_g| on odd) and M_g its centered upper transverse inner-hull margin. In the current sectors I and H agree on this physical parity: M_g=(d_g-n_g)/2 on odd, or |d_g-3n_g|/2 on even with n_g≤d_g/2. The selected strict unimodular pairs use the same appropriate linear piece of M. Indeed p,u,b,q are positive combinations of adjacent u,b, which cannot strictly straddle 1/2 or 1/3 by the Farey denominator lower bound d_u+d_b≥5. A boundary parent can use either incident formula. Denote by F its common linear functional with M_g=F(g). Then |F(f)|≤2d+n, including F(f)=-d in the physical-odd case. Coordinates p=αe+f/T, u=θe-f/T, b=γe+2f/T imply
  |α m_b-γ m_p|≤(3d+n)/T,    |α m_u-θ m_p|≤(3d+n)/T,
  |m_b-γ m_q|≤2(3d+n)/T,     |m_u-θ m_q|≤(3d+n)/T.
For example in odd parity use |d_z-2n_z| and the triangle inequality applied directly to αb-γp=f/T (or αu-θp=-f/T); in even parity use the n-coordinate with |L|≤3d+n. Here q=(d,n), L=d+n and T=d²+2dn-n². We have G≥4d+2n, H≥3d+n, Gs_u relations J=Gθ+4/T=Hγ+4/T, G-T_b=2J and H-2T_u=J.

The authentic P+v cell has s_p=Kx-2y and t_p=x-Ky. For candidates x≥1 and y≤1, s_p>0; since the lower Q ray has paid y≤M_t and y is on the true mesh, Ty≥2, so t_p≤u_bound-2α<1 (u_bound=2α+(n+2+E)/T). The half-integral t grade is ≤1/2≤M_p. Thus P failure means that either
  longitudinal failure: c=K(δ-γ)+4/T-2y≥m_p+2,
  transverse failure: K(y-α)≥M_p+x-2/T+1.
The first uses fixed physical-parity s mesh two and K²=T T_p+2; the second uses t_p and -T_p-M_p on the same half-integer grade mesh with step one. In the absence of transverse failure we have K(y-α)≤M_p+x-2/T. If longitudinal failure occurs then δ>γ by y≥2/T. If transverse failure occurs then y>α, so the upper Q column supplies a unless Tδ>m_q+2. Its lower x cutoff is already below 1. Hence for every remaining point either δ>γ, or Tδ>m_q+2 and y>α. In particular θTδ+2y>m_u: in the first case use Hγ=J-4/T>m_u; in the second use H≥3d+n and θ(m_q+2)>m_u via the margin bound.

## The b standards and the complementary slot

The actual W0 b origins in natural slots 0,1,2,3 are 0,V_u-b,2u+V_u,2u+2V_u-b. Slots 2 and 1 differ by e; slots 0 and 3 are exchanged under actual R minus position. Use the genuine even-ALT table and the standard H enclosure, cited in the companion saved-last-3 actual-cell note.

At z the slot 0 b-grade is s0=-Gδ-4(1-y). This is below -m_b either because δ>γ (Gγ=T_b+8/T), or because Tδ>m_q+2 and 2G>2(3d+n). Slot 2 subtracts 2J-2 from that grade because s_b(V_u)=-2. For slot 3 test a+e at slot 0 by reflection. Its grades are s=G(1-γ+δ)-4(y-2/T), t=2+2δ-Gy. For y≥α, t<-T_b-M_b follows from Gα-T_b=J+4/T, δ<2, and J≥3d_b+n_b>M_b+6 (d_b≥3,n_b≥1). For y<α transverse failure is impossible, so δ>γ and s>G-4α>T_b+m_b (2J-4α>m_b).

At slot 1 z has
  s1=T_b+2γ-Gδ+4(y-α),    t1=G(y-α)+4/T-2δ.
If the transverse P test fails, use M_b=γ M_q+2F(f)/T and M_p=α M_q+F(f)/T to calculate
  K(t1-M_b)≥2G-Tδ+2-F(f)≥G-n-E-F(f)>0.
The last strict inequality holds: G≥4d+2n, E≤d-n, and F(f)≤2d+n. Thus the b upper H facet fails. If the transverse test passes, P must instead fail longitudinally. There is an exact identity
  αs1+γc=2(y-α)-4/T.
Here 2T(y-α)≤2(M_p+x-2/T)/α≤L+8: use M_p≤(d_p+n_p)/2, d_p+n_p=αL+2n/T, and x≤2α+(n+2+E)/T<2α+1-α. Since α>1/2, 2x/α<6 and 2n/(Tα)<2. Consequently
  2T(y-α)-4 < 2G-(3d+n)
from G≥4d+2n and d≥7. With c≥m_p+2 and αm_b-γm_p≤(3d+n)/T this implies s1<-m_b, as required.

## The two u standards and the seventh prior u alternate

At u slot 4 (origin b), z has s=-Hδ+2(1-y)-J<-m_u. The reflected slot 5 is tested at slot 4 on a+e. There t=1-δ-Hy, s=2T_u+H(δ-γ)+2y-4/T. If y≥α, the lower H facet fails since Hα-T_u=J-2/T and J≥4d_u+2n_u>M_u+2. If y<α, longitudinal P failure applies and
  α(s-2T_u)-θc=2y-4/T≥0.
Since 2θ>(3d+n)/T and αm_u-θm_p≤(3d+n)/T, this gives s>2T_u+m_u.

The ordinary old even ALT has one earlier uALT: actual W0 origin V_u+2u-b for its birth last1, or V_b for last2. Their s_u grades are 2T_u-J and 2, respectively. The true underlying proper odd R2 has horizontal base β0=2-2T_u+J and 0 respectively: for last1 the earlier phase was W1 with old mixed-plus-even norm 2T_u-J; for last2 it was W0. This is the authentic own-R2 and origin table in the 'Ordinary alternate seventh source: own-creation-R2 upper enclosure by hand' dossier, §§1 and 3, and 'Actual ordinary alternate: seventh donor and true creator binding', both in the 19 November recovery audit. In both cases the sum of the origin grade and the correct base is exactly 2, not 2-2T_u. Thus at z the centered base-removed grade equals -Hδ+2(1-y)-2=-Hδ-2y<-m_u, below the old source's longitudinal R2 lower for odd physical parity. On even physical parity that R2 lower after centering is -n_u=-m_u as well. No current or earlier R2 is filled artificially.

All old operands are excluded at z in the claimed ordinary strict case. Together with the genuine old row cover this pays the fixed candidate. Only the even sites at q slope n/d>1/2 remain outside this argument about ordinary births: on that parity a native standard may lack an optional t-boundary site and its upper H margin can exceed its occupied I margin. Nor is the argument above a proof for actual corrected W0 LONG replacement slots, firstmixed literal seventh sources without a separately checked bound, finite short suffixes, or absolute all-word coverage.
