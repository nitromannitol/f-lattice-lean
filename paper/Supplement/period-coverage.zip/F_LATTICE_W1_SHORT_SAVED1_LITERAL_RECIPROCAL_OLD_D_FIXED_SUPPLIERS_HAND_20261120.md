# Literal reciprocal old alternate: payment of the W1 SHORT fixed positive middle

20 November 2026. Hand proof. This is a direct analysis of the raw literal donor, not an application of generic old-ALT R2. Use the fixed W1 SHORT stationary supplier coordinates for the old pair p=(d-1,1), q=(d,1), d odd >=3. For d>=5 this is the actual old pair for a first digit 1 after a positive pure3 prefix; d=3 is the literal empty-prefix root pair. Assume the authentic stationary supplier placements and genuine earlier standard covers. The fixed middle payment proved below includes the root arithmetic if the same placements/region reductions are available. No root-specific moving, wrapped, or short-suffix result is asserted by this note alone.

Put e=q, f=V_q=(1-d,d+1), B=(1/2,-1/2), v=-2p, T=d^2+2d-1, alpha=s_q(p)/T=1-(d+1)/T, beta=2/T, gamma=2alpha-1. In the fixed chart a-v-B=xe+yf, the positive middle after the standard ray/column reductions is x>1, M_t<y<=1-M_t, with M_t=(d-1)/(2T) on physical-odd sites or (d-3)/(2T) on physical-even sites. Centered y is at least beta on the occupied parity mesh in this residual range. The unshifted old literal D head and its nonnegative e translates, and the unchanged P+v, are actual stationary suppliers. The upper Q column in this chart pays y>=alpha-M_t and 1<x<=1+(m_q+2)/T, with m_q=d-2 on odd physical sites and m_q=1 on even physical sites. Only these already identified stationary placements are used.

The genuinely consumed reciprocal D mask is raw, including its A4 shift cancellation. It has body
  4-2d<=X<=d,  0<=Y<=d,  2-d<=X+Y<=d+2,
plus bottom and top rails (Y=-1 and d+1, respectively) and two explicit corners. This includes d=3 in the independently audited first-mixed staircase dossier. In particular the whole true mask satisfies s_q(X,Y)<=T+d+3, including its top-right rail. One must not substitute the formal old-ALT R2 longitudinal upper bound for this literal bound.

## Exact literal row coverage and large x

For every integer Y=0,...,d the body's X interval is [max(4-2d,2-d-Y), min(d,d+2-Y)]. Its projections onto t_q=X-dY have no gaps: the upper endpoint of the interval for Y+1 is at least the lower endpoint for Y, since upper_X(Y+1)>=2 and lower_X(Y)<=2-d. The two overall extremes give the entire integer interval [3-T,d]. In particular this includes both physical parity subsets of the usual central interval [L-k-T+2,k], where L=d+1, k=d on odd sites, and k<=d on even sites with k<=L-1. It also includes all rows of the fixed residual above: t_q(a)=L/2+2-Ty, and M_t<=y<=1-M_t gives the inclusion (the smaller physical-even margin still gives the lower bound 3-T).

At x>=2 the actual literal s_q cap cannot contain a+e or any later lift, because s_q(a+e)=1+T(x+1-2alpha)>=T+2(d+1)+1>T+d+3. Every integral point on that t row is a+j e, since q is primitive. The literal row nonemptiness therefore supplies a previous lift a-i e with i>=0, and the stationary D+Z_{>=0}e arm pays the site. This does not claim that the row point lies in the generic R2 of D.

## The remaining 1<x<2

Put delta=x-1 and r=T*delta, an odd integer; hence 0<delta<1. The candidate itself has coordinates
  X=5/2-d+d*delta-(d-1)*y,
  Y=-3/2+delta+(d+1)*y,
  X+Y=1-d+(d+1)*delta+2y,
  X-(4-2d)=d*delta+(d-1)*(1-y)-1/2.

* If x<=2alpha and y<=alpha, the real P+v pays. Its centered grades are s_p=Kx-2y and t_p=x-Ky, K=alpha*T. With x>1 and beta<=y<=alpha, 0<=s_p<=2T_p and -T_p<=t_p<=0, using K^2-T*T_p=2. This is in its actual occupied inner hull, on both parities.
* If x>2alpha then delta>gamma and in fact delta>=1/2. This is immediate for d>=5; for d=3 it uses T=14, T*gamma=6 and the odd mesh r>6. As y>=beta>0 and y<=1, the displayed formulas give Y>-1 and Y<d+1/2, hence 0<=Y<=d. The lower X bound follows from d*delta+(d-1)*(1-y)-1/2>0; the upper follows from X<5/2<=d. Finally X+Y>=1-d+(d+1)/2>2-d and X+Y<4<=d+2. Thus the actual literal D body pays the address.
* If y>alpha and the actual upper Q column does not already pay, r>=m_q+4 by parity. This gives X-(4-2d)>0: multiply it by T and substitute 1-y>=M_t and r>=d+2 on physical-odd sites, or r>=5 on physical-even sites. The resulting lower bounds are respectively d^2+1 and 2d+2. Also Y> -3/2+(d+1)/2>=1/2, Y<d+1/2 and integral, and X<=d as before. Since y>1/2, X+Y>2-d; the upper sum bound still follows from delta<1 and y<=1. Hence the same literal D body pays.

Together these checks prove the positive fixed middle test under the stated actual supplier bindings. Their whole-child reflection version uses the separately established child symmetry, not a fake pure-mask hull. The row interval [3-T,d] and literal s cap can also replace generic R2 where the moving proof only needs a nonempty literal row and an upper longitudinal bound. A separate source-frame audit should record exactly which moving/wrapped steps have that form before claiming full eventual coverage at the root.
