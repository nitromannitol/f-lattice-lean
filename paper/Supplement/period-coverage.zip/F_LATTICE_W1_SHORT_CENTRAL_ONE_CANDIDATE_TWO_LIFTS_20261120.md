# Fixed central W1 SHORT intersection: at most one candidate per unique old transverse row, and its exact alternate-site test

20 November 2026. Separate continuation from the paid wrapped result. Hand proof using genuine native placements and own-creation R2, no enumeration or mathematical code. This note does not prove full fixed-central or all-word quotient coverage.

## Sources and setup

Use the authenticated placements and the exact test (3),(6) of the root-reviewed Dropbox file `F_LATTICE_W1_TWO_RUN_SHORT_STATIC_SEAM_AND_PAID_OUTER_ROWS_20261120.md` (id:7FnwDTaoNtQAAAAAACa2Gg) and independent replay (id:7FnwDTaoNtQAAAAAACa2GQ). For the literal old ALT R2 in W1 saved-last-3 or -1, use §1 of the old-QALT G3 endpoint proof and §2 of the all-word native upper support assembly. For the occupied inner hulls and their actual parity grades use STANDARD_NATIVE_COVER_CORE_AND_INNER_HULL_EQUIVALENCE.md and its cited hull/core theorem.

The genuine positive proper saved pair p,q has det(p,q)=-1, e=q, f=V_q, v=-2p, w=V_p. The old actual standard masks P,Q cover their own decks and the old actual alternate D covers its own deck in the frame of its true creator. Put q=(d,n), T=d²+2dn-n², K=s_q(p), alpha=K/T, beta=2/T, B=(1/2,-1/2). Here d,n are odd and n>=3 for the strict proper-creator situations. Both p and q-p are proper positive vectors. In saved3 p is the earlier a with q=2a+R and in saved1 p=q-a; thus 0<alpha<1/2 in saved3 and 1/2<alpha<1 in saved1. In both phases K>=d+n, T-K>=d+n, and alpha>beta. Both parities are handled separately. M_s=(n-l_q)/T>=1/T and M_t=((d+n)/2-k_q)/T>=0 are the actual centered inward-hull expansion margins. Physical-parity preservation holds for v,w,e,f.

For a fixed integral address a relative to the seam origin H, write a-v-B=x e+y f (this is the CENTRAL chart, different from the wrapped one). Then Tx is odd since s_q(a-v) is even and s_q(B)=n is odd. In particular x is not an integer, and positive x is at least 1/T. Also T y and T M_t have the same parity: t_q(a-v) is congruent to the physical parity, and so is the integer endpoint k_q. On each fixed transverse grade t=t_q(a), the physical addresses differ by integral multiples of e since q is primitive; thus their x coordinates are spaced exactly one unit apart. This is the old row mesh only, not a child deck period. The actual complete child reflection takes (x,y) to (-x,1-y), so questions on the negative side can be transferred to actual positive addresses without claiming reflection of D.

## 1. The near central column range is paid in every transverse row

Every fixed address with 0<x<=b, b=min(1,2alpha), is eventually represented by genuine STANDARD sources in the exact fixed test. Indeed the authentic Q+v+Z_{>=0}e-Z_{>=1}f subset in (6) pays y<=M_t at x>0 by independent reductions into the occupied rectangular Q hull. The positive G1 column Q+v+w+Z_{>=0}f pays y>=alpha-M_t when beta-M_s<=x<=1+beta+M_s. This contains all 0<x<=1 on the physical mesh because Tx>=1 and TM_s>=1. The only interval left can have M_t<y<alpha-M_t; here y>=M_t+beta>=beta on the physical mesh and y<=alpha.

For 0<x<=2alpha and beta<=y<=alpha, use the true G2 P placement at v. The centered p-grades of a-v-B are
     
     s_p = Kx-2y,             t_p=x-Ky.
     
The first is an integer because s_p(B)=n_p. Its lower bound is K/T-2alpha=-alpha>-1 and its upper bound is 2Kalpha-2beta=2T_p by K²-T T_p=2. Thus 0<=s_p<=2T_p. The second is on the half-integer mesh since p has odd type and t_p(B)=(d_p+n_p)/2. It is at most 2alpha-K beta=0, and at least 1/T-K alpha=-T_p-1/T>-T_p-1/2, hence t_p>=-T_p. This is the true occupied P period cell inside its parity inner hull. The claimed all-y column range follows.

## 2. All except a single positive site on a unique R2 vertical row

By “unique” here one means that t is in the old physical-parity R2 interval [a_q+2-T,L-a_q], L=d+n, and t is its ONLY representative in that interval modulo T. Equivalently on the parity mesh, L-a_q-T+2<=t<=a_q. This definition concerns only the vertical lift, not an actual complete row or any filled R2. Cover of the old D deck supplies a site in D equivalent to ANY given row-t address. Uniqueness means that site has the same t and lies at a+he for an integer h.

The genuine W1 R2 s interval [lo,hi] on this parity is:
     
     saved3: [-E, 2T-2K+2n+E],
     saved1: [T-2K-2-E, T+2n+2+E].
     
Here 0<=E<=d-n; the applicable birth side, parity and sector determine E. Note hi<2T and hi-lo<2T. For saved3 these hold from K>n+E (since n+E<=d and K>=d+n), hence also 2K>2n+E. For saved1, 2n+2+E<=d+n+2<T by the strict proper record inequalities, and n+2+E<=d+2<d+n<=T-K. These strict inequalities are why no unlicensed interior of D is being used.

Write u=(hi-T-n+2K)/T; explicitly u=1+(n+E)/T in saved3 and u=2alpha+(n+2+E)/T in saved1. If x>u then s_q(a)=n-2K+Tx>hi-T: every old alternate representative in the unique row must already be at or to the left of a, since s_q(a+e)>hi. Thus the exact real D head, D+Z_{>=0}e, pays a. On the other side 0<x<=b, §1 pays a by standards alone. Consequently all possible positive-x failures on this unique row lie in (b,u]. The interval length is <1: for saved3 b=2alpha and n+E<2K, and for saved1 b=1 and n+2+E<2(T-K). A fixed row has x spacing exactly one, so AT MOST ONE physical candidate remains.

Moreover on this entire candidate interval, the old D test reduces literally to a in D, with a+e the one possible adverse alternative. Indeed s_q(a-e)<=hi-2T<lo, so no old D site strictly left of a could supply its positive head. And x>b>u-1 implies s_q(a+2e)>hi, so the only row lifts in D can be a and a+e; at least one occurs by old D cover and transverse uniqueness. The opposite D arm, D+v+Z_{<=-2}e, never pays ANY positive x: it would need an old D site with s at least s_q(a-v)+2T=n+Tx+2T>hi. This exclusion does not assume any actual D reflection and does not require the t-2 row to be unique. Thus, unless the other genuine standard families of (3),(6) pay the residual point, its exact condition is presence of the LEFT of the two genuine old sites a,a+e. Own R2 and old quotient cover allow both or just the right representative; they do not by themselves force the left choice. Either actual standard payment or an independent left-choice property of the native old ALT would be needed to resolve this last site. This identifies an obstruction to a purely geometric deduction from cover and enclosure, not a counterexample for actual donors.

## 3. Scope of this reduction

At positive x, the static Q ray used above pays EVERY y<=M_t, not just the near-x patch. Also the independently checked fixed outer-strip result pays every fixed y>1-M_t. Thus only M_t<y<=1-M_t need remain; since t=L/2+2-Ty, on the physical parity mesh they have L-k_q-T+2<=t<=k_q. When k_q=a_q, every such row is vertically unique in D's authentic R2 and therefore has at most the single literal test just proved. That equality holds at either parity below slope 1/2 and at odd physical parity above it. The bound t is symmetric only after correctly transforming t with the whole child reflection; no old D site is reflected on its own. High-slope even rows need not be vertically unique in own R2. Existing moving-row coverage for them does not give missing fixed lateral sites. The one-candidate result on such rows is asserted only where the vertical-uniqueness condition itself actually holds. The actual standard sources in the exact fixed test were not all exhausted merely by deriving this bound, and no failure is asserted. No conclusion is drawn for short suffixes as a whole, another run/phase, or any new recurrence statement.

## Independent replay

The true P cell grade identities and integer rounding, the strict
old R2 lateral width and cutoff inequalities in both birth records,
physical parity, and the exact eligibility of just a and a+e in the
remaining row were separately rederived. No standard payment or
left-lift property is inferred for the last candidate.
