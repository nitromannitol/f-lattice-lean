# W1 SHORT: fixed-history eventual native cover promotes to EVERY j≥2

20 November 2026. Analytic finite-witness truncation with no parameter search, numerical test or solver. This is a uniform threshold independent of sizes or slopes for W1 saved-last-1/3 cases in the exact stationary/ordinary-growing layout below. It is conditional on the existing per-history eventual-cover theorem (or simply on its stationary test succeeding for every fixed integral address), covered genuine standards and authentic frames. The main proof treats j>=2 and the addendum treats j=1 for saved-last-3. Positive pure2 prefixes followed by 1 are covered at all lengths by the earlier matched near-one theorem. No claim is made for other layouts. Here j is the source-layout parameter S=p+jq, C=2j+1 (j=k+1 when k is the helper's raw suffix count).

## Period coordinates and accepted source inputs

Use q=(d,n) proper even type, p proper odd type, det(p,q)=-1, e=q, f=V_q, B=(1/2,-1/2), T=T_q, K=s_q(p), α=K/T, β=2/T, L=d+n, w=V_p, v=-2p. Assume 0<β<α<1 and T-K=s_q(q-p)≥L, as for the strict saved births and the literal reciprocal/near-one saved pairs for which q-p has denominator coordinate ≥1 and numerator coordinate ≥0. We have d≥3, T≥d²+2d-1≥14 and
  (2+d)/T < 1/2.
Central coordinates are a-v-B=xe+yf, where H+a is the physical target position and H=2p+V_S. In (e,f), p=(α,1/T), w=(β,α), v=(-2α,-β). The actual child periods have columns U=(Θ,β), V=(2β,Θ), with Θ=2j+1+2α. Child reflection modulo the horizontal period is (x,y)↦(-x,1-y).

For any source point q0∈Q denote q0-B=Q_x e+Q_y f. Its actual standard H enclosure gives
  -m_s/T≤Q_x≤1+m_s/T,      -M/T≤Q_y≤1+M/T,
where m_s≤d and 0≤M≤L/2 is the **outer** transverse H expansion on this parity (not the potentially smaller covered I). In particular α+M/T<1. For p0∈P, write p0-B=t p+u w. Its outer H bounds give |t|<3 and u>-1/2, t>-1: m_s(p)<T_p and M^H(p)≤L_p/2<T_p/2. Its normalized q transverse coordinate P_y=t/T+αu is therefore >-1.

For D sites d0 let d0-B=D_xe+D_yf. Only the following elementary horizontal support bounds are needed:
  D_x+2α≥0,    D_x<2.                                               (1)
For strict saved3 use the authentic s interval [-E,2T-2K+2n+E] and n+E≤d< K. For strict saved1 use [T-2K-2-E,T+2n+2+E] and n+2+E≤d+2<T. Subtract s_q(B)=n and divide by T. For literal reciprocal D with q=(d,1) and p=(d-1,1), its raw A4-restored staircase has s≥-K: on the body use x+y≥2-d, Y≤d in s=(d+1)(x+y)-2Y, and on the bottom rail use X≥1-d,Y=-1; top rail and added points also exceed this bound. Its s≤T+d+3 from the complete rails/body proof. K>1 and (T+d+3-1)/T<2 even at root d=3. For the other pure (near-one) even q=(d,d-2), d≥5, the consumed mask in §2 of the first-mixed literal ladder-donor dossier (19 November recovery audit) has -2≤X≤d, 0≤Y≤3d-6. The negative-x body rows have Y≥d-2 by the deleted left strip; the added left point also does. Thus s=(2d-2)X+2Y≥-2d there, and s≥0 at X≥0. We obtain D_x+2α≥(-2d-n+2K)/T>0 from K≥L, while s≤(2d-2)d+2(3d-6)<2T with T=2d²-4. These checks use only the true covered/layout histories already treated, not generic R2 at literal initiations.

## Only a horizontal strip remains at each finite length j≥2

Center the actual period parallelogram at the origin of the (x,y) chart and subtract integral deck periods. On the resulting representative,
  |x|≤Θ/2+β=j+1/2+α+β,    |y|≤Θ/2+β/2.
The previously established **finite** almost-whole-period wrapped slab for every j≥1 is
  |x-β|≤2j,    1+α≤y≤2j+1+α.
This is exactly its normalized test |x_wrap|≤2j, |y_wrap-1|≤j after subtracting jf+w. Adding the genuine V to the address gives the companion covered slab |x+β|≤2j, -2j-α≤y≤-α. Source: F_LATTICE_W1_SHORT_WRAPPED_CORNER_SHORT_PROOF_AND_AUDIT_20261120.md, final finite-box theorem, in the bounded-defect checkpoint. Throughout the centered parallelogram both horizontal width tests hold because 1/2+α+2β<2≤j. The y bounds lie inside the two extreme slab ends. Hence only
  -α<y<1+α,    |x|≤j+1/2+α+β                                    (2)
needs payment. Reflect if needed to x≥0; (2) is preserved, even if the new representative is no longer in the centered coefficient parallelogram.

## Uniform truncation of the stationary supplier test

For this particular physical a (however it was obtained), hold its integer value fixed and consider the SAME saved history at arbitrary later j'. The exact native stationary limit (3),(6) of F_LATTICE_W1_TWO_RUN_SHORT_STATIC_SEAM_AND_PAID_OUTER_ROWS_20261120.md (id:7FnwDTaoNtQAAAAAACa2Gg) implies a has at least one witness in its listed infinite sets. Indeed by the fixed-history eventual full cover it is covered for all sufficiently large j' and the stated characterization is necessary. This inference does not depend on the convergence rate of a geometric growing-cell facet and does not reinterpret a as independently moving during that auxiliary limit. We now exhibit the very same type of witness in the actual length j computed in (2), never replacing a native mask by a containing rectangle.

1. The two isolated P offsets in (3) are genuine for every j≥1. A stationary Q column with k≥0 has either y=Q_y+α+k or y=Q_y-α-k. From (2) and the Q bounds, k<1+M/T<2 in either case. Thus k≤1≤j and the authentic finite column retains its site.

2. In the D head x=D_x+2α+i for i≥0. By (1), i≤x<j+2, so i≤j+1≤2j-1=C-2 at j≥2. Hence the true finite G3 head at index i supplies the address. The opposite D tail cannot be its witness at x≥0, since it has x=D_x-k, k≥2, contrary to (1).

3. The first extra stationary set in (6) is the true far growing support E_infty+v+e+f, with E_infty unrolled at the ordinary W1 source layout. Its P-chain term P+t(2e+f) must have y=P_y+1+t, so t<α-P_y<2 and t≤1≤j. For its first Q triangle Q-v+(2h+d')e+b'f (0≤b'≤h, d'=0 or 1), x=Q_x+2α+2h+d'+1. If h≥j, then
  x≥2j+1+2α-m_s/T>j+1/2+α+β,
by (2+d)/T<1/2. This contradicts (2), so h<j, as required in the actual triangle. In the second Q triangle Q+w+(2b'+d')e+hf, y=Q_y+α+h+1; the upper strip bound implies h<-Q_y≤M/T<1 and hence h=0. Both witness indices thus survive truncation. These arguments use |x| only, and so also prove realization of this entire stationary set at the reflected test location (-x,1-y).

4. The other extra set in (6) is Q+v+n'e-kf, n'≥0,k≥1. Here y=Q_y-k and (2) yields
  k≤1+M/T-y<1+M/T+α<2.
Thus k=1, not just O(1). Moreover n'=x-Q_x≤j+1/2+α+(2+m_s)/T<j+2, so n'≤j+1. Choose h=j-1 and b'=floor(n'/2), d'=n'-2b'. The actual near second triangle supplies precisely Q+v+(2b'+d')e+(h-j)f; feasibility is just 0≤b'≤h<j. It holds since floor((j+1)/2)≤j-1 for EVERY j≥2. These bounds also apply when (x,y) is replaced by (-x,1-y), so the reflected extra set is realized by the genuine child reflection at finite j.

These are all source types in (3),(6) including the two reflected extra sets. At least one witness exists, and each possible type survives at the particular j under consideration. The two finite wrapped slabs cover every other class. This proves the uniform improvement from eventual W1 SHORT cover to cover for every j≥2. It uses no maximal-constant theorem across varying records, no nonsummable approximation error, and no estimate of how large a later probing suffix j' was needed in the fixed-history theorem. At j=1 the inequality floor((j+1)/2)≤j-1 fails; also the wrapped strips need not cover all horizontal parallelogram representatives, so that length is not concluded here.

## Addendum: j=1 also works for saved-last-3

Here the actual old q=2p+b with effective earlier proper even b. This b is the genuine proper earlier selected standard for the old q birth, even when the old alternate later substitutes LONG pieces for two placements. Its strict even type gives d_b>=3,n_b>=1. Let G=s_q(b)=T-2K. Then G>=4d+2n and alpha=1/2-G/(2T). Since G>=8, one has alpha<=1/2-2beta. Therefore at j=1 the centered fundamental x bound 3/2+alpha+beta is at most 2-beta. Both finite wrapped width tests from §2 hold at this length also. Their y ranges still include the whole extreme parts of the fundamental parallelogram: the fundamental y radius 3/2+alpha+beta/2 is below 2+alpha, and the upper slab extends to 3+alpha. So only the same central band needs a proof.

The same stationary-witness truncation works with the following two sharpened index checks. The G3 head index i is at most x<2 by (1), so i<=1, exactly the existing finite range. The opposite tail is excluded after reflecting once to x>=0. In Q+v+n'e-f (and its reflected test), use the improved bound
  n' <= 3/2+alpha+beta + m_s/T
      = 2+(2+m_s-G/2)/T <2,
because m_s<=d and G/2>=2d+n>d+2. Thus n'<=1 and the actual near triangle uses h=0,b'=0,d'=n'. All other terms already satisfied their exact finite bounds at j=1 in the preceding proof: both Q columns have k<=1, the far P chain has t<=1, and the two far Q triangles have h<j or h=0, respectively, regardless of the x sign. This exhausts the exact test, so saved-last-3 has no short-length exception at all.
