# W1 SHORT moving horizontal seams: exact row tests and unconditional wrapped-strip payment

20 November 2026. Hand proof for the fixed proper W1 two-run SHORT
saved record, in the exact live frames. This concerns native
quotient cover, not the already established recurrence theorem.
The vertical seam strips and the bounded intersections are not
settled by this note.

Use the notation of the independently checked W1 SHORT fixed seam
proof: det(p,q)=−1, e=q, f=V_q, v=−2p, w=V_p,
S=p+jq, X=2S+q, C=2j+1 and seam origin H=2p+V_S.
The true child columns are U_X=−v+Ce, V_X=2w+Cf.
D,Q,P are the actual restored old alternate and two standards
in their prescribed frames, respectively. Both ordinary growing
copies with their actual unrolled sources are used below.

## 1. Two moving tests

Take a fixed bounded set of integral a0 representatives for rows
modulo the period e; specify physical parity separately. There is
a constant K depending only on that set and the saved record such
that for all K<=i<=2j−K and sufficiently large j, the exact
coverage tests in the two horizontal strips are as follows.

* At a=a0+i e, the central test is

    a0 in (D+Z e) union (Q+Z e+Z_{>=1} f)
                    union (Q+v+Z e+Z_{<=−1} f).               (C)

* At a=j f+a0+i e, the wrapped-strip test is

    a0 in (Q+v+w+Z e+Z_{<=0} f)
                    union (Q+w+Z e+Z_{>=1} f).               (W)

Writing a supplier as a ray here is a characterization of bounded
row data at the moving addresses; no extra donor is inserted.

**Proof.** In (e,f) coordinates the exact recentered union lies
in [-O(1),2j+O(1)] times [-j−O(1),j+O(1)], by the exact source
list. A target period lift into this box has both coefficients
bounded independently of j: the two-column period matrix divided
by 2j tends to the identity. For the stated middle range in i,
taking K beyond the finite cross-axis errors excludes any
horizontal deck subtraction. The central strip requires zero
vertical shift. At the wrapped upper strip the possible shifts
are zero and +V_X on the source, corresponding to the far and
near growing copies.

The genuine G3 interval D+[0,C−2]e pays exactly the central rows
met by D once i is away from both ends, and cannot meet the
wrapped middle strip. Recenter G1/G2 modulo the true columns as in
the source proof: the two P placements and the two Q columns
have bounded e coordinates, and so pay neither middle. The
growing P-chain has linked horizontal and vertical indices:
keeping its vertical coordinate bounded or at a bounded distance
from a strip endpoint forces its horizontal coordinate within a
fixed distance of one end. Thus it too pays no middle addresses.

It remains to substitute the two true Q triangles of E_j at the
near and far growing offsets v−w−j f and v+e+f. The triangles
before placement are Q−v+(2h+d)e+b f and Q+w+(2b+d)e+h f
with 0<=b<=h<j and d=0,1. At central height the far first
triangle gives Q+(2h+d+1)e+(b+1)f; the near second gives
Q+v+(2b+d)e+(h−j)f. They yield precisely (C)'s two Q rays:
fixed height bounds b or j−h, and the other index ranges freely
across the middle with d=0,1 supplying both residues.
At the wrapped upper height, the far second triangle gives
Q+v+w+(2b+d+1)e+(h+1−j)f after subtraction of j f, and the
near first triangle lifted by +V_X gives
Q+w+(2h+d)e+(b+1)f after subtraction of j f. These are (W)'s
two rays, with the same free-index range. All omitted triangle
terms are height-ineligible. These are necessity and sufficiency
statements uniform on the bounded set of a0, not just individual
pointwise limits. The lower outer strip is identified by the
true vertical deck with the upper one, with a bounded change
in a0.

## 2. Wrapped payment from the stationary standard alone

Assume the actual stationary standard Q covers its own quotient,
so its occupied inner hull I is present in its genuine frame.
Let Z=q=(d,n), T=T_q, L=d+n, and B=(1/2,−1/2).
On the chosen physical parity, denote the symmetric t facet
parameter of I by k, so that its t range is [k−T,L−k], and
put m=L/2−k>=0. Its s width is at least T. For every admissible
t in that interval an integer site can be found in I at that t
by moving along e=q, which changes s by T and preserves parity.
Thus the row projection of Q contains the entire stated parity
mesh even when nothing is assumed about sites outside I.

Set y=det(e,a0−w−B)/T. The shifted Q+v lower ray in (W)
pays every admissible y<=1+(m−2)/T, while the Q upper ray pays
every admissible y>=1−m/T. Indeed det(e,v)=−2 and det(e,f)=T;
the I row interval runs from −m/T to 1+m/T before these shifts,
and shifting by integer multiples of f introduces no holes.
If m>=1 these two intervals overlap or touch. In the remaining
case m=0, k=L/2 has the physical parity of t_Q on this coset,
and T y=−t_Q(a0−w−B) is even. The only integer strictly
between T−2 and T is T−1, which is odd because q is even
type and T is even. Thus no admissible row is lost there either.
This proves complete moving wrapped-strip payment away from the
bounded vertical intersections. No old alternate cover is needed
for this conclusion.

## 3. Precise remaining central rows

With the same stationary I premise, the Q rays in (C) pay
every row except possibly those with

                  L−k−T+2 <= t_Q(a0) <= k

on the physical mesh. This is the exact complement of the two
rays obtained from I (not necessarily the complement for the
larger true Q). Indeed t_Q(v)=2 and t_Q(f)=−T, so negative f
shifts of Q+v pay t>=k+2 and positive f shifts of Q pay
t<=L−k−T. For each remaining row, a single actual D site with
the same t grade on that parity now pays the entire central
moving interval. The failed row condition, if established
against both true Q rays and D, would yield an interval of
actual missing classes, not just a failed sufficient test.

Here is a further sufficient but explicitly conditional
alignment shortcut. If k=a where a is the old even ALT raw
R2 facet parameter, and the actual restored D is enclosed on
this parity by t in [a+2−T,L−a] **in these same coordinates**,
then D covering its own quotient forces all these possible
central rows. Their t values are exactly the unique lifts in
that enclosing interval modulo T on the parity mesh:
L−a−T<t<a+2. This applies when that alignment is established;
it must not be inferred merely from an equal-width R2 in a
different frame or from high-slope inner-hull saturation.
General actual restoration and the remaining central rows
are not claimed. The vertical long strip and bounded seam
intersections are likewise still open.
