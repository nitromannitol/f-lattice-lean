# W1 LONG corrected odd alternate: native coverage at every positive suffix length

20 November 2026. Hand proof. This is a transition theorem, not an unconditional all-word coverage theorem and not a new recurrence result.

Fix an actual proper W1 saved-last-1 or saved-last-3 history and the genuine earlier own-cover assumptions already used for W1 SHORT, including cover of the genuine earlier corrected E_1 at saved-last-3. Let E_j be the actual previously made growing odd-standard mask of S=p+jq. Its coverage follows by ordinary propagation from the actual E_1, with the earlier ordinary construction at saved-last-1 and corrected seed at saved-last-3 distinguished. Then the corrected odd alternate using LONG, whose true output is O=S+q, covers its native quotient at every j>=1, on both physical parities. The matched literal pure2 histories already have an all-length proof; the proof below applies to the remaining genuine histories, including the literal reciprocal/root branch. It does not unroll E_1 into a fictitious ordinary mask.

## Actual finite quotient source list and representatives

Use e=q, f=V_q, w=V_p, v=-2p, B=(1/2,-1/2), T=T_q, K=s_q(p), alpha=K/T, beta=2/T, and h=j+alpha. P and Q are the actual saved standard masks; D is the genuinely restored old alternate. The exact finite quotient source list, proved from the actual LONG dispatch and offsets in F_LATTICE_W1_LONG_ODD_ALT_EVENTUAL_NATIVE_COVER_TRANSFER_20261120.md §1, is
  E_j;
  Q-2e+[0,j]f,            Q-e-[2,j+2]f;
  P-e-f,                  P-2p-e-w;
  D+2p-f+[-1,2j-1]e.
The true native U_O,V_O columns in the chart a-B=xe+yf are (2h+2,beta),(beta,h+1). The actual finite reflection modulo the columns is (x,y)->(-2-x,-1-y). Center the real period parallelogram at (-1,-1/2) in this chart and reduce the address by whole periods into coefficient intervals [-1/2,1/2]. This parallelogram is invariant under the actual quotient reflection. Reflect if necessary, so that
  -1<x<=h+beta/2,
  -h/2-1-beta/2 <= y <= h/2+beta/2.
There are no physical lines x=-1 or x=0, because T*x is odd. We use 0<beta<alpha<1, T>=14, and T*(1-alpha)=s_q(q-p)>=d+n for the retained histories. All stated shifts preserve the physical parity.

On the chosen physical parity let M be the unscaled occupied inner Q transverse margin and m=M/T. Let A=m_s(q)/T be the normalized actual Q longitudinal margin. Thus 0<=m<1/2, A>=1/T, and the occupied Q rectangle has x in [-A,1+A], y in [-m,1+m] in its centered chart. Ty and M have the same parity because q is even rational type and the true centered old t endpoints are on the given physical mesh. Write M_S for the unscaled occupied inner S transverse margin. The exact centered S grades and width are
  s=h*T*x-2y,    t=x-h*T*y,    T_S=T*h^2-2/T.
The continuous degree-one margin functional on the positive cone is (D-N)/2 at odd physical parity, |D-3N|/2 at even parity for N<=D/2, and |5N-3D|/2 for N>=D/2. This is the previously proved occupied I margin. Its linear pieces have absolute derivative at most 4d+n on f=(n-d,n+d). Since S=hq+f/T, this gives
  |M_S-h*M| <= (4d+n)/T < 1.
For d=3 use n=1; for d>=4 use T>=d^2+2d-1>5d.

## The upper and lower regions for x>0

First suppose T*y>=-M+2. The genuine E_j at origin pays directly. Its required longitudinal interval contains [0,2T_S]. For the lower endpoint use T*x>=1 and y<=h/2+beta/2, whence s>=-beta; s is integral, so s>=0. For the upper endpoint, y>=-m+2/T>-1/2 yields s<=T*h^2+h+1<2T_S. For the transverse facet, t<=h*M-h+beta/2<M_S since h-beta/2>1 and the displayed margin bound holds. The opposite facet is automatic since t>=-h*T*(h/2+beta/2)>-T_S. These comparisons use h>1, beta<=1/7 and T>=14.

Next suppose T*y<=-T+M. Test the actual E_j-V_O, i.e. test a+V_O in E_j. Addition of V_O=V_S+f changes s by -2 and t by -T_S-hT. The translated longitudinal grade is positive: since y<=-1+m<-1/2 and T*x>=1, it is greater than h-1. It is below 2T_S since the lower chart bound y>=-h/2-1-beta/2 gives s-2<=T*h^2+2h+beta<2T_S. The translated transverse grade is bounded above by
  h+beta/2+hT*(h/2+beta/2)-T_S
  = 2h+beta/2+2/T-T*h^2/2 <0,
so it satisfies the upper facet. If T*y<=-T+M-2, the lower facet also follows immediately from the extra 2h and |M_S-hM|<1.

For the remaining equality T*y=-T+M, the lower facet is exactly x>=hM-M_S. This uses the literal row mesh rather than a limiting strict inequality. On the segment of rays from q to S there is no strict interior break of the above margin functional: q and S are primitive unimodular neighbors, and an intermediate primitive ray has denominator at least d_q+d_S>5; all section break rays have denominator at most five. Use the appropriate linear piece, taking the derivative toward S if q is itself a break. It has the form F(z)=d_z*g_y-n_z*g_x with half-odd g_x,g_y. Thus M=F(q), M_S=hM+F(f)/T and
  delta=hM-M_S=-F(f)/T=s_q(g)/T,   |delta|<1.
The physical site B+g-f is integral and on the literal equality row: its B-centered y is -1+M/T. Its x is delta since s_q(f)=0. Primitive q means that all integral sites on this literal row differ by an integer multiple of e, so every such x satisfies x≡delta mod 1. For x>0 and |delta|<1 we obtain x>=delta, as required. This proves the translated lower facet including equality. The two regions just established are exactly y>-m and y<=-1+m on the actual step-two mesh.

## The two outer regions for -1<x<0

Here the genuine Q-e-[2,j+2]f column pays y<=-1+m. Its x window is [-1-A,A], and its finite covered y range is [-j-2-m,-1+m], which contains the required part of the centered period chart. For y>=-m use the actual second column after +V_O, namely Q-e+w+[-1,j-1]f. Its x window [-1+beta-A,beta+A] contains the entire physical interval -1<x<0: its lower endpoint is at most -1+1/T, and T*x is odd. Its finite y window [alpha-1-m,h+m] contains the required upper part of the chart. Thus no long-run or terminal-index limit is used in these column payments.

## The same finite middle for both signs of x

Only -1+m<y<=-m remains. Map to the SHORT fixed positive middle by a*=a-2p+e+f, so that in the actual SHORT chart a*-v-B=x*e+y*f the coordinates are x*=x+1>0 and y*=y+1 with m<y*<=1-m. The proved SHORT constructive middle theorem pays that fixed physical site by one of three genuine sources: P+v, the upper Q column Q+v+w+Z_nonnegative f, or the literal old D head D+Z_nonnegative e. This theorem includes nonliteral and literal reciprocal earlier pairs, both parities and both saved records, and does not require an unrolled E_1 for this middle. It is the actual positive middle proof, not merely an equivalence with a filled hull or a convergence argument. Undo the translation a→a*:

* The P source becomes the always present actual LONG G2 source P-e-f.
* The upper Q witness becomes Q-e+w-f+i f with i>=0. Even if this is an optional native Q site outside the occupied I, the true outer H gives its normalized y at least -M_H/T, with M_H<=L/2 and L=d+n. Thus i<=y-alpha+1+M_H/T<=1-alpha+(M_H-M)/T<1, because alpha*T=K>=L. Hence i=0, realized by the actual finite shifted column Q-e+w+[-1,j-1]f.
* The D witness becomes D+2p-f+i e for i>=-1. In the old B-centered chart every actual D site satisfies D_x+2alpha>=0, by the exact proper own-R2 lower bound or the separately checked literal reciprocal lower bound. Thus i=x-(D_x+2alpha)<=x<=h+beta/2<j+1, so i<=j<=2j-1. This is inside the actual LONG G3 train at the very same j.

This proves coverage of every fundamental representative and hence of the whole native quotient for every j>=1. The finite proof did not require the moving or fixed far-index convergence of E_j. It used true prior E_j cover, the unchanged actual finite LONG list, and the already established constructive SHORT middle test as a source witness transfer. No other corrected branch is inferred.
