# Fixed W1 SHORT: genuine P inner hulls, nonunique lateral rows, and a saved-last-1 fixed-corner payment
20 November 2026; analytic proof with no mathematical code, search over parameters, or solver.

## Setting and inputs

The proper W1 corrected even standard is taken after a proper saved-last-1 or saved-last-3 record, with previously covered genuine old P, Q and D and the authentic frame and source-union assertions. All conclusions here concern fixed integral addresses as the suffix grows. The moving seam and short suffixes are not substituted for this calculation.

Use the two 20 November source notes F_LATTICE_W1_TWO_RUN_SHORT_STATIC_SEAM_AND_PAID_OUTER_ROWS and F_LATTICE_W1_SHORT_CENTRAL_ONE_CANDIDATE_TWO_LIFTS. Let q=(d,n), p=(d_p,n_p), e=q, f=V_q=(n-d,n+d), v=-2p, B=(1/2,-1/2), T=det(e,f), K=s_q(p), α=K/T, β=2/T, L=d+n. At a fixed integral address a write a-v-B=xe+yf, S=Tx and Y=Ty. Here S is odd, x on each t=t_q(a)=L/2+2-Ty row has mesh 1, and y has mesh β on each physical parity. We have p=αe+f/T by s_q(p)=K and det(q,p)=1. Hence n_p=α n+L/T and d_p=α d-(d-n)/T. The two genuine old source choices have 0<α<1/2 (saved3) or 1/2<α<1 (saved1). We have T>2L, K,T-K≥L, K²=T T_p+2.

The earlier reduction uses b=min(1,2α) and u=1+(n+E)/T for saved3, or 2α+(n+2+E)/T for saved1. On a nonempty D row the only positive candidate lies in (b,u], which has length <1. The only remaining y satisfy M_t<y≤1-M_t. Physical sites below this strip are paid by the lower Q ray, and those above by the growing corners. The positive upper Q column pays y≥α-M_t for β-M_s≤x≤1+β+M_s, with M_s=(n-l_q)/T≥1/T. The whole child reflection exchanges positive and negative sides; x=0 is not physical.

## 1. Full P margin and grade parity

Among candidate addresses with β≤y≤α, the complete upper longitudinal facet is the only possible obstruction to supply by P+v. The centered grades are s_p=Kx-2y, t_p=x-Ky. The covered P contains its actual parity inner hull, whose centered intervals are [-m_s,2T_p+m_s] and [-T_p-m_t,m_t]. Here m_s=n_p on physically even sites, m_s=|d_p-2n_p| on physically odd sites; m_t=(d_p+n_p)/2-k_p≥1/2 because k_p is an integer and d_p+n_p is odd. All these are the true parity-dependent occupied-hull parameters.

Since x≥1/T and y≤α, s_p≥-α>-1, hence s_p≥0. Likewise t_p≥-T_p-1/T. Since y≥β and x≤u, t_p≤u-2α<1: in saved3 use n+E<2K, and in saved1 use n+2+E<T. The centered transverse grade is half-integral; hence t_p≥-T_p and t_p≤1/2, sufficient for its actual occupied transverse interval. For x=2α+r/T one has
  s_p=2T_p+4/T+αr-2y ≤ 2T_p+αr.
The centered s grade is an integer of the same parity as 2T_p+m_s. In detail, d_p+n_p and d_p-n_p are both odd, so s_p(a-v) is congruent to the physical parity, and s_p(B)=n_p. On even sites m_s=n_p; on odd sites m_s=n_p-l_p with l_p odd. The finite physical parity upper grade rounds down in steps of two. Consequently αr<m_s+2 suffices for actual payment. There is no assertion of this test at y>α.

For saved1 and even sites all candidate r are ≤n+2 since E=0; α(n+2)=n_p+2α-L/T<n_p+2. For lower-sector odd sites at saved1 the old true birth has W0 and E=d-3n-2, so r≤d-2n. Moreover d_p-2n_p=α(d-2n)-(3d+n)/T. Since (3d+n)/T<2, the same strict inequality αr<m_s+2 follows. Thus *all* candidate addresses in β≤y≤α on either of these saved1 branches are actually paid by P+v. For any residual pair on the even or lower-sector odd saved1 branch its lower y is at most (1+β)/2≤α (2K-T is positive even), and at least β on the true parity mesh. The alternate may nevertheless select the side already paid by P, so this is not in general full pair payment.

## 2. Nonemptiness suffices in the lateral reduction

The earlier reduction invoked transverse uniqueness only to obtain some D site on the literal grade t. Because q is primitive, two integral sites of the same t differ by Z e. Thus nonemptiness of the literal row gives an actual D site on the same longitudinal class as every point on it. In particular the upper R2 cutoff still pays x>u, and on (b,u] some of a,a+e occurs and no other horizontal lift can occur, by the exact same old R2 exclusions. The opposite D arm still cannot pay a positive site.

On each residual grade the required nonemptiness is known: in the unique interval from old cover; for the nonunique high-slope even strips from F_LATTICE_W1_SHORT_HIGH_SLOPE_CENTRAL_ROWS_PAID_BY_OLD_ALT_FRONT_20261120.md. The latter gives an actual site on each of [C+2,k] and [L-k+2-T,L-C-T] (even mesh), where C=d-n and k=min(2C,2n-C), and these are the only residual rows omitted by vertical uniqueness. Thus the fixed one-candidate and exact two-site test now apply to *every* residual row of both parities, not merely to unique rows. Nonemptiness itself does not decide the left lift.

The actual D reflection has R=v+2e+f+2B. Define a'=R-a-e. Then (x',y')=(1+2α-x,1+β-y), t'=L+2-T-t. This map preserves physical parity and the residual row interval, exchanges the left and right lifts, and has fixed integral center a*= -p+B+(e+f)/2. Indeed d,n odd imply integrality, and rows have x mesh 1. If a row and its mate both have candidates a,c, then x(a)+x(c) is congruent to 1+2α modulo 1. It belongs to (2b,2u], whose endpoints exclude sums 2α and 2+2α: for saved3 use b=2α and (n+E)/T<α; for saved1 use b=1 and (n+2+E)/T<1-α. Hence c=a' and at least one of the two is paid by D. The midpoint row is completely paid: its only candidate, if any, is a*. This follows even without placing a* in the interval in advance: the bounds just given force any self-row candidate to be its own reflected address. D must contain one of a*,a*+e, and actual reflection exchanges them. No general claim that both sites in another pair occur is made.

## 3. Actual fixed high-slope corners in saved1

On high-slope even sites define t_0∈[C+2,k] and t_1=L+2-T-t_0. The previously reviewed actual lower-support front, not just old R2, furnishes z=r_j+(1,-1) at t_0 with j>0, where r_j is the true ascending mechanical cursor; R-z belongs to D at t_1. In particular s_q(z)=s_q(r_j)+2n≥2n, as each actual cursor step increases s_q. For a fixed t_1 address a with x>1, its lower matching address a'=R-a-e satisfies s_q(a')=n+T(1-x)<n. Since z lies on that same t_0 row, z=a'+h e for an integer h≥1. Therefore R-z=a+(1-h)e is an actual D head at or to the left of a. This proves payment, independent of whether a' is a candidate. The same reflected argument works in either saved record and actually whenever x>1+(n-s_q(z))/T.

For saved1 all positive x≤1 are paid by earlier standard sources. Thus *every fixed address at t_1 on the positive side* is supplied. At t_0 either the old row and ordinary cutoffs already pay the address, or it is residual with β≤y≤α: the lower bound follows from the mesh and y>M_t, and the upper from Ty=L/2+2-t_0≤L/2-C<K. The saved1 physical-even P result in §1 pays that candidate as well. Thus neither of the two nonunique high-slope even strips leaves any positive candidate in the fixed saved1 central intersection. Other residual grades, notably the large unique middle, are not exhausted here. We do not assert that reflection by the whole child fixes these two strips; it gives the corresponding paid reflected *addresses* on the negative side.

## 4. Two adjacent true P cells for saved3

At saved3 p is the old creator A, q=2A+B_0 and the true birth phase is W1, det(A,B_0)=-1. The authentic ordinary-even-ALT natural origins table in the exact ordinary even ALT slot ledger, §3 puts a full standard A at 0 (slot 4). In the corrected even ALT, natural source tuple (RIGHT,B_0,B_0,LEFT,A,A) keeps slot 4. See also the actual-front proof §1 and authentic current-source tuple in the exact corrected even ALT current-source tuple proof. A4 restores the frame. Hence the actual old D contains P at zero regardless of whether this strict proper old ALT was ordinary or corrected, with no filling assumption on the other D sites.

The literal D head therefore supplies all of P, in addition to the true G2 supplier P+v. Their displacement from one another is 2p=-v, the exact longitudinal P period *between two actual copies*. In centered p grades relative to P+v, they have identical occupied transverse interval and their guaranteed longitudinal intervals [-m_s,2T_p+m_s] and [2T_p-m_s,4T_p+m_s] overlap. On the same candidate set β≤y≤α, all s grades up to 4T_p+m_s are consequently paid. In particular x≤4α suffices, since Kx-2y≤4K²/T-2β=4T_p+4/T<4T_p+1, and s_p is integral. More precisely x=4α+r/T is paid whenever αr+4/T<m_s+2 by the same parity rounding.

For saved3 the upper Q column reaches through u on every physical-even row (E=l_q=0) and lower-sector odd row (E=d-3n+2, l_q=3n-d). For those parities every remaining candidate not already supplied by a Q ray has M_t<y<α-M_t. Therefore if 4α≥u, the two actual P copies pay *all* their fixed positive candidates. This is a conditional range of birth parameters, not a general solution for all saved3 records. It does not grant coverage of short suffixes, other corrected branches, or all-word coverage.

## Independent replay

Recomputed the physical parity upper-facet rounding, each old slope
margin, the preserved R2 row interval and the literal reflected head
at the nonunique grade. Checked the doubled standard intersection
using the actual unmodified A@0 alternate source. No general
fixed-corner or other phase claim follows.
