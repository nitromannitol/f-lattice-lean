# Saved3 W1 fixed seam: the third genuine front cell removes the size restriction for an ordinary old ALT

20 November 2026. Hand proof, no parameter enumeration, code or solver.

Assume the strict proper W1 SHORT setting of F_LATTICE_W1_SHORT_CENTRAL_INNER_HULL_AND_SAVED_HISTORY_PAYMENT_20261120.md, saved-last-3, and that the genuine earlier parent standard of b_0=q-2p covers its own deck. Suppose the old even alternate D was constructed by the ordinary even-ALT branch. More generally it suffices that its literal B_0 standard at 2p survived in full in the A4-restored frame. Then on every physical parity the band M_t<y≤α contains NO positive fixed candidate overlooked by the two earlier P cells. On physically even or lower-sector physically odd sites the genuine Q rays cover the rest, so there are no fixed defects on those parities for this ordinary-old-birth subclass, with no restriction on α. The whole child reflection also pays their corresponding negative addresses; in view of the parity-preserving child reflection, paying all positive fixed addresses on such a parity pays all fixed addresses on that parity. This statement does not assert that a corrected old slot 0 is full, and does not by itself settle a short suffix or all words.

Use the earlier proof's notation and bounds, in particular T>2L, K≥L, b=2α and u=1+η, η=(n+E)/T<α. For physical sites of any residual parity, Ty≥3. In fact the even mesh margin TM_t is |d-3n|/2 for n≤d/2 and |5n-3d|/2 for n>d/2; physical-odd TM_t=(d-n)/2. All are positive integers. At the exceptional rays with zero even margin the primitive vectors are (3,1) and (5,3), not proper here: n≥3 and d=2d_p+d_b≥7 since p and b_0 are strict (d_p≥2 and d_b≥3). Now M_t<y gives Ty≥TM_t+2≥3 on the old physical mesh.

The authentic phase W1, ordinary even-ALT natural slots for q=2p+b_0 include P at 0 and the earlier standard B_0 at 2p; see SIX_STANDARD_OPERANDS_OWN_R2_HAND_PROOF.md, §3. The actual ALT D contains both before its seventh donor is inserted; the literal D head supplies their sites. No assertion is made here about the proper corrected replacement for B_0. The preceding proof used the adjacent P+v and P occupied cells to pay all candidates x≤4α in β≤y≤α. Thus it suffices to take 4α<x≤1+η and M_t<y≤α. In particular 4α<1+η<1+α, so α<1/3. Put γ=1-2α, G=γT=T-2K, and T_b=det(b_0,V_b). The identities b_0=γe-βf and G²-TT_b=8 follow by linearity or K²-TT_p=2.

In the B_0 copy at 2p, the centered test vector a-2p-B is (x-4α)e+(y-2β)f. The old b_0 grades of this vector are
  s=G(x-4α)+4(y-2β),     t=-2(x-4α)-G(y-2β).
This follows from s_b(e)=G, s_b(f)=4, t_b(e)=-2, t_b(f)=-G. Both grades are integers: b_0 has even rational type and t_b(B)=(d_b+n_b)/2, s_b(B)=n_b are integers. Check the undisplaced period cell of this standard:

* s>-8β=-16/T>-1, so s≥0. At x≤1+η and y≤α,
  s≤T_b-G(2α-η)+4α-8/T<T_b.
  Indeed G(2α-η)>γK≥γL>4α, since γ>1/3, α<1/3 and L≥10.
* Ty≥3 and x>4α imply t<G/T=γ<1, hence t≤0. At x≤1+η and y≤α,
  T_b+t≥γ(T-3K)+2-2η-8/T>0.
  Here T-3K>0, η<1/3 and T>2L≥20. The displayed identity comes from T_b-Gα=γ(T-3K)-8/T and 2βG=4γ.

Thus 0≤s≤T_b and -T_b≤t≤0: the actual covered earlier standard B_0 contains the tested site via its occupied native inner hull, without filling an alternate box. Since B_0+2p is a real operand of D, this proves fixed payment by the D head throughout the claimed band. In saved3 physically even E=l_q=0, and in lower odd E=d-3n+2, l_q=3n-d. In each case E+l_q≤2, so every x≤u in the candidate range is within the upper Q column. Outside the band already the lower ray, this upper column, the outer growing strip, or the actual D cutoff on a nonempty literal row pays the address. Residual y>α outside those parities is not decided by this proof.

## Independent replay

The authentic slot at 2p, parity mesh margins, both real grade
identities, and all four integer facet signs were rederived.
Combined with the previously checked complete moving seams this
proves eventual native cover on the named physical parities in
this ordinary-old-birth subclass, conditional on the stated old
cover premises. It does not imply a bound across saved records
or payment in the corrected old-birth subclass.
