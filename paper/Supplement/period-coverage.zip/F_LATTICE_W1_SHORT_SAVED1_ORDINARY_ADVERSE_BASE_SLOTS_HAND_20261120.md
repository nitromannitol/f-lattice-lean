# W1 SHORT saved-last-1: an adverse-lift reduction for ordinary old alternates

20 November 2026. Hand proof, no mathematical code or parameter search. This is a partial result only, in the fixed upper odd strip with an ordinary old even ALT built from strict parents.

Use the exact stationary W1 chart a-v-B=xe+yf of the companion W1 SHORT notes, with q=e=(d,n), f=V_q, v=-2p, T=s_q(q), K=s_q(p), alpha=K/T, beta=2/T. Saved-last-1 has alpha>1/2. The old even q and current retained odd p have proper true W0 creator c=q-p, b=2p-q: q=2c+b, p=c+b, det(c,b)=1. Write lambda=1-alpha, gamma=2alpha-1, L_c=lambda T=s_q(c), G=gamma T=s_q(b) and J=s_b(c). Then c=lambda*e-f/T, b=gamma*e+beta*f, w_c=V_c=-beta*e+lambda*f, lambda*G=J-2beta, lambda*L_c=T_c+2/T. We work on physical-odd sites with y>alpha and y<=1-M_t<1. Put delta=x-1, r=T*delta. For a remaining positive address the Q upper column gives r>m_q+2 where m_q=|d-2n|. Both r and m_q are odd, so r>=m_q+4. The two-lift reduction also gives delta<=gamma+(n+2+E)/T and delta<1. Here E is the genuine old ALT longitudinal excess, with E<=d-n (zero outside the lower odd sector). No claim is made that all fixed residual addresses have y>alpha.

The right lift A=a+e belongs to D if and only if z=R-A does, where R=v+2e+f+2B is the actual old ALT reflection. Its coordinates centered at B, rather than at v+B, are z-B=-delta*e+(1-y)*f. Put H=1-y, so 0<H<lambda. The undisplaced centered grade pairs for b and c are
  s_b=-G*delta-4H,    t_b=-2delta-G*H;
  s_c=-L_c*delta+2H,   t_c=delta-L_c*H.
This follows from det(c,b)=1 and the linear determinant forms. The physical-odd standard H outer bounds in any c or b slot have lower centered longitudinal facet -m with m=|d_z-2n_z| and upper centered transverse facet M=(d_z-n_z)/2.

## Five of the six ordinary base slots cannot supply the adverse lift

The authentic W0 ordinary even ALT table has b at 0, w_c-b, 2c+w_c, 2c+2w_c-b, and c at b, w_c-b+V_b.

* b at 0 misses the lower s bound: m_b<=gamma*m_q+2(3d+n)/T, while 4gamma>2(3d+n)/T since G>=4d+2n. Thus gamma*r>m_b.
* b at 2c+w_c subtracts 2J-2 from this s value, so also misses the same facet.
* b at 2c+2w_c-b subtracts 2-2J from t_b. So its relative transverse grade is greater than J-2-2delta+2beta, which exceeds M_b because J>=3d_b+n_b and delta<1.
* c at b has relative s_c=-L_c*delta+2H-J<-m_c, since H<lambda<1/2 and J>=4d_c+2n_c.
* c at w_c-b+V_b has relative t_c=T_c+J-1+delta-L_c*H>J-1-2/T, beyond M_c. Here its offset t_c is -T_c+1-J, and lambda*L_c=T_c+2/T.

These exclusions use actual standard H outer bounds, so they do not rely on the interior being occupied.

## The last b slot loses whenever P fails its lower transverse test

For b at w_c-b, the exact relative grade is t_b=G*(y-alpha)+2beta-2delta. If this copy supplies z it requires
  y-alpha <= (M_b+2delta-2beta)/G.
The unchanged standard P+v passes its lower transverse facet exactly when
  y-alpha <= (M_p+1+delta-2/T)/K.
These thresholds are ordered in favor of P. Indeed multiply their difference (P minus b) by KG. The result is G*M_p-K*M_b+G-T*delta+2. From the p and b coordinates relative to q,
  M_p=alpha*(d-n)/2-d/T,
  M_b=gamma*(d-n)/2-2d/T,
so the expression is G-T*delta+d+2 >= d-n-E >= 0. This proves that if P fails its lower transverse facet, all six base slots miss the adverse right lift. If P passes the lower transverse facet but fails another facet, this implication does not apply.

## What remains

In this subcase only the genuine seventh donor can pay the right lift when the lower transverse test fails. It is not justified to discard it: the legitimate source shifts are w_c+2c-b at actual old letter 1 and V_b at actual old letter 2. No exclusion of these two donors, payment for possible failures of P's longitudinal facet, corrected old histories, physical-even histories, short suffixes, or full saved-last-1 cover is obtained here. The previously completed saved-last-3 branch is separate.
