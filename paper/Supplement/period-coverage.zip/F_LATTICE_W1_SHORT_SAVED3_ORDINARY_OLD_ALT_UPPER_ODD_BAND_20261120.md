# The top of the thin odd saved3 strip is paid by a real ordinary-old-ALT slot

20 November 2026. Fixed positive addresses only; hand proof with no code, solver, or parameter search.

Assume the strict proper W1 SHORT saved3 hypotheses in the preceding fixed-front notes, that the genuine old even ALT D was an ordinary birth, and that the earlier standard of b_0=q-2p covers its own deck. This proper b_0 was the original even parent in the strict saved3 birth. Let W1 old birth have w=V_p, and use e=q, f=V_q, v=-2p, T, K, α=K/T, β=2/T, γ=1-2α>0 and Gs=γT. Write x,y for the central chart a-v-B=xe+yf, with B=(1/2,-1/2). Candidate addresses on balanced or upper physically odd sites have x≤u=1+n/T (E=0 there) and M_t<y≤1-M_t. In y>α outside the upper Q window the only possible x is 1+r/T with
  m_s(q)+2<r≤n,   r odd,    m_s(q)=|d-2n|≥1.
Thus r≥5. No candidate on any other saved3 parity needs this extra test.

The true W1 ordinary-even-ALT table in SIX_STANDARD_OPERANDS_OWN_R2_HAND_PROOF.md, §3 includes B_0 at 2w+b_0. This is slot 3, not the distinct source B_0 at w (slot 2), and is not presumed intact in a corrected old ALT. Its centered origin relative to the seam's v is e+2w=(1+2β)e+2αf. It follows that if y≥2α the two centered b_0 grades of a relative to this copy are
  s=Gs(r-4)/T+4(y-2α),   t=-2(r-4)/T-Gs(y-2α).
These are integral because b_0 has even rational type. Using 2α≤y≤1 gives
  0≤s≤γ n+4γ<n_b+5<T_b,
where n_b=γ n-2(d+n)/T, 2(d+n)/T<1, and T_b=d_b²+2d_b n_b-n_b²>n_b+5 for d_b≥3, d_b>n_b≥1. Also t≤0 and
  t≥-2(n-4)/T-Gsγ=-T_b-2n/T>-T_b-1,
using Gs²-TT_b=8. Thus -T_b≤t≤0. This is precisely an occupied genuine period cell of the earlier standard B_0; its actual old ALT slot supplies the site via the D head. It follows that the only remaining odd candidates for this ordinary-old-birth saved3 subclass are in the narrower strip m_s(q)+2<r≤n, α<y<2α. The argument does not tell whether any such physical site is genuinely uncovered.

For contrast the intact B_0 at w has relative origin (2α+β,α+β), so at x=1+r/T its upper longitudinal excess above T_b is exactly γ(r-2)+4(y-α). Its occupied upper allowance is |d_b-2n_b|. No uniform payment in the remaining middle strip is inferred from that facet.

Independent replay: checked the true slot, origin, two exact grades,
and strict lower t rounding. This pays a band, not the remaining
fixed odd seam; the middle interval is left open.
