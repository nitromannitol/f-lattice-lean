# W1 SHORT after saved-last-3: eventual native cover also for corrected old alternate births

20 November 2026. Hand proof; no numerical experiment, solver or enumeration.

## Statement and inputs

For any fixed strict proper saved-last-3 W1 record, the corrected W1 SHORT even standard after a sufficiently long 2-suffix covers its native quotient on both physical parities, under the genuine earlier-own-cover assumptions in the stationary and moving-seam proofs. This note supplies the corrected-old-even-ALT case; the paired ordinary-old-birth proof and its literal first-mixed addendum supply the other case. This is a suffix result, not an all-word induction or a bound uniform in the saved record.

Use the coordinates, source frames and literal old-D two-lift rule from the earlier W1 SHORT notes. Thus q=e=(d,n), f=V_q, v=-2p, w=V_p, B=(1/2,-1/2), T=det(e,f), K=s_q(p), alpha=K/T, beta=2/T. For a fixed positive address write a-v-B=xe+yf. The earlier lower-band and Q-column payments cover physically even and lower-sector physically odd addresses, and all residual fixed addresses with y<=alpha. For the other odd addresses the Q upper ray/column and fixed localization leave only
  x=1+r/T,  m_q+2<r<=n, r odd,  alpha<y<=1-M_t<1,
where m_q=|d-2n| and M_t=(d-n)/(2T)>0. No earlier upper restriction y<2alpha is assumed here. The old D contains at least one of a and A=a+e. We exclude A from the entire literal corrected old D.

Let the actual preceding 3-run give q=2hp+g, with h>=2, and write b=q-2p, m=h-1, J_g=s_p(g), J=s_p(b)=K-2T_p. The anchor is the most recent real letter 1 or 2. The phase is W1 throughout the 3-run, so that anchor is not a pure W0 initialization or a switch lacking any digit 1. Its selected p,g are the actual proper parents. In particular g is even-type proper, d_g>=3 and n_g>=1. Put gamma_g=1-2h alpha and G_g=gamma_g T=s_q(g)>0, so alpha<1/(2h)<=1/4, g=gamma_g e-h beta f, and G_g^2-T T_g=8h^2. Let m_z=|d_z-2n_z| for a proper vector z. From p=alpha q+f/T we have
  |m_p-alpha m_q| <= (3d+n)/T < 4alpha,
using K=s_q(p)>=3d+n. Since r,m_q are odd, r>=m_q+4; thus alpha r>m_p. In particular s*:=alpha r-2y>m_p-2, even at high y.

## The standard slots and both protected helper prefixes

The actual corrected even ALT replaces ordinary slots 0 and 3 by its RIGHT and LEFT LONG even helpers and retains standard slots 1,2,4,5. For slots 1,2, the calculation excluding the right lift in the ordinary proof requires only y>alpha, not y<2alpha: slot 1 at A gives the slot 2 grade at a, namely T_b+(1-2alpha)(r-2)+4(y-alpha)>T_b+m_b; slot 2 at A has larger grade. Slots 4 and 5 are included in the following full prefix check.

In the actual RIGHT helper at outer origin 2p, the G1 standards plus retained slot 4 are p+2ip, 0<=i<h; the terminal G2 is g+2hp. The standard H supports of the LEFT prefix and slot 5 are bounded by the reflected formal standard H sets under the actual center R=v+2e+f+2B. This is the sourcewise formal pairing from ALL_CORRECTED_G1_G2_PREFIXES_AND_FOUR_G3_ENDPOINT_GATE and its independent prefix hand check, not a presumed equality for cropped helper supports or alternate values. Thus it suffices to test A and R-A in the indicated right-side standard copies. The latter address has central coordinates (2alpha-r/T,1+beta-y).

For p+2ip the grades s_p at A and R-A (centered on the tested copy) are
  2K+alpha r-2y-2(i+1)T_p,
  -2iT_p-alpha r-2+2y,
respectively. For i<=h-1 the first is at least 2hT_p+2J_g+alpha r-2y>2T_p+m_p: here K=2hT_p+J_g, J_g>=4d_p+2n_p and alpha r-2y>m_p-2. The second is strictly below -m_p by alpha r>m_p and y<1. Thus none of these copies or their formal reflected H sets contain A.

For g+2hp the exact centered s_g grades at A and R-A are
  T_g+G_g(1-2alpha)+gamma_g*r+4h*y-8h/T,
  -2h*J_g-gamma_g*r+4h*(1-y).
To verify, use the centered coordinates relative to g+2hp, namely (x-2(h+1)alpha,y-(h+1)beta), and the map s_g(u,v)=G_g*u+4h*v. The two identities above for G_g, and alpha*G_g=J_g-4h/T, give the displayed reductions. Since alpha<1/4, G_g>=3d_g+n_g, h<d/(2d_p) and T>d^2, the first is greater than T_g+m_g: G_g/2-8h/T>m_g because m_g<=d_g and 8h/T<1. The second is less than -m_g because J_g>=3d_g+n_g, h>=2, and y>0. This excludes both terminal prefixes by the outer standard H bound.

## Both actual LONG G3 trains

The actual two G3 families are direct translations of the same earlier restored pALT; no support equality or symmetry of this donor is needed. Their exact origins in the old D frame are as follows, for j=1,...,2m:
  anchor 1: RIGHT b+jw; LEFT b+(2+2m-j)w;
  anchor 2: RIGHT b+g+V_g+(j-1)w; LEFT b+g+V_g+(2m+1-j)w.
Indeed the two even W1 G2 origins before the outer slot move are 2mp and 2mw. In the original helper formulas RIGHT/LEFT steps are w,-w; K3 is (g-2p,0) at last 1 and (2g-2p+V_g-w,V_g-w+g) at last 2. Add the true outer origins 2p and 2w+b. This establishes the lists above for the actual LONG count, including its last additional head. The source binding is the same independently reviewed corrected prefix and four-head-endpoint dossier. There is no extra ordinary seventh donor in this corrected even ALT.

Because s_p(w)=0, all heads from either side have the SAME centered longitudinal test on the earlier pALT. Specifically the centered grade of A after moving back by the listed origin is
  K+s*       (anchor last 1),
  K+s*+2-J_g (anchor last 2).
For direct verification s_p(b)=J, s_p(g+V_g)=J_g-2, and subtracting the indicated shift from s_p(A-B)=2K+s*-2T_p gives the formulas. If the pALT has a strict own creator, its longitudinal R2 at this physical parity is [beta_old-m_p,beta_old+2T_p+m_p-2]. The actual earlier creator phases give beta_old=0 for last 1 and beta_old=2-J_g for last 2, by the authentic selector identities. In both cases the required centered grade minus beta_old is K+s*>K+m_p-2>2T_p+m_p-2. Thus every G3 head misses A.

If the W1 anchor is first mixed, it is 1, 2^a1 or 3^a1. At 3^a1 with a>=1, p=(2a+2,1), g=(2a+3,1), and q=2hp+g remains lower sector (d>3n), which has already been covered. At 2^a1 including root, put l=2a+3. The literal consumed odd staircase has centered s_p<=l^2+4l-4, as proved directly from its actual mask in F_LATTICE_W1_SHORT_SAVED3_ORDINARY_FIRSTMIXED_RIGHT_LIFT_EXCLUSION_20261120.md. Here p,g are those same anchor-selected vectors, and increasing h from 1 only increases K, so K>=2l^2+3l-3. Since s*>m_p-2>=-2, K+s*>2l^2+3l-5>l^2+4l-4 for l>=3. This excludes both literal head trains, including the root anchor. The literal odd donor is never passed through a fictitious generic R2 assumption.

## Conclusion

A=a+e belongs to none of the literal corrected old D operands. Earlier own coverage forces a itself by the exact two-lift rule. This pays every remaining fixed positive corner site, and actual child reflection pays the corresponding negative side. The verified moving-seam and wrapped-corner payments localize all possible defects to a fixed finite box. The stationary survivor test realizes each of these finitely many payments for all sufficiently long suffixes, proving the assertion. The all-word native-cover question, the general saved-last-1 case, and the arbitrarily short suffixes are not settled by this argument.
