# W1 LONG corrected odd alternate: eventual native quotient cover via the SHORT fixed suppliers

20 November 2026. Hand proof. Fix an actual proper W1 saved-last-1 or saved-last-3 record. Assume genuine earlier covers as in the W1 SHORT branch. In saved-last-3 the actual earlier E_1 is a corrected odd standard, and its cover is an explicit prior hypothesis; only subsequent ordinary stages propagate that cover. In saved-last-1 the first stage is ordinary. This is the corrected chronology in F_LATTICE_W1_SHORT_SAVED3_CORRECTED_SEED_CHRONOLOGY_ERRATUM_20261120.md. The corrected odd alternate using the actual LONG helper covers its native quotient on both physical parities for every sufficiently large suffix index j, with j allowed to depend on the fixed saved history. The matched near-one initial pure2 tracks already have their own all-length proof. This note uses genuine source masks and native periods and does not assert that a finite alternate fills any rectangle, or that this covers all finite j.

## 1. Exact actual quotient union

Let p and q be the fixed saved odd and even standards, det(p,q)=-1, P,Q their masks, D the actual restored old q alternate, e=q, f=V_q, w=V_p, v=-2p, B=(1/2,-1/2). Write S=p+jq, E_j its actual ordinary standard, O=S+q. The actual output here is get_alt_child_c(...,getOdd=true) at digit 2; its target is the odd O, NOT the auxiliary even sibling 2S+q used in some older raw field identities. Its true native columns are
   U_O=2p+(2j+2)e,   V_O=w+(j+1)f.
Use coordinates a-B=x e+y f, alpha=s_q(p)/T, beta=2/T, h=j+alpha, T=T_q. In this chart the columns are (2h+2,beta),(beta,h+1).

The actual W1 outer odd-ALT slots contain E_j at 0 and V_S+f (identical modulo V_O), Q at 2S and 2V_S-e, and put the LONG LEFT and RIGHT helpers at V_S-e and e+f, respectively. These are the audited W1 odd-ALT table and the corrected-prefix/endpoint tables §§2,6,7 of 'All corrected G1/G2 prefixes lie in the replaced H; four G3 endpoints suffice' in the recovery audit. In the two helpers the G1 Q sources add Q at 2S+bf and 2V_S-e-bf, 1<=b<=j; G2 P is at V_S-e and (2j+1)e+(j+1)f. The LONG G3 origins, after including the outer slots and reducing modulo V_O, are
   LEFT 2p+(`ell`-2)e-f;  RIGHT 2p+(2j-`ell`)e-f,
for 1<=`ell`<=2j. Thus the actual target support, modulo its native columns, is EXACTLY the union of
  E_j;
  Q-2e+[0,j]f,            Q-e-[2,j+2]f;
  P-e-f,                  P-2p-e-w;
  D+2p-f+[-1,2j-1]e.
Here [l,u] means all integers between the displayed endpoints. Derivation: subtract U_O from the first Q sequence, 2V_O from the second, V_O from the first P, and U_O+V_O from the second P; the G3 arithmetic sequences have the indicated union. For proper selected saved records these offsets depend on the actual saved pair, not a formula for generic old D. This allows the literal root/reciprocal D when the exact old A4 restoration is used. Its row proof is cited below.

The genuine complete odd ALT reflection sum in raw coordinates is 2S+2V_S+f+2B (audited native support reflection L150). Reduce by U_O+2V_O to get -2e-f+2B. Thus the exact quotient reflection in this chart is (x,y)->(-2-x,-1-y), and preserves the physical parity.

## 2. Moving seams and bounded reduction

Write L=d+n for q=(d,n), k for the genuine inner Q t endpoint parameter (t in [k-T,L-k] on the fixed physical mesh), and M=L/2-k, m=M/T, A=m_s(q)/T. We use three earlier results with their actual scopes:

* On this parity Q contains its occupied I rectangle x in [-A,1+A], y in [-m,1+m], in its B-centered e,f chart; A>=1/T. The actual E_j contains its own centered period parallelogram and expanded I.
* D meets every prescribed row with actual t_q in [L-k-T+2,k], in its true old frame. This is exactly the W1 SHORT moving-central row theorem (including the nonunique high-even rows proved by actual old front sites, not generic uniqueness). For literal reciprocal D the explicit raw body projection [3-T,d] includes these rows, at the root as well. The matched pure2 histories need no appeal to this theorem here.
* For the same nonliteral and literal reciprocal D cases, write D coordinates relative to B as (D_x,D_y). The actual lower/upper longitudinal bounds give D_x+2alpha>=0 and D_x<2. The literal raw-mask check and proper own-R2 proof are in F_LATTICE_W1_SHORT_UNIFORM_J_GE_2_AND_SAVED3_ALL_LENGTHS_20261120.md. These are bounds on actual sites only.

For the moving vertical strip, consider x in a fixed bounded neighborhood of [-2,0] and y between a fixed distance above zero and below h. The genuine Q columns at -2e and, after adding V_O, (-1+beta)e+(j-1+alpha-b)f, 0<=b<=j, both meet every such y in their actual occupied cells. Indeed their consecutive f shifts cover the whole y intervals [-m,j+1+m] and [-1+alpha-m,j+alpha+m], respectively. Their x windows [-2-A,-1+A] and [-1+beta-A,beta+A] overlap because 2A>=beta. In the portion x>=beta, E_j's own actual centered cell covers for j sufficiently large: its two period columns (2h,beta),(beta,h) give first-coordinate left boundary between 0 and beta throughout this vertical middle and its other facets are interior. For x<=-2, E_j-U_O covers similarly on its right boundary between -2 and -2+beta. These assertions can also be checked by the two unit cell coefficients (h*x-beta*y)/(2h^2-beta^2) and (2h*y-beta*x)/(2h^2-beta^2), and by applying these at (x+2h+2,y+beta) in the second case. Thus the entire vertical moving ribbon near the identified horizontal-period boundary is genuinely covered.

For the horizontal moving strip take y in any fixed bounded neighborhood of [-1,0] and 4<=x<=2h-4; increase the endpoint buffer or j if needed to make this range compatible with the finite box. The true E_j centered grades are s_S=hTx-2y, t_S=x-hTy, T_S=h^2T-2/T. The complete s interval is valid in both E_j and its shift -V_O, since s_S lies strictly inside [2,2T_S-2] for all large j in this ribbon, and s_S(V_O)=-2. The unscaled occupied inner transverse margin M_S satisfies |M_S-hM|<=(4d+n)/T<1: use S=hq+f/T and the continuous piecewise-linear inner-margin formulas. Their directional derivatives in direction f have size at most 4d+n; d>=4 gives 4d+n<T, and d=3,n=1 is direct. When Ty>=-M+2, t_S<=hM-4<=M_S; the opposite facet is automatic in the bounded ribbon for large j. When Ty<=-T+M, t_S>=hT-hM+4>=hT-M_S. Adding V_O changes t_S by -T_S-hT, so E_j-V_O pays; again the opposite t facet is interior for large j. The old physical parity mesh has step two on Ty and agrees with M, so only
   -T+M+2 <= Ty <= -M
remains. For D at 2p-f the relevant literal grade is t_q(a)-T+2=L/2-Ty-T+2, exactly in [L-k-T+2,k]. A genuine D site d0 on that row gives an integral index i=x-2alpha-D_x (same primitive e fiber). The earlier bounds give 0<=i<=x<=2j-1 in this ribbon, so it belongs to the actual finite LONG G3 range. This proves the moving horizontal ribbon without an asymptotic assumption about individual masks.

To reduce to a bounded intersection, start a real period parallelogram at (-2,-1) in the central coordinate chart. Its four corners are within a uniform additive constant of [-2,2h] by [-1,h] and the actual E_j occupied core corners are similarly within a uniform constant of [0,2h] by [0,h]. Every physical point in [6,2h-6] by [3,h-3] is inside the actual E_j core for all large j, directly from the two displayed unit cell coefficients. The actual periods identify right/top strips with left/bottom up to bounded offsets. The moving vertical and horizontal payments just proved cover the parts away from their intersections after those identifications. All four period corners meet the same fixed bounded intersection modulo the exact periods. Thus only finitely many fixed integral addresses in a bounded central box need eventual witnesses.

## 3. Fixed-corner transfer from the constructive SHORT proof

Reflect once to x>-1; there is no x=-1 physical line, since Tx is odd. For fixed y<=-1+m, there is exact standard payment. If -1<x<0 the real lower stationary Q column Q-e-[2,j+2]f supplies it eventually by reductions into its occupied inner rectangle. If x>0, use the actual ordinary E_j unroll: its second Q triangle is
  Q+w+(2b+d0)e+h0*f,       0<=b<=h0<j, d0=0,1.
Subtract V_O and take h0=j-r, r>=1. For every fixed choice of n=2b+d0>=0 and r>=1 this gives Q+n e-(r+1)f at all sufficiently large j. In saved-last-3 take j large enough that h0-b=j-r-b>=1: this is a graft at a genuine subsequent ordinary step, not a formula treating the corrected E_1 as the ordinary union. The full stationary union Q+Z_nonnegative e-Z_at_least_2 f covers all fixed x>0,y<=-1+m by independent integer reductions into the actual occupied Q rectangle. This includes the equality edge, which need not follow from a limiting growing t facet.

For y>-m, if x>0 the actual E_j core-plus-margin at its lower-left corner pays for every sufficiently large j: Tx odd gives strict longitudinal sign, Ty>=-M+2 gives the strict lower transverse test from the same grade formula with x fixed. If -1<x<0 use the shifted other Q column: Q-e+w+n f realized at n in [-1,j-1] by translating Q-e-[2,j+2]f by V_O. Its x interval [-1+beta-A,beta+A] contains every physical -1<x<0 by the odd Tx mesh and A>=1/T. Its lower y cutoff alpha-1-m is below -m.

For the remaining fixed -1+m<y<=-m and x>-1, translate the address to a*=a-2p+e+f. In the SHORT chart a*-v-B=x*e+y*f this gives exactly (x*,y*)=(x+1,y+1), so x*>0 and m<y*<=1-m. In precisely this fixed positive strip the established SHORT hand proofs used ONLY:
   the actual P+v; the actual upper Q column Q+v+w+Z_nonnegative f;
   the actual old D head D+Z_nonnegative e.
This is the direct near-column/P proof for x*<=1, the actual adverse-lift/sibling proof for nonliteral saved1, the genuine-window and old-head proof for saved3, and the raw-body/head proof for the literal reciprocal family. In this middle strip the SHORT lower Q ray does not enter; its outer growing standard payments were used only outside the indicated y interval. The pre-existing matched near-one all-output theorem handles the other literal family directly.

All three literal middle suppliers transfer:
  P+v becomes P-e-f, an actual LONG G2 source;
  Q+v+w+Z_nonnegative f becomes Q-e+w-f+Z_nonnegative f, the genuine shifted column with eventual indices n>=-1;
  D+Z_nonnegative e becomes D+2p-f+Z_at_least_minus_1 e, each fixed index in the actual LONG G3 range for large j.
These are direct translations of the native sites, not a claim that quotient periods or complete output tiles of SHORT and LONG coincide. This covers the fixed middle on the positive side and then everywhere by the actual LONG reflection.

A maximum over the finitely many fixed addresses in §2 yields the stated fixed-history eventual native quotient coverage. The proof gives a genuine transition of the LONG corrected odd-ALT branch; its short lengths and a history-uniform bound are separate work.
