# W1 SHORT saved-last-1: the fixed upper odd strip is covered for both ordinary old births

20 November 2026. Hand proof. This supplements F_LATTICE_W1_SHORT_SAVED1_ORDINARY_ADVERSE_BASE_SLOTS_HAND_20261120.md. Use its notation, true strict creator hypothesis, physical-odd parity and fixed range alpha<y<=1-M_t. The conclusion here is payment of every such fixed residual site when the ordinary old D was born at actual last digit 1 or 2 and its old odd donor has a strict own creator. No general saved-last-1 theorem is asserted.

The unchanged actual P+v has centered grades Kx-2y and x-Ky. With x>1, x<2 and y>alpha, the first grade is positive and the second negative, since K*alpha=T_p+2/T. Thus a failure of the guaranteed physical-odd standard rectangle can be only at its upper longitudinal facet or its lower transverse facet. The five base slots excluded in the preceding note stay excluded. If P fails the lower transverse facet the sixth slot b at w_c-b also misses, by the ordered transverse thresholds already proved.

Suppose instead P passes its lower transverse facet but fails its upper longitudinal facet. Put C=K(delta-gamma)+4/T-2y, its upper longitudinal grade excess over 2T_p. On the physical-odd step-two mesh failure gives C>=m_p+2. The tested b slot1 longitudinal grade at the reflected adverse site is
 s_1=T_b+2gamma-G*delta+4(y-alpha).
Direct substitution using G^2-T*T_b=8 gives the exact identity
 alpha*s_1+gamma*C=2(y-alpha)-4/T.
The signed differences d_q-2n_q, d_p-2n_p and d_b-2n_b all have the same weak sign. Indeed q and p are positive combinations of the strict unimodular pair c,b, whose interval cannot strictly contain the ray 1/2, as any rational strictly between has denominator at least d_c+d_b>2. The coordinates p=alpha*q+f/T and b=gamma*q+2f/T therefore give
 alpha*m_b-gamma*m_p <= (3d+n)/T.
Passing the lower transverse facet gives K(y-alpha)<=M_p+1+delta-2/T. Using 2M_p<=alpha(d-n), delta<1, and K>T/2 gives
 2(y-alpha)<(d-n+8)/T.
Consequently
 alpha*(s_1+m_b) <= (3d+n)/T - 2gamma + 2(y-alpha)-4/T
                 < (4d+4-2G)/T <0,
since G=s_q(b)>=4d+2n. Thus the sixth standard slot again misses the reflected adverse site by its actual longitudinal enclosure. If P pays directly there is nothing to prove; otherwise all six standard slots miss.

At a genuine old last-2 birth the ordinary donor at V_b is restored in its W0 odd frame, with beta_old=0 and centered longitudinal lower bound -m_c. The total projected shift s_c(V_b)+beta_old is 2. At a genuine old last-1 birth the donor is at w_c+2c-b and its own birth phase was W1. The source's base in that phase is beta_old=2-2T_c+J by the true last-1 creator identity; its translation has s_c(w_c+2c-b)=2T_c-J. Thus again the total projected shift including beta_old is exactly 2. In both cases the base-removed grade at the reflected adverse site z=R-a-e is -lambda*r-2y. Since c=lambda*q-f/T, m_c<=lambda*m_q+(3d+n)/T. Strict c gives 4lambda*T>=4(3d+n) and r>=m_q+4; hence the donor grade is <-m_c.

Thus no genuine operand contains z. Old D reflection excludes a+e, and old coverage forces a. This proves fixed payment on the specified upper odd strip for both true ordinary old births under strict own-creator R2. Literal first-mixed sources, fixed lower sites not already otherwise supplied, and corrected old births are outside this proof.
