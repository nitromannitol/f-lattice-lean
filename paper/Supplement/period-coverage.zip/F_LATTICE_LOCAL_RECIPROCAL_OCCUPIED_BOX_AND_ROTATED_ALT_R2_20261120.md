# What a local reciprocal rotation preserves in the occupied standard box and odd-ALT enclosure

20 November 2026. Hand calculation. This is a reduction for ordinary even ALT and the unresolved reverse transfer, not a proof of those transitions. It does not assert identity of actual masks after rotation or create a full standard rectangle from own cover.

Use the actual centered quarter-turn and gauges in F_LATTICE_RECIPROCAL_PROPER_SOURCE_GAUGES_AND_HELPER_TRANSPORT_PRELIMINARY_20261120.md. For an actual standard z the true occupied inner box I exists when its native quotient is covered, by the earlier core/trace theorem. In its own real deck coordinates (u,v) relative B, the actual reciprocal affine map sends (u,v) to (1-v,u). The parity flips. Thus the transported actual support contains the rotated *occupied* I rectangle, with its horizontal and vertical normalized expansions exchanged. Its larger OUTER H, if needed, must not be treated as occupied.

## Exact occupied margins after the local rotation

Call the new reciprocal vector (d,n), and give both margins in its own native longitudinal s and transverse t grade units. On transported physical-odd parity the transverse margin is (d-n)/2; on physical-even parity it is |d-3n|/2. These are exactly the formal standard OUTER transverse margins, but here they are actually occupied in the transported rectangle, not because any synthetic H has been filled. The synthetic longitudinal margin is
  physical even: n;
  physical odd and n>=d/3: |d-2n|;
  physical odd and n<d/3: |d-4n|.
At the slope break the expressions agree. To verify all factors: for original odd type, the reciprocal T is twice the original, and U swaps from a doubled primitive to a single primitive. The new unscaled longitudinal margin is twice the original occupied transverse margin, and the new unscaled transverse margin is the original longitudinal margin. For original even type, the reciprocal T is half the original and the synthetic U doubles; the new longitudinal margin is the original transverse one and the new transverse margin is half the original longitudinal one. Substituting the two rational vector maps and flipping physical parity gives the same displayed formulas for either type. In particular an even synthetic Q has d,n both odd and its rotated longitudinal margin is always at least 1. The one narrower strip compared to the canonical I is the LOW synthetic slope physical-odd longitudinal margin |d-4n| instead of d-2n. It corresponds to the missing optional qq portion in the physical-even high-slope original input. This loss cannot be hidden by labeling the rotated rectangle canonical.

## Transformed old odd ALT has exactly the needed literal row interval

Let actual old odd ALT be built at z=A+B0=(D,N) from proper selected odd A and even B0 and true phase W. Let S=T_z, J0=T_A+s_A(B0), and L0=D+N. Let m_old be the original old longitudinal parity margin of the actual standard z. The genuine old odd-ALT R2 (19 November ordinary/corrected source audits) has width 2S+2m_old-2 in s and width S+J0+2W+2H-L0 in t, where H=D+1-2W on originally physical-odd sites and on originally lower-sector even sites, and H=2N on the other originally physical-even sites.

The reciprocal synthetic even ALT has T'=2S, d'=D+N, n'=D-N, and its true gauge sends the old ACTUAL reflection center to the canonical even-ALT center. In unscaled centered grades rotation exchanges changes by
  Delta s_new = 2 Delta t_old,    Delta t_new = -Delta s_old.
The resulting actual t enclosure has total width T'+2m_old-2 and absolute midpoint determined by t endpoint sum L'-T'+2, L'=d'+n'. Thus it is precisely
  [a'+2-T', L'-a'],     a'=L'/2-m_old.
But m_old is the actual occupied transverse margin of the locally rotated companion standard, as computed above. Therefore earlier actual D quotient cover forces every actual t row in [L'-a'-T'+2,a'] to meet D in this transported affine lattice: each is the unique allowed literal lift of its own transverse grade. No high-even nonunique-strip front is required in this local rotation. This argument uses own earlier quotient cover of the source ALT, which is invariant under the genuine integral quarter-turn and deck transform.

The longitudinal width becomes T'+2J0+4W+4H-2L0. The proper transformed creator has even-parent longitudinal product J'=2J0. Subtract the conventional even-ALT base width T'+J'+2n'+4(1-W): the excess divided by two is exactly
  E'=2H-2D+4W-2.
This is zero on synthetic physical-even sites and on synthetic physical-odd high-sector sites. On the remaining synthetic physical-odd sites it equals d'-3n'+4W-2. If the synthetic slope is below 1/3 this is the conventional lower-sector widening; if the synthetic slope is balanced it is nonpositive (away from literal small endpoint cases) and only tightens both longitudinal facets because the canonical center is matched. Thus these locally rotated old ALT sources satisfy the usual needed lateral upper/lower enclosure or a stronger one. Both calculations are based on the actual old creator; no literal initializer exception has been checked by this general formula.

## What this pays and what remains

This rotation preserves the true deck and gives the correct row-cover premise and lateral bounds for a possible synthetic odd-ALT proof of ordinary even ALT. It does not supply a complete constructive middle. In particular one may not use the previous canonical upper-Q column window on low synthetic odd rows: its right end was 1+(d-2n+2)/T, whereas the directly occupied rotated column only reaches 1+(|d-4n|+2)/T. The exact unresolved difference is a strip between these two grade endpoints, unless extra actual Q sites or an independent old-D lift argument pay it. Even outside that strip, the necessary antecedent source-position and margin-strength checks must be replayed, rather than claiming native equality of unrelated proper histories. This note records the surviving exact box and the first concrete missing condition.
