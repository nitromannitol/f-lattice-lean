# The entire saved3 W1 old front pays the fixed lower band, including a corrected old even alternate

20 November 2026. Hand proof. No mathematical code, solver, or parameter enumeration was used.

Work under the same strict proper W1 SHORT, saved-last-3 assumptions as the two fixed-corner notes. All earlier standards that are used have own cover; in particular this applies to the terminal proper standard G identified below. This is a chronological hypothesis, not an unconditional all-word coverage claim. The old D, P and Q have their previously stated own cover. Then every positive fixed candidate in M_t<y≤α is paid, whether the old even alternate D was ordinary or corrected. Consequently no fixed seam address survives on physically even sites, nor on physically odd lower-sector sites, for this saved-last-3 branch. This does not dispose of the balanced/upper physical-odd seam, saved-last-1 in general, or short suffixes.

## Authentic lower front

Keep p=(d_p,n_p), q=(d,n), v=-2p, e=q, f=V_q, T=det(e,f), K=s_q(p), α=K/T, β=2/T and B=(1/2,-1/2). Write a-v-B=xe+yf; Ty is on the physical parity mesh. In the strict saved3 case p is the old creator A, q=2A+B_0 and the true old birth phase is W1. The natural A4-restored old even ALT has full P at zero (slot 4). If it was an ordinary birth, it has full B_0 at 2p (slot 0), so put h=1, g=B_0 as a vector. If the old birth was corrected, it was a digit 3. Its natural slot 0 at 2p is the actual unflipped RIGHT LONG even helper. The stationary odd vector in its G1 front is the same p: each repeated digit 3 selects the retained former odd parent (Gp0), then retains that very selected parent again, while the even output increases by twice that odd parent. At the most recent saved ancestor its G1 is the retained odd parent Gp2, and G2 the retained even parent Gq2, not the intervening new odd output. The source binding is literal get_next_mat (the original even ALT constructor and its source ledger) and get_l_correct (the original saved correction routine and its source ledger). The restored W1 RIGHT offsets are 2ip for 0≤i<m and 2mp for the last standard g, with B_0=2mp+g. In particular there is no exceptional G2 displacement: the pure2 even exception is flipped LEFT only, and the LONG extension changes only G3. This is the reviewed actual-front lemma in F_LATTICE_W1_SHORT_HIGH_SLOPE_CENTRAL_ROWS_PAID_BY_OLD_ALT_FRONT_20261120.md §1 and the unflipped prefix table in the exact horizontal atom and mandatory-extra proof §5. Thus, adding slot 4 and the slot 0 translation 2p, and setting h=m+1 in this case, both branches give
  q=2hp+g,     P+2ip ⊂ D (0≤i<h),     G+2hp ⊂ D.
Here det(p,g)=-1, g is even rational type; it may be the earlier endpoint (1,1). The D head and the genuine G2 P+v provide h+1 adjacent P cells in the central chart.

Put η=(n+E)/T<α, u=1+η. In the remaining band the previous P proof gives -T_p≤t_p≤1/2 in the occupied inner hull and s_p≥0. At x≤2(h+1)α,
  s_p=Kx-2y≤2(h+1)T_p+4h/T<2(h+1)T_p+1,
using the residual mesh y≥β. Since s_p is integral and the h+1 longitudinal intervals overlap at consecutive genuine P periods, this pays all such x.

## The terminal proper standard

Suppose 2(h+1)α<x≤u and M_t<y≤α. Put γ=1-2hα, Gs=γT=s_q(g). Then γ>2α-η>α, γ<1, h<d/(2d_p), and g=γq-hβ f. In particular g cannot be the endpoint (1,1), since that would give Gs=2d<K (p≥(2,1) componentwise). The remaining use of G therefore involves a proper earlier covered standard only. Write T_g=det(g,V_g). Then Gs²-TT_g=8h², since g=q-2hp, K²-T T_p=2. In the actual G+2hp cell the centered old grades are
  s=Gs[x-2(h+1)α]+4h[y-(h+1)β],
  t=-2h[x-2(h+1)α]-Gs[y-(h+1)β].
Indeed the coefficient pairs on e,f are (Gs,4h) and (-2h,-Gs); the origin displacement relative to the P+v chart is 2(h+1)p. These grades are integers, as g has even rational type. I check the full hull constraints.

* Lower s: s>-8h(h+1)/T>-1 since T>d², d_p≥2, d≥7 and 8h(h+1)/T<2/d_p²+4/(d_p d)<1.
* Upper s: s≤T_g-Gs(2α-η)+4hα-8h/T<T_g. Indeed Gs(2α-η)>α K=T_p+2/T, while 4hα<2 and T_p≥7.
* Lower t: T_g+t≥γT(γ-α)+2-2hη-8h²/T>0. To obtain the bound put x=1+η, y=α and expand the displayed t formula. Use η≤d/T, h<d/(2d_p) and T>d² to get 2hη+8h²/T<1/d_p+2/d_p²≤1.

For the upper t facet one must use the genuine margin, not just Ty≥3: a fixed terminal G can have a small margin in a long chain. For either parity define M(z) as the *unscaled* centered upper transverse margin of the native standard inner hull. On odd sites it is (d_z-n_z)/2. On even sites it is |d_z-3n_z|/2 for n_z≤d_z/2 and |5n_z-3d_z|/2 for n_z≥d_z/2. The formulas agree at n_z=d_z/2 and give a continuous, homogeneous, piecewise linear function on the cone. We need:

1. M(q)≥h. On odd sites this follows from q=2hp+g and d_p-n_p≥1. For even q at slope ≤1/2, p and g do not strictly straddle 1/3: a primitive integer ray strictly between unimodular neighbors has denominator at least d_p+d_g≥5. Thus the two values of d_z-3n_z have a common weak sign. Its value at p is odd and nonzero, which proves the claim. On even q at slope ≥1/2, use the same argument for 3/5; the only possible d_p+d_g≤5 with p,g proper is d_p=2, d_g=3. In that case p=(2,1) and the proper even-type g of denominator 3 is (3,1), so there is no strict crossing. Again 5n_p-3d_p is odd. Cases of equality of a parent ray are covered by the weak sign. This reasoning is invoked only after g is known proper.
2. M(g)>γ M(q)-2. Along the segment from γq to g=γq-hβ f (entirely in the positive cone), the absolute derivative of each signed affine piece of M along f is at most 4d+n: for example the extremal high-sector form (5n_z-3d_z)/2 has value (5(d+n)+3(d-n))/2=4d+n on f. The other two types of forms have smaller absolute values. Splitting at the break rays therefore bounds the change by hβ(4d+n)<d(4d+n)/(d_p T)<2. In the last step 4d²+dn<4T holds for 0<n<d, and d_p≥2.
3. On the actual q parity mesh Ty≥M(q)+2. Hence, because x>2(h+1)α,
  t<γ[2(h+1)-Ty]≤γ[2h-M(q)]≤γ M(q)<M(g)+2.
  The source G center has t=t_g(a-2hp)-(d_g+n_g)/2; t_g(a-2hp) is congruent to physical parity since d_g,n_g are odd. The centered upper margin M(g)=(d_g+n_g)/2-k_g has the same parity as t: the physical-parity endpoint k_g has the same parity as t_g(a-2hp). Thus the strict +2 bound rounds to t≤M(g).

Together these inequalities give 0≤s≤T_g and -T_g≤t≤M(g). This rectangle is contained in the actual parity inner hull of the covered old G. The actual D head supplies the site. This closes the remaining band for either parity and old-birth type. Finally, on even sites E=l_q=0 and on lower-sector odd sites E=d-3n+2, l_q=3n-d, so the upper Q window covers through u in each case. Together with the old row nonemptiness/cutoffs, the lower ray and the outer-strip proof this gives payment of all fixed positive sites on the claimed parities. The actual child reflection then gives the negative sites; x=0 cannot be physical.

## Independent replay

Rechecked that the stationary odd parent survives the real old
3-run and that the true unflipped LONG front supplies the stated
sequence of genuine standard copies. Recomputed the determinant
and shifted terminal grades, the terminal endpoint exclusion,
the lower/upper facet signs, and the piecewise-linear margin
comparison with the correct even-type parity spacing. Combined
with the earlier moving-seam theorem, this gives eventual cover
on the named physical parities for fixed proper saved-last-3
histories, under the stated earlier native cover hypotheses.
Balanced and upper physical-odd addresses and short suffixes
remain outside the conclusion.
