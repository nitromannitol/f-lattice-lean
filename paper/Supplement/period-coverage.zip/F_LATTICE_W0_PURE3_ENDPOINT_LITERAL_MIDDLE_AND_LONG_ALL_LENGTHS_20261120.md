# The pure W0 reciprocal endpoint: literal SHORT middle and finite LONG coverage

20 November 2026. Hand proof. This treats an actual positive pure3 saved record with p=(1,0), q=(d,1), d odd >=3. It proves pointwise constructive payment of the fixed SHORT middle and, with that input, native cover at every positive j of the corrected odd alternate LONG. It does NOT claim complete finite SHORT coverage by these steps. We use the exact live frame and genuine prior standard cover; the literal Q and literal first reciprocal odd E_1 have independently checked occupied core cells. No earlier D quotient-cover assumption is needed for its raw-row argument.

## Exact literal frames and three middle suppliers

Use e=q, f=V_q=(1-d,d+1), w=V_p=(-1,1), B=(1/2,-1/2), I=(1,-1), T=d^2+2d-1, L=d+1, alpha=L/T and beta=2/T. The transported W0 mirror M reverses the e coordinate and keeps f, and p'=-Mp, w'=Mw. The affine target chart is the one in F_LATTICE_W0_SHORT_REFLECTED_W1_LAYOUT_ACTUAL_SOURCE_CONJUGACY_20261120.md, with a target site centered around V_S+B before transport, S=p+jq. The appropriate target parity is the original physical parity carried by M. This is not an assumed lattice-preserving symmetry of the original axes.

The actual pure3 odd-helper A6 prefix from the audited native source ledger has RIGHT Q at i f (0<=i<j), RIGHT atom P at j f-e2, LEFT Q at the usual reflected prefix origins, and LEFT atom P at 2j e+I. The original pure corrections are G2-only shifts; the actual Q/G3 lists and outer origins remain those of the W0 SHORT/ LONG tables. This is the literal 'Pure-saved standard and odd-ALT outer contacts' dossier §§1–4 and actual A6 frame audit L150. The genuine P is the six-site literal rectangle {0,1} times {0,1,2} at lower-left zero. The actual A4 restored reciprocal D is the raw staircase, including rails and two additions (literal firstmix staircase dossier). There are no generic endpoint H/I or old R2 replacements in what follows.

With P'=2p'+M(P-B) in the centered transported chart, the near actual SHORT G2 is P'+MI rather than P'. Indeed physical LEFT at outer e+V_S plus 2j e+I, recentered by V_S and reduced modulo U_SHORT=2p+(2j+1)e, gives -2p+I; applying M gives the indicated term. The other actual P source is P'+f-w'-2p'-M e2; it is not needed for the constructive positive middle. The true upper Q column and positive D head are unchanged:
  Q'+w'+[0,j]f;    D'+2p'+[0,2j-1]e.
Here Q'=e+M(Q-B) and D'=e+M(D-B). Its interval extensions supply the corresponding fixed stationary witnesses eventually.

## True literal rows and the head bound

The raw D body contains the integral rectangle-with-diagonal-bounds
  4-2d<=X<=d,  0<=Y<=d,  2-d<=X+Y<=d+2.
As proved by its adjacent X intervals row-by-row, it meets every raw grade t_q=X-dY in [3-T,d]. In the transported frame t_q is unchanged. The required central row range [L-k-T+2,k] lies inside [3-T,d], including d=3 (k is the occupied-inner Q endpoint parameter). Any actual old D row witness can be used in the primitive e fiber; physical parity is the parity of this literal t grade.

The true raw full D longitudinal range is [-T+L,T+d+3]. The body lower estimate follows from s_q=(d+1)(X+Y)-2Y, and lower equality is the actual bottom-rail site (1-d,-1). The actual upper value occurs at (3,d+1); all other rail/body/marked sites fit the range. Therefore the transformed D' body/rail support has
   -(d+2)/T <= D'_x <= 2-d/T,
and the unshifted positive head base D'_x+2alpha lies in [d/T,2+(d+2)/T]. In particular it is strictly positive and D'_x<2. Set u=1+(d+2)/T. On a nonempty residual row, any fixed x>u has a genuine D site on or to the left of the tested address in integer e steps: any site one full e to its right exceeds the actual head cap. Thus the positive head pays that address. This is a statement about actual staircase row sites, including the extra rail outside formal R2.

## Fixed positive middle, including the genuine shifted P

On the given physical parity let m be the normalized inner transverse margin of Q. Its unscaled value is (d-3)/2 on even sites and (d-1)/2 on odd sites. The positive middle is x>0, m<y<=1-m. Its actual row mesh gives y>=beta. The upper Q column pays every eligible y>=alpha-m in its horizontal interval [beta-A,1+beta+A], with A the actual normalized longitudinal margin and A>=1/T. Thus it pays all such y when 0<x<=1 (Tx is odd).

If 0<x<=2alpha and the upper Q column does not already pay, then beta<=y<=alpha. Write the inverse physical lattice point z0=B+M(xe+yf). Its coordinates are
  X0=1/2-d*x-(d-1)*y,    Y0=-1/2-x+(d+1)*y.
Since x<=2alpha=(d+1)*beta, its lower Y0 is at least -1/2. Since (d+1)*alpha=(d+1)^2/T=1+2/T<3/2, its upper Y0 is less than 1. Integrality gives Y0=0. Then X0=(1-T*x)/(d+1) is in (-2,0], hence X0=-1 or 0. Consequently z0+(1,1) is in the actual literal P atom. This is exactly the required true shifted G2 witness: P'+MI=M(P-B+I-2p)=M(P-B-(1,1)). No unshifted formal endpoint P cell was filled.

If 2alpha<x<=u and the upper Q column does not pay, the tested address itself is in the actual old D head at i=0. Inverting D'+2p' gives a raw old D point with
  X=5/2+d*(1-x)-(d-1)*y,
  Y=1/2-x+(d+1)*y,
  X+Y=d+3-(d+1)*x+2y.
Here u<3/2. Thus Y>-1; for x>=1 its upper bound is d+1/2, while for x<1 upper Q nonpayment gives y<alpha-m and hence Y<2. In either case integrality gives 0<=Y<=d. We have X<d+1 because d*x>2d*alpha>3/2, and X>=4-2d since
  X>=7/2-d-d*(d+2)/T,    d*(d+2)/T=1+1/T<d-1/2.
The lower sum bound follows from (d+1)*(d+2)/T=(d+2)*alpha<d. For the upper sum bound it suffices that (d+1)*x-2y>=1. If x>=1 it is at least d-1; if x<1 then y<alpha and x>2alpha give a strict lower bound 2d*alpha>1. Thus all literal body facets hold. This includes all x,y in this middle subcase, not just an idealized old R2 coordinate. For x>u use the earlier genuine nonempty-row head. These steps prove that every fixed positive middle site has a native witness in the actual shifted P, upper Q column, or D head.

## Finite LONG implication, with the same pure shift

The W0 LONG source transfer formula is in F_LATTICE_W0_LONG_FINITE_TRANSFER_FROM_W0_SHORT_MIDDLE_20261120.md. The only changes at this pure endpoint are its two G2 shifts. In physical coordinates its LEFT LONG P raw origin is (2j+2)e+V_S+I and its RIGHT origin is (j+1)f-e2. Modulo the true LONG U_O=2S+2e,V_O=V_S+f, these are -2p-f+I and -w-e2. Under the same transformed output gauge 2S'+e they give the actual P' terms
   P'-e-f+MI,     P'-2p'-e-w'-M e2.
Thus the shift carries EXACTLY the previously exhibited SHORT near witness into the finite LONG middle after the same a* translation. Q columns and D train are unchanged from the actual finite LONG source list. This can also be seen directly by adding the actual LONG outer LEFT (2e+V_S) to the same pure G2 prefix, so no inference from an individual helper rotation is needed.

The finite LONG exterior proof applies as written on the actual transported mesh: alpha>beta, T>=14, T*(1-alpha)>=L, alpha*T=L, the already covered actual S standard is strict proper even at the literal first S, and (q,S) are still unimodular neighbors for its equality-row argument. For a representative in the LONG middle, map (x,y) -> (x+1,y+1) in the corresponding SHORT chart as before. The constructed P witness is the just-verified shifted P term; the TRUE upper Q witness requires only finite column index zero by the outer-margin bound; and the genuine D witness index obeys -1<=i<=x<=j+alpha+beta/2<j+1 from D'_x+2alpha>0. Therefore i<=j<=2j-1, valid even at j=1. These are all actual sources. The finite LONG exterior and actual reflection then prove full native quotient cover at every positive j for this pure3 endpoint branch.

This does not settle the finite SHORT exterior at the smallest pure suffixes or reverse propagation of native reciprocal support equality through the literal endpoint. The new result is the literal fixed middle and the finite LONG coverage on the prescribed native deck.
