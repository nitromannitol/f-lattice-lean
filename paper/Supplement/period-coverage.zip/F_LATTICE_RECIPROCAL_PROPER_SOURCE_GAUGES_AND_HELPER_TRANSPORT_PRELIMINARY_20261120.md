# Reciprocal quarter-turn: proper source gauges and the remaining pure-prefix question

20 November 2026. Hand source-algebra checkpoint. This establishes the proper algebra below, not an all-history coverage theorem. Literal source correspondences and any required one-sided pure-prefix inclusions must be checked before an induction can use it.

For an actual odd rational-type vector p=(d,n) define its even reciprocal hat p=(d+n,d-n); for an actual even rational-type vector q define its odd reciprocal hat q=((d+n)/2,(d-n)/2). Write J(x,y)=(-y,x), U_z=2z on odd type and z on even type, V_z=(n_z-d_z,d_z+n_z). Then
  J U_z=V_hat z,   J V_z=-U_hat z.
If selected p,q are replaced by the ordered pair p'=hat q (odd), q'=hat p (even), the determinant sign is unchanged; this exchanges digits 2 and 3 and preserves W. A centered native mask has sites z-B with B=(1/2,-1/2). The quarter-turn and an indicated centered gauge c means the actual physical map z -> B+c+J(z-B). It is integral, with the same parity reversal for all indicated gauges (all c have even coordinate sum).

## Standard and alternate gauges

For a standard use c=U_hat z. This matches its genuine native reflection vector by direct subtraction. For old odd alternate p+q, whose new even peer is 2p'+q', use
  c_odd_to_even=2p'+(W+1)q'+W V_{p'}.
For old even alternate 2p+q, whose new odd peer is p'+q', use
  c_even_to_odd=2p'+(2-W)q'+(1-W)V_{p'}.
These gauges follow by taking half of the difference of the true centered old/new reflection sums after J, using the audited L150 raw native-domain reflection vectors: old odd 2p+2(1-W)q+2V_p+V_q, old even 2p+2Wq+2V_p+V_q. They fix actual coordinate anchoring, not an assumed identity of values or masks. At any graft with physical shift o, relative offsets transform as c(target)+J(o)-c(source).

For example the actual W1 odd standard's Q copies at 2p, 2p+q, V_p, V_p+q go to the new even standard's odd sources at q'+V_{q'}, q'+V_{q'}+V_{p'}, 0, V_{p'}, respectively. Its two old P sources become the new even parent's copies at 2p' and 2V_{p'}. The replaced old Q positions 2p and V_p+q go to exactly the replaced even-standard positions q'+V_{q'} and V_{p'}. In W1 odd ALT the old ordinary Q copies go to the new even ALT's odd sources at 0 and V_{p'}+V_{q'}+2q'; the two untouched old P copies go to q' copies at 2p'+q'+V_{p'} and V_{p'}. The corrected origins V_p-q and q+V_q go to even ALT slots 0 and 3, at 2p' and 2V_{p'}+q'. These are genuine exact source-offset checks, not a metrical symmetry argument. The corresponding W0 tables use the same gauges.

## Proper odd helper to proper even helper, both SHORT and LONG

The odd replaced standard S=p+jq maps to the even Y=q'+2j p'. For a helper alone in its authentic after-A6 frame choose centered target gauge Y. The literal G1/G2 tables of 'All corrected G1/G2 prefixes lie in the replaced H; four G3 endpoints suffice' §2 then match termwise:
  W0: RIGHT -> RIGHT, LEFT -> LEFT;
  W1: LEFT -> RIGHT, RIGHT -> LEFT.
For example W1 old LEFT G2 P@0 becomes the new even helper RIGHT G2 q'@2j p'. The W1 old LEFT Q prefix at V_p+(j-1-i)V_q becomes p'@2i p'. The W1 old RIGHT P@2j q+jV_q becomes new LEFT q'@2j V_{p'}. The W0 old RIGHT P@jV_q becomes new RIGHT q'@0 and its Q prefix maps to p'@q'+2(j-1-i)p' (same exact finite set in reverse index order). The other prefixes follow by the same substitution or actual paired helper reflection; none requires replacing a literal endpoint G2 by a generic rectangle.

The actual G3 old odd target helper consumes the real earlier even alternate D of q. Its mapped odd ALT gauge, obtained from the real older creator, is
  actual saved last 1: 2W p'+(1-W)q'+W(V_{q'}-V_{p'});
  actual saved last 3 (new last 2): 2p'-Wq'+(1-W)(V_{p'}-V_{q'}).
For last 1, q and p were the two previous siblings and their preceding creator has phase 1-W. For last 3, q was made with the retained p and a real other even parent, same phase W. Substituting these identities into the displayed alternate gauge gives these two formulas, including the frame-dependent linear terms.

Insert these into the authentic after-A6 G3 head table of the same dossier §6, with the original true range 1<=ell<=2j-1 (SHORT) or 2j (LONG). For W1 old LEFT 2p+(ell-1)q maps, after adding Y and subtracting the D gauge, to
  right saved1: 2j p'+q'-2p'+ell V_{p'};
  right saved2: 2j p'+2q'-2p'+V_{q'}-V_{p'}+ell V_{p'}.
For W0 old RIGHT V_p+(j-1)V_q+ell q the two resulting origins are
  right saved1: 2p'-q'+ell V_{p'};
  right saved2: V_{q'}-V_{p'}+ell V_{p'}.
These are precisely the authentic new right head tables. The other sides follow by direct substitution in the literal left/right tables or by their audited genuine cross-reflection (assuming the donor itself has the indicated reciprocal image). This is an equality of source placements for proper helpers conditional on prior corresponding actual masks. It contrasts with the separate proven cardinality mismatch for literally improper pure G2.

## Ordinary seventh translations and the induction issue

Applying these gauges to the authentic seventh offsets (ordinary ALT genuine old donor ledger) gives:
  old even last1 -> new odd last1, W0 shift V_{p'}+q', W1 shift V_{p'}+2p'-q';
  old even last2 -> new odd last3, the same two shifts;
  old odd last1 -> new even last1, W0 shift V_{p'}+2p'-q', W1 shift V_{p'}+q';
  old odd last3 -> new even last2, W0 shift V_{q'}, W1 shift 2q'+V_{q'}.
For example at old W1 even last2 its donor shift 2q+V_q maps to 2V_{p'}-2p'. The true older odd donor gauge is 2q'-2p'+V_{p'}, since p was a previous odd child and q the retained selected even parent; the current new odd gauge is 2p'+q'. The offset difference is V_{p'}+2p'-q', as claimed. The last1 cases use the preceding phase 1-W rather than the current W.

These calculations identify the natural proper stage of a reciprocal support induction. They do not prove the required paired literal initial states. In particular F_LATTICE_RECIPROCAL_PURE_ENDPOINT_HELPER_CARDINALITY_OBSTRUCTION_20261120.md shows an extra native point in a real pure reciprocal RIGHT helper: identities of proper operands cannot be applied to that literal six-site/four-site mismatch. It remains to check whether the extra is absorbed by the authentic outer union, or whether a suitable one-sided induction plus a direct endpoint transition covers the missing direction. No all-word duality or global native cover is claimed in this checkpoint.
