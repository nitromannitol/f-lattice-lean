# The two-run W1 SHORT seam: fixed native suppliers and two paid outer strips

20 November 2026. Analytic result for the proper W1 corrected even standard, with no computation or parameter enumeration. It applies to proper saved-last-1/3 records in their actual restored frames, not to formal substitutions for endpoint workers. The estimates here concern fixed addresses in the recentered seam as the suffix grows, not a uniform statement about addresses growing with the suffix. No conclusion about W0, 3-runs, or all-word cover is drawn.

Fix the saved odd/even pair p,q, det(p,q)=-1. Use e=q, f=V_q, w=V_p, v=-2p, S=p+jq, C=2j+1, X=2S+q, H=2p+V_S. Use D,P,Q for the true restored old q-alternate, standard p, standard q masks, respectively. Work relative to H. By "pays a" we mean that H+a is represented by an actual placed source modulo the target deck, not that an extra copy has been installed. The two target periods are
     
    U_X=-v+C e,        V_X=2w+C f.

## 1. Exact payment from G1/G2, without an arithmetic progression in j

In the seam frame the actual G3 train is D+[0,C-2]e. The true G2 origins are V_S and Cq+(j+1)f. Subtract H and use C e=v modulo U_X. The two P copies are therefore at the *fixed* offsets

    v,                 2v+f-w.                                      (1)

Together, the actual W1 G1 chains and the two ordinary stationary endpoint slots put Q at 2S+b f and 2V_S-b f for 0<=b<=j. The first, after subtraction of H, is (C-1)e-w-(j-b)f; subtract one U_X. The second needs no horizontal deck change. Thus the two Q columns are exactly

    v-e-w-k f,         v+w+k f,          0<=k<=j.                  (2)

These placements use the literal W1 restored table in ORDINARY_SOURCE_LEDGER.md, ALL_PROPER_W1_SHORT_G1.md and the explicitly verified W1 G2 origin bindings in ASTRA_ALL_TRULY_PROPER_CORRECTED_NATIVE_CONSTRUCTOR_PROJECTIVE_GLUE_ALL_SLOTS_20261119T0455Z.zip. The proper saved last digit determines the old alternate D, not a further displacement of the two standard G2 scans.

For fixed a the eventually paid set from these three source types alone is exactly

    (P+v) union (P+2v+f-w)
    union (Q+v-e-w-Z_ge0 f) union (Q+v+w+Z_ge0 f)
    union (D+Z_ge0 e) union (D+v+Z_le(-2) e).                      (3)

In the last term the last G3 index C-2 becomes -2, not -1. To see necessity as well as sufficiency, write all shifts in the real basis (e,f). In (1) there is no growing displacement. Each column (2) has bounded e displacement and f displacement of modulus at most j+O(1). A deck lift covering a fixed a first has both its integer period coefficients bounded, by the affine deck matrix with leading term 2j times the identity. Its vertical coefficient must then be zero, since nonzero vertical period shifts exceed j+O(1); its horizontal coefficient must likewise be zero. Its column index k stays bounded. For G3 the same argument leaves vertical coefficient zero and horizontal deck subtraction either 0 or 1. In the first case the surviving head indices are nonnegative; in the second they take all fixed values <=-2 after replacing C e by v. This proves the eventual identity, uniformly on any fixed finite set of a. The proof does not require P,Q,D to be filled hulls.

For donor row r use the parity basis (e,v), with parity origin z0, and old lateral extrema l_r,h_r as in the exact row-gap note. A gap between consecutive occupied rows r,r+1, once the row intervals have stabilized, has the following *fixed* representatives:
     
    a=z0+i e+(r+1)v,              h_r-1 <= i <= l_(r+1)-1.          (4)

Indeed the child character takes e to 1 and v to C, so subtracting one horizontal deck from the previous-row addresses transforms C r+h_r+C-1+t into C(r+1)+h_r-1+t. These are precisely the holes between the two rays of (3) at this row. In particular (1)-(2) furnish fixed exact standard-supplier tests there without any period search in j.

## 2. The corners of the actual growing standards pay a larger band complement

Assume that the genuine ordinary growing standards S and the stationary standard q cover their own deck classes, hence occupy their earlier proved inner hulls I. This assumption on the ordinary chain follows by ordinary propagation from covered initial inputs. Write B=(1/2,-1/2) and for each fixed integral seam address a set
     
    a-B-v=x e+y f.
     
Let T=det(q,V_q), let k_q be the exact transverse lower endpoint coefficient on the physical parity in the occupied hull I_q and put
     
    m=(d_q+n_q)/2-k_q.
     
In the notation of the ordinary proof, the centered t grades in I_q permit expansion by m on each side of the true fundamental cell. Then EVERY fixed address satisfying either strict inequality
     
    y < m/T             or             y > 1-m/T                     (5)

is actually paid for all sufficiently large j. The threshold can be chosen for any finite list of these addresses. In particular only central physical rows meeting the closed strip between these inequalities can remain in (4). This removes actual rows, not just a possible j-dependent congruence obstruction. It does not assert that the remaining strip is paid.

**Four growing corners.** The two genuine S origins relative to H are v-w-jf (near) and v+e+f (far). Use no horizontal deck subtraction for their left corners, subtract one U_X for their right corners. In centered coordinates a-B-v, their four relevant vertices and inward directions are

    near upper left      0       :  +2S, -V_S
    near upper right    -e       :  -2S, -V_S
    far lower left       e+f     :  +2S, +V_S
    far lower right      f       :  -2S, +V_S.

For example the near upper right is v-w-jf-U_X+2S+V_S=v-e before removal of v. Real offsets do not change the physical-parity mesh of a source.

Center the actual S inner-hull grades at B. Its longitudinal grade runs from -m_s(S) to 2T_S+m_s(S), its transverse grade from -T_S-m_t(S) to m_t(S); both margins are nonnegative. The limiting per-j transverse margin is
     
    m_t(S)/j -> m.

This follows directly from the continuous piecewise-linear k in the actual I formula and S/j -> q, including a sector endpoint. On a bounded displacement x'e+y'f from any indicated corner one has t_S/j -> -Ty', s_S/j -> Tx', since t_q(e)=s_q(f)=0, t_q(f)=-T, s_q(e)=T. At a left (right) corner its nontrivial longitudinal test therefore holds for x'>0 (x'<0); the far longitudinal facet is order j². At an upper corner the active transverse test is t_S >= -m_t(S) relative to the vertex, hence holds for y'<m/T. At a lower corner it is t_S <= m_t(S), hence holds for y'>-m/T. Again the opposite facet is order j². These sign statements are sufficient only at the specified strict inequalities and need no rounding convention.

The near copies therefore pay the lower strip of (5) whenever x>0 or x<-1; the far copies pay the upper strip whenever x>1 or x<0. There are no integral addresses on any of the vertical lines x=-1,0,1: q has both coordinates odd, s_q on the physical lattice is even, s_q(B)=n_q is odd, and T is even. Hence Tx is odd.

**Two stationary columns close the missing longitudinal intervals.** Write w=beta e+alpha f, with beta=2/T and alpha=s_q(p)/T. The determinant sign gives s_q(V_p)=2; det(q,V_p)=s_q(p). Both saved choices satisfy 0<alpha<1: for the true proper birth q=2a+R the effective p is a or q-a, strictly between zero and q componentwise.

The centered Q hull permits horizontal enlargement m_s(q)=n_q-l_q on each side in s-grade. Here l_q=0 at physical even parity and min(d_q-n_q,3n_q-d_q) at odd. Thus m_s(q)>=1 in both cases (at odd parity it is |2n_q-d_q|, nonzero because d_q is odd). The lower Q column in (2) occupies all integral sites in the horizontal window
     
    -1-beta-m_s(q)/T <= x <= -beta+m_s(q)/T

and in the vertical half-strip y<=1-alpha+m/T, for each fixed such site eventually. This is just the union of the consecutive f shifts of I_q, whose vertical width is at least one full period. It covers every -1<x<0 in the lower strip of (5): Tx is odd, so x<=-1/T, while its upper window endpoint is at least -1/T. Likewise the upper column occupies the horizontal window [beta-m_s(q)/T,1+beta+m_s(q)/T] and eventually all fixed y>=alpha-m/T therein. It covers every 0<x<1 in the upper strip, since x>=1/T. This proves (5), including the potential one-grade slivers that a bare closed-cell approximation to the G1 columns would not justify.

The condition is a real payment test for the explicit unresolved rows: y in (4) is independent of i because e=q, and can be read from det(q,z0+(r+1)v-B-v)/T. No old lateral pick is needed to use (5). One may not apply this fixed-address theorem uniformly to an O(j) interval spanning a missing row or the large cyclic wrap without new bounds. Even among the remaining fixed rows of the closed central band, (3) does not imply all possible gaps are covered. Those need new information about the actual relative lateral supports.

## 3. Exact answer to the eventual supplier test on each remaining bounded address

The preceding payment outside the band uses the true inner hulls. A separate direct source calculation eliminates even the possible period in j on the *remaining fixed finite test*: for each fixed integral a, actual coverage of H+a is eventually constant (true or false), with an explicit stationary membership test using only P,Q,D. This still does not assert every test is true.

Write E_i for the actual growing odd standard at p+i q, E_0=P. At W1 each such subsequent ordinary transition has E_i at 0 and 2e+f, and Q at 2(p+i q), 2(p+i q)+e, V_(p+i q) and V_(p+i q)+e. This is the m=1, W1 six-source ordinary layout applied to the growing standard itself, not the changed SHORT siblings. Iterating gives E_j as the union of
     
    P+t(2e+f),                                         0<=t<=j,
    Q-v+(2h+d)e+b f,                                  0<=b<=h<j, d=0,1,
    Q+w+(2b+d)e+h f,                                  0<=b<=h<j, d=0,1.

Indeed a Q born at step i+1 may move t times by 2e+f in the later j-1-i steps; h=i+t,b=t. The remaining steps place it at zero, so every pair 0<=b<=h<j occurs. Let E_inf denote exactly this displayed union with no upper bound, not a filled cone.

Let rho(a)=2v+f+(1,-1)-a. Beyond (3), add to the fixed test set
     
    E_inf + v+e+f,                 Q+v+Z_ge0 e-Z_ge1 f,             (6)
     
and their two rho images. Then a belongs to this enlarged explicit set if and only if H+a is represented by the whole actual SHORT tile for all sufficiently large j; if a does not belong, it is unrepresented for all sufficiently large j.

To prove this, the two recentered S origins are v-w-jf and v+e+f. For either, horizontal e-coordinates of possible recentered sites lie between -O(1) and 2j+O(1), vertical f-coordinates between -j-O(1) and j+O(1), with constants depending only on the finite birth data. Thus at a fixed a the deck subtraction can be only zero or U_X: as in §1 both coefficients are bounded first, after which a nonzero V_X coefficient would give a vertical displacement outside that range. For the far copy with zero subtraction, its pure increasing union is exactly the first set of (6); each fixed witness appears at all sufficiently large j. For the near copy with zero subtraction, a surviving horizontal index in the P list forces t bounded, and in the first Q list forces h bounded. Neither can then cancel the -jf vertical displacement. In the second Q list b must be bounded and j-h must be bounded but at least one. The possible limiting offsets are exactly v+n e-k f, n>=0,k>=1 (write n=2b+d, h=j-k). Conversely every such fixed choice is valid eventually. This gives the other set in (6).

Finally the genuine complete standard reflection pairs the two growing copies. Its recentered center is v+C e+f+(1,-1), congruent to 2v+f+(1,-1) modulo U_X. Reflection by rho takes a zero-subtraction witness in either actual growing copy exactly to a one-U_X-subtraction witness in the partner. This accounts for both remaining corner tests and proves necessity as well as sufficiency. In particular no undecided infinite arithmetic progression in j is inherent in these bounded W1 SHORT seam tests; the issue is whether the fixed native sets fill the central strip. This corner limit does not turn a test at every fixed a into a uniform test for independently moving a(j).
