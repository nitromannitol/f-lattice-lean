# The first-mixed ordinary old alternates obey the same W1 SHORT cover theorem

20 November 2026. Hand proof using the literal restored staircase, not a generic R2 bound for a pure donor.

This supplements F_LATTICE_W1_SHORT_SAVED3_ODD_RIGHT_LIFT_SEVENTH_DONOR_20261120.md. Under the same proper saved-last-3 and earlier-own-cover hypotheses, every ordinary old even ALT birth is now covered, including the first mixed transition. As before, the conclusion is full W1 SHORT native coverage for every sufficiently long 2-suffix after each fixed saved record. There is no uniform threshold or claim for the corrected old even ALT.

An ordinary old even ALT in phase W1 is born at digit 1 or 2. If it is the first mixed transition, it must be the root digit 1, or 3^a1 or 2^a1 with a>=1: switching between 2 and 3 alone never flips W0 to W1. A pure old birth is likewise W0 and is not at issue. In 3^a1 the even vector is (3l-2,3) for l=2a+3>=5, which is lower sector. Its fixed seam was already paid on both physical parities by the saved3 all-old-birth front proof. That argument needs no strict R2 bound on a literal pure donor.

For 2^a1, include a=0 for root 1 and write l=2a+3. The actual selected parents of the ordinary old even ALT are
  p=((l+1)/2,(l-1)/2),   b=(l,l-2),
so q=2p+b=(2l+1,2l-3). The old odd alternate seventh donor is genuinely the restored near-one staircase, with shift w+b. In the actual consumed frame its exact mask is (Y,l-X), with X>=4-2l and Y<=l+1, including the rails and all corner additions. These facts are proved in FIRSTMIXED_LITERAL_STAIRCASE_SEVENTH_HAND_PROOF (the literal staircase first-mixed dossier in the 19 November recovery audit), §§1 and 3.

In p's longitudinal grade s_p(u)=l u_1+u_2, the literal mask therefore has
  s_p <= l(l+1) + (3l-4) = l^2+4l-4.
The centered grade subtracts n_p>=1, so the same coarse upper bound holds. The earlier right-lift calculation used only the shift w+b to show the centered required grade is K+alpha*r-2y. It applies unchanged to this literal donor. In the thin remaining strip, r>=5 and y<2alpha, so alpha*r-2y>0. But K=s_q(p)=2l^2+3l-3, and K-(l^2+4l-4)=l^2-l+1>0. Thus the right lift is not in the literal seventh donor.

The earlier six-slot exclusions still apply to root1 and these first-mixed ALT births, because the selected p and b are proper, and their covered standard H enclosures are already among the standing hypotheses. No use of strict pure-donor R2 is made. All ordinary old even ALT births are now exhausted: in every remaining thin-strip row a+e is impossible in the actual old alternate, so its earlier cover forces a itself. The moving and stationary arguments then give the full eventual cover stated above.
