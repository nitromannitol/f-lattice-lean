# Actual-cell coverage and exclusions for the W1 SHORT saved-last-3 odd strip

20 November 2026. Hand proof. No mathematical program, solver, or enumeration is used.

**Conclusion.** For a fixed strict proper saved-last-3 record whose old even alternate is ordinary, the W1 SHORT even standard covers its native quotient for every sufficiently long 2-suffix if `alpha <= 1/4`. This assumes own cover of the genuine earlier standards and old alternate used in the previous W1 localization and fixed-seam proofs. No bound on the threshold uniform in the saved record is asserted. More generally, the actual-cell tests below narrow the remaining region. This is separate from all-word recurrence and does not claim cover for all words.

## Standing notation and reduction

Write `q=(d,n)=2p+b`, where the odd retained vector `p` and the genuine earlier even vector `b` are strict proper. Put `e=q, f=V_q, v=-2p, w=V_p, T=det(e,f), K=s_q(p), alpha=K/T, beta=2/T`, and `gamma=1-2alpha, G=gamma T, T_b=det(b,V_b)`. Here `B=(1/2,-1/2)` and the fixed address is `a-v-B=xe+yf`. The identities are `p=alpha e+f/T, w=beta e+alpha f, b=gamma e-beta f` and `G^2-T T_b=8`. Also `K>=d+n>4, d>=7, T>2(d+n)`. See the companion notes F_LATTICE_W1_SHORT_SAVED3_ALL_OLD_BIRTH_FRONT_STRIP_20261120.md, F_LATTICE_W1_SHORT_SAVED3_ORDINARY_OLD_ALT_THIRD_CELL_20261120.md, and F_LATTICE_W1_SHORT_SAVED3_ORDINARY_OLD_ALT_UPPER_ODD_BAND_20261120.md for the actual source bindings.

After their payments, the only fixed positive addresses that can remain are physically odd in the balanced or upper sector:
```
x=1+r/T,  |d-2n|+2 < r <= n,  r odd,
alpha < y < 2alpha.
```
In particular `r>=5` and `x<=1+n/T<1+alpha`. The actual child reflection handles negative addresses and there are no physical sites on `x=0`. The companion bounded-defect checkpoint establishes that only a fixed finite box can contain missing classes, and the stationary test realizes every fixed supplier in that box for all sufficiently large suffix lengths.

## 1. Old alternate slot 0 at 2p

Take a candidate with `x>4alpha`. Then `alpha<1/3` and `gamma>1/3`. Relative to the genuine `b+2p` standard copy the centered grades are
```
s=G(x-4alpha)+4(y-4/T),
t=-2(x-4alpha)-G(y-4/T).
```
The first grade is positive since `Ty>K>4`; the second is negative for the same reason. Since `y<2alpha`, substitution and `G^2-T T_b=8` show
```
s < T_b - gamma(2K-r) + 8alpha - 8/T < T_b.
```
Indeed `r<=n<K` and `gamma K>8alpha` since `G>8` (use `T>d^2>=49` and `gamma>1/3`). The remaining rectangular inner-hull condition is precisely
```
T_b+t = G(gamma-y) + 2 - (2r+8)/T >= 0.
```
Thus this actual slot pays whenever `x>4alpha` and `y<=gamma+[2-(2r+8)/T]/G`. The right-hand correction is positive: `r<=n`, `T>2(d+n)` and `d>=7`. If `alpha<=1/4`, then `x>1>=4alpha` and `y<2alpha<=gamma`. In this case slot 0 pays the entire remaining strip. Combined with the fixed and moving payments already proved, this proves the stated eventual-cover theorem for both physical parities.

For `alpha>1/4`, all residual x actually satisfy `x<4alpha`. Indeed `k=4p-q=2p-b` has positive odd components: `k_n=(4alpha-1)n+4(d+n)/T>0` and `k_d=(4alpha-1)d-4(d-n)/T>-1`. Therefore `s_q(k)>=2d>r` and `x<4alpha`. Moreover slot 0 is impossible throughout this strip in this parameter range. Its longitudinal grade is `gamma r+4y-s_b(k)`. Since `s_b(k)>=2d_b`, and
```
gamma r+4y < gamma n+8alpha = n_b+2(d+n)/T+4-4gamma < n_b+4,
```
this is strictly less than `-|d_b-2n_b|`. The last inequality in the display uses `G>=4d+2n`; the last outer-facet comparison uses `2d_b-n_b-|d_b-2n_b|=min(d_b+n_b,3(d_b-n_b))>=4`. This rules out slot 0 by the actual outer H bound.

## 2. Old alternate slot 3 at 2w+b

For `z=2alpha-y>0`, its genuine centered grades are
```
s=gamma(r-4)-4z,   t=Gz-2(r-4)/T.
```
On odd sites let `M_b=(d_b-n_b)/2` and `m_b=|d_b-2n_b|`. The actual earlier covered b support equals its H rectangle on this parity, by STANDARD_NATIVE_COVER_CORE_AND_INNER_HULL_EQUIVALENCE.md. Its centered bounds are `[-m_b,T_b+m_b]` and `[-T_b-M_b,M_b]`. Here `s>-2` since `z<alpha<1/2` and `r>=5`. As s is integral and `m_b>=1`, the lower s facet is automatic. Also `t>-2(n-4)/T>-1` and `s<gamma n=n_b+2(d+n)/T<n_b+1<T_b`. Thus membership in slot 3 is **equivalent** to `t<=M_b`. On the true step-two mesh this is exactly
```
z < [M_b+2+2(r-4)/T]/G.
```

## 3. Two adjacent genuine p cells, including the old alternate slot 4

The source P+v and the retained P at zero are separated by the true p longitudinal period `2p`. In grades relative to P+v their occupied inner hulls jointly include
```
-m_s(p)<=s<=4T_p+m_s(p),   -T_p-m_t(p)<=t<=m_t(p),
```
where both margins are the actual physically odd standard margins. In the candidate strip their grades are `s=Kx-2y>0` and `t=x-Ky<0`: for the latter use `Ky>K alpha=T_p+2/T` and `x<1+alpha<3/2`. Thus both tests
```
Kx-2y <= 4T_p+m_s(p),   y <= alpha + (x+m_t(p)-2/T)/K
```
suffice. In particular, with `x<=4alpha` the first is automatic: `Kx-2y<4T_p+(8-2K)/T<4T_p`. This pays above the previous bound `y=alpha` on this side of the slot 0 cutoff. These two p cells are genuine also for a corrected old birth, wherever the same candidate inequalities hold.

## 4. Old alternate slot 2 at w

Set `u=y-alpha>0`. The actual intact b copy at w has centered grades (with origin `(2alpha+beta,alpha+beta)` in the central chart)
```
s=T_b+gamma(r-2)+4u,    t=-G u-2(r-2)/T.
```
This copy **never** supplies a point of this residual strip. Indeed
```
| |d_b-2n_b| - gamma |d-2n| | <= 2(3d+n)/T < 2gamma,
```
because `b=gamma q-beta f` and `G=s_q(b)>=4d+2n>3d+n` for proper even b. The hypothesis `r>|d-2n|+2` and `u>0` therefore give `s>T_b+|d_b-2n_b|`, outside the actual H enclosure (not merely outside some chosen period cell). Thus slot 2 cannot close what the other suppliers leave.

## 5. The other two ordinary base slots are absent

The ordinary source table gives slot 1 by translating slot 2 by e. Its centered longitudinal grade is therefore
```
s_1=-2s_b(p)+gamma(r-2)+4u < -2s_b(p)+n_b+3 < -|d_b-2n_b|.
```
Here `T_b-G=-2s_b(p)`, `4u<2`, and `s_b(p)>=(d_b+n_b)2+(d_b-n_b)=3d_b+n_b`. This is again a strict H exclusion.

The last p slot (slot 5) is the old alternate reflection of its retained slot 4 at zero. The reflected address has coordinates `(1+2alpha-r/T,1+beta-y)`. Relative to P at zero, its longitudinal grade is `K-alpha r-2+2y`. Since `K-2T_p=s_b(p)`, `alpha r<n_p`, and `s_b(p)>=4d_p+2n_p` (proper b), the excess over `2T_p+|d_p-2n_p|` is strictly positive. Thus slot 5 is excluded.

In particular above alpha=1/4, if the lower test in §3 and the exact slot 3 test in §2 both fail, then no ordinary base slot of the old alternate pays the literal address. A payment *inside that alternate* must come from its seventh donor, if present. Other independent suppliers in the full child union are not excluded by this calculation. No point failing these tests is claimed to be globally uncovered.
