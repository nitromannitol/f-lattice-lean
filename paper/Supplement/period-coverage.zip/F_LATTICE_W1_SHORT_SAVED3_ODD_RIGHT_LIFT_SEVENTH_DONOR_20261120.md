# Eventual W1 SHORT native cover for strict saved3 ordinary old births

20 November 2026. Hand proof.

Use all hypotheses and notation of F_LATTICE_W1_SHORT_SAVED3_ODD_MIDDLE_STRIP_ACTUAL_CELL_COVER_20261120.md, including ordinary old even ALT D and own cover of the earlier tiles. Thus b=q-2p is proper, e=q, and the remaining candidate a has central coordinates x=1+r/T, alpha<y<2alpha, with r odd and |d-2n|+2<r<=n. The fixed-corner two-lift result proves a or a+e belongs to D. Here we show a+e cannot belong to any of the six actual standard base slots. This holds for the whole candidate strip, without requiring alpha>1/4.

Write m_q=|d-2n|, m_b=|d_b-2n_b|, m_p=|d_p-2n_p|, J=s_b(p)=K-2T_p. The old b and p standard long grades on this physical parity are enclosed by [-m_b,T_b+m_b] and [-m_p,2T_p+m_p], respectively, by the audited native H. Translation of the query by e increases centered s_b by G and centered s_p by K; the old P-slot reflection reverses this sign. The following checks use the genuine source bindings:
 
* Slot 0, the b copy at 2p: the centered s for a+e is 2T_b+gamma r+4y. Indeed x+1-4alpha=2gamma+r/T, and G^2-T T_b=8. This exceeds T_b+m_b.
* Slot 1 at e+w: its query at a+e has the same grade as slot 2 at a, which is strictly beyond T_b+m_b by the preceding note.
* Slot 2 at w: its query at a+e has even larger s than its query at a, so is also outside.
* Slot 3 at 2w+b: the earlier s at a is >-2, so after translation it is >G-2>T_b+m_b. Use G-T_b=2J and J>=4d_p+2n_p. Also J>=3d_b+n_b by d_p>=2, n_p>=1; in particular 2J>m_b+2.
* Slot 4 at zero, the retained p copy: the centered s for a+e is 2K+alpha r-2y-2T_p. Its excess over 2T_p is 2J+alpha r-2y>2J-2>m_p.
* Slot 5, the actual old-ALT reflection of slot 4: the centered slot 4 grade of the reflected a+e is -alpha r-2+2y. Since both r and m_q are odd, r>=m_q+4. Also 2y<4alpha, so this score is <-alpha m_q-2. From p=alpha q+f/T one has |m_p-alpha m_q|<2, by (3d+n)/T<2. Thus the reflected score is <-m_p.

Consequently, whenever a+e is present, its representation in D requires the actual seventh donor. In particular, an independent exclusion of the seventh donor from a+e at any such address forces the *left* address a to belong to D, by the proven two-lift alternative. Conversely, if the left address is outside all six base slots, the same alternative forces the seventh to meet one of these two exact addresses. These implications apply to the literal support, not the filled hull of D and not just the support of a chosen deck representative.

## The genuine seventh donor also misses the right lift

Assume now that the actual creator of the old odd donor had strict parents, so its reviewed own-creation R2 enclosure applies. The ordinary even alternate D itself can only have been born at last digit 1 or 2 (even ALT at digit 3 is corrected). Its phase in our setting is W1. The actual restored seventh origins in these respective cases are w+b and 2b+V_b; these use the prior **current** odd alternate, not a retained alternate or a newly created output. The strict creator requirement holds for ordinary old births after the first mixed transition. See ACTUAL_ORDINARY_CALLER_AND_RETAINED_PARENT_BINDING, the ordinary-alternate seventh source enclosure and the TRUE_CREATOR_BINDING notes in the 19 November recovery audit.

Use q coordinates in the same central chart and center the old donor grades at its native B. With V_b=f-2w, the two centered longitudinal grades of a are
  last 1: alpha*r-2y;
  last 2: (2-J)+alpha*r-2y.
Indeed the respective origins in q coordinates are (gamma+beta, alpha-beta) and (2gamma-2beta,gamma-2beta). To compute either grade, subtract the appropriate origin and also (2alpha,beta) from the central coordinates, then apply (K,-2). In the second case K*gamma=J-4/T, so the constant is exactly 2-J. Translation by e adds K to either grade.

The true odd-donor R2 longitudinal interval after centering is
  [beta_old-m_p, beta_old+2T_p+m_p-2].
The true creator phase is 0 at last 1, giving beta_old=0, and 1 at last 2, giving beta_old=2-J: the actual last-2 creator has p=A+B0 and b=B0, so its mixed-plus-even norm is s_b(p)=J. Thus in either case the right lift has centered grade minus beta_old equal to K+alpha*r-2y. Since r>=m_q+4 and 2y<4alpha, this is >K+alpha*m_q. As |m_p-alpha*m_q|<2, it strictly exceeds 2T_p+m_p-2 (in fact by more than J). Therefore the actual seventh donor cannot supply a+e.

## Conclusion

The six base slots and the actual seventh donor exhaust the old ordinary even ALT. They all exclude a+e, while the genuine old-row argument from assumed own cover puts at least one of a and a+e in D. Therefore a belongs to D at *every* thin-strip address in both strict ordinary-old-birth cases, with no restriction on alpha. The old D arm pays the entire remaining fixed corner. Together with the verified moving seams, bounded localization, reflection and the exact stationary supplier test, this proves full native quotient cover on both physical parities for every sufficiently long 2-suffix after each such fixed proper saved-last-3 history, under the stated earlier covers. This does not yet treat literal first-mixed odd donors outside the strict R2 theorem, corrected old even ALT births in the balanced or upper physical-odd sector, arbitrary saved-last-1 histories, or short 2-suffixes.
