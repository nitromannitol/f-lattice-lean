# W0 LONG: exact finite transfer from the actual W0 SHORT middle

20 November 2026. Hand proof, independently audited. This proves a finite conditional transition for the corrected odd alternate, not a claim about endpoint helpers or an unconditional identification of W0 and W1 histories.

Fix a proper saved W0 2-run record with genuine p odd type, q even type, det(p,q)=+1. Assume the actual prior growing standard E_j for S=p+jq covers its own quotient, the old standards cover, the genuine physical W0 SHORT fixed middle is paid after the transported chart change by its three actual P/Q-upper/D suppliers, and the normalized old D has the lower bound D'_x+2alpha>=0 in that chart. The latter conditions hold in the strict old-creator W0 stationary analysis; literal exceptions need their own proofs. Under these conditions, the corrected odd alternate using LONG has native cover for every j>=1.

## Exact physical union

Put e=q, f=V_q, w=V_p, B=(1/2,-1/2), S=p+je, and O=S+e. The physical actual native periods are U_O=2S+2e and V_O=V_S+f. Write supports centered at B in this paragraph. The audited ordinary W0 odd-ALT slots are Q@0, Q@(2S+2V_S+e), E_j@e, E_j@(e+f+V_S), with LONG LEFT at 2e+V_S and RIGHT at f. The true corrected-prefix and G3 tables are in §§2,6,7 of 'All corrected G1/G2 prefixes lie in the replaced H; four G3 endpoints suffice', 19 November recovery audit.

The two E_j sources agree modulo V_O. RIGHT G1 and Q@0 give Q+[0,j]f. LEFT G1 and the true far Q slot give Q+2S+e+2V_S-[0,j]f, hence Q-e-[2,j+2]f after subtracting U_O+2V_O. RIGHT and LEFT G2 are P+(j+1)f and P+(2j+2)e+V_S, hence P-w and P-2p-f after subtracting real deck columns. LONG G3s are D+V_S+ell*e and D+V_S+(2j+2-ell)*e for ell=1,...,2j. After subtracting V_O their union is D-f+[1,2j+1]e. Thus the physical finite quotient union is exactly
   E_j+e; Q+[0,j]f; Q-e-[2,j+2]f;
   P-w; P-2p-f; D-f+[1,2j+1]e.
No E_1 unroll or generic literal R2 is used.

## Exact transported W1-form union

In q coordinates let M(x,y)=(-x,y), p'=-Mp, w'=Mw and S'=-MS. Then M(e)=-e, M(f)=f, p'=(alpha,1/T), w'=(beta,alpha) and beta=2/T. Orient the transformed periods as U'=-M U_O, V'=M V_O. Apply the centered output transformation a' = c+M(a-B), c=2S'+e. The actual transformed masks are E'_j=2S'+M E_j, Q'=e+M Q, P'=2p'+M P, D'=e+M D. A physical source translation o is transformed by adding c+Mo minus the corresponding mask gauge. All these gauges are parity preserving translations on the transported affine mesh, not an assertion that M is integral on the original square lattice.

Reducing the transformed origins modulo U',V' gives exactly
   E'_j; Q'-2e+[0,j]f; Q'-e-[2,j+2]f;
   P'-e-f; P'-2p'-e-w'; D'+2p'-f+[-1,2j-1]e.
For example the D index i transforms to 2j-i because its gauge is e; the two P origins exchange order. This is the literal finite W1-form LONG table. The absolute centered reflection of the physical W0 odd alternate before quotient reduction is the sum of its two actual E_j corners; after applying 2c+M to that sum it is 2S'+2W_S'+f, which becomes -2e-f modulo U',V'. Thus the actual transformed reflection is (x,y)->(-2-x,-1-y).

Each transformed true H/I rectangle has the same longitudinal and transverse margins as the original physical one, because the gauge maps the standard's period coordinates (u,v) to (1-u,v). The actual finite proof in F_LATTICE_W1_LONG_ODD_ALT_ALL_POSITIVE_LENGTHS_HAND_THEOREM_20261120.md now applies on the transported mesh, with the W0 constructive P/Q/D middle substituted for W1. In particular both finite columns and the D index bound use actual sources, and the requested stationary upper-Q index is zero even using the outer H. The only equality check involving a literal integral site is replayed next.

## Literal equality row on the transported mesh

Let M_q and M_S denote the genuine occupied unscaled transverse margins on the selected physical parity, and h=j+alpha. Physical S=h*q-f/T in W0. The segment of rays from physical q to S consists of unimodular neighbors and cannot strictly contain a primitive functional break ray of denominator at most five. Choose the correct margin piece F(z)=d_z*g_y-n_z*g_x with half-odd g_x,g_y; then M_q=F(q), M_S=h*M_q-F(f)/T and
  delta=h*M_q-M_S=F(f)/T=-s_q(g)/T, |delta|<1.
The original integral site B+g-f maps, in the centered transported mesh, to M(g-f), with y=-1+M_q/T and x=delta. All other transported sites on this literal equality row differ by integral e shifts, since original q is primitive. Hence x>0 on that row implies x>=delta just as required for the occupied E'_j-V' lower transverse facet. This is the correct sign after reversal, not the W1 formula with the original, untransported integral site.

All other finite facet and column inequalities are unchanged; the coefficients and true row/column meshes are the same. Therefore the entire corrected W0 odd alternate LONG is covered at every j>=1 in the stated domains. This is conditional on the proven genuine middle inputs of the corresponding W0 SHORT case; it does not use W0 SHORT coverage as a global black box or cover an unproved physical initializer.
