# W1 SHORT covers its native quotient at every positive suffix length

20 November 2026. Hand proof, in the exact live source frames, without numerical search. This is a transition theorem for the corrected even standard SHORT branch, not an all-word coverage or recurrence assertion.

**Theorem.** Fix a proper saved-last-1 or saved-last-3 W1 record. If its genuine earlier standard/alternate cover hypotheses hold as in the eventual-cover theorem, the actual W1 SHORT target X=2(p+jq)+q covers its native quotient on both physical parities for every integer j>=1. Here j is the source-layout index (one greater than the raw saved-helper gap index). There is no required delay within this branch.

The companion F_LATTICE_W1_SHORT_UNIFORM_J_GE_2_AND_SAVED3_ALL_LENGTHS_20261120.md proves all j>=2, and also j=1 for saved-last-3; the verified matched near-one theorem already includes old literal pure2 histories. The remaining case is j=1 with saved-last-1, for nonliteral old pairs and the literal reciprocal old pair (including root). The proof below completes those cases under the same hypotheses. It uses the genuine earlier row-nonemptiness and fixed-history stationary theorem, not an induction on the unproved short length.

## 1. The j=1 wrapped boxes are wider in the saved-last-1 chart

Use q=(d,n), e=q, f=V_q, B=(1/2,-1/2), alpha=s_q(p)/T>1/2, beta=2/T, T=T_q, v=-2p, w=V_p, and h=1+alpha. Thus h>3/2, beta<=1/7, and the two growing-standard columns in (e,f) coordinates are (2h,beta),(beta,h). Their determinant in these coordinates is Delta=2h^2-beta^2. Let M_s and M_t denote the genuine occupied stationary Q's normalized inner margins (grade margin divided by T). In particular M_s<=d/T and M_t<1/2. Write the central chart as a-v-B=x e+y f. The centered child fundamental parallelogram at j=1 has representatives with
  |x|<=3/2+alpha+beta,     |y|<=3/2+alpha+beta/2.
Define R=3/2+alpha+2beta. The following bounds will be used:
  R<=2h-beta,       R+M_s<3.
The first follows from 3beta<=1/2+alpha. For the second, T(1-alpha)=s_q(q-p)>=d+n gives R+M_s<=5/2+(4-n)/T<3.

In the normalized wrapped chart a=f+a0, write a0-v-w-B=x' e+y' f. I claim the j=1 actual tile pays the entire box |x'|<=R, 0<=y'<=2. The actual wrapped reflection is (x',y')->(-x',2-y'); reduce to 0<=y'<=1, and put s=1-y'. Use the following four finite-source payments. These are the same actual corners and rungs as in the companion finite wrapped-box proof, now with the larger R.

* If x'>1, the actual far growing-standard upper-left corner is (1,1) and the inward edges are +2S,-V_S, S=p+q. The unit coefficients from that corner to the point are (h*(x'-1)+beta*s)/Delta and (beta*(x'-1)+2h*s)/Delta. Both numerators are nonnegative. The first is at most h*(2h-beta-1)+beta<=Delta, since h>3/2 and beta<=1/7. The second is at most beta*(2h-beta-1)+2h<=Delta because 2h*(h-1-beta)+beta>=0. The actual covered S period rectangle pays the point.
* If -M_s<=x'<=1, the actual top Q column copy already covers all such y' in [0,1] by its inner rectangle.
* If x'<-M_s and y'<1-M_t, put r=-x'. Both r and s are at least beta by the actual old physical mesh: T*x' is odd, T*M_s>=1, and T*y' has the parity of T*M_t. Also r<=R<=2h-beta and s<=1. The far growing upper-right corner (0,1), in the deck chart with one horizontal subtraction, has inward distances from this point with coefficients (h*r-beta*s)/Delta and (2h*s-beta*r)/Delta. They are nonnegative since h*r>=beta*s and 2h*s>=beta*r. They are at most one since h*r<=2h^2-h*beta<=Delta and 2h*s<=2h<=Delta. This again gives a real occupied S witness.
* If x'<-M_s and y'>=1-M_t, reflect to (x'',y'')=(-x',2-y'), so x''∈[0,R] and y''∈[1,1+M_t]. The genuine j=1 top Q rung includes exactly the indices 0,1,2 needed here: n0=floor(x''+M_s) lies in [0,2] since R+M_s<3. The adjusted point lies in the true occupied Q rectangle. This is the actual finite rung from the upper G1 column and the far Q triangle.

Thus the bigger wrapped box is proved. For a centered representative with y>=1+alpha, its wrapped coordinates are x'=x-beta, y'=y-1-alpha∈[0,1/2+beta/2]. For y<=-alpha, add the genuine vertical child period V_X=(2beta,3+2alpha) in central coordinates and use x'=x+beta, y'=y+2+alpha∈[1/2-beta/2,2]. In both cases |x'|<=R. It remains to consider only
  -alpha<y<1+alpha,     |x|<=3/2+alpha+beta.
This band and horizontal bound are preserved by the genuine stationary expression of child reflection (x,y)->(-x,1-y).

## 2. All but one finite stationary index already truncate

Every fixed physical address has an actual stationary source witness by the exact stationary characterization and eventual-cover theorem. As in the j>=2 companion proof, apply this fact to each representative at j=1, holding that address fixed only for the auxiliary eventual test. The Q columns, two isolated P terms, and far P/first-Q/second-Q terms have exactly the required finite ranges already at j=1. The latter arguments use only the indicated central band and horizontal bound. Likewise the negative D tail cannot be a witness after reflecting to x>=0, by D_x<2.

For the positive D head, x=D_x+2alpha+i. Its normalized base is positive. If i>=2, necessarily D_x+2alpha<=alpha-1/2+beta. This is impossible: for genuine nonliteral saved1 old D its real restored lower s facet gives
  D_x+2alpha>=1-(n+2+E)/T >=1-(d+2)/T > alpha-1/2+beta,
where (d+4)/T<=1/2 and alpha<1. For the literal reciprocal mask its actual s>=-K, K=alpha*T, gives D_x+2alpha>=alpha-1/T>alpha-1/2+beta because T>=14. Thus i<=1, exactly the authentic j=1 head range.

The only possible failure of direct truncation is the near stationary Q ray, Q+v+n'e-kf, with k=1,n'=2 (or its exact reflected test). All other indices are retained by the companion proof: k=1 on this band, n'<=2, and n'=0 or 1 is directly supplied by the genuine near Q triangle with h-index zero. For a witness at n'=2 write its coordinates as x=2+Q_x, y=Q_y-1, with Q_x,Q_y coordinates of a genuine Q site centered at B. In particular
  x>=2-m_s/T>3/2,      y<=M^H/T,
where m_s<=d is the actual centered Q s margin, and M^H the unscaled outer Q t margin. The following two tests replace this missing index.

## 3. Payment of the only missing near-Q index

If y<=M_t, where M_t is the normalized inner Q margin, use the actual near S growing upper-left corner in the CENTRAL chart, located at (0,0). Relative to this vertex the centered increments are
  s_S=T*h*x-2y,     t_S=x-T*h*y.
The second is to be compared with [-M_t(S),T_S+M_t(S)] in unscaled grade units, where M_t(S) denotes the actual unscaled inner S transverse margin. The homogeneous inner transverse margin function on positive vectors is (D-N)/2 at odd physical parity, |D-3N|/2 at even parity below slope 1/2, and |5N-3D|/2 at even parity above slope 1/2, continuous at the break. Its linear pieces have absolute derivative at most 4d+n in direction f. Since S=hq+f/T this gives
  |M_t(S)-h*T*M_t| <= (4d+n)/T < 1.
For the last inequality use d=3,n=1 directly, or T>=d^2+2d-1>5d when d>=4. Hence t_S+M_t(S)>=x-1>0. The opposite t facet holds since y>-alpha and T_S-(T*h*alpha)=T*h-2/T>x. The s increment lies in (0,2T_S): use x>3/2, |y|<2, T_S=T*h^2-2/T and x<=3/2+alpha+beta, so 2h-x>=1/2+alpha-beta. Thus the genuine occupied S rectangle at this actual near corner covers the point.

If y>M_t, its native Q witness must lie beyond Q's inner transverse margin. This can only happen at physical even parity in the sector n>d/2, since I=H on the other parities/sectors. The old pair here is nonliteral, since literal reciprocal is low-slope and the matched pure2 branch is already disposed of. The actual old D nonemptiness on the literal central rows (including the high-even nonunique strips) has already been proved; this address is in that range since M_t<y<=M^H/T<1/2<=1-M_t. Its x satisfies
  x>=2-n/T > 2alpha+(n+2)/T
because T*(1-alpha)>=d+n>n+1. The upper bound on actual high-even saved1 old D, with E=0, is s_q<=T+2n+2, and the displayed strict inequality implies s_q(a+e)>T+2n+2. Thus some actual point of the nonempty D row lies at or to the left of a in exact e-steps, giving a genuine nonnegative head witness. Section 2 proves that any such witness is already at finite index i<=1. This supplies the last possible high-even case without presuming that optional Q strip sites are retained in I.

For the reflected near-Q stationary test, apply the same exact payments to the reflected address, then reflect the actual witness back at finite j. All required bounds are preserved. This finishes the j=1 saved1 case. Together with the j>=2 and saved3 proofs it establishes the theorem at every positive suffix index; no other phase or corrected output is inferred.
