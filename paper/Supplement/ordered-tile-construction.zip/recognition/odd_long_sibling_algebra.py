import sympy as s
from pathlib import Path
import json
D=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/recognition_ledger/saved3_gate')
d,n,e,r,k,i,x,y=s.symbols('d n e r k i x y');A=s.Matrix([d,n]);R=s.Matrix([e,r]);Z=2*A+R;C=A+k*Z;O=C+Z;z=s.Matrix([x,y]);delta=s.Matrix([1,-1]);b=lambda X:s.Matrix([X[1],-X[0]]);v=lambda X:s.Matrix([X[1]-X[0],sum(X)]);T=lambda X:-b(X).dot(v(X));c=lambda X:(T(X)+sum(X))/2;eta=lambda X:(T(X)-sum(X))/2
Y=z+v(C)+i*Z;zp=2*A+v(Z)+delta-z;w=zp+(2*k+2-i)*Z
G=s.groebner([d*r-n*e-1],d,n,e,r,k,i,x,y,domain=s.QQ);out={}
def check(name,p):
 q=G.reduce(s.expand(p))[1];assert q==0,(name,q);out[name]=str(q)
for j in range(2):check('reflection_position_'+str(j),delta[j]-Y[j]-(w-2*O-v(O))[j])
check('second_normalized_zero',b(O).dot(z+i*Z)-c(O)-b(Z).dot(Y)+c(Z)-b(C).dot(Y)-eta(C))
check('first_normalized_old_reflection',-b(O).dot(w)-eta(O)-b(C).dot(Y)-eta(C)-1-(b(Z).dot(z)+eta(Z)-1))
check('old_reflection_offset',b(Z).dot(2*A)-2)
(D/'ODD_LONG_SIBLING_ALGEBRA.json').write_text(json.dumps(out,indent=2));print(out)
