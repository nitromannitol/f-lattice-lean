# Independent whole-crop polygon audit

Verdict: PASS in the strict saved3/W0 scope stated in SAVED3_W0_TWO_CONTACTS_FROM_RAW_MIDPOINT.md: A=(d,n), R=(e,r), dr-ne=1, d-n>=3,n>=2,e-r>=2,r>=1, Z=2A+R=(D,N). This is not an assertion about literal pure endpoints excluded by these hypotheses.

Set T=T_Z, K=M(A,Z), L=D+N, and P=A+kZ for integer k>=1. For every point z of the genuine restored earlier alternate Z crop, and every integer 1<=i<=2k-1, the physical point z+iZ belongs to the closed canonical polygon E(P).

## Actual source enclosure, including low-slope odd loss

I read the all-sector `bounds` function at recovery_20261101_0745/check_strict_corrected_even_primary_support_transport.py, lines16-17. In current t,s notation, its even-alternate W0 rows are
 t in [L-T+2-h,h], s in [b-ex,T+2N+2+ex],
where h=D at odd physical sites, and h=c=D-N in the lower sector / 2N otherwise at even sites; b=-(2+2M(A,R)+T_R)=-T+2K-2; ex=D-3N-2 only for lower-sector odd sites, otherwise0.

Thus the ACTUAL restored crop satisfies
 -T<=s<=T+L, -T<=t,
 t<=D at odd sites, t<=L-2 at even sites.
For the lower-sector odd lower endpoint, b-ex=-T+2K-D+3N>=-T; the exact strict cone has 2K>D+2. Its upper endpoint is T+D-N<=T+L. In other rows use c>=2. No upper-sector-only R2 extrapolation or omission of the odd loss is involved. These are true crop containments, not assertions that every point of a relaxed rectangle is a native source point. The earlier source/R2 theorem remains the stated chronological premise.

## Independently derived odd polygon

For any odd P=(dP,nP), let its even arithmetic dual be (dP+nP,dP-nP). The physical parity-reversing map z -> (-y,x-1)+Udual gives
 tdual=L_P-s_P, sdual=2t_P+2T_P-2nP.
Substituting the genuine even closed-polygon parity rectangles gives exactly:
 even roots: 1-T_P<=t_P<=L_P-1, 0<=s_P<=2T_P+2nP;
 odd roots: nP-T_P<=t_P<=dP, 2-c_P<=s_P<=2T_P+L_P-2.
The shift by Udual and the -1 in x-1 are essential. Since D+N is even, translation by iZ preserves physical parity.

## Whole-crop inclusion

The determinant identities give
 t_A=(K t-s)/T, s_A=(K s-2t)/T,
 t_P(z+iZ)=t_A+k t-i,
 s_P(z+iZ)=s_A+k s+i(K+kT).
In particular the sign of i in the t expression is MINUS: t_A(Z)=-1.

All quantities are integers. Using KD=dT-c, KL=L_A T+2N, K>N and L<T:
 odd: t_A<d+1, hence t_A<=d;
 even: t_A<L_A+1, hence t_A<=L_A;
 all: t_A>-K-2, so the weaker t_A>=-K-2 suffices.
Consequently t_P is below its appropriate upper polygon row. Its common lower bound is
 t_P>=-kT-K-2k-1.
The exact cone polynomial
 T_P-nP-(kT+K+2k+1)>0
puts this above BOTH required lower polygon bounds.

Since 2t<T and s>=-T, s_A>-K-1 and integrality gives s_A>=-K. Since i>=1,
 s_P>=-K-kT+(K+kT)=0.
For the upper bound, K<T and t>=-T imply s_A<=K+L+2, whence
 s_P<=2k^2 T+2kK+(k+1)L+2 < 2T_P.
This lies in both parity-specific upper rows. Both lower s rows also hold, because 2-c_P<=0.

`whole_crop_audit.py` independently verifies four exact determinant identities and ten strict polynomial margins. Substitute n=u+2,d=u+v+5,r=w+1,e=w+h+3,k=l+1: every displayed margin has strictly positive constant and nonnegative coefficients. Hence these are unbounded algebraic proofs, not fitted finite tests. WHOLE_CROP_ARITHMETIC.json records the expanded margins.

## Shielding and frame scope

The inclusion is for z in the restored earlier ALT frame and physical translations +iZ, with P=A+kZ. It therefore licenses application of the ALREADY AUTHENTICATED current-parent polygon identity/comparator at every such whole head, not just native intersections. If a literal operand is exported in a different raw frame, its already-proved restoration must be applied before using z. No new scalar or restoration is inferred from support inclusion.

The conclusion closes the proposed geometric guard for all these heads. Equality or inequality of their values follows only by inserting the separately established head jet and polygon price identity; membership alone is not a new head-height theorem. It uses no current child recurrence, and does not turn an earlier rounded-midpoint hypothesis into an unconditional all-word admission statement.
