# Independent audit: conditional saved3 full-head retention and lower-W0 forcing

2026-11-03. Conditional PASS for:

- STRICT_SAVED3_ODD_L_FIRST_HEAD_IS_FULLY_RETAINED_UNDER_EARLIER_CANONICAL_EVEN_ALT_CALIBRATION.md;
- STRICT_SAVED3_CORRECTED_ODD_ALT_LOWER_W0_FULL_NATIVE_FORCING_FROM_ACTUAL_RETENTION.md.

The first proves full internal retention from the stated earlier calibration, rather than assuming the desired prefix/head equality. The second proves a one-direction whole-native C packet from that retention and the additional explicit paired inputs. Neither discharges its earlier calibration/induction hypotheses or proves current recurrence.

## 1. Scope and chronology

The exact scope is NONLITERAL strict rebuilt savedcore1/core2, A=(d,n), E proper even, det(A,E)=1, E<2A componentwise, d>=5,n>=2,d-n>=3, Z=2sA+E,s>=2. In the forcing application A is renamed D, Z is renamed B, P=D+hB,h>=1, and current odd R=P+B. Literal endpoint creators, arbitrary corelast histories and all-word closure are excluded.

The new substantive input is actual earlier phase0 ALT_Z calibration: protected RIGHT gauge0; actual raw head common chart Fstar; middle R=Z-2A scalar etaA+1; principal A scalar0; and genuine finite HEIGHT center2A+V_Z+delta, gradient a_Z, constant etaZ-1. The candidate-first even-ALT calibration module has been read: its use of earlier retained standard P MAIN values and SAME-ORDER primitive reflection is explicit. The RIGHT normalization modules additionally require admission of that earlier Bhat at the first-head join and recurrence of its strictly earlier odd primitive. These are not current odd admission/recurrence. They remain hypotheses, not consequences of the current theorem.

In particular the repaired one-sided core1 coefficient floor alone is insufficient: epsilon_j>=0 does not imply epsilon_j=0. The present exact common-chart calibration supplies the stronger equality. Canonical active etaS must belong to the actual earlier profile packet in the claimed creator scope; an unrelated clean-only citation does not enlarge that scope.

## 2. Repaired physical gamma

Substituting G(x)=Ahat(x+v)-a_S.(x+v)-etaS into Fstar(t)=G(t-Y)+a_E.t+etaE gives origin Y-v=2A-E+V, slope a_A and coefficient a_S.(Y-v)+etaE-etaS=etaA+1. Iterating the genuine phase1 primitive V character etaA-T+1 gives exactly

 gamma_j=(j^2 T-j L)/2+1.

There is no A4 height shift. The actual primitive reflected value H(y-E), combined with this coefficient, is the same physical reference as the historical formal H(y-E)+1 combined with the coefficient one lower. Thus the all-integer orbit/reflection comparisons survive the repair, but the old raw gamma formula is not reinstated. Core2 uses the stated etaE+(j-1)M+T(j-1)^2/2-L(j-1)/2 and its own phase0 primitive chart.

## 3. Complete reflected-G1 equality

For a fan or principal A owner, q=u+E+2iA-2A-V is genuinely native Z. With K=M(A,Z), the exact identity T s_Z(u)=K s_A(u)+t_A(u), native s_A(u)>=2-T and t_A(u)>=-d give

 T s_Z(q)>=(2s+2i-2)T+2M-d>0.

The native Z upper rows put this same q inside the standard zero strip; hence Z(q)=0. This does not claim a zero roof on arbitrary global Z points. The previously rebound native reflection gives A(u)=a_A.t+etaA+1, and the now actual zero fan/principal coefficients yield equality with the required F(t).

The remaining owner partition is exhaustive under the cited actual-domain receipts: middle R has query q and uses actual retained standard R@0 in Z, so its exact etaA+1 coefficient yields equality; far A, late R and terminal E are excluded where claimed. Actual RIGHT G3 owners have epsilon_j=0 and the genuine primitive H contact, hence exact equality. No head is evaluated as an owner at a prefix-owned point.

For outer LEFT owners the earlier whole Bhat finite HEIGHT maps to actual FIRST RIGHT support. Reflected fan A is absent, reflected terminal E has the already proved exact H contact, and reflected G3 uses the canonical common orbit chart. The virtual index beyond the finite chain is an earlier V-orbit value, not an invented native copy. The old all-integer contact identity is gauge-invariant in this physical chart. Thus the complete reflected-G1 window has equality, not merely the previous inequality.

## 4. Complete reflected-G2 equality

The corrected literal-row/domain receipt excludes both whole LONGs and the far A/late R groups. Principal A at R has query v+2A and its actual coefficient0 gives A(v). For middle R, u=v+R-V is genuinely native R. The earlier middle-R contact proof gives R(v-V)=H(v-V), independently of the superseded G3-origin argument in its historical file; only that valid contact portion is used.

The new bound is sound: T_R t_A(u)=M(A,R)t_R(u)-2s_R(u), with t_R(u)<=T_R+L_R and s_R(u)>-T_R, gives

 t_A(u)<M(A,R)+L+2r_R/T_R+2<M(A,R)+L+3.

Using t_A(u)=t_A(v)+M(A,R), native A's exact lower H endpoint and L+3<2L-2, L+3<3d+n-2 in the strict cone enroll v in its genuine H strip. Consequently A(v)=H(v), and the actual middle coefficient etaA+1 gives Bhat(Z+v)=A(v). No extrapolation from finite samples or from global H roofs to equality occurs.

## 5. Actual max, full crop and later heads

Both reflected overlap reductions now make the first raw odd-L head's excess identically etaA+1 on the complete last-G1/G2 intersections. Nonlast G1 copies are absent by their strict s_Z gap. The mandatory z=V+Z contact is native and gives the same excess. The literal touching maximum therefore selects etaA+1, and every point in the incoming crop survives because its complete overlap agrees with the old prefix.

Later heads miss the entire standard prefix. Their true zero-Z character and genuine adjacent contacts identify one global chart, so they agree on every mutual overlap, not just at the anchoring port. Their full crops are retained. The opposite LONG requires the separately licensed SAME-ORDER inner reflection; ordinary domain reflection alone would not suffice. This proves full internal retention conditional on the named earlier packets.

## 6. Actual LONG endpoints and lower outer coherence

Read original get_l_correction.jl and get_odd_l_offsets. The odd-L standard G1/G2 and alternate G3 choices, affine increments and phase/flip offsets do not depend on the saved final letter being1 versus3. The exceptional all3 initializer translations are excluded here. With k=h-1, LONG has num_iters=2h; it does not perform the SHORT decrement. Both real head endpoints1 and2h are included on both sides, also h=1. Interior indices follow the literal arithmetic progression. The saved3 endpoint checker binds positions, not heights; actual slopes and coefficients are supplied by the constructor and the separate canonical jet modules, not by those positional checks alone.

Read the saved3 W0 RIGHT/profile/all-maxima theorem: its complete first-four outer comparisons use the actual phase0 Bhat floor, an explicit generic standard G1 H comparison, prefix exclusions, and common zero-B head values. Its last two outer operands are calibrated by candidate paired-source completion. These are whole completed-operand equalities. Combining them with the newly proved internal raw-head equalities and earlier standard-prefix coherence genuinely retains every flattened lower primitive leaf. A scalar maximum or completed-LONG equality alone would not have done so.

## 7. Four DAG windows, carried center and first ownership

The four required earlier actual zero-offset DAGs at s0=(b,0) are precisely standard D on D_D-2D, standard B on D_B-B, standard P on D_P-2P, and actual even alternate Bhat on D_Bhat-B. Their upper partners are the actual positive-prefixed primitive outputs, including supplied explicit auxiliary halo derivations. No earlier full odd-ALT DAG is assumed or constructed circularly here.

The containing lower field's genuine extension with U=2R and chi=-1 remains an explicit additional hypothesis. Native retention pays a contact at n+v_lower; this character moves it to n+v_lower-U with the correct value. The actual transform center is so=s0-MB. For all ten rows, covariance gives t=-M^-1(v_upper+Gamma ell_upper)-B, t-U_i=v_lower-U and -M^T ell_upper=ell_lower. The native-to-window chi and target subtraction -chi both occur and cancel correctly in the scalar identity. All four primitive types have zero own primary drift. The result forces upper g+1, not g and not a lift at unshifted s0.

Upper actual finite jets require their own phase1 constructor/HEIGHT module and SAME-WORD STANDARD-before-ALT inputs. Upper whole raw retention is unnecessary: at every actual first-owned native point one uses that actual occurrence and its exact effective value. Sourcewise transported DAGs force those values plus1. Keep coincident occurrence labels and every explicit halo derivation separate; finite union introduces no recursive use of the current conclusion.

## 8. Replays and verdict

Fresh runs: check_saved3_exact_ordinary_contact_windows.py PASS14; check_saved3_corrected_odd_long_covariance_binding.py PASS28; check_corrected_odd_alt_full_forcing_covariance.py PASS58 per phase,116 total. These corroborate the analytic source/owner arguments above, not substitute for their hypotheses.

Verdict: full retention IS proved as a conditional implication under earlier canonical Bhat calibration and the listed genuine standard/primitive packets. It is NOT an unconditional saved3 initializer or a discharge of earlier Bhat admission, recurrence, same-word compatibility, profile normalization, or DAG existence. The forcing assembly additionally assumes the true lower extension, four actual earlier DAGs and upper constructor jets. Under them the lower-W0 carried-center whole-native C statement is valid. Opposite lower-W1 retention, current A/B, current lift identification, recurrence and a well-founded all-word induction remain separate.
