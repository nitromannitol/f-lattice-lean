# Independent W0 odd SHORT nominal upper-x audit

2026-11-02 17:52 UTC. Full source/checker read and fresh replay PASS for `ROOT_W_ZERO_ODD_SHORT_CORRECTIONS_HAVE_THE_NOMINAL_UPPER_X_BOUND.md`; six positive-polynomial checks and two RIGHT-chain coordinate identities pass.

Independently recovered the even-ALT R2 upper rows from the adopted formula: phase0 b0=-2-L makes even tmax=T+2r+2, while the lower-sector odd extension gives T+(e-r); phase1 b0=0 gives T+L+2r or T+L+(e-r)+2. The stated s maxima are exact safe rows. Substitution into x=((e-r)s+e*t)/T gives precisely the six displayed excess polynomials, all strictly below2T. The phase1 inequality0<L<T follows T-L=4T_S+2M(S,R0)>0. No narrow balanced-only row is used.

Read literal `get_staircase_even_alt` and `get_doubled_ladder_even_alt`. The reciprocal-even raw selector has xmax e including all exceptional corners; its native centering is canceled by the actual pure3 A4 displacement (the extra e2 is retained). For near-one even, the flipped parameter is e-1, so raw xmax=(e-1)+1=e; only y recentering occurs and the A4 candidate has negative imaginary part. Thus the literal phase0 x bound is licensed, not inferred from nonbase R2.

The protected-prefix inclusion is domain-only: RIGHT q0/p5 persist at the saved root and each later W0 ordinary odd step places the old standard atY while retaining newq0. LEFT q3/p4 uses the separately audited unchanged fan/seed. This applies also to the corrected savedlast3 root because those exact slots are unreplaced.

Literal `get_odd_l_offsets` W0 RIGHT has K1=Y,K2=Y,K3=VA-Y,K4=Z, so G3 origins are VA+(h-1)Y+jZ with1<=j<=2h-1. The independently adopted restored LEFT origins arejZ in the same range. Both coordinate bounds and the strict sibling e<2a implication e+1<=2a check exactly. SHORT's omission of the extra LONG head is essential and explicitly retained.

Therefore BOTH actual restored W0 odd SHORT supports have x<=2d_X in the stated strict proper savedlast1/3 states and the specified proper literal phase0-source cases. This is only one support row; no whole-H inclusion, source-value compatibility, or LONG bound follows. The endpoint A=0/1 prefix is explicitly left to its separate literal family theorem.
