# W0 odd SHORT corrections have x<=twice the represented denominator

2026-11-02 17:49 UTC. Root analytic DOMAIN theorem, independent audit requested. This supplies one coordinate row, not a full-H or value theorem.

Take an actual W0 odd-L savedlast1/3 record with proper A=(a,b), Z=(e,r), X=A+hZ,h>=1. Both LEFT and RIGHT SHORT, in their actual restored represented-X frames, satisfy x<=2d_X. For savedlast1, actual sibling provenance gives Z<2A componentwise and the consumed Z alternate has creation phase1. For savedlast3 its creation phase is0. Proper literal phase0 Z sources are included by their actual selector x bound below; an endpoint A=0/1 requires its separate literal family theorem.

## 1. Both protected prefixes are actual subsets of D_X

LEFT has the already proved unchanged q3 Z fan and p4 A@2hZ seed inside the actual standard X. RIGHT G1 is Z@iY,0<=i<=h-1, and G2 is A@hY. At h=1 these are unchanged q0 and p5, even if the initial savedlast3 odd creation is corrected. Each further ordinary letter2 retains the previous X at Y and adds q0 at0, giving the entire RIGHT chain/terminal seed. Thus BOTH actual protected prefixes lie in D_X and inherit the standard upper coordinate2d_X. No assertion about equality of their heights is used.

## 2. A coarse actual even-ALT x bound

Let c=e-r,T=T_Z. For a nonbase even alternate in phase0, its actual R2 rows give

 even: s<=c or2r, t<=T+2r+2;
 odd: s<=e, t<=T+max(2r+2,c).

For phase1, put L=2M(S,R0)+T_R0 for its actual creation Z=2S+R0. Then0<L<T and

 even: s<=c or2r, t<=T+L+2r;
 odd: s<=e, t<=T+L+max(2r,c+2).

Use x=(c*s+e*t)/T. In every displayed case the numerator beyond eT (and beyond eL in phase1) is STRICTLY less than2T. The only expressions to check are

 c²+e(2r+2), 2rc+e(2r+2),
 e(e+r+2), 2ec, e(e+r), 2e(c+1).

All are<2T for e=r+c,r>=1,c>=2; this is direct polynomial positivity, independently reproducible below. Therefore

 phase0: x<e+2, hence x<=e+1;
 phase1: x<e+eL/T+2<2e+2, hence x<=2e+1.

Proper literal phase0 reciprocal-even and near-one-even alternates actually have x<=e in their adopted A4-restored selectors, including their exceptional corners. The reciprocal centering/A4 shifts cancel to the literal raw frame; near-one has only y recentering and no further A4 shift. Thus they also obey the phase0 bound without a false R2 extrapolation at reciprocal odd corners.

## 3. The SHORT G3 chains

LEFT origins are jZ,1<=j<=2h-1. In savedlast3 the source phase0 bound gives x<=2he+1<=2he+2a. In savedlast1 the phase1 bound gives x<=(2h+1)e+1<=2he+2a, since actual Z<2A implies e+1<=2a. This is2d_X.

RIGHT origins are o+jZ, o=V_A+(h-1)Y,1<=j<=2h-1. Their maximum x is at most

 he+(h-1)r+b-a+xmax(ALT_Z).

To bound this by2a+2he it suffices xmax(ALT_Z)<=3a+e-b+(h-1)(e-r). The phase0 bound e+1 satisfies this immediately. The phase1 bound2e+1 also does, because e+1<=2a<=3a-b. Thus every RIGHT G3 source satisfies the same row.

All statements concern actual source support and SHORT length. The extra LONG head is not included. An arbitrary neighboring pair without the stated savedlast1 sibling provenance cannot use e<2a. This theorem does not fix touching constants or identify an alternate/standard field.
