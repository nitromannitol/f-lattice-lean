# Strict saved3 odd-L first head: full retention from earlier canonical even-ALT calibration

2026-11-03. Conditional strengthening of the repaired first-head scalar theorem. This proves equality on both complete actual prefix/head interfaces, rather than inferring equality from its previous one-sided bound. Earlier containing even-ALT calibration is an explicit induction input. No admission, character or recurrence of the CURRENT odd output is used.

## 1. Scope and exact additional earlier inputs

Let A=(d,n), E=(e,r), det(A,E)=1, Z=2sA+E, s>=2, R=Z-2A. Require the actual strict rebuilt savedcore1 or savedcore2 history, d>=5,n>=2,d-n>=3, E proper even, E<2A componentwise, and the prior literal native/domain packets. Put V=V_A, Y=V_E, T=T_A, L=d+n, M=M(A,E).

Use the earlier standard canonical retained-source, true zero-character/secondary-character, finite HEIGHT and exact zero/H-contact packets for A,E,R,Z. Use the actual earlier odd primitive phase1 in core1 or phase0 in core2. Its source-normalized active, true secondary and finite HEIGHT packets have the canonical gauges, including etaS rather than etaS+1 in core1. The canonical repair is SAVED3_CORE1_CANONICAL_PRIMITIVE_JET_AND_HEAD_COEFFICIENT_HAVE_THE_REQUIRED_COMBINED_LOWER_BOUND.md, independently accepted by root after the gauge-parametric audit.

The new substantive earlier input is the ACTUAL calibrated phase0 even alternate Bhat=ALT_Z:

- The first RIGHT prefix gauge is kappa_R=0.
- Its actual raw head charts are the canonical global Fstar, not merely charts lying above a formal reference.
- The actual middle R coefficient is etaA+1, and the actual principal A coefficient is0.
- Bhat has its genuine finite HEIGHT with center C_Z=2A+V_Z+delta, gradient a_Z and constant etaZ-1.

The first two inputs are supplied in the stated creator scopes by PHASE_ZERO_SAVEDCORE1_REFLECTED_HALFPLANE_FORCES_RIGHT_HEAD_NONPOSITIVITY.md or PHASE_ZERO_SAVEDCORE2_FIRST_RIGHT_HEAD_AND_NORMALIZATION_ARE_CANONICAL.md. Those inputs explicitly use recurrence of the strictly earlier odd primitive and admission of Bhat at its calibration join. They do not use recurrence of the current odd output. The canonical middle/principal constants and finite HEIGHT follow from CURRENT_PHASE0_CORRECTED_EVEN_ALT_ALL_OUTER_SCALARS_AND_HEIGHT_CALIBRATE_CANDIDATE_FIRST.md with its earlier standard-P retained MAIN compatibility and j=s-1. They remain conditional inputs here; this theorem does not itself discharge that earlier admission or same-word standard compatibility.

An equivalent route to the head-chart input is a separately proved candidate-first calibration plus the appropriate creator-specific full companion comparison. Do not replace it with the older one-sided saved3 gamma bound.

## 2. Exact raw head coefficients, with the repaired core1 gauge

The actual FIRST RIGHT sources inside Bhat are A@E+2iA (0<=i<=s-2), E@0, and the corrected literal odd primitive heads.

For core1 write A=S+T0,E=2S+T0, v=V_S-T0 and

 G(x)=Ahat(x+v)-a_S.(x+v)-etaS.

The calibrated chart is Fstar(t)=G(t-Y)+a_E.t+etaE. Rewriting it in the actual primitive frame gives origin Y-v=2A-E+V and slope a_A. Its first effective coefficient is exactly

 a_S.(Y-v)+etaE-etaS=etaA+1.

The genuine primitive V character then gives

 o_j=2A-E+jV,
 lambda_j=j*a_A,
 gamma_j=(j*j*T-j*L)/2+1.

No original A4 height shift is introduced. In particular gamma_j is one larger than the withdrawn old reference. The corrected reflected primitive jet is Ahat(y)=H(y-E), so its complete physical G3 comparison is exact.

For core2 the earlier primitive active scalar is0; the actual calibrated chart is Ahat(t-Y)+a_E.t+etaE. Thus

 o_j=Y+(j-1)V,
 lambda_j=a_E+(j-1)*a_A,
 gamma_j=etaE+(j-1)*M+T*(j-1)^2/2-L*(j-1)/2.

These are the exact reference coefficients of the rebuilt core2 module. Later-head calibration uses the previously proved entire-prefix gaps and genuine adjacent native ports; no arbitrary raw-head retention is assumed to obtain it.

## 3. A new exact zero contact for all reflected-G1 A owners

Consider t in Bhat with q=t-2A-V native standard Z. The old reflected-G1 target is

 F(t)=Zstd(q)+a_A.t+etaA+1.

For a protected fan or principal A owner, write t=E+2iA+u with u actual native A and 0<=i<=s-1. The principal is i=s-1. The native standard A rows give s_A(u)>=2-T: odd lower is n-T, and either even lower is 2n-T or d-n-T. They also give t_A(u)>=-d.

Let K=M(A,Z)=2sT+M. Exact cross and translation identities are

 T*s_Z(u)=K*s_A(u)+t_A(u),
 s_Z(q)=s_Z(u)+K-2(s-i)-2.

Consequently

 T*s_Z(q)>=(2s+2i-2)*T+2M-d>0.

All terms have a uniform positive margin for s>=2 and the strict proper A,E assumptions. Since q is ACTUALLY native Z, its upper s row is at most d_Z on odd sites and max(d_Z-n_Z,2n_Z) on even sites. These bounds, together with s_Z(q)>0, put q in the earlier standard global zero strip. Therefore

 Zstd(q)=0.

The previously audited native reflection calculation gives A(u)=a_A.t+etaA+1. Both the fan and principal actual coefficients are0. Thus their complete actual owner values equal F(t), not merely dominate it. This is a restricted two-native-domain contact theorem, not a global zero assertion about all standard Z sites.

## 4. Every other reflected-G1 owner also gives equality

The earlier literal owner exhaustion remains in force:

- Middle R at2A+V has native query q. The earlier standard Z actually retains its first R@0 source, so Zstd(q)=R(q). Its exact actual coefficient etaA+1 makes its value exactly F(t).
- Far A and late R are absent by the accepted actual-domain exclusions.
- The FIRST RIGHT terminal E source is absent by the accepted terminal-E support certificate.
- For every actual FIRST RIGHT G3 owner, the rebuilt standard-Z H-contact proof applies and the corrected canonical coefficients in Section2 give exactly F(t). This uses that owner's actual raw value, not a raw-head label at a prefix-owned point.
- An outer LEFT owner reflects into the FIRST RIGHT through the earlier genuine finite HEIGHT. Reflected fan A is absent. Reflected terminal E gives exact equality by the accepted native standard H-contact proof. At a reflected G3 owner, the canonical common chart has exactly the same finite reflection as Bhat, and the all-integer virtual-copy target identity gives F(t) exactly. A virtual index beyond the finite chain is used only as a genuine earlier V-orbit value, never claimed to be an actual retained native crop.

These are precisely the corrected groups in SAVED_THREE_REFLECTED_G1_LEFT_OWNERS_CLOSE_BY_CORRECTED_RIGHT_ORBITS_AND_STANDARD_H_CONTACTS.md and INDEPENDENT_REBOUND_SAVED_THREE_G1_ORDINARY_AND_TERMINAL_OWNER_AUDIT.md. Their geometry is unchanged. Sections2-3 here supply the two formerly missing exact-value upgrades. Thus the COMPLETE reflected-G1 window satisfies

 Bhat(t)=Zstd(t-2A-V)+a_A.t+etaA+1.

## 5. A new exact H contact for the reflected-G2 middle R

The second window is t=Z+v, with v actual native A and t native Bhat. The accepted corrected-domain theorem excludes both whole LONGs, far A and late R. Only principal A or middle R can own t.

The principal A@R query is v+2A. Its value is A(v) by the true zero2A character and actual coefficient0.

For the middle R, u=v+R-V is actual native R. The earlier reflected-G2 contact lemma proves R(v-V)=H(v-V). We now also prove A(v)=H(v), eliminating the old final inequality. Write K_R=M(A,R). Native R has t_R(u)<=T_R+L_R and s_R(u)>-T_R. Its opposite cross identity and mixed-sum identity give

 t_A(u)=[K_R*t_R(u)-2s_R(u)]/T_R
       <K_R+L+2r_R/T_R+2
       <K_R+L+3.

Here K_R*L_R=L*T_R+2r_R and 2r_R<T_R. Since t_A(u)=t_A(v)+K_R, we have t_A(v)<L+3. The actual native A lower t row is exactly the lower H-contact endpoint. Its upper bound L+3 lies below both H-strip upper endpoints2L-2 (even) and3d+n-2 (odd) in the stated strict scope. Thus A(v)=H(v) on the whole actual middle-R intersection.

Using the ACTUAL coefficient etaA+1, the earlier exact middle-R formula now reads

 Bhat(Z+v)=H(v)+(etaA+1)-etaA-1=H(v)=A(v).

Together with the principal owner this proves COMPLETE reflected-G2 equality Bhat(Z+v)=A(v). The old one-sided inequality alone would not imply this conclusion.

## 6. Actual outer first head and all later raw heads

Retain as an ADDITIONAL explicit input the ACTUAL current odd-L protected-prefix packet: after the genuine last-G1 spatial/affine normalization, its last standard Z source at0 is the genuine global standard Z restriction, and its protected A G2 atV_Z has slope a_Z and coefficient etaZ. The entire old G1/G2 prefix has its previously proved retained compatibility. This packet comes from the earlier saved MAIN/prefix theorem, not from the containing finite HEIGHT or the Bhat scalar calibration. Also retain the earlier Bhat GENUINE zero-Z primary character on its global extension. It is a separate earlier character input and does not follow from finite HEIGHT.

In this explicitly licensed prefix frame, the incoming first head is Bhat(z-V-Z)+a_A.z+kappa. The accepted reflected reductions are

 Zstd(z)-Bhat(z-V-Z)-a_A.z
   =Zstd(q)+a_A.t-Bhat(t)+2etaA+2,

 A(v)+a_Z.z+etaZ-Bhat(z-V-Z)-a_A.z
   =A(u)-Bhat(Z+u)+etaA+1.

Sections4-5 make BOTH excesses identically etaA+1 on their full genuine intersections. Earlier nonlast G1 copies are absent by the accepted exact s_Z gap. The mandatory z=V+Z contact exists and has this value. Thus the literal maximum sets kappa=etaA+1 and the ENTIRE first raw head agrees with the existing prefix wherever they overlap. Its full native crop is retained by the minimum operation.

All subsequent current odd-L heads miss the whole standard prefix by the accepted tail-domain theorem. Their true Bhat zero-Z character and genuine adjacent contacts align them with the first global chart, so they too are retained on their full native crops. The paired current LEFT has the same conclusion after the separately licensed SAME-ORDER inner reflection. No new independent outer LEFT scalar is inferred here beyond that explicit packet.

## 7. Exact remaining boundary

This is a full internal raw-head retention theorem for the strict saved3 current odd-L chain, CONDITIONAL on the earlier actual canonical Bhat calibration and its explicit prerequisites. It removes the clipping obstruction for these histories; it does not cover arbitrary literal bases, missing creator normalization, or an earlier Bhat whose only known input is the old one-sided head bound.

It does not itself prove current native admission, current selected-parent contact retention, a full paired forcing DAG, the corrected odd boundary atlas, or recurrence. Those require their own source binding and joint-IH ledger. All earlier admission/recurrence premises named above are for strictly earlier fields and must not be retroactively derived from the current odd recurrence conclusion.

Replay: check_saved3_exact_ordinary_contact_windows.py PASS14 exact new contact/gauge identities and strict positive-cone certificates. Section2's raw gauge also uses the separately audited canonical repair. No cached sample, new generation, or synthetic census is a proof premise.
