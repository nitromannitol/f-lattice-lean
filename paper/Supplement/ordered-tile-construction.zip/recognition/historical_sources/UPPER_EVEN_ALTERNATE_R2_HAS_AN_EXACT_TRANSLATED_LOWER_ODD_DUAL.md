# Upper even-alternate R2 has an exact translated lower odd dual

2026-11-02 13:30 UTC. Exact arithmetic SUPPORT-set identity, not an original finite-domain or value-rotation assertion.

Let P=(d,n) odd,Q=(e,r) even be strict upper creation parents with a_P.Q=epsilon=2W-1. Set R=2P+Q=(D,N), T=T_R, K=mixed(P,Q), Tp=T_P,Tq=T_Q. Define dual creation parents

 p*=((e+r)/2,(e-r)/2), q*=(d+n,d-n),
 R*=p*+q*=((D+N)/2,(D-N)/2).

They have the same phase W, with Tp*=Tq/2,Tq*=2Tp,K*=K. Standard arithmetic duality for even R is

 rho_R(z)=rot(z)+e1-rot(R), rot(x,y)=(y,-x),
 s_R*(rho_R(z))=(t_R(z)+D-N-T)/2,
 t_R*(rho_R(z))=D-s_R(z).

Let

 tau=0 if W=0; tau=V_(p*)-q* if W=1.

Then rho_R(R2_upper_even(P,Q,W))+tau equals EXACTLY R2_lower_odd(p*,q*,W), with physical parity reversed.

## Direct endpoint verification

Upper even ALT has s interval[D+N-T+2-h,h], with h=2N on even sites and h=D on odd sites; its parity-independent t interval is[b,C-b], where

 b=-(1-W)(2+2K+Tq),
 C=T+2N+epsilon(2K+Tq).

The lower odd dual has s interval[C*-h*,h*] with h*=D*-epsilon on BOTH physical parities, and t intervals

 new odd: [b*+3N*-D*,b*+2T*+D*-N*-2];
 new even: [b*,b*+2T*+2N*-2],

where b*=W(2-K-2Tp).

Before tau, the mapped t intervals are respectively[D-2N,T+N-2] and[0,T+D-N-2]. Since3N*-D*=D-2N, D*-N*=N,2N*=D-N and2T*=T, adding t(tau)=b* gives the required endpoints.

For the s upper endpoint, the required shift is

 h*-(C-b+D-N-T)/2=-W(K+Tq/2+1).

The lower endpoint agrees because the reflected endpoint sums agree under the same substitution. For W0 both shifts are0. For W1, exact creation identities give

 s_R*(V_(p*)-q*)=-Tp*-K-1=-Tq/2-K-1,
 t_R*(V_(p*)-q*)=2-K-Tq*=2-K-2Tp.

Thus tau realizes BOTH required shifts exactly. All coordinates are integral: Q is even type, so e,r are odd; p* is integral. Tau has even coordinate sum, while rho_R flips parity. The standard quotient periods satisfy rot(U_R)=-V_R*,rot(V_R)=U_R*, so quotient coverage transports under this affine map as well.

## Scope

This identity may transport a lower abstract domain-cover certificate ONLY after all corresponding A3/A4/A5/A6 source placements and saved creation parameters are matched. It does not identify actual upper and lower native supports or heights. Literal endpoint ALT supports may have extra corners outside formalR2 and require their own separately transformed selectors.
