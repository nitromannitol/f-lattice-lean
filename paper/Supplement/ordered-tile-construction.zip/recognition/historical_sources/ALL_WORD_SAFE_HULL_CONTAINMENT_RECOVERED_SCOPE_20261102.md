# Recovered all-word safe hull theorem: exact current scope

2026-11-02 07:42 UTC. Read the complete assembly and independent final receipt anew.

The already adopted theorem is in `ORIGINAL_ALL_WORD_SUPPORT_RECORD_EXHAUSTION_AND_INDUCTION.md`; independent audit `INDEPENDENT_ALL_WORD_SUPPORT_RECORD_INDUCTION_AUDIT.md` records root adoption November 1 at 19:53. Literal placement audit: `INDEPENDENT_BALANCED_ENCLOSURE_ENGINE_LITERAL_LAYOUT_AUDIT.md`.

For a strict standard fraction n/d let T=d²+2dn−n², s=nx−dy, t=(d+n)x+(d−n)y, μ=2 for odd fraction and μ=1 for even fraction. Every actual finite standard output lies in:

- even native sites: min(2n,d−n)−T ≤ s ≤ max(2n,d−n), 0 ≤ t ≤ μT+2n;
- odd native sites: n−T ≤ s ≤ d, min(d−n,3n−d) ≤ t ≤ μT+max(d−n,3n−d).

This is CONTAINMENT, not equality. Missing lattice sites such as the two word23 sites are consistent with it.

Proof inventory: literal pure standard initialization; fresh 576 ordinary A3 certificates; strict outer SHORT/LONG packets 4480 rows; balanced 4816 inequalities including six literal root cases; all first-mixed initializations; all sixteen nonroot saved-endpoint SHORT/LONG cases. Saved-record chronology and sector exhaustion are explicitly proved in the assembly. Nonbase alternate operands use earlier creation-R2 enclosures; pure alternate operands use literal domains instead. All literal flips and A6 frames were independently checked.

Only support SUBSET of translated operand union is required. Neither current touching-scalar definedness, equality of that union with finite support, current periods, height compatibility, binary labels, nor recurrence is inferred.

**Remaining new task:** intrinsic quotient coverage of the ACTUAL all-word standard domains. It is not a conclusion of the hull theorem. The paper's standard_tile_properties (farey_recursion.tex lines3242ff) provides a domain-only almost tiling for its abstract standard tiles. Applying it to literal code requires an actual-domain identification or sufficient subset inclusion; do not silently import that bridge from affine/height compatibility assertions.
