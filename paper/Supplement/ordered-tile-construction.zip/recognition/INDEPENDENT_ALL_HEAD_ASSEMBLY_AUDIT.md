# Independent all-head assembly audit: strict saved3/W0

Verdict: the final transverse-wrap argument closes the endpoint implication under the explicitly retained earlier-field, native-support and calibrated-source hypotheses. Consequently the conditional corrected-even recognition extends to every actual index1 through2k, including k=1. This is not an unconditional all-word recurrence theorem or a proof of the outer scalar premises.

## 1. Final wrap identity and signs

Use the notation of WHOLE_PHYSICAL_CORRECTED_HEADS.md. On the old lower-longitudinal region set x=z+Z and U=2A, v=V_A. The true P and D functions satisfy, globally,

 P(x)=P(x-U)+D(x)-D(x+v).

This follows simply by expanding their four F_Z values; b_A.U=0, so no scalar remains. Since P(Z)=-1 and D(Z)=0,

 P(z)=P(x-U)+D(z)-D(x+v)+1.

The final +1 is essential. The physical character D(V_Z)=2 has the correct sign, so

 D(x+v)=D(x+v-V_Z)+2.

Thus P(x-U)<=c_A and D(x+v-V_Z)>=0 give

 P(z)<=c_A+D(z)-1.

In particular D(z)<=1 implies P(z)<=c_A. For D=2 the same calculation gives P(z)<=c_A+1, exactly the permitted endpoint credit.

## 2. The wrapped D query is in the complete nonnegative interval

This is the remaining case where x+v fails the LOWER transverse E_Z edge. Let lo_even=2-T and lo_odd=N-T. Its condition is t(z)<lo+K, since t(x+v)=t(z)-K. Put u=x+v-V_Z, so t(u)=t(z)-K+T.

At odd sites the actual old ALT bound t(z)>=N-T+2 gives t(u)>=N+2-K. At even sites its actual bound gives t(u)>=min(2N,c)+2-K. Both exceed the complete interval's lower edge3-D-T: their differences are respectively L-1+T-K and min(2N,c)+D-1+T-K, positive in the strict cone (T>K).

The wrap condition gives t(u)<N at odd sites and t(u)<2 at even sites, hence t(u)<=N-1 or1. Both are below N+2D-1. Thus u belongs to the complete physical nonnegative D interval [3-D-T,N+2D-1]. This is an actual physical-strip argument, not a claim that u is a native vertex. The earlier complete interval theorem is necessary here; the central absolute-value bound alone does not prove nonnegativity.

## 3. The P(x-U) premise and its sole even exception

The old all-sector ALT lower-s row is s(z)>=-T+2K-2-ex, where ex=0 except at low-slope odd roots, for which ex=D-3N-2. Hence

 s(x-U)>=-2-ex.

For odd roots this is at least2-c: in the lower sector it is3N-D, larger than2-c by2N-2; in the other sector it is-2, inside since c>=4. For even roots it is>=-2, leaving only s(x-U)=-2 outside E_Z. The genuine t bounds place x-U in its proper parity E_Z transverse interval in this wrapping case: its t is t(z)+2, the old lower bounds exceed the lower E_Z edges, and t(z)<lo+K gives an upper bound below the upper E_Z edge because K<T. The upper s row is harmless here because z was below its lower s edge, so s(x-U)<T-2K+lo_s<T+lo_s.

At the even lower excursion, the exact gcd/parity argument and transverse interval identify x-U=v, as in the earlier exception audit. Both v and2v lie in the complete harmonic strip, since their s values are-2 and-4. Its true v jet yields P(v)=c_A. All ordinary E_Z points have P<=c_A by the earlier full polygon price span. Therefore P(x-U)<=c_A, including the exceptional point; it does not require an unpriced raw-minimum extension.

## 4. Other cases and endpoint attainment

When s(z) is not below E_Z's lower edge, longitudinal/secondary deck folding gives P(z)<=c_A (forward longitudinal folding only decreases P). In the lower-s case with x+v also in its E_Z chart, the genuine two-A raw gap psi gives

 D(z)=min(0,psi)-min(0,psi-2),
 P(z)-c_A=1_{psi<=0}.

Thus P>c_A forces D=2 directly. The sole remaining transverse-wrap case is closed by Sections1-3. These cover the earlier audited possible failures; no new unchecked upper-s or upper-t extension is introduced.

The exact endpoint equation is

 min(f1,1-D,c_A-P)=min(0,1-D),

where f1=F_C(z)-F_Z(z). The previous independent folded-endpoint audit gives f1>=0 everywhere, f1=0 off the folded region, and P>=c_A on that region. The correlation just proved gives P<=c_A+1_{D=2}.

For D=1 or2 the second offer attains the target and neither other offer undercuts it. For D=0, outside the folded region f1=0; inside it P>=c_A and the correlation force P=c_A, so the third offer attains zero. This proves the endpoint equation uniformly. The previous genuine old-crop reflection exchanges indices1 and2k, so the other endpoint follows with its exact affine correction, not an unqualified pointwise symmetry assumption.

## 5. Final conditional scope

Together with the independently checked intermediate-head reduction, every genuine corrected-even head at y=V_C+iZ+z, 1<=i<=2k, has predicted two-offer value

 M_Q(y)=J_Z(z)+b_C.y+eta_C+1

on the full authentic restored ALT_Z crop. This includes the collapsed k=1 case, whose two heads are both endpoints.

To identify this with actual F_Q, retain the licensed E_Q condition (or restrict to actual standard native points, whose inclusion in E_Q was already authenticated). To identify it with actual G3 values, retain the genuine saved-last3 source choice, restoration/reflection, old midpoint scalar, occurrence origin/jet, protected-prefix pricing, and outer normalization. The original source-list/dispatcher binding and these scalar premises are inherited, not independently reimplemented in this audit. No current recurrence, arbitrary helper periodicity, or recovery of truncated vertices is used. The result is a conditional all-k recognition theorem for this strict W0 corrected-even dispatcher, not the full native/all-word realization or recurrence theorem.
