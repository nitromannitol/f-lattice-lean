import sympy as s,json
from pathlib import Path
D=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/recognition_ledger/saved3_gate/W1')
d,n,e,r,k,i,z0,z1=s.symbols('d n e r k i z0 z1');A=s.Matrix([d,n]);R=s.Matrix([e,r]);Z=2*A+R;C=A+k*Z;O=C+Z;z=s.Matrix([z0,z1]);delta=s.Matrix([1,-1]);b=lambda X:s.Matrix([X[1],-X[0]]);v=lambda X:s.Matrix([X[1]-X[0],sum(X)]);T=lambda X:-b(X).dot(v(X));c=lambda X:(T(X)+sum(X))/2;eta=lambda X:(T(X)-sum(X))/2
Y=z+v(C)+2*A+i*Z;X=Y+Z;zp=2*Z-2*A+v(Z)+delta-z;w=zp+2*A+(2*k-1-i)*Z
G=s.groebner([d*r-n*e+1],d,n,e,r,k,i,z0,z1,domain=s.QQ);out={}
def check(name,p):
 q=G.reduce(s.expand(p))[1];out[name]=str(q)
check('short_first',-b(C).dot(v(C))-c(C)-eta(C))
# delta-(Y-VZ-Z)=w-2C-VC
for j in range(2):check('short_second_position'+str(j),delta[j]-(Y-v(Z)-Z)[j]-(w-2*C-v(C))[j])
# FZ(zp)=FZ(z+2A)-bZ.z +? calculate reflection at z+2A-2Z
# FZ(delta-(z+2A-2Z)+VZ)=FZ(z+2A)-bZ.(z+2A-2Z)-etaZ
old=-b(Z).dot(z+2*A-2*Z)-eta(Z)
# target correction -old+1
check('short_second_gauge',-b(C).dot(w)-eta(C)+b(Z).dot(Y)+eta(Z)+2-b(C).dot(Y)-eta(C)-(-old+1))
for j in range(2):check('long_first_position'+str(j),delta[j]-X[j]-(w-2*O-v(O))[j])
check('long_first_gauge',-b(O).dot(w)-eta(O)-b(C).dot(Y)-eta(C)-(-old+1))
check('long_second_gauge',b(O).dot(z+2*A+(i+1)*Z)-c(O)-b(Z).dot(X)+c(Z)-1-b(C).dot(Y)-eta(C))
print(out);assert all(q=='0'for q in out.values());(D/'INDEPENDENT_SIBLING_ALGEBRA.json').write_text(json.dumps(out,indent=2))
