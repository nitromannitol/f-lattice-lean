from pathlib import Path
import sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D.parent))
from physical_heads import *
def go(w,k):
 assert w.count('1')%2==1 and w[-1]=='3';ow=w+'3'+'2'*k
 m,a0=alg.get_odometers(w);_,zf,af,rf=getFracs(w);A,Z,R=[(p.denominator,p.numerator) for p in (af,zf,rf)]
 mx,ax=alg.get_odometers(ow);of,qf,cf,zff=getFracs(ow);C=(cf.denominator,cf.numerator);Q=(qf.denominator,qf.numerator);O=(of.denominator,of.numerator);assert C==add(A,scale(k,Z)) and Q==add(scale(2,C),Z)and O==add(C,Z)and zf==zff
 F=review.Field(*Z[::-1],alg.export_tile(m[1])).g;FC=review.Field(*C[::-1],alg.export_tile(mx[2])).g
 FO=review.Field(*O[::-1],alg.export_tile(mx[0])).g;FQ=review.Field(*Q[::-1],alg.export_tile(mx[1])).g
 S=alg.export_tile(a0[1]); H=add(scale(2,Z),scale(-2,A),v(Z),(1,-1));assert set(S)=={add(H,scale(-1,z))for z in S}
 seen=Counter();sts=Counter(); caZ=t(Z)-eta(Z)
 for z,raw in S.items():
  u=add(z,scale(2,A));d=F(z)-F(u);assert 0<=d<=2;J=(F(z)+F(u)+1)//2;seen['oldraw',raw-J]+=1
  zz=add(H,scale(-1,z));p0=F(u)-F(add(u,scale(-1,v(A))))-mul(b(A),u)
  assert p0<=eta(A)-int(d>0)
  for i in range(-1,2*k):
   y=add(z,v(C),scale(2,A),scale(i,Z));jet=mul(b(C),y)+eta(C);exp=J+jet
   if i>=0:
    g1=FC(y);g2=FC(add(y,scale(-1,v(Z)),scale(-1,Z)))+mul(b(Z),y)+eta(Z)+2
    assert g1-jet==FC(add(u,scale(i,Z)))
    assert g2-jet==FC(add(zz,scale(2,A),scale(2*k-1-i,Z)))-F(zz)+F(u)+1
    assert min(g1,g2)==exp,(w,k,'short',z,i);seen['true_Q_at_source',FQ(y)-exp]+=1
   x=add(y,Z);g2=FO(add(x,v(Z)))-mul(b(Z),x)+caZ-1;g1=FO(x)
   assert g2-jet==FO(add(u,scale(i+1,Z)))
   assert g1-jet==FO(add(zz,scale(2,A),scale(2*k-1-i,Z)))-F(zz)+F(u)+1
   assert min(g1,g2)==exp,(w,k,'long',z,i);sts['LONGROOTS']+=1
 print('PASS',w,k,'A,Z,R',A,Z,R,len(S),seen,sts,flush=True)
go(sys.argv[1],int(sys.argv[2]))
