# W1 stationary whole-crop dominance: corrected shifted-price argument

Conditional uniform result in the strict proper saved3 W1 frame. Let A=(d,n), Z=(D,N)=2A+R, b_A.Z=1, U=2A, v=V_A, T=T_Z, K=M(A,Z), L=D+N, c=D-N. Put c_A=(T_A+L_A)/2, eta_A=(T_A-L_A)/2. Assume the genuine earlier E_Z two-source realization, physical standard strips, actual W1 restored ALT bounds, midpoint D(z)=F_Z(z)-F_Z(z+U) in{0,1,2} on that crop, and the earlier complete central range |D|<=1 on [3-D-K,N+2D-1+K]. No current-child recognition is assumed.

Set q=z+U-v, w=q+v=z+U and
 h(z)=F_Z(q)+b_A.z+eta_A.
Then h(z)>=F_Z(z)-1 on the whole genuine restored old ALT crop.

## Price convention, independently checked signs

The W1 standard two-level price is
 Pstd(u)=F_Z(u)-F_Z(u-v)-b_A.u,
 eta_A-1<=Pstd<=eta_A on E_Z.
It is NOT the W0 forward price. Define P0(q)=F_Z(q)-F_Z(q+v)+b_A.q. Direct expansion gives

 P0(q)=T_A-Pstd(q+v),
 h(z)-F_Z(z)=P0(q)-D(z)-c_A
             =eta_A-Pstd(w)-D(z).

Pstd(Z)=-1 and Pstd(V_Z)=0. Thus its correct folding argument is at w=z+U, never at q. Finite diagnostic evaluations from genuine standards13 and123 give respectively Pstd-eta_A in{-1,0}; these tests are not substituted for the earlier full-polygon span theorem.

## Exact W1 restored support bounds

The actual all-sector `bounds` function in recovery_20261101_0745/check_strict_corrected_even_primary_support_transport.py specializes for W1 to
 t(z) in[L-T+2-h,h],
 s(z) in[-ex,2T-2K+2N+ex],
 where h=D at odd sites, h=c in the lower even sector and2N otherwise, and ex=D-3N+2 only for lower-sector odd sites (zero otherwise).

Thus z is above both lower E_Z rows: even s>=0, odd lower-sector s>=3N-D-2>=2-c (N>=2), and odd other-sector s>=0>=2-c. Transversely its lower bound is at least the corresponding E lower bound plus2, and its upper bound h is within E's upper row. These are true containments of the authentic restored crop, not a claim that all points in the relaxed rectangle are occupied.

Coordinate changes are
 t(q)=t(z)+K-2, s(q)=s(z)+2K-2;
 t(w)=t(z)-2, s(w)=s(z)+2K.
In particular q cannot fail an E lower edge. If w is not above E's upper s edge, then q and z satisfy BOTH longitudinal edges, since K>1. This eliminates all unlisted geometric cases.

## Case 1: w above the upper longitudinal E edge

Fold w backwards by positive multiples of the genuine primary Z into a length-T terminal subinterval of E's longitudinal interval, then fold transversely by V_Z into the matching parity E interval. These periods preserve parity. Writing w=w0+iZ+jV_Z gives i>=1 and w0 in E. Therefore
 Pstd(w)=Pstd(w0)-i<=eta_A-1.
Since D(z)<=2, h-F_Z>=1-D>=-1. No raw-minimum formula outside E is invoked.

## Case 2: w longitudinally inside E, but q above its upper transverse edge

Fold w transversely into E, preserving Pstd, to get Pstd(w)<=eta_A. We need D(z)<=1. The failure condition gives
 t(z)>=D-K+3 at odd sites,
 t(z)>=L-K+1 at even sites.
Both exceed the lower central endpoint3-D-K. The genuine native upper bound t(z)<=max(D,c,2N) is below N+2D-1+K. Thus the earlier central interval gives D<=1 and h-F_Z>=-1.

## Case 3: q is in E

The preceding geometry puts z in E also. Their actual two-A raw representations give, with the authentic relative gap psi at q,
 h(z)-F_Z(z)=-[min(0,psi+1)-min(0,psi)]>=-1.
This is the stated genuine W1 two-source gap identity, applied only where both fields equal that raw representation. The price-folding proof does not extend this identity to off-polygon points.

## Stationary consequence and remaining gates

If the genuine stationary W1 source algebra is
 M_C(z+U+lZ)=min(F_Z(z),h(z)+l),
then the inequality just proved gives M_C(z+U+lZ)=F_Z(z) for every l>=1. Identification with F_C still requires actual E_C membership. At l=0 the exact residual is min(F_Z(z),h(z)); a stronger cap/midpoint identity is NOT established by h>=F_Z-1 alone. In particular, this note does not claim the W1 endpoint correlation, source restoration scalar, actual current G3 placement, or outer normalization. Those remain separate producer/recognition obligations.

The only raw-gap premise above is the specified W1 two-source relation on licensed q,z. The all-sector restored support formula is read directly from the actual prior support transport; the standard Pstd span and complete D interval remain explicit earlier theorem inputs. This is a reusable uniform geometric/price argument rather than finite extrapolation.
