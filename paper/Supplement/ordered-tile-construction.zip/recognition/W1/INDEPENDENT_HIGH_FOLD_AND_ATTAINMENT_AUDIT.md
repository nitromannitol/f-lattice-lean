# W1 high-fold fmax and attainment: independent audit

PASS under the genuine earlier hypotheses in WHOLE_CROP_DOMINANCE.md and INTRINSIC_CORRELATION_AUDIT.md, plus the already licensed stationary source law on E(C). The latter remains a value/source input, not something inferred from polygon membership.

Let C=A+kZ, k>=1, B=K+kT. At the final point q=z+2A+(2k-1)Z, the preceding audit proves either q in E(C), or its high-s primary fold q-2C=z-Z in E(C).

## High fold forces z above the old E_Z upper s row

Set h_E=2N at even sites and L-2 at odd sites. The last-point formula simplifies to
 s_C(q)=2T_C+B(s_Z(z)-T)/T+2t_Z(z)/T.
If s_Z(z)<=T+h_E, then its excess above2T_C is at most(B h_E+2h)/T, where the actual R2 upper t endpoint is h=D odd, h in{c,2N} even.

At even sites, using KN=nT-L,
 B(2N)+2h-T(2n+2kN)=2(h-L)<0.
At odd sites, using KL=L_A T-2N,
 B(L-2)+2D-T(L_A+kL-2)=2(c-K-(k-1)T)<0.
Thus q is NOT above its actual upper polygon row in either case. Contrapositively, a high fold implies s_Z(z)>T+h_E. These are actual physical parity rows, not the untrimmed bounding box. The four exact algebraic identities are independently checked in high_fold_audit.py; positivity K>c is included in the preceding cone estimates.

By the earlier standard span eta_A-1<=Pstd<=eta_A on E_Z, the genuine forward-longitudinal fold of this high-s z uses at least one positive Z. Its true character is Pstd(Z)=-1 and Pstd(V_Z)=0. Hence Pstd(z)<=eta_A-1.

## fmax nonnegativity with the correct D orientation

The given authentic stationary source formula at the LICENSED folded point is
 F_C(z-Z)=min(F_Z(z-2A), F_Z(z-v)+b_A.z+eta_A-1).
Subtracting F_Z(z) gives exactly
 fmax(z)=min(D(z-2A), eta_A-1-Pstd(z)),
where D(w)=F_Z(w)-F_Z(w+2A). There is no reversal of D here: D(z-2A)=F_Z(z-2A)-F_Z(z).

The actual R2 transverse range gives t_Z(z-2A)=t_Z(z)+2 in the full earlier [3-D_Z-T,N+2D_Z-1] interval: its lower endpoint is at least5-T; its upper is at most L+1<=N+2D_Z-1. Therefore D(z-2A)>=0 by the complete physical scalar-window theorem. The second term is nonnegative by the high-s price bound. Thus fmax(z)>=0. This is not obtained by presuming the shifted point is ALT-native.

## Reflected high fold gives exact l=0 attainment

Let z'=H'-z, H'=2Z-2A+V_Z+(1,-1), and suppose z' needs its high-s fold. Put u=z+2A. The exact center identity gives
 s_Z(u)=2T+2N-s_Z(z') < T+2N-h_E.
Thus u is below its E_Z upper s row (even: belowT; odd: belowT-c+2). Its lower s edge is paid directly by the actual old R2 lower row:
 s_Z(u)>=2K-ex>=0,
using the established strict-cone 2K>L+max(0,ex). This is above both E lower rows.

Moreover t_Z(u)=t_Z(z)-2. The actual R2 lower endpoint L-T+2-h gives t_Z(u)>=L-T-h: at odd sites this is N-T, exactly the old E lower row; at even sites it is at least2-T since h<=L-2. The upper endpoints h-2 are also within the actual E rows. Therefore u belongs to the GENUINE closed E_Z, with no transverse fold or missing-corner assumption.

Its native span gives Pstd(u)>=eta_A-1. The separately proved intrinsic correlation gives Pstd(u)<=eta_A-1 whenever D(z)=2. Hence equality holds. The exact fringe price
 e0(z)=eta_A-Pstd(u)-D(z)
is consequently -1. This pays attainment rather than merely a lower cap.

## Scope

The all-cone geometry, sign identities, old scalar-window licensing and attainment implication are verified here. This audit does not independently regenerate the stationary source formula displayed above; that must remain bound to the authentic stationary roof theorem/current source ledger. No current recurrence is used. It distinguishes root membership from arbitrary outside-old-crop halo membership.
