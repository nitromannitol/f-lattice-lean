# Mirrored W1 saved3: whole-crop polygon and final primary fold

PASS in the strict saved3 cone: A=(d,n), R=(e,r), det(A,R)=-1, n>=2,d-n>=3,r>=1,e-r>=2. Let Z=2A+R=(D,N), T=T_Z, K=M(A,Z), L=D+N. Fix k>=1, C=A+kZ. Let z belong to the true RESTORED W1 alternate Z crop. Then

 (i) z+2A+lZ belongs to E(C) for every 0<=l<=2k-2;
 (ii) z+2A+(2k-1)Z belongs to E(C) or E(C)+2C. If its longitudinal coordinate is above its genuine E(C) upper row, its representative after subtracting2C is exactly z-Z and belongs to E(C).

These are whole-crop root statements, not assertions about unspecified raw exported frames or about inputs outside the old native crop.

## Actual W1 rows and center

The genuine all-sector R2 source in check_strict_corrected_even_primary_support_transport.py gives
 t in[L-T+2-h,h], s in[-ex,2T-2K+2N+ex],
 h=D on odd sites; h=D-N in lower-sector even,2N otherwise;
 ex=D-3N+2 on lower-sector odd sites,0 otherwise.
The center H'=2Z-2A+V_Z+(1,-1) has
 t_Z(H')=L-T+2, s_Z(H')=2T-2K+2N,
exactly the sums of opposite row endpoints. Thus both signs in the stated old center are correct. Its physical parity is even. No height reflection is inferred solely from these support identities.

For upper estimates put E=max(0,ex). Then -E<=s<=2T-2K+2N+E and t>=-T. The two alternatives E=0 and E=D-3N+2 are handled separately in the arithmetic certificate, without assuming an upper-sector formula in the lower sector.

## Exact coordinates

The determinant is the opposite of W0. Here a_A.Z=+1, a_Z.A=-1. Therefore
 t_A=(K t+s)/T, s_A=(K s+2t)/T,
 t_C(z+2A+lZ)=t_A+k t-2k+l,
 s_C(z+2A+lZ)=s_A+k s+2T_A+2kK+l(K+kT).
The last point minus2C is z-Z, not z+Z. Translation preserves physical parity.

The odd C polygon rows, independently derived in the W0 audit by the true parity-reversing dual map, are
 even: t_C in[1-T_C,L_C-1], s_C in[0,2T_C+2N_C];
 odd: t_C in[N_C-T_C,D_C], s_C in[2-c_C,2T_C+L_C-2].

## All interior head indices

Exact identities are KD=dT+c, KL=L_A T-2N, K²=T_A T+2. The strict cone gives E<T,2K>L+E, T>2max(D,L-2).

Integrality gives t_A>=-K-1; at odd sites t_A<=d+1, at even sites t_A<=L_A+1. It follows, even allowing the final index l=2k-1, that every t_C is in its required row. The lower estimate is
 t_C>=-kT-K-2k-1,
 and the positive margin T_C-N_C-(kT+K+2k+1)>0 pays both parities.

Also s_A>=-E-2. Thus at l=0,
 s_C>=2T_A-2+2kK-(k+1)E>0.
The longitudinal coordinate increases with l. Using the discriminant identity, s_A<=2K-2T_A+2N+E+2. Hence for l<=2k-2,
 s_C<=2k²T+2kK+(k+1)(2N+E)+2<2T_C.
These inequalities put the entire range in both actual s rows, without endpoint/corner deletion.

## Final index

At l=2k-1 the same t bounds and positive lower s bound hold. The upper estimate increases by K+kT:
 s_C<=2k²T+kT+3kK+(k+1)(2N+E)+2<4T_C.
If the point is already within the relevant upper s row, it lies in E(C). Otherwise subtract2C: t_C does not change and s_C decreases by2T_C. Since the original s exceeded the appropriate upper row, the new s is >2N_C (even) or >L_C-2 (odd), hence above its lower row; and it is <2T_C, hence below its upper row. This proves the claimed exact primary fold. The use of the actual primary period2C is geometrically and phase-correct.

## Unbounded check and scope

check_arithmetic.py verifies three determinant identities modulo dr-ne=-1 and twelve strictly positive polynomial margins. Under n=u+2,d=u+v+5,r=w+1,e=w+h+3,k=j+1, each margin has positive constant and nonnegative coefficients. ARITHMETIC.json records the full polynomials. This is an all-cone proof, not a finite parameter test.

The actual old W1 crop inclusion is an inherited source premise, now used with the correct low-sector ex. To use the final fold for VALUES, one still invokes the already authenticated ordinary C primary character; to use it for a complete PHYSICAL STAR, apply the appropriate statement separately to each queried input or supply its halo guard. Root membership alone does not license an outside-old-crop input. No current recurrence or new helper scalar is assumed or proved here.
