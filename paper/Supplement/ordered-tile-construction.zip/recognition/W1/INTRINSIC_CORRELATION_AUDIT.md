# W1 intrinsic cap correlation: independent audit

Retain the genuine earlier hypotheses and notation of WHOLE_CROP_DOMINANCE.md; in addition use the earlier full physical interval 0<=D<=2 on [3-D_Z-T,N+2D_Z-1]. Write eta=eta_A and u=z+2A, q=u-v, w=z-v. Then uniformly on the actual restored ALT crop,

 Pstd(u)<=eta-1_{D(z)>0}.

Consequently h(z)>=J(z)=F_Z(z)-floor(D(z)/2), strengthening h>=F_Z-1. This is a lower cap, NOT alone an equality/attainment statement.

## Exact identity

Pstd(u)=Pstd(z)-D(z)+D(w),

by direct four-value expansion; b_A.(2A)=0. Also Pstd(Z)=-1 and Pstd(V_Z)=0. Since the old ALT s(z) is at or above E_Z's parity lower s edge, folding forward longitudinal positions back into E and then transversely gives Pstd(z)<=eta. This applies even when z is above E's longitudinal upper edge.

## Upper-longitudinal case

If u lies above E's upper s edge, the same folding uses at least one positive Z, giving Pstd(u)<=eta-1. This proves the desired correlation for every D in{0,1,2}.

## Remaining case: u is longitudinally inside E

The exact actual lower bounds for z imply u and q are above E's lower s edge: their increases are2K and2K-2, respectively, with K>1. Both are below its upper s edge if u is. Also z is longitudinally inside. The old ALT transverse lower bound, minus2 for u, is still inside E; its upper bound h minus2 is below E's upper bound. Thus z and u are in their actual E charts. The point q has t=t(z)+K-2 and may only fail the upper transverse edge, not its lower or longitudinal edges. In particular there is no unpriced q.s exception.

If q is in E, the genuine two-A relative gap psi at u gives

 D(z)=min(0,psi+2)-min(0,psi),
 Pstd(u)=eta+min(0,psi)-min(0,psi+1).

For integer psi, D>0 iff psi<=-1, and then Pstd(u)=eta-1. For D=0, Pstd(u)=eta. The correlation follows, and in this fully licensed case h=J exactly.

If q is above its transverse edge hi (hi=D_Z odd, hi=L-2 even), then t(w)=t(q)+2>=hi+3. Put w1=w+V_Z, so t(w1)=t(w)-T. Its lower bound is D_Z+3-T at odd sites or L+1-T at even sites, above3-D_Z-T. Its upper bound is h+K-T<h, below N+2D_Z-1, using T>K. Hence w1 lies in the full physical [0,2] interval. Because D(V_Z)=2,

 D(w)=D(w1)-2<=0.

The exact identity and Pstd(z)<=eta now give Pstd(u)<=eta-D(z), which implies the claimed correlation.

## What this does and does not close

Since h-F_Z=eta-Pstd(u)-D(z), the correlation implies h-F_Z>=0 when D=0 or1, and >=-1 when D=2. This is exactly h>=J.

It does NOT imply min(F_Z,h)=J for D=2: if Pstd(u)=eta-2, for example, then h=F_Z>J. Equality at the l=0 fringe needs either Pstd(u)=eta-1 whenever D=2, or another actual offer attaining J. The fully licensed raw-gap case supplies that equality; the two folded cases above prove only the lower cap. No equality of their fringe is asserted without a further argument.

This proof uses the complete physical D range, not a presumed native membership of w1, and retains genuine W1 restoration/source/scalar premises. It is independent sign and domain review of the proposed argument, not a fresh proof of its earlier profile invariants.
