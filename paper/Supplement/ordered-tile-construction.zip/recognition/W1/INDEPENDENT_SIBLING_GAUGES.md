# Independent W1 SHORT/LONG sibling gauges and mask audit

## Verdict
The proposed SHORT and LONG two-price normalizations are EXACT, with no hidden common additive offset in the stated x=y+Z phase chart. Eight independent polynomial/vector identities vanish modulo det(A,R)=-1. The final absolute head masks require actual helper upper-right alignment; literal iteration count alone does not prove them. This audit therefore separates exact gauge verification from that source-binding premise.

## Independent conventions
A=(d,n), Z=2A+R, det(A,R)=-1, C=A+kZ, O=C+Z, k>=1. Define b_X=(n_X,-d_X), V_X=(n_X-d_X,d_X+n_X), c_X=(T_X+L_X)/2, eta_X=(T_X-L_X)/2. The genuine standard secondary jet is b_X·z-c_X. Put

 y=z+V_C+2A+iZ,
 x=y+Z,
 z'=2Z-2A+V_Z+delta-z,
 w=z'+2A+(2k-1-i)Z.

The actual prior restored crop reflection z↦z' must hold as a SUPPORT statement. The all-plane algebra alone does not assert it.

## SHORT exact calculation
The even raw comparator is min(F_C(y),F_C(y-V_Z-Z)+b_Z·y+eta_Z+2). Subtract b_C·y+eta_C. The first offer is F_C(z+2A+iZ), by the V_C deck. For the second,

 delta-(y-V_Z-Z)=w-2C-V_C.

Reflection, the genuine zero2C primary character and negative secondary jet give exactly

 F_C(w)-F_Z(z')+F_Z(z+2A)+1.

Here the old reflection identity is F_Z(z')=F_Z(z+2A)-b_Z·z+2-eta_Z; b_Z·2A=-2, not+2 as in W0. This sign change is included in the checked identity. No rotation of the W0 result is used.

## LONG exact calculation
The odd alternate phase comparator, evaluated at x=y+Z, is min(F_O(x),F_O(x+V_Z)-b_Z·x+c_Z-1). Subtract the SAME jet b_C·y+eta_C. Since x+V_Z=z+2A+(i+1)Z+V_O, the second offer becomes exactly

 F_O(z+2A+(i+1)Z).

Also delta-x=w-2O-V_O, so the first becomes

 F_O(w)-F_Z(z')+F_Z(z+2A)+1.

Every constant is fixed: changing c_Z-1 to c_Z+1 leaves an error2 in the second normalized offer. Replacing y by x in the subtracted gauge also changes the constant, since b_C·Z=1. Thus the result licenses the stated phase chart, not an identification with an unshifted/canonically exported odd alternate without its actual translation and normalization.

## Literal source audit and exact limitation
original_port_recursion.py get_l_correct uses actual qa2 after translate_alts for the odd helper G3. _odd_l at W1 has right/nonflip K4=-q1, left/flip K4=+q1; the LONG flag adds precisely one full G3 iteration. No opposite-orientation assumption was substituted. At the outer level, corrected standard EVEN uses natural Gl slot3 and Gr slot4 with getEvenTileFull. Corrected alternate ODD uses the same natural slots but getAltOddTileFull. In W1 these standard slots are V_C and V_Z+Z, while alternate slots are V_C+Z and V_Z+Z, before the actual helper alignment/inner origins are added. Thus Gl's outer displacement increases by exactly+Z; Gr's outer displacement is unchanged. Affine offset differences follow the same literal table, with zero primary slope for Z.

Crucially, both outputs call align_corrections with actual target p=C, and W1 terminal2 aligns Gr by the actual upper-right vertex of that helper. A LONG extra head can change that vertex. Absolute source masks are therefore not inferred merely from the one extra iteration and the +Z Gl offset. The supplied final masks

 SHORT: i=0..2k-1;
 LONG RIGHT: i=0..2k-1, LONG LEFT: i=-1..2k-2

are compatible with these literal tables, but this audit retains their authenticated raw origin/UR-restoration theorem as an explicit premise. It has not independently reconstructed the full all-k helper UR from a union of relaxed envelopes. This is a source-binding limitation, not a failed gauge identity.

## Query ranges and noncircular use
On the given SHORT mask, the two stationary indices i and2k-1-i lie in0..2k-1. On the LONG union, i+1 and2k-1-i lie in0..2k. They are shifted queries z+2A+lZ and z'+2A+lZ. NONE may be replaced by an unshifted whole-crop assertion F_C(z+lZ)=F_Z(z). One must use the actual W1 shifted-crop polygon/price theorem, including its l=0 fringe and real restored crop reflection. If these earlier results and source calibration are supplied, the displayed normalizations reduce the desired native identity to precisely their two endpoint prices. This note neither assumes the current native identity to license an odd standard query nor asserts current recurrence or global alternate admission.

## Historical covariance replay
Fresh replay of recovery_20261101_0745/check_saved3_corrected_odd_long_covariance_binding.py returned `PASS 28 saved3 actual both-phase LONG/ordinary endpoint bindings`. This independently uses actual alt_layout and raw_piece_ops at saved-last3 for both phases, with RIGHT natural slot4 and LEFT slot3. It certifies endpoint affine origins for both arithmetic progressions and ordinary carriers, not a new proof of helper upper-right dimensions. Thus the theoretical fixed-physical-contour result and the given masks are consistent with the actual symbolic layout; true array restoration/UR alignment remains the explicitly inherited historical placement premise.
