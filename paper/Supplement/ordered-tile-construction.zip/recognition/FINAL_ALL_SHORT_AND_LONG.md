# Every strict saved3/W0 corrected head has the target height

**Constructor lemma, unbounded run length.** Let Z=2A+R be the stored proper even fraction in a strict saved-last-3/W0 record, C=A+kZ (k≥1), Q=2C+Z the current even standard, O=C+Z its odd sibling. Under the authenticated earlier standard and restored alternate fields, their geometric/strip data, and the genuine current source formulas specified below, the current even-standard two-offer comparator and the odd-alternate two-slip comparator reproduce the complete predicted earlier alternate G3 height on **all** their actual corrected SHORT and LONG crop indices, respectively. The two endcaps are included. The assertion is conditional, concerns these native source values, and is not itself a proof of either full native output or of all-word recurrence.

Earlier work paid only the two internal head/prefix contacts or all but an endpoint of this comparison. Here essentially the same proof pays every whole crop in both siblings. It does not require a new burning graph for each individual correction.

## Hypotheses and notation

Let A=(d,n), R=(e,r), det(A,R)=dr-ne=1; d-n>=3,n>=2,e-r>=2,r>=1, proper fractions. In actual strict rebuilt last3 core1/core2 use Z=2sA+E, s>=2, R=Z-2A with all source records in their true restored W0 frames. Put b_X=(n_X,-d_X), V_X=(n_X-d_X,d_X+n_X), T_X=-b_X.V_X, L_X=d_X+n_X, c_X=(T_X+L_X)/2, eta_X=(T_X-L_X)/2, delta=(1,-1). Standard F_X has zero primary character (X if even type,2X if odd) and secondary F_X(z+V_X)=F_X(z)+b_X.z-c_X. Its genuine reflection is F_X(U_X+V_X+delta-z)=F_X(z)-b_X.z-eta_X. In particular F_X(delta-z)=F_X(z), by the actual deck laws (not an assumed point symmetry of an arbitrary pasted helper).

Earlier hypotheses: the genuine fields F_A,F_Z,F_C, actual two-Z W0 representation of F_C on its closed polygon, all-parameter old native R2 support, E_Z polygon representation/price span, authentic h0/zero strips, central D+ interval, and old restored native midpoint J(z)=ceil((F_Z(z)+F_Z(z-2A))/2) with 0<=D(z)=F_Z(z)-F_Z(z-2A)<=2 on this crop. Use its genuine support reflection z'=2A+V_Z+delta-z, not just covariance of unbounded functions. The preceding contact note and its final independent audit specify and price the one exceptional old polygon point: no global unperiodized M_Z identity is assumed. Current geometry/normalization inputs are the genuine two ordinary offers for Q and the actual spatial/affine G3 placements; where literal equality to the actual calibrated head is desired use the earlier internal G1/G2 pricing, protected-prefix packet and actual outer scalar normalization. Matching locations alone proves no scalar. No recurrence of Q or a clipped helper is assumed.

## 1. The whole old crop is shielded in the stationary odd parent

Put v=V_A, K=-b_A.V_Z, T=T_Z, L=L_Z,
q=z-v-2A and h(z)=F_Z(q)+b_A.z+eta_A+2.
For every old native restored ALT point z we have h(z)>=F_Z(z), even when q is NOT native standard Z. A complete conditional proof is given in INDEPENDENT_ALL_CROP_DOMINANCE_AUDIT.md. Here are the essential cases. h-F_Z=P(q)-D(z)-c_A+2 for P(q)=F_Z(q)-F_Z(q+v)+b_A.q. If q in E_Z, q and z both see the authentic two-copy minimum, except the single separately paid reflected point. The difference F_Z(z)-h=min(0,psi+1)-min(0,psi)-1<=0. If q falls below E_Z's longitudinal lower side, fold by the genuine periods and use the old native P span c_A-1<=P<=c_A on E_Z: each backward Z adds1, so P(q)>=c_A. If only its transverse upper side fails, fold using V_Z alone to get P(q)>=c_A-1; the earlier central range and old ALT top transverse row give D(z)<=1 there. The actual R2 bounds exclude all other failures. The detailed audit also gives a sign-extension alternative which does not use the ALT top transverse row in this last step.

The stationary odd child C=A+kZ has previous odd parent A+(k-1)Z and even parent Z. Its raw W0 formula and actual Z deck give, for every integer l,
 M_C(z+lZ)=min(F_Z(z),h(z)+2(k-1)-l).
The affine coefficient +2(k-1)-l is exact: the shifted query is q+(l-2(k-1))Z-(k-1)V_Z, and the quadratic terms of the old secondary jet cancel those of eta_(A+(k-1)Z). See the independent derivation.

The entire physical translate z+lZ belongs to E(C) whenever 1<=l<=2k-1. The independent proof INDEPENDENT_WHOLE_CROP_POLYGON_AUDIT.md uses the all-sector old R2 (including its extra low-slope odd loss), the authentic parity-reversing polygon map and elementary projections, with ten unbounded positivity certificates. Thus
 F_C(z+lZ)=F_Z(z) for 1<=l<=2k-2;
 F_C(z+(2k-1)Z)=min(F_Z(z),h(z)-1).
Importantly, no membership of z itself in E(C) is asserted.

## 2. The actual corrected-even head sees exactly the old midpoint

The true W0 standard SHORT lists put right head i at V_C+iZ for 1<=i<=2k-1, and left head at V_C+(2k+1-i)Z for 1<=i<=2k-1. Their effective expected affine part in current coordinates is b_C.y+eta_C+1. The saved-last3 source selection uses the earlier restored even alternate Z. The literal spatial list is independently bound through old original get_l_correct tables; the calibrated constants are earlier/outer hypotheses precisely as above. Let y=z+V_C+iZ be a point in a head crop and subtract this affine part from each ordinary Q offer. The ordinary raw offers are
 F_C(y-Z),   F_C(y-V_Z)+b_Z.(y-Z)+eta_Z.
The first becomes F_C(z+(i-1)Z) after the secondary deck and b_C.Z=-1. Since
 delta-(y-V_Z) = z'+(2k-i)Z -2C -V_C,
the second, by the primary and negative secondary decks and delta-reflection, becomes exactly
 F_C(z'+(2k-i)Z)-F_Z(z')+F_Z(z-2A)+1.
Indeed F_Z(z')=F_Z(z-2A)-b_Z.z+2-eta_Z, and b_C.(2A+V_Z+delta)=2k-K-kT+L_C. Thus for every 2<=i<=2k-1 both true stationary queries are among those paid in Section1: the normalized current minimum is
 min(F_Z(z),F_Z(z-2A)+1)=J(z).
The last equality uses the genuine native D in {0,1,2}, not a general real-variable identity. This is WHOLE-CROP recognition of the intermediate corrected jets, not just contact preservation. Whenever the underlying current native G3 crop is actually included in E_Q, the licensed periodized standard comparator F_Q equals this same value there. Equivalently, it suffices to restrict to the actual standard output: the authenticated native support lies in E_Q. If an implementation truncates a source before placement, no claim of recovery of the lost points is made. If a literal outer maximum or the source affine gauge has not yet been paid in a constructor, the theorem verifies the exact predicted candidate value but does not certify that maximum by location alone.


## 3. The two actual SHORT endcaps

Reflection interchanges index1 and 2k. Put e_l(w)=F_C(w+lZ)-F_Z(w). On subtracting F_Z(z) from the normalized offers, their minimum at i is
 min(e_(i-1)(z),1-D(z)+e_(2k-i)(z')).
Because D(z′)=2-D(z), interchanging z,z′ and i,2k+1-i changes this price and the desired min(0,1-D) by the same constant. Only i=1 needs proof. The Section1 exact fringe at l=2k−1, the delta-reflection and deck identities reduce the normalized endpoint equation to
 min(f(z),1-D(z),c_A-P(z)) = min(0,1-D(z)),
where f(z)=F_C(z)-F_Z(z).

**First offer.** If z belongs to E_C, f=0 by raw dominance. If it does not, its only possible failure is below the longitudinal lower row, and z+2C belongs to E_C. The earlier stationary formula there gives
 f=min(D(z+2A),P(z-v)-c_A)>=0.
The complete true transverse D≥0 interval covers z+2A. Both P(z),P(z-v) are ≥c_A here by longitudinal folding; the single boundary layer at s=0 or 2-(D_Z-N_Z) is in the harmonic strip, so P=c_A on it. INDEPENDENT_FOLDED_ENDPOINT_FIRST_OFFER.md supplies the exact signed row checks. In particular f>0 can occur only when P(z)≥c_A. Individual first-offer equality is *false*: in a strict word113 instance, f=1 on191 out of1720 points while the minimum remains correct.

**Correlated bound, including the transverse seam.** Prove P(z)≤c_A+1_{D(z)=2}. Throughout the true restored crop the earlier E_Z longitudinal price span and R2 width give P≤c_A+1. If s(z) is at or above the E_Z lower row, the same fold immediately gives P≤c_A. Otherwise put x=z+Z and w=x-2A. Both are licensed in E_Z except that the even point w=v can lie at s=-2; its authentic F=M is separately paid in the earlier two-contact proof. The old t/s bounds put y=x+v in E_Z unless y lies BELOW the lower transverse edge.

If y belongs to E_Z, use the actual raw gap psi at x: D(z)=min(0,psi)-min(0,psi-2), while P(z)-c_A=1_{psi<=0}. This proves the assertion.

If y is below the transverse edge, **do not use the raw formula at y**. The t coordinate of y−V_Z is t(z)−K+T, strictly above −K and at most 1 (even) or N−1 (odd). Thus the strictly earlier COMPLETE physical transverse interval gives D(y−V_Z)≥0; by true deck drift D(y)≥2. Also P(w)≤c_A: w has the correct longitudinal range except for an even s=-2 layer; the h0 strip at s=-2,-4 prices this layer directly. Now the exact identity
 P(x)−P(w)=D(x)−D(y)
implies P(z)=P(w)+D(z)−D(y)+1≤c_A+D(z)−1. In particular if D(z)≤1 then P(z)≤c_A. This also covers genuine D=1 points in the wrapped region.

**Attainment.** For D=2 the second term is −1 and neither of the other terms is smaller. For D=1 the second term is0 and neither of the other terms is smaller. For D=0 the first term is0 on the nonfolded sites; on folded sites P≥c_A plus the correlated bound give P=c_A, so the third term is0. This proves the first endcap and, by the authenticated reflection, the second. All SHORT indices 1,...,2k are settled including k=1. See INDEPENDENT_ALL_HEAD_ASSEMBLY_AUDIT.md and INDEPENDENT_FINAL_ENDPOINT_WRAP_AUDIT.md.

## 4. Odd alternate sibling: the same cap pays all true LONGs

Let O=C+Z=A+(k+1)Z. In the genuine W0 odd alternate phase/gauge the two-slip comparator is
 min(F_O(y), F_O(y+V_Z)−b_Z.y+c_Z+1).
This is the analytic comparator on its licensed actual alternate crop (and even on an authenticated halo if the prior two-slip theorem so supplies); do not identify a literal ALT with this expression merely by naming it. For the RIGHT LONG the indices i are1,...,2k; for the LEFT LONG, the real additional +Z placement reindexes them as2,...,2k+1. At y=z+V_C+iZ subtract the same G3 affine part b_C.y+eta_C+1. The second offer becomes F_O(z+iZ), since c_O=c_C+c_Z+M(C,Z). The first becomes
 F_O(z′+(2k+2−i)Z)−F_Z(z′)+F_Z(z−2A)+1,
by delta-reflection and the true negative V_O jet. These identities, including the scalar +1, are explicitly expanded and independently polynomial-checked in INDEPENDENT_ODD_LONG_SIBLING_AUDIT.md.

Apply Section1 with k+1 in place of k. For 2≤i≤2k both indices are in [1,2k], and both queried stationary fields equal the old F_Z values. At i=1 or 2k+1 one index is the physical fringe 2k+1 and the other the paid interior1. At i=1 the normalized residual equals min(0,1-D,c_A-P); the correlated bound just proved pays it. Reflection pays i=2k+1. There is **no zero-index fold** in this sibling. All physical queries have been shown to lie in E_O. This handles every true RIGHT/LEFT LONG corrected G3 crop, including both extra end heads.

## What has and has not been proved

The standard parents' physical fields, old corrected alternate midpoint and restored symmetric domain, true R2 enclosure and earlier strip/price data are inputs. The two current analytic target expressions have the stated ordinary-source gauges and are licensed using the independent earlier analytic construction, *not* assumed to match the literal new arrays. The exact spatial G3 masks distinguish actual SHORT/LONG and LEFT/RIGHT. To identify the literal assembled head, use the real internal and outer touch gauges; the result proves the values at the canonical gauges and does not infer an unpaid outer maximum from identical support. See the accompanying independent source review for these distinctions.

Once those frames are in place, neither interior depths nor first/last caps remain a fresh *G3-to-target price* obligation for this strict saved3/W0 dispatcher. Other ordinary outer sources and their calibrations, other dispatcher records and phases, literal base or clipping issues, and the entire original all-word recurrence theorem are not certified by this lemma. Historical sources in the archive document the relevant strictly earlier hypotheses; copying them is not fresh formal verification. The universal proof is algebra plus genuine domain and deck bounds. Finite diagnostics were useful only to disprove incorrect stronger individual-offer assertions.
