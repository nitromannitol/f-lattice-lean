import json
from pathlib import Path
from collections import Counter
D=Path(__file__).resolve().parent;rows=json.loads((D/'ENDPOINT_TESTS.json').read_text());out=[]
for a in rows:
 d,n=a['A'];DD,N=a['Z'];T=DD*DD+2*DD*N-N*N;K=(d+n)*DD+(d-n)*N;L=DD+N;c=DD-N;cc=Counter()
 for xy,pv,dv,t,s,par,flags in a['miss']:
  lo,hi,sl,sh=(N-T,DD,2-c,T+L-2)if par else(2-T,L-2,0,T+2*N)
  bad=(t<lo+K,t>hi,s<sl+2*K-T,s>sh-T);assert any(bad);cc[bad]+=1
 out.append({'word':a['word'],'unpaid_guard_sectors':[[list(k),v]for k,v in cc.items()]})
(D/'GUARD_SECTORS.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
