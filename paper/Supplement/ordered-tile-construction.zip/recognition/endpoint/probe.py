from pathlib import Path
import sys
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
from collections import Counter
C=Path(__file__).resolve().parent
def run(w):
 assert w.count('1')%2==0 and w[-1]=='3'
 mats,alts=alg.get_odometers(w);po,Zf,Af,Rf=getFracs(w);Z=(Zf.denominator,Zf.numerator);A=(Af.denominator,Af.numerator);R=(Rf.denominator,Rf.numerator)
 va=alg.vf(Af)[1];U=(2*A[0],2*A[1]);V=(int(va.real),int(va.imag));b=(A[1],-A[0]);T=-sum(t*u for t,u in zip(b,V));L=sum(A);eta=(T-L)//2;c0=(T+L)//2
 S=alg.export_tile(mats[1]);Al0=alg.export_tile(alts[1]);P=alg.export_tile(mats[2]);F=review.Field(Z[1],Z[0],S);Fa=review.Field(A[1],A[0],P)
 O=(R[0]-V[0],R[1]-V[1]);O=O if O[1]>=0 else(0,0);Araw={(x-O[0],y-O[1]):v for(x,y),v in Al0.items()}
 def zz(z,w,m=1):return tuple(v+m*u for v,u in zip(z,w))
 def dot(z):return sum(s*t for s,t in zip(b,z))
 def D(z):return F.g(z)-F.g(zz(z,U,-1))
 def pp(z):return F.g(z)-F.g(zz(z,V))+dot(z)
 def J(z):return F.g(z)-D(z)//2
 shifts=Counter(v-J(z)for z,v in Araw.items());C0=shifts.most_common(1)[0][0]
 print(w,'A R Z',A,R,Z,'O',O,'phase',F.phase,'Jconst',shifts.most_common(3),'num',len(shifts),flush=True)
 if len(shifts)>1:return
 aR=(R[1],-R[0]);TR=R[0]**2+2*R[0]*R[1]-R[1]**2;VZ=(Z[1]-Z[0],sum(Z));te=(R[1]-2*R[0],R[0])
 def mm(z):
  x=zz(z,R,-1);return min(Fa.g(x),Fa.g(zz(x,te,-1))+sum(i*j for i,j in zip(aR,x))+(TR-sum(R))//2)
 def arc(z,a,b,A,B):
  pts=[z]; ee=[0]+[vv for j in range(1,A+B-1)for vv in ([1] if B*(j+1)//(A+B)-B*j//(A+B)else [0,0])]+[0]
  for h in ee:pts.append(zz(zz(pts[-1],a),b,h))
  return pts
 H=arc((1,0),(1,0),(0,1),(Z[0]-Z[1])//2,Z[1])
 Vs=arc((0,0),(0,1),(-1,0),Z[1],Z[0]-Z[1])
 poly=H+[zz(z,Z)for z in Vs]+[zz(z,VZ)for z in H[::-1]]+Vs[::-1]
 def inside(z):
  x,y=z;n=0
  for (p,q),(s,t) in zip(poly,poly[1:]+poly[:1]):
   cross=(x-p)*(t-q)-(y-q)*(s-p)
   if cross==0 and min(p,s)<=x<=max(p,s) and min(q,t)<=y<=max(q,t):return True
   if (q<=y<t or t<=y<q) and cross*(t-q)<0:n+=1
  return n%2==1
 E={z for z in set(S)|set(Araw)|{zz(z,V)for z in S} if inside(z)}
 rows=Counter();bad=[];miss=[];wrong=[]
 for z in Araw:
  x=zz(z,Z);points=[x,zz(x,V),zz(x,U,-1)];guard=all(inside(v)for v in points)
  pv=pp(z)-c0;dv=D(z);rows[(pv,dv,int(guard))]+=1
  if pv>int(dv==2):bad.append([z,pv,dv])
  if not guard:miss.append([z,pv,dv,Z[1]*z[0]-Z[0]*z[1],sum(Z)*z[0]+(Z[0]-Z[1])*z[1],sum(z)%2,[inside(v)for v in points]])
 return dict(word=w,A=A,Z=Z,R=R,restoration=O,sites=len(Araw),rows=[[list(k),v]for k,v in rows.items()],bad=bad,miss=miss)
if __name__=='__main__':
 out=[run(w)for w in sys.argv[1:]];(C/'ENDPOINT_TESTS.json').write_text(json.dumps(out,indent=2))
 for q in out:print(q['word'],q['rows'],'BAD',q['bad'][:3], 'miss',len(q['miss']))
