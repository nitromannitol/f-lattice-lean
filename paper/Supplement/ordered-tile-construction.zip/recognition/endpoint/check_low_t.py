from pathlib import Path
import sys
D=Path(__file__).resolve().parent; sys.path.insert(0,str(D.parent))
from physical_heads import *
def go(w):
 m,a0=alg.get_odometers(w);_,zf,af,rf=getFracs(w)
 A,Z,R=[(v.denominator,v.numerator)for v in (af,zf,rf)]; T=t(Z); L=sum(Z);K=-mul(b(A),v(Z));hR=eta(R); ea=eta(A);ca=t(A)-ea
 F=review.Field(*Z[::-1],alg.export_tile(m[1])).g
 Fa=review.Field(*A[::-1],alg.export_tile(m[2])).g
 O=add(R,scale(-1,v(A)));O=O if O[1]>=0 else(0,0);S=[add(z,scale(-1,O))for z in alg.export_tile(a0[1])]
 def prices(y):
  x=add(y,scale(-1,R));q=add(y,scale(-1,v(R)));return Fa(x),Fa(q)+mul(b(R),x)+hR
 ct=Counter();ex={};ct2=Counter()
 for z in S:
  x=add(z,Z); tx=mul(b(Z),x);sx=mul((L,Z[0]-Z[1]),z)
  chi=sum(z)%2;lo,sl=(Z[1]-T,2-Z[0]+Z[1])if chi else(2-T,0)
  if sx>=sl or tx>=lo+K:continue
  y=add(x,v(A));a,cc=prices(x);aa,dd=prices(y);psi=cc-a; diff=F(y)-min(aa,dd)
  ui=add(x,scale(-2,A));DV=F(x)-F(ui)
  pp=F(z)-F(add(z,v(A)))+mul(b(A),z)-ca
  key=(DV,pp,diff);ct[key]+=1;ex.setdefault(key,z);ct2[('psi',psi>=1,diff)]+=1
 print(w,'lowleft',ct,'psi',ct2,'ex',ex,flush=True)
for w in sys.argv[1:]:go(w)
