# Endpoint price: proved local implication and exact remaining guard

Use the saved3/W0 earlier-field hypotheses and restored ALT frame in the adjacent two-contact theorem. Write P(z)=F_Z(z)-F_Z(z+V_A)+a_A.z, D(z)=F_Z(z)-F_Z(z-2A), c_A=(T_A+L_A)/2. The desired whole-crop assertion is
 P(z)<=c_A+1_{D(z)=2}.

## Licensed matched-chart implication

Put x=z+Z. If x,x+V_A,x-2A all belong to E_Z, the actual two matched source charts, with their true old A period/jet, give
 P(z)-c_A=1_{psi(x)<=0},
 D(z)=min(0,psi(x))-min(0,psi(x)-2).
Here psi is the second chart minus the first, not its negative. The integer cases are:
 psi<=0: (P-c_A,D)=(1,2);
 psi=1: (0,1);
 psi>=2: (0,0).
Thus the desired implication follows, including the zero-gap endpoint. This is conditional on the genuine matched-chart identity on all THREE sites; no off-polygon source extension is used.

The guard is EXACTLY the following rectangle in the root's physical parity. Write E_Z's rows t in[lo,hi],s in[a,b]. Since t_Z(V_A)=-K,s_Z(V_A)=-2,t_Z(2A)=2,s_Z(2A)=2K and s_Z(Z)=T, its conjunction is
 lo+K<=t_Z(z)<=hi, a+2K-T<=s_Z(z)<=b-T.
K>2 in the strict cone. For even roots (lo,hi,a,b)=(2-T,L-2,0,T+2N); for odd roots (N-T,D,2-c,T+L-2). This reduction includes physical parity because all three translations have even coordinate sum.

## Additional licensed high-s portion

If instead z,z+V_A,z-2A lie in E_Z, apply the preceding identity to z-Z and use the ACTUAL primary character P(z+Z)=P(z)-1, D(z+Z)=D(z). It gives P(z)<=c_A, which is stronger than the target. This guard is
 lo+K<=t_Z(z)<=hi, a+2K<=s_Z(z)<=b.
No unproved global minimum representation is used. The same implication transports by V_Z, since P(z+V_Z)=P(z) and D(z+V_Z)=D(z)+2; the stronger P<=c_A does not depend on D. Thus any V_Z-fold with this three-point guard also pays the target.

## Exact gap, not a full proof

The first guard alone leaves three possible sectors on the actual R2 crop: t<lo+K; s<a+2K-T; or s>b-T. The fourth possibility t>hi is ruled out by the true R2 upper row. The second guard pays the high portion s>=a+2K when its t interval holds, but leaves a genuine middle longitudinal strip b-T<s<a+2K as well as the transverse low-t strip. A V_Z fold does not change s and cannot by itself eliminate this longitudinal gap. Thus these two local matched-chart calculations do NOT prove the entire endpoint assertion. Further strip/cut or comparator information is required on that gap.

Four genuine-source checks, not an extrapolation: restored native crops at113,1133,1123,3113 have respectively1720,3510,6698,4792 sites, and zero violations of the desired inequality. Full data include the actual restoration, quotient-coherent global field, price values, and the first guard's failures. In all four, precisely ONE actual site fails only the low-s guard; many fail the high-s guard. The exact sector counts are in GUARD_SECTORS.json. These are not endpoint counterexamples, only failures of the proposed three-point licensing mechanism.

The result is a rigorous local implication and a precise remaining sector. No whole-crop, all-word, or fresh recurrence conclusion is claimed.
