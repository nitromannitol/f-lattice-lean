# Updated residual after using the earlier longitudinal price bound

The earlier note deliberately used only the three matched source guards. With the separately established native price bound P<=c_A on E_Z and its correct longitudinal deck transport, the apparent high-s gap is already paid. It must not be treated as a new obstruction to the full induction.

Indeed P(z+Z)=P(z)-1, P(z+V_Z)=P(z). A genuine E_Z representative with only nonnegative Z translations therefore gives P(z)<=c_A. In the parent's authenticated fold this covers s>=lo_s(E_Z). In the remaining s<lo_s(E_Z), the exact old R2 lower rows license x=z+Z and x-2A, except the single genuine even v excursion; its actual scalar value was independently paid in FINAL_INDEPENDENT_TWO_CONTACT_AUDIT.md. The longitudinal guard for x+V_A also holds. The outstanding matched-chart issue is therefore only
 s<lo_s(E_Z), t<lo_t(E_Z)+K,
where x+V_A is below the transverse polygon row and requires a genuine wrap/value comparison.

A tempting shortcut 'D=2 throughout this remaining region' is FALSE in the tested real crops. Among the first-guard failures with s below the native lower row, (P-c_A,D)=(0,1) occurs12 times at113,12 at1133,48 at1123,40 at3113. One of these in each even sector is the separately paid scalar excursion; the others include genuine low-transverse points. For example word113 has root z=(-17,34), odd, t=-1105,s=-102, D=1,P-c_A=0 (T=1202,K=222; the exact stored record is authoritative). These are not counterexamples to the desired endpoint inequality; they show why the residual needs price control rather than the assertion D=2.

No universal sign proof for the transverse-wrapped source gap is established in this packet. The exact remaining local obligation is P<=c_A at those remaining sites where D=0 or1; the all-crop bound P<=c_A+1 alone already covers D=2. Parent's earlier native price/longitudinal-fold premise and paid v scalar are explicitly additional inputs here.
