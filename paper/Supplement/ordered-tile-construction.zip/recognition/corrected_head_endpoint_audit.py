import sys
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
add=lambda a,b:tuple(x+y for x,y in zip(a,b))
scale=lambda k,a:tuple(k*x for x in a)
b=lambda a:(a[1],-a[0])
v=lambda a:(a[1]-a[0],sum(a))
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
eta=lambda a:(-dot(b(a),v(a))-sum(a))//2
for w in sys.argv[1:] or ['113']:
 mats,alts=alg.get_odometers(w);_,zf,af,rf=getFracs(w);Z=(zf.denominator,zf.numerator);A=(af.denominator,af.numerator);R=(rf.denominator,rf.numerator)
 F=review.Field(Z[1],Z[0],alg.export_tile(mats[1]));O=add(R,scale(-1,v(A)));O=O if O[1]>=0 else(0,0);crop={add(z,scale(-1,O)) for z in alg.export_tile(alts[1])}
 for k in [1,2]:
  C=add(A,scale(k,Z));cw=w+'3'+'2'*(k-1);ms,_=alg.get_odometers(cw);Fc=review.Field(C[1],C[0],alg.export_tile(ms[0]));counts=Counter();examples=[]
  for z in crop:
   zp=add(add(scale(2,A),v(Z)),add((1,-1),scale(-1,z)))
   assert zp in crop,(w,z,zp)
   for i in [1,2*k]:
    y=add(add(v(C),scale(i,Z)),z);com=dot(b(C),y)+eta(C)+1
    first=Fc.g(add(y,scale(-1,Z)))-com
    sec=Fc.g(add(y,scale(-1,v(Z))))+dot(b(Z),add(y,scale(-1,Z)))+eta(Z)-com
    J=min(F.g(z),F.g(add(z,scale(-2,A)))+1)
    counts[(i,first-F.g(z),sec-F.g(add(z,scale(-2,A)))-1,min(first,sec)-J)]+=1
    if (first!=F.g(z) or sec!=F.g(add(z,scale(-2,A)))+1) and len(examples)<8:examples.append((z,i,first,sec,J,F.g(z),F.g(add(z,scale(-2,A)))+1))
  print(w,k,counts,'BAD',examples,flush=True)
