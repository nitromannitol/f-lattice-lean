import sympy as s,json
from pathlib import Path
d,n,e,r=s.symbols('d n e r');P=s.Matrix([d,n]);Q=s.Matrix([e,r]);zero=s.zeros(2,1);BH=s.Matrix([[1,1],[1,-1]])/2
b=lambda v:s.Matrix([v[1],-v[0]]);V=lambda v:s.Matrix([v[1]-v[0],sum(v)]);rot=lambda v:s.Matrix([v[1],-v[0]]);dual=lambda v,odd:s.Matrix([sum(v),v[0]-v[1]])/(1 if odd else 2);T=lambda v:-b(v).dot(V(v));eta=lambda v:(T(v)-sum(v))/2
out=[]
for W in [0,1]:
 vp,vq=V(P),V(Q);ap,aq=b(P),b(Q);eps=b(P).dot(Q)
 ov=[zero,2*P+2*vp,Q,Q+vp,vq,vq+vp]if W==0 else[2*P,2*vp,zero,vp,Q+vq,Q+vq+vp]
 oj=[zero,2*ap,zero,ap,aq,aq+ap];od=[Q,Q,P,P,P,P];oi=[False,False,True,True,True,True]
 DD=2*T(P)-sum(P);K=-ap.dot(vq)
 oc=[0,DD-2*eps,0,eta(P)-eps,eta(Q),eta(P)+eta(Q)+K]if W==0 else[0,DD,0,eta(P),eta(Q)+2*eps,eta(P)+eta(Q)+K+eps]
 A,B=dual(Q,False),dual(P,True);va,vb=V(A),V(B);aa,ab=b(A),b(B);det=A[0]*B[1]-A[1]*B[0]
 nv=[zero,B,2*A+va,2*A+va+B,2*B,vb]if W==0 else[2*A,2*A+B,va,va+B,zero,2*B+vb]
 nj=[zero,zero,aa,aa,zero,ab];nd=[B,B,B,B,A,A];ni=[False,False,False,False,True,True]
 nc=[0,0,eta(A)+2*det,eta(A)+2*det,0,eta(B)]if W==0 else[0,0,eta(A),eta(A),0,eta(B)-2*det]
 for i in range(6):
  vv=rot(ov[i]-(2*P+Q)+(2 if oi[i]else 1)*od[i]);hits=[j for j in range(6)if ni[j]!=oi[i]and s.simplify(nd[j]-dual(od[i],oi[i]))==zero and s.simplify(nv[j]-vv)==zero];assert len(hits)==1,(W,i,hits)
  j=hits[0];res=s.simplify(BH*vv+rot(oj[i])-nj[j]);assert res==zero
  cc=s.expand(oc[i]+oj[i].dot(2*P+Q-s.Matrix([0,1]))-vv.dot(BH*vv)/2-vv[1]/2-nc[j]);assert cc==0,(W,i,j,cc)
  out.append({'W':W,'old_even_natural':i,'new_odd_natural':j,'gradient':'0','scalar':'0','origin':[str(a)for a in vv]})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print('PASS12 exact source origins, slopes AND canonical scalars; no determinant restriction')
