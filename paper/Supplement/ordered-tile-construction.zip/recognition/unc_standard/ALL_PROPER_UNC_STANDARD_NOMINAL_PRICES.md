# All-proper UNC standard ordinary-source nominal pricing

## Verdict and scope

Under the genuine earlier standard field/price/strip invariants and authentic basic odd-p donor theorem, all SIX nominal ordinary sources of every actually dispatched proper odd UNC standard agree with its raw comparator on their whole closed parent polygons, in both phases. The arithmetic-dual even UNC list has exactly the matching source origins, gradients and canonical scalars. This is a raw nominal source-coherence theorem, not an assumption that the current field already equals its sources.

The literal initial gauge and chronological-overlap issue are distinguished in Section6. In particular this document does not import the historical full-compatibility premise to infer a new actual greedy maximum noncircularly.

## 1. Actual dispatcher and allowed zero-length case

I read original_port_recursion.py:get_next_mat/get_std_child_unc and original_port_offsets.py:getOddTileFull/getEvenTileFull. The branches are:

 next1: both standard children UNC;
 next2: odd standard UNC, even standard corrected;
 next3: odd standard corrected, even standard UNC.

For odd UNC at next2, the selected stationary parents are C=A+kZ,k>=1, with saved record1 or3. At next1, the selected current siblings are C=Z-a and Z=2a+R, i.e. effective saved1 with k=0 and phase opposite Z's birth phase. There is NO odd-UNC k=0 saved3 branch. This exclusion is substantive: the bounds below would not justify both near-q copies in that artificial branch.

The actual odd natural source list is q,q,q,q,p,p, with chronological permutation0,1,4,5,2,3. With current p=C,q=Z:

 W0 origins: 0,Z,2C+V_C,2C+V_C+Z,2Z,V_Z;
 W1 origins: 2C,2C+Z,V_C,V_C+Z,0,2Z+V_Z.

Slopes are0,0,b_C,b_C,0,b_Z. The first chronological source is qNear0 in BOTH phases, not pNear in W1. The literal code and source table agree exactly.

## 2. W0 near-q prices

Use h(u)=F_Z(u-V_A-2A)+b_A.u+eta_A+2 and H=h-F_Z. The true stationary raw odd comparator on y=u+lZ, l=0,1, has normalized competing gap

 H(u)+2k-l.

For saved3, the independently proved whole-E_Z three-case theorem gives H>=0. Since an actually dispatched saved3 odd UNC has k>=1, both gaps are nonnegative. For saved1, the earlier genuine intrinsic-chain maximum theorem gives H>=1 on ALL E_Z, so both gaps are nonnegative even for k=0. Therefore each near q source is attained exactly on its entire E_Z copy.

No containment of these copies in a current child polygon is needed: the calculation is for the globally defined RAW comparator with genuine earlier fields, not a premature current-periodized equality.

## 3. W1 near-q prices and full-E lower bounds

Now define hhat(u)=F_Z(u+2A-V_A)+b_A.u+eta_A and Hhat=hhat-F_Z. At y=u+2C+lZ, l=0,1, the normalized raw minimum is

 min(F_Z(u),hhat(u)+2k+l).

For saved3, Hhat>=-1 on ALL E_Z. Here is the needed extension beyond the earlier ALT R2: set q=u+2A-v and w=u+2A. The exact price is Hhat=eta_A-Pstd(w)-D(u), with D(u)=F_Z(u)-F_Z(u+2A). Its true full physical window contains E_Z, so0<=D<=2. The coordinate changes are s(q)=s(u)+2K-2,t(q)=t(u)+K-2,s(w)=s(u)+2K. Thus q can fail only upper s or upper t. If w is above E's upper s edge, forward-primary folding gives Pstd(w)<=eta_A-1, hence Hhat>=-1. Otherwise all longitudinal guards hold. If q is above its upper t edge, the exact central D interval gives D(u)<=1 and transverse folding gives Pstd(w)<=eta_A, again Hhat>=-1. If q is in E, both q,u have the authentic raw two-A representation and Hhat=-[min(0,psi+1)-min(0,psi)]>=-1. No raw value is extended off its licensed polygon.

For saved1 the global birth identity in ODD_TWO_Q_DONOR_SHIELDING is Psi=c0+2-Phi_plus, and the genuine earlier max_E Phi_plus<=c0+2 gives Hhat>=0 on all E_Z. Its earlier mate-admission/trace hypotheses remain explicit.

Thus saved3 k>=1 has Hhat+2k+l>=1, while saved1 k>=0 has Hhat+2k+l>=0. Both actual near-q sources are exactly priced.

## 4. Far-q reflection and both p donors

The raw odd minimum itself has the exact affine child reflection, derived only from genuine old F_Z reflection/decks. In W0 its first branch F_Z(y) reflects to the second branch with scalar eta_C+2; in W1 its first branch F_Z(y-2C) reflects to the second with scalar eta_C. This follows from b_Z.C=1 in W0 and -1 in W1, b_Z.V_C=-M(C,Z), and eta_(C+Z)=eta_C+eta_Z+M(C,Z). Hence it is a GLOBAL RAW identity, not a presumed reflection of a newly assembled field.

Reflecting the two already priced near-q polygon copies gives the two genuine far-q copies, with the actual earlier polygon reflection and canonical affine jet. The true odd p-donor theorem INDEPENDENT_ODD_P_DONOR_CONJUGACY gives zero-tilt/zero-scalar equality on E_C+2(1-W)Z; it is explicitly a preperiodization comparator theorem. The same raw reflection gives pFar. This prices all six sources without assuming current recurrence or current native realization.

For det(C,Z)=1-2W the resulting natural canonical scalar arrays are exactly

 W0: [0,0,eta_C+2,eta_C+2,0,eta_Z],
 W1: [0,0,eta_C,eta_C,0,eta_Z+2].

They agree with the literal standard source slopes and the previously derived general-determinant tables.

## 5. Dual even UNC list, including constants and parity

The even UNC dispatcher consists of next1 and next3; the source-list arithmetic dual maps it to the odd next1/next2 cases just proved. dual_six_sources.py independently constructs both literal six-source tables from their offset formulas. For both phases it matches all six transformed origins and primitive types, and proves exact equality of gradients AND canonical scalars, with no determinant restriction in the scalar algebra. All12 checks pass.

For an old even child U=2P+Q and source with true kernel U_source, the transformed origin is v*=Rot(v-U+U_source); its target gradient is B_H v*+Rot(ell). The full transformed scalar is

 c+ell.(U-e2)-(v*.B_H v*)/2-v*_2/2.

Every matching target standard origin has even coordinate sum, so the h0 parity terms cancel in this translation. Thus this is one exact scalar on both physical parities, not two independent parity calibrations. The corresponding global raw standard conjugacy transfers the proved odd nominal source equality to the dual even ordinary sources. Actual parent polygon conjugacy supplies the guard without requiring current child containment.

## 6. Literal initial gauge and chronological calibration limit

The literal first q source has zero slope and canonical scalar0 in both phases, for both target types. Its location is0 in W0 and2P in W1. If the earlier actual q is already in its authenticated canonical native gauge, that first occurrence anchors the constructor's global scalar. If one retains an earlier global normalization constant instead, it is inherited as ONE common overall scalar.

The nominal theorem now proves that every proposed canonical source agrees on all actual pairwise overlaps, since each equals the same raw target there. Therefore, whenever an actual new occurrence has a nonempty overlap with the already assembled prefix, its greedy touching normalization is forced to be the canonical one: all overlap differences are that same constant. Induction then calibrates the actual ordered assembly. This is a valid replacement for a circular appeal to current full compatibility, BUT nonempty chronological overlap must still be authenticated from genuine native domains.

Several contacts follow immediately from the true standard ports: qNear twins share the common0/Z port; the first p meets the preceding near-q at2Z in W0 or2C in W1; in W0 pFar meets qNear0 at V_Z+e1. The historical scalar document's W1 argument fixes pFar using qFar, which is inserted LATER in the actual order0,1,4,5,2,3. It is not by itself a chronological proof of that touching maximum.

A useful W1 prior-prefix contact is y=2C+Z+V_Z+e1, shared by qNear1's true V_Z+e1 port and pFar provided its earlier native C contains2C-Z+e1. For a positive stationary run this is the earlier qNear1 port; in the first corrected/zero-length cases its actual retained-source/native licensing must be checked, not inferred from nominal E_C membership. Fixed native/UR/source-retention or a separate overlap certificate can supply this. This document does NOT silently assume it from current source agreement.

Consequently all ordinary nominal prices and canonical scalar tables are now proved conditionally on the stated earlier fields. Actual literal UNC normalization follows when those genuine chronological contacts are supplied; no unconditional all-word literal scalar/recurrence theorem is claimed here. This qualification is especially important at the genuine k=0 saved1 dispatcher, not an artificial saved3 zero-length case.
