# Strict saved3/W0: an arbitrarily long corrected head chain from one earlier midpoint

**Conditional constructor theorem.** In the strict lower saved-last-3 frame, let A be the saved odd fraction, Z=2A+R the earlier genuine even fraction, and C=A+kZ the selected stationary odd parent (k>=1). Write Q=2C+Z for the current even standard. At *every point of the whole authentic restored alternate Z crop*, every intermediate corrected head of Q (indices 2 through 2k-1, when nonempty) has the exact current two-offer value. All head sizes, parent parameters and run lengths in the indicated strict dispatcher are allowed. No check of any of their inner or outer boundaries is necessary. The proof uses one uniform old-crop inequality, one polygon inclusion, and a two-branch computation. This is not yet the complete native all-word theorem.

## Hypotheses and notation

Let A=(d,n), R=(e,r), det(A,R)=dr-ne=1; d-n>=3,n>=2,e-r>=2,r>=1, proper fractions. In actual strict rebuilt last3 core1/core2 use Z=2sA+E, s>=2, R=Z-2A with all source records in their true restored W0 frames. Put b_X=(n_X,-d_X), V_X=(n_X-d_X,d_X+n_X), T_X=-b_X.V_X, L_X=d_X+n_X, c_X=(T_X+L_X)/2, eta_X=(T_X-L_X)/2, delta=(1,-1). Standard F_X has zero primary character (X if even type,2X if odd) and secondary F_X(z+V_X)=F_X(z)+b_X.z-c_X. Its genuine reflection is F_X(U_X+V_X+delta-z)=F_X(z)-b_X.z-eta_X. In particular F_X(delta-z)=F_X(z), by the actual deck laws (not an assumed point symmetry of an arbitrary pasted helper).

Earlier hypotheses: the genuine fields F_A,F_Z,F_C, actual two-Z W0 representation of F_C on its closed polygon, all-parameter old native R2 support, E_Z polygon representation/price span, authentic h0/zero strips, central D+ interval, and old restored native midpoint J(z)=ceil((F_Z(z)+F_Z(z-2A))/2) with 0<=D(z)=F_Z(z)-F_Z(z-2A)<=2 on this crop. Use its genuine support reflection z'=2A+V_Z+delta-z, not just covariance of unbounded functions. The preceding contact note and its final independent audit specify and price the one exceptional old polygon point: no global unperiodized M_Z identity is assumed. Current geometry/normalization inputs are the genuine two ordinary offers for Q and the actual spatial/affine G3 placements; where literal equality to the actual calibrated head is desired use the earlier internal G1/G2 pricing, protected-prefix packet and actual outer scalar normalization. Matching locations alone proves no scalar. No recurrence of Q or a clipped helper is assumed.

## 1. The whole old crop is shielded in the stationary odd parent

Put v=V_A, K=-b_A.V_Z, T=T_Z, L=L_Z,
q=z-v-2A and h(z)=F_Z(q)+b_A.z+eta_A+2.
For every old native restored ALT point z we have h(z)>=F_Z(z), even when q is NOT native standard Z. A complete conditional proof is given in INDEPENDENT_ALL_CROP_DOMINANCE_AUDIT.md. Here are the essential cases. h-F_Z=P(q)-D(z)-c_A+2 for P(q)=F_Z(q)-F_Z(q+v)+b_A.q. If q in E_Z, q and z both see the authentic two-copy minimum, except the single separately paid reflected point. The difference F_Z(z)-h=min(0,psi+1)-min(0,psi)-1<=0. If q falls below E_Z's longitudinal lower side, fold by the genuine periods and use the old native P span c_A-1<=P<=c_A on E_Z: each backward Z adds1, so P(q)>=c_A. If only its transverse upper side fails, fold using V_Z alone to get P(q)>=c_A-1; the earlier central range and old ALT top transverse row give D(z)<=1 there. The actual R2 bounds exclude all other failures. The detailed audit also gives a sign-extension alternative which does not use the ALT top transverse row in this last step.

The stationary odd child C=A+kZ has previous odd parent A+(k-1)Z and even parent Z. Its raw W0 formula and actual Z deck give, for every integer l,
 M_C(z+lZ)=min(F_Z(z),h(z)+2(k-1)-l).
The affine coefficient +2(k-1)-l is exact: the shifted query is q+(l-2(k-1))Z-(k-1)V_Z, and the quadratic terms of the old secondary jet cancel those of eta_(A+(k-1)Z). See the independent derivation.

The entire physical translate z+lZ belongs to E(C) whenever 1<=l<=2k-1. The independent proof INDEPENDENT_WHOLE_CROP_POLYGON_AUDIT.md uses the all-sector old R2 (including its extra low-slope odd loss), the authentic parity-reversing polygon map and elementary projections, with ten unbounded positivity certificates. Thus
 F_C(z+lZ)=F_Z(z) for 1<=l<=2k-2;
 F_C(z+(2k-1)Z)=min(F_Z(z),h(z)-1).
Importantly, no membership of z itself in E(C) is asserted.

## 2. The actual corrected-even head sees exactly the old midpoint

The true W0 standard SHORT lists put right head i at V_C+iZ for 1<=i<=2k-1, and left head at V_C+(2k+1-i)Z for 1<=i<=2k-1. Their effective expected affine part in current coordinates is b_C.y+eta_C+1. The saved-last3 source selection uses the earlier restored even alternate Z. The literal spatial list is independently bound through old original get_l_correct tables; the calibrated constants are earlier/outer hypotheses precisely as above. Let y=z+V_C+iZ be a point in a head crop and subtract this affine part from each ordinary Q offer. The ordinary raw offers are
 F_C(y-Z),   F_C(y-V_Z)+b_Z.(y-Z)+eta_Z.
The first becomes F_C(z+(i-1)Z) after the secondary deck and b_C.Z=-1. Since
 delta-(y-V_Z) = z'+(2k-i)Z -2C -V_C,
the second, by the primary and negative secondary decks and delta-reflection, becomes exactly
 F_C(z'+(2k-i)Z)-F_Z(z')+F_Z(z-2A)+1.
Indeed F_Z(z')=F_Z(z-2A)-b_Z.z+2-eta_Z, and b_C.(2A+V_Z+delta)=2k-K-kT+L_C. Thus for every 2<=i<=2k-1 both true stationary queries are among those paid in Section1: the normalized current minimum is
 min(F_Z(z),F_Z(z-2A)+1)=J(z).
The last equality uses the genuine native D in {0,1,2}, not a general real-variable identity. This is WHOLE-CROP recognition of the intermediate corrected jets, not just contact preservation. Whenever the underlying current native G3 crop is actually included in E_Q, the licensed periodized standard comparator F_Q equals this same value there. Equivalently, it suffices to restrict to the actual standard output: the authenticated native support lies in E_Q. If an implementation truncates a source before placement, no claim of recovery of the lost points is made. If a literal outer maximum or the source affine gauge has not yet been paid in a constructor, the theorem verifies the exact predicted candidate value but does not certify that maximum by location alone.

## 3. Residual endpoint, honestly stated

Reflection interchanges index1 and 2k: the two stationary indices (i-1,2k-i) swap under i -> 2k+1-i and old crop reflection. More precisely, on subtracting F_Z(z), the target is d0=min(0,1-D(z)). Writing e_l(u)=F_C(u+lZ)-F_Z(u), the two offers' minimum relative to F_Z(z) is min(e_(i-1)(z),1-D(z)+e_(2k-i)(z')). Since D(z')=2-D(z), the reflected minimum differs by the same deterministic (1-D(z)) as d0; equality is invariant. Thus there is only ONE independent endcap problem.

At i=1 we know the second fringe exactly. Compared with F_Z(z), the desired equation is
 min( F_C(z)-F_Z(z), 1-D(z), c_A-P(z) ) = min(0,1-D(z)).
This is an exact reduction: folding h(z')-1 using the old delta-reflection and decks gives the term c_A-P(z). It removes any unbounded list of caps or internal guard points. It is not yet asserted for all admissible earlier fields. Even where F_C(z)=F_Z(z) is already known, c_A-P(z) must not undercut the target. Whole-crop raw dominance alone does not give this stronger assertion. No finiteness sample proves it.

## Scope

Intermediate heads of one strict lower W0 corrected EVEN standard dispatcher (an unbounded family). On the strictly earlier realized inputs listed, the theorem pays their complete comparison with the new unperiodized two-source field, and with its globally sewn standard on the licensed native points. Undefined endpoint constants, other dispatcher histories, full native realization and fixed padding are not thereby resolved. The separate tie-adaptive word123 record in the archive gives an independently replayed finite transfer experiment and general sound transfer rule; it is not an assumption or proof of this conditional constructor theorem.

**Endpoint reduction sharpened after independent checks.** In the folded case s_C(z) below its E_C lower bound, z+2C genuinely belongs to E_C. The odd raw price at the translated point gives
 F_C(z)-F_Z(z)=min(D(z+2A),P(z-v)-c_A).
Both terms are nonnegative: the first by the old complete physical transverse D range (not by assuming z+2A native), the second by genuine lower-s folding, pricing its single boundary layer by the h0 strip. Also P(z)>=c_A on folded sites. In the nonfolded case the first offer equals F_Z(z) exactly. Thus the *only* unsatisfied implication sufficient and necessary for the endpoint formula is
 P(z)>c_A  implies  D(z)=2
on the earlier restored crop (the old P span and R2 give P<=c_A+1). The folded D=0 case with P=c_A attains the third offer; D=1,2 attain the second. See INDEPENDENT_FOLDED_ENDPOINT_FIRST_OFFER.md.

If the old s_Z is not below its E_Z lower edge, then P<=c_A by longitudinal deck folding. Otherwise put x=z+Z. At x and x-2A the genuine old E_Z charts are licensed, except the already paid even value x-2A=v. If x+v also lies in E_Z, its raw gap psi gives D=min(0,psi)-min(0,psi-2) and P(z)-c_A=1_{psi<=0}, proving the implication. Only the strip t_Z(z)<lo_t(E_Z)+K at the lower-s side remains. There D=1 is possible in genuine data, so one cannot replace the implication by D=2 throughout. At the strict seed113, z=(-17,34) has D=1, P=c_A. The exact needed comparison is with the price of x+v across its transverse polygon edge. No uniform proof inserted for that last comparison is claimed.
