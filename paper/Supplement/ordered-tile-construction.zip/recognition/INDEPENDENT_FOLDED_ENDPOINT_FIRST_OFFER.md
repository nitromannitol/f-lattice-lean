# Folded endpoint first offer: independent geometric audit

Strict saved3/W0 notation as in the neighboring audits. Set v=V_A, U=2A, T=T_Z, K=M(A,Z), L=L_Z, c=D-N; distinguish the geometric c from scalar c_A=(T_A+L_A)/2. Let C=A+kZ, k>=1. The genuine earlier restored ALT crop has s>=-T, t>=-T, t<=D at odd sites and t<=h_even<=L-2 at even sites, with 2h_even<T. Coordinates satisfy

 t_C=t_A+k t, s_C=(K+kT)s/T-2t/T,
 Kc=(d-n)T-2D.

## Lower-edge localization

If an even z had s>=0, then s_C>=-2h_even/T>-1. As s_C is integer, s_C>=0, its even E_C lower edge. Thus a lower-edge fold forces s<0. Since D,N are odd, s=(D+N)x+(D-N)y is always even: folded even sites have s<=-2.

At an odd site with s>=2-c,

 s_C-(2-c_C) >= (2K+2D-2t)/T+2k-2 >0.

Thus folded odd sites have s<2-c and, by evenness of s, s<=-c. Every folded site lies strictly below the corresponding lower E_Z longitudinal edge. This is stronger than merely saying s<=0.

## Both P lower bounds, including exact rim

The earlier P span on E_Z is c_A-1<=P<=c_A, with characters P(Z)=-1 and P(V_Z)=0. Folding a point strictly below the E_Z s-edge upward by its true primary Z, then transversely by V_Z, therefore gives P>=c_A. In particular P(z)>=c_A throughout the folded region.

For w=z-v, s(w)=s(z)+2. It too is strictly below the E_Z edge except at the single longitudinal layer s(w)=0 (even) or s(w)=2-c (odd). On that layer both w and w+v have longitudinal coordinates inside the authenticated full harmonic strip [1-2D,2L-1]. Therefore both field values equal h0, and its exact v jet gives

 P(w)=h0(w)-h0(w+v)+b_A.w=c_A.

This uses the complete physical harmonic strip, not an assertion that the whole rim is literally native. Thus P(z-v)>=c_A uniformly, with no leftover boundary exception.

## Folded point plus 2C really lies in E_C

Translation by 2C preserves t_C and adds2T_C to s_C. The prior whole-crop coordinate proof gives t_A<=d odd and t_A<=L_A even, so

 t_C(z)<=d_C (odd),
 t_C(z)<=L_C-2k<=L_C-2 (even).

These are within the genuine E_C upper rows d_C and L_C-1. The prior lower estimate t_A>=-K-2 gives t_C>=-kT-K-2, stronger than the already audited bound -kT-K-2k-1 used in the whole-crop theorem; its positive margin therefore supplies both lower rows.

Since s>=-T and 2t<T, s_C>-K-kT-1; integrality gives s_C>=-K-kT. Hence

 s_C(z+2C)>=2T_C-K-kT
 =2T_A+(4k-1)K+(2k^2-k)T>0.

The fold hypothesis itself gives s_C(z)<0 in both parities, because the odd lower edge2-c_C is negative. Consequently s_C(z+2C)<2T_C, below both upper E_C edges2T_C+2n_C and2T_C+L_C-2. This proves the claimed actual closed-polygon license without assuming current-child recurrence.

## First-offer conclusion and exact residual dependency

With that license, the supplied folded-source calculation expresses the first endpoint offer relative to F_Z(z) as

 f1=min(D+(z+2A), P(z-v)-c_A).

The P term has just been proved nonnegative. To conclude f1>=0 one needs the earlier complete physical nonnegative D+ interval [3-D-T,N+2D-1] to contain t(z+2A)=t(z)+2. The actual ALT lower bound yields t(z)+2>=N-T+4 at odd sites and >=4-T+min(2N,c) at even sites, both above3-D-T. Its upper bound t(z)+2<=max(D,c,2N)+2 is below N+2D-1 in the strict cone. Thus the interval applies. This step is conditional on that stronger physical D+ theorem; the weaker central |D+|<=1 statement alone would not supply its sign.

Therefore f1>=0, stronger than the requested f1>=min(0,1-D+(z)). Also a folded point can never have P(z)<c_A. Thus the requested special attainment clause for D=0 and P<c_A occurs only in the nonfolded regime, where the separately licensed original shielding gives f1=0.

For D=0,P=c_A the extra second-offer branch has zero excess and gives attainment. Excluding D=0,P>c_A still belongs to the separate P/D correlation proof. This note does not silently derive that correlation from separate range bounds. The present audit closes the first-offer sign and the P<c_A special attainment, under the stated earlier physical strip/range inputs.
