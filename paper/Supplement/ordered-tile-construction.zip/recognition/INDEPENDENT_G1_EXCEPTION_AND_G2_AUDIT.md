# Independent saved3 audit: G1 algebra/exceptions and G2 scalar closure

Scope: A=(d,n) odd, Z=(D,N)=2A+R even, dN-nD=1, W=0, with the strict proper hypotheses in the supplied proof. Use I=(1,-1), TA=M(A,A), B=M(A,R), M=M(A,Z)=2TA+B, LA=d+n, eta_X=(T_X-L_X)/2, c0=(TA+LA)/2. This note does not substitute sampled literal arrays for parameter-uniform geometry.

## G1 midpoint algebra: verified
Write x=q-R and psi=C(q)-A(q). The genuine two offers are A(q)=F_A(x), C(q)=F_A(x-te)+a_R.x+eta_R, te=V_R-R. Since t_A(R)=-1, t_R(A)=1,

 psi(q+v)=psi(q)-1, psi(q+U)=psi(q)+2.

Both offers acquire the same v jet except for that relative -1. Their common part is F_A(x)+a_A.x-c0. Thus for z=q+v+U,

 ceil((M_Z(q+v)+M_Z(z))/2)
 =F_A(x)+a_A.x-c0+ceil((min(0,psi-1)+min(0,psi+1))/2)
 =M_Z(q)+a_A.x-c0.

The scalar min identity holds for every integer psi, including psi=0 (ceiling of -1/2 is zero). Finally a_A.x-c0=a_A.z+eta_A+1. Thus the proposed G1 value follows whenever the three evaluations of M_Z equal the authentic F_Z.

## Odd longitudinal upper bound and parity exceptions
The proposed ALT odd upper bound is safe: max(2N+2,D-N)<=D+N-2 provided D-N>=4 and N>=1. The stated strict-parent regime implies this. The old-native odd lower bound s(q)>=4-(D-N) gives s(q+v)>=2-(D-N), exactly the odd E lower edge. Even s(q)>=0 leaves only s(q)=0 as a possible lower failure, since s takes even values at even sites. With gcd(D+N,D-N)=2, the s=0 lattice line has step V_Z/2, but that step is odd; even parity reduces it to integer V_Z translates. The even E t interval excludes all such q except q=0, since T_Z>L_Z.

At the upper even edge only s(z)=T_Z+2N+2 is outside E. Its reference point is z*=Z+V_Z+I-v. On the overlap, the transverse width is strictly below T_Z: z lies between L_Z-T_Z+2-h_even and L_Z-M, where h_even=max(D-N,2N)<M. Thus the same gcd/parity argument gives at most the single representative z*. These arguments use the supplied exact parity rectangle/ALT spectral bounds as geometric premises; their independent source derivation is outside this note.

## Both exceptional values: verified directly
At v, the first offer is 1-c0, using F_A(-R)=0 and t_A(-R)=1. The second is -c0, using s_A(-V_R)=-2, F_A(-V_R)=h0(-V_R)=-eta_R, and a_A.V_R=-B. The actual value F_Z(v)=h0(v)=-c0 therefore equals the minimum.

At z*=Z+V_Z+I-v, use the TRUE reflection F_A(I-u)=F_A(u), plus its U and v deck jets. Do not assume invariance about the deck-shifted full polygon center. The first offer is

 LA-c0-B-eta_R,

and the second is exactly one larger. Independently, true child reflection and deck give

 F_Z(z*)=-c0+M-eta_Z.

Since eta_Z=2TA+2B+eta_R-LA, this is exactly the first offer. Hence the second exceptional minimum also equals the authentic field. This avoids relying on an unproved global reflection identity for M_Z.

The ordinary old zero strip contains t_A(-R)=1, and the old harmonic strip contains s_A(-V_R)=-2. Thus these evaluations do not borrow current-child recurrence.

## G2: algebra verified; geometric inclusions require the explicit bounds
The identities

 TA t_Z=M t_A+s_A,
 TA s_Z=M s_A+2t_A,
 Md=D TA+d-n,
 M LA=L_Z TA-2n

follow exactly from dN-nD=1. If the geometry places w in BOTH harmonic strips, then F_Z(w)=F_A(w)=h0(w). If it also puts t_Z(w) in the specified central slip interval, D+(w) lies in [-1,1]. Since z=w+Z and Z is the authentic zero-primary period, D+(z)=D+(w). The restored-native ALT bound D+(z) in [0,2] then forces D+(z) in {0,1}; hence J_Z(z)=F_Z(w)=F_A(w).

This audit has NOT independently established those three geometric inclusions solely from the identities above. They need the actual native-A bounds and ALT cutoff substituted with parity tracked. Until those inequalities are supplied/reviewed, G2 remains conditional on them. No adverse arithmetic example has been found, but absence of one is not a proof.
