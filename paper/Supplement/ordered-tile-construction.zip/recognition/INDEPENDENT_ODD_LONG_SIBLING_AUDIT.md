# Independent strict saved3/W0 odd-alternate LONG sibling audit

## Verdict
PASS as a conditional whole-native head comparison, with the same authentic earlier-field and calibrated-source premises as WHOLE_PHYSICAL_CORRECTED_HEADS.md and its final endpoint audits. The extension requires no new zero-index fold. It is not a proof of current odd alternate recurrence, global binary admission, or an unverified outer maximum. The older main note's residual endpoint wording is superseded by INDEPENDENT_FINAL_ENDPOINT_WRAP_AUDIT.md and INDEPENDENT_ALL_HEAD_ASSEMBLY_AUDIT.md.

## 1. Independent exact gauges
Use A=(d,n), Z=2A+R, det(A,R)=1, C=A+kZ, O=C+Z=A+(k+1)Z, k>=1. All c_X below are positive (T_X+L_X)/2, so the actual secondary character is -c_X. Put y=z+V_C+iZ, z'=2A+V_Z+delta-z, delta=(1,-1), and j=2k+2-i. The genuine W0 odd sibling comparator is

 min(F_O(y), F_O(y+V_Z)-b_Z dot y+c_Z+1).

Subtract the predicted head jet b_C dot y+eta_C+1. The SECOND offer becomes exactly F_O(z+iZ), since y+V_Z=z+iZ+V_O and
 -b_O dot V_C-c_O+c_Z-eta_C=0.

For the FIRST offer, delta-y=z'+jZ-2O-V_O. Primary character0 and the negative secondary law F_O(w-V_O)=F_O(w)-b_O dot w-eta_O give

 F_O(z'+jZ)-F_Z(z')+F_Z(z-2A)+1.

The old reflection identity used here is
 F_Z(z')=F_Z(z-2A)-b_Z dot z+2-eta_Z.

All constants, both vector coordinates and the two residual polynomials independently reduce to0 modulo det(A,R)=1 in odd_long_sibling_algebra.py. In particular the +1 in the odd comparator and the +1 in the predicted head jet cannot be removed. No alternate-field character is substituted for a standard character.

## 2. All required physical queries are licensed
Apply the previously proved whole-crop stationary theorem with m=k+1 and stationary odd field O. For every point of the ACTUAL restored old ALT Z crop,

 F_O(z+lZ)=F_Z(z) for1<=l<=2k;
 F_O(z+(2k+1)Z)=min(F_Z(z),h(z)-1).

The geometric theorem gives z+lZ in the genuine odd polygon E_O for the entire range1<=l<=2k+1. The same holds for z', because the old restored CROP, not merely an unbounded formula, has the authenticated reflection z↦z'. Thus all queries above use a paid native standard chart and its true physical extension. There is no evaluation of the unperiodized two-source minimum outside its license.

## 3. Interior and endpoint calculation
Normalize by F_Z(z), let D=F_Z(z)-F_Z(z-2A), and e_l(v)=F_O(v+lZ)-F_Z(v). The normalized minimum is

 min(e_i(z),1-D(z)+e_(2k+2-i)(z')).

For2<=i<=2k both errors vanish. Its value is min(0,1-D), which equals the old midpoint minus F_Z on the genuine native three-value set D∈{0,1,2}.

At i=1 the first error vanishes, while the second is the single known fringe. The already authenticated reflected fringe identity gives

 min(0,1-D,c_A-P(z)).

The earlier complete-crop endpoint inequality P(z)<=c_A+1_{D(z)=2} makes the third term no smaller than min(0,1-D); the first two already attain that minimum. Thus equality holds. The case i=2k+1 follows by z↦z', i↦2k+2-i and D(z')=2-D(z). For k=1 the list is1,2,3, with index2 interior and the two fringes covered exactly the same way. Neither endpoint ever requests l=0.

## 4. Literal LONG support and calibration boundary
The original get_l_correct explicitly uses the actual qa2 operand in its odd-helper branch after translate_alts, and emits one full translated G3 per head-loop iteration. LONG has exactly one additional iteration compared with SHORT. In the present stationary notation the RIGHT list is1..2k. The LEFT list must be placed using the corrected ODD ALTERNATE offsets, not the standard-even offsets: its extra +Z changes the effective index list to2..2k+1. The source code get_alt_child_c uses getAltOddTileFull, with Gl in natural slot3 and Gr in slot4; the later chronological permutation changes merge order but not their physical origins. Accordingly the union of genuine head indices is1..2k+1. The algebra above covers every point of each such full authentic crop, including any overlap.

This count/placement statement retains the prior authenticated raw restoration, helper alignment, and outer affine calibration as explicit constructor inputs. The script's final max-normalization is not inferred from an address list. If a separately implemented finite padded helper loses sites, the conclusion applies to the actual retained crop only; it does not restore them by fiat. No new source-mask reconstruction from a relaxed polygon is used.

## 5. Noncircularity and precise conclusion
The analytic two-slip comparator is used as an independently admitted physical standard-field comparison on the actual odd sibling crop. Its evaluation uses the strictly earlier O field and the whole-crop stationary native theorem, not the desired new odd alternate identity. The earlier P/D endpoint inequality comes from the paid full physical D interval and old R2 guards, as detailed in the final wrap audit; the central absolute-value interval alone would not suffice. All native heads therefore have the predicted old midpoint plus b_C dot y+eta_C+1, conditional on the stated actual calibration. Extending this to an entire new output also requires its other source pieces and chronological calibration, and claiming recurrence requires its own physical comparison/forcing argument.
