from pathlib import Path
import sys
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
from collections import Counter
C=Path(__file__).resolve().parent
def run(w):
 assert w.count('1')%2==0 and w[-1]=='3'
 mats,alts=alg.get_odometers(w);po,Zf,Af,Rf=getFracs(w);Z=(Zf.denominator,Zf.numerator);A=(Af.denominator,Af.numerator);R=(Rf.denominator,Rf.numerator)
 va=alg.vf(Af)[1];U=(2*A[0],2*A[1]);V=(int(va.real),int(va.imag));b=(A[1],-A[0]);T=-sum(t*u for t,u in zip(b,V));L=sum(A);eta=(T-L)//2;c0=(T+L)//2
 S=alg.export_tile(mats[1]);Al0=alg.export_tile(alts[1]);P=alg.export_tile(mats[2]);F=review.Field(Z[1],Z[0],S);Fa=review.Field(A[1],A[0],P)
 O=(R[0]-V[0],R[1]-V[1]);O=O if O[1]>=0 else(0,0);Araw={(x-O[0],y-O[1]):v for(x,y),v in Al0.items()}
 def zz(z,w,m=1):return tuple(v+m*u for v,u in zip(z,w))
 def dot(z):return sum(s*t for s,t in zip(b,z))
 def D(z):return F.g(z)-F.g(zz(z,U,-1))
 def pp(z):return F.g(z)-F.g(zz(z,V))+dot(z)
 def J(z):return F.g(z)-D(z)//2
 shifts=Counter(v-J(z)for z,v in Araw.items());C0=shifts.most_common(1)[0][0]
 print(w,'A R Z',A,R,Z,'O',O,'phase',F.phase,'Jconst',shifts.most_common(3),'num',len(shifts),flush=True)
 if len(shifts)>1:return
 one=[];tb=Counter();tw=Counter();g1=Counter();g2=Counter();g2p=Counter()
 for z in Araw:
  q=zz(zz(z,U,-1),V,-1)
  if q in S:
   v1=D(z);v2=pp(q)-c0;direct=J(z)-F.g(q)-dot(z)-eta-1;calc= -1-v2+(v1+1)//2
   assert calc==direct;tb[(v2,v1)]+=1;g1[direct]+=1
  q=zz(z,Z,-1)
  if q in P:
   shift=F.g(q)-Fa.g(q);dif=J(z)-Fa.g(q);di=D(z);assert dif==shift-di//2;tw[(shift,di)]+=1;g2[dif]+=1
 print('G1',g1,'P−c0,D(z)',tb,'G2',g2,'F(q)−A(q),D(z)',tw,flush=True)
 lam=lambda q:Z[0]*q[0]+(2*Z[0]-Z[1])*q[1]
 sq={lam(q):2*(pp(q)-c0+1)-D(zz(zz(q,V),U)) for q in S}
 Tz=Z[0]**2+2*Z[0]*Z[1]-Z[1]**2
 lifts={h+Tz*(ss//2)for h,ss in sq.items()};assert len(lifts)==Tz
 ov={zz(zz(z,U,-1),V,-1)for z in Araw if zz(zz(z,U,-1),V,-1)in S}
 hv=[lam(q)for q in ov];inside=[h for h in range(min(hv),max(hv)+1)if h not in lifts]
 print('full special lift vs T',Tz,(min(lifts),max(lifts)), 'overlap λ',(min(hv),max(hv)),'missing in range',len(inside),'firstlast', (inside[:5],inside[-5:]),'overlap distinct',len(set(hv)),flush=True)
 return {'word':w,'A':A,'Z':Z,'R':R,'restoration':O,'constant':C0,'G1':sorted((list(k),v)for k,v in tb.items()),'G2':sorted((list(k),v)for k,v in tw.items())}
if __name__=='__main__':
 out=[run(w)for w in sys.argv[1:]];(C/'SAVED3_SCALAR_ROWS.json').write_text(json.dumps(out,indent=2))
