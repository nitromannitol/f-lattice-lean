# Final independent audit of SAVED3_W0_TWO_CONTACTS_FROM_RAW_MIDPOINT, §§2–3

## Verdict and scope
PASS as a chronological conditional theorem under the four explicit earlier-field inputs in that note. I independently checked every displayed projection, the parity and gcd exceptions, the inequalities in §§2–3, and the two midpoint deductions. No correction to the conclusions is required. In particular the G2 geometric inequalities that remained pending in my earlier note are now verified. The earlier note's pending status is superseded by this final review.

This audit does not independently establish the actual crop containments in Input4, the true restored alternate midpoint and scalar in Input3, or the original source-selection/retention facts used in §4. These are explicit producer obligations, not hidden conclusions. The native crop bounds must be for the specified actual frames, especially the improved odd native s lower bound; replacing them by the larger closed-polygon bounds invalidates the G1 argument.

## §2: G1 chart membership and both exceptional points
Let K=M(A,Z), T=T_Z, L=D+N, c=D-N. All three points have equal parity because v has even coordinate sum and U=2A. The four projection changes are correct: t(w)=t(q)-K, t(z)=t(w)+2, s(w)=s(q)-2, s(z)=s(w)+2K.

For odd transverse lower bounds the restored ALT inequality gives t(w)>=L-T-D=N-T exactly. For even roots it gives t(w)>=L-T-max(c,2N)>=2-T, since both L-c=2N and L-2N=c are at least2. Upper t bounds follow directly from q's E bound and K>2.

The improved odd native bound is essential: min(3N-D,c)>=4-c because 3N-D=2N-c and N>=2,c>=2. Thus w remains above the odd lower E edge. The ALT upper s bound is within the odd E upper edge since 2N+2<=L-2 iff c>=4, and c<=L-2 iff N>=1. Both hold in the strict cone. This checks the potentially troublesome ODD upper bound without silently using the even rectangle.

At even roots s values are even. The lower failure is exactly s(w)=-2, hence s(q)=0. Coprimality and odd D,N give primitive kernel V_Z/2, which has odd parity, so even points on that line are exactly integer V_Z translates. The t interval [2-T,L-2], with T>L, includes only q=0.

The upper failure is exactly s(z)=T+2N+2. The reference z*=H-v has t=L-T+K. Its nearest even same-s neighbors have t=L+K and L-2T+K. The first exceeds the known upper bound L-K; the second lies below2-T since L+K<T, a consequence of K<T/2 and L<T/2. Thus z=z*. No other even exceptions occur. The complementary s bounds follow from K>2 and the bounds on q,z, as stated.

## Direct second-exception expansion (independent of a global M reflection shortcut)
Use B=M(A,R), LA=d+n, cA=(TA+LA)/2, and the true old reflection F_A(I-u)=F_A(u), I=(1,-1), together with the actual U and v jets. At v the two offers are 1-cA and -cA, as in the written proof: F_A(-R)=0 from t_A(-R)=1, and F_A(-V_R)=-eta_R from s_A(-V_R)=-2. The authentic F_Z(v)=h0(v)=-cA equals the lower offer.

At z*=Z+V_Z+I-v, the first source argument is

 x*=z*-R=2A+v+V_R+I.

Removing primary2A, then using the v jet and reflection, gives

 F_A(x*)=F_A(V_R+I)+b_A.(V_R+I)-cA
          =F_A(-V_R)-B+LA-cA
          =LA-cA-B-eta_R.

The second source argument is

 x*-te=z*-V_R=2A+R+v+I.

Its parent value is

 F_A(x*-te)=F_A(-R)+b_A.(R+I)-cA=LA-1-cA.

Also b_R.x*=2-B-T_R+L_R. Thus adding the genuine second-source jet and scalar yields

 LA-1-cA+(2-B-T_R+L_R)+eta_R
 =LA-cA+1-B-eta_R,

exactly one more than the first offer. Independently, authentic child reflection plus the V_Z jet gives

 F_Z(z*)=F_Z(v)+K-eta_Z=-cA+K-eta_Z.

Since K=2TA+B and eta_Z=2TA+2B+eta_R-LA, this equals LA-cA-B-eta_R. Therefore F_Z=M_Z at z* by direct pricing. This independently verifies the written common-affine-reflection conclusion. It is important not to replace that affine reflection by unqualified invariance about H; the invariant reflection is about I, and moving to H introduces the deck jet.

The integer rounded-min identity and normalization were checked in the previous audit, so these membership and exception checks complete G1 under Inputs1–4.

## §3: G2 harmonic and central-strip inequalities
From actual restored ALT membership of Z+w and s_Z(Z)=T,

 s_Z(w)<=max(2N+2,c)<=L,

because c>=2. The four cross-coordinate identities in the proof follow exactly from det(A,R)=1.

Using t_A>=1-TA gives

 s_A <= LA+(2n+2TA-2)/K < LA+2.

The final strict inequality is justified by K>2TA and n<TA: the numerator is strictly below4TA while2K>4TA. With s_A>=-d, this is inside [1-2d,2LA-1] (indeed LA>=7 here). Thus F_A(w)=h0(w).

Conversely

 s_Z >=(-Kd-2TA+2)/TA
      =-D-2-(d-n-2)/TA >-D-3,

since TA>d-n-2. As s_Z is an integer, it is at least -D-2, which is at least1-2D for D>=3. This integer step makes the proof's terse D>=3 justification precise. The upper s_Z<=L is inside2L-1. Therefore F_Z(w)=h0(w) as well.

For t_Z, the lower estimate is

 t_Z>=-K+(K-d)/TA >-K,

using K>d. For the upper estimate, max(d,2n)<2d<TA and LA<TA give

 t_Z<=K max(d,2n)/TA+2+LA/TA <K+3.

These bounds lie in [3-D-K,N+2D-1+K], since D>=3 and N+2D-1>=3. No parity extension of the slip interval is needed. Finally Z is the true zero-primary period, so F_Z(Z+w)=F_Z(w) and D+(Z+w)=D+(w). The central interval gives D+ in [-1,1], and restored ALT membership gives D+ in [0,2]. Its integer value is therefore0 or1, whose floor after division by2 is zero. This proves G2.

## Dependency and independence assessment
The proof uses only previously produced actual standard periods, jets, strips and closed-polygon realization; actual restored alternate midpoint and scalar ranges; exact source chronology; and the stated all-sector crop envelopes. It does not use current outer-head agreement, current output recurrence, source-owner labels, or finite sample extrapolation. The symbolic identities are checked algebraically; the supplied identity_audit.py is a useful additional machine check but not a replacement for the explicit inequalities reviewed here. The proof remains a conditional reusable contact lemma, not a proof that all arbitrary-word producer obligations hold.
