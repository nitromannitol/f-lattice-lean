# Two saved-last-3 contacts from one rounded minimum identity

**Result.** In the strict saved-last-3/W0 frame, the two complete reflected first-head comparisons follow from the *earlier* standard two-chart representation, strips and actual restored alternate midpoint, together with domain envelopes. No subdivision by earlier RIGHT/LEFT, middle, principal, or odd-primitive heads is required. The proof works at genuine native intersections even if those earlier first-owner labels change. It proves exact values, not just roofs.

This is a chronological deduction under a stated earlier-field invariant. It does not itself prove an earlier alternate equals the midpoint at every creation, or prove the current first head agrees with the independent current target on its fresh outer boundary.

## Coordinates and earlier input

Write A=(d,n) proper odd, R=(e,r) proper even, Z=2A+R=(D,N), det(A,R)=dr−ne=1, W=0. This includes both strict saved cores Z=2sA+E, R=2(s−1)A+E, s≥2. Retain the true standard and restored alternate coordinates; Z also denotes the even primary period vector. For definiteness d≥5,n≥2,d−n≥3, e−r≥2,r≥1, gcd(D,N)=1. For X=(d_X,n_X) use

    b_X=(n_X,−d_X),  V_X=(n_X−d_X,d_X+n_X),
    t_X(y)=b_X·y,     s_X(y)=(d_X+n_X)y1+(d_X−n_X)y2,
    L_X=d_X+n_X,     T_X=−b_X·V_X,     M(X,Y)=−b_X·V_Y,
    η_X=(T_X−L_X)/2, c_X=(T_X+L_X)/2.

Put U=2A, v=V_A, K=M(A,Z), T=T_Z,L=L_Z,c=D−N. Earlier inputs:

1. F_A and F_Z have their authenticated primary periods and V jets b_X·y−c_X, and their actual global zero and harmonic strips: F_X=0 if 1−d_X≤t_X≤n_X+2d_X−1; F_X=h0 if 1−2d_X≤s_X≤2L_X−1. The odd F_A strips are in its actual phase-zero standard coordinates.
2. On the closed polygon E_Z, F_Z=M_Z, the authentic two-copy minimum. For x=q−R, te=V_R−R,
   
       M_Z(q)=min(F_A(x), F_A(x−te)+b_R·x+η_R).
   
   Both M_Z and F_Z have the SAME standard affine reflection under y↦H−y, H=Z+V_Z+(1,−1). Do not assume F_Z=M_Z elsewhere.
3. The earlier restored W0 alternate in THESE coordinates, with fixed scalar, equals J(z)=ceil((F_Z(z)+F_Z(z−U))/2). On its native crop 0≤D+(z)=F_Z(z)−F_Z(z−U)≤2. On the complete scalar interval [3−D−K,N+2D−1+K], |D+|≤1. Here K=|t_Z(v)|. These are earlier-field hypotheses, not consequences of partial native compatibility or of one-sided head scalar bounds.
4. A native standard Z point belongs to E_Z, whose exact parity rectangles are even t∈[2−T,L−2], s∈[0,T+2N], odd t∈[N−T,D], s∈[2−c,T+L−2]. Its ACTUAL odd native crop has lower s at least min(3N−D,c), which may be better than the polygon lower bound. Earlier standard A native bounds include s_A≥−d, s_A≤2T_A+L_A, 1−T_A≤t_A≤max(d,2n). The genuine restored W0 alternate Z crop is inside t_Z≥L−T+2−hχ, h_odd=D, h_even=max(c,2N), and s_Z≤T+2N+2 (even) or T+max(c,2N+2) (odd). These are containments, not filled-crop hypotheses. They are the previously adopted all-sector standard crop and restored W0 R2 upper/lower rows.

## 1. A raw identity independent of the parent shape

Write the two branches at q as B and B+ψ. Moving q by v changes B by b_A·(q−R)−c_A; it changes the gap by −b_A·te+b_R·v=−1. Moving another U changes B by zero and ψ by b_R·U=2. Hence the two raw values at q+v and q+v+U share first branch B+b_A·(q−R)−c_A and have respective gaps ψ−1,ψ+1. For any integer h,

    ceil((min(0,h−1)+min(0,h+1))/2)=min(0,h).

The only nontautological case h=0 gives ceil(−1/2)=0. Thus, for every physical q, putting z=q+v+U,

    ceil((M_Z(z−U)+M_Z(z))/2)=M_Z(q)+b_A·z+η_A+1.     (*)

The constant uses b_A·R=−1, b_A·v=−T_A and c_A+η_A=T_A. In fact (*) is sign-uniform as a RAW identity for a child with ε=2W−1, lv=(1−W)R, te=V_R+εR, σ=2εA: evaluate the two endpoints q+v and z=q+v−σ. Their gaps are ψ−1,ψ+1 since b_A·R=ε and b_R·(−σ)=2. The constant at right becomes η_A+1−W. This algebra alone is NOT a license to apply an unperiodized minimum wherever the earlier periodic standard is queried.

## 2. The entire first reflected contact (G1)

Assume q∈dom(native standard Z) and z=q+v+U∈dom(restored native alternate Z). Then

    J(z)=F_Z(q)+b_A·z+η_A+1.                             (G1)

Here is the physical chart check that (*) requires. Set w=q+v. All three sites have the same physical parity. Their projections satisfy

    t(w)=t(q)−K,   t(z)=t(w)+2,
    s(w)=s(q)−2,   s(z)=s(w)+2K.

The upper t bound on q and K>2 imply the proper E upper bound on w,z. For their lower bound, the true ALT bound gives t(w)=t(z)−2≥N−T at odd sites, and t(w)≥L−T−max(c,2N)≥2−T at even sites. Thus transverse membership in E is paid for both, without extrapolating an occupied crop.

Odd sites: the genuine standard q has s(q)≥min(3N−D,c)≥4−c, since N≥2,c≥2. Therefore w,z have s≥2−c. The ALT upper bound s(z)≤T+max(c,2N+2)≤T+L−2 (c≥4); w is smaller. Both are in E.

Even sites: s(w)≥−2, s(z)≤T+2N+2. Both s values are even. The only possible lower excursion is s(w)=−2, hence s(q)=0. Since gcd(D,N)=1, D,N odd, the kernel of s on parity-even differences is Z V_Z (the primitive generator V_Z/2 has odd coordinate sum). Thus q is a multiple of V_Z, and its E transverse interval [2−T,L−2] forces q=0, w=v. At the other end only s(z)=T+2N+2 is excluded. The even point H−v has exactly this s and t(H−v)=L−T+K. Every other even point at that s differs by kV_Z, changing t by kT up to sign. The bounds 2−T≤t(z)≤L−K exclude both neighbors L+K,L−2T+K, as K<T/2 and L<T/2. Thus z=H−v. There are no other escaping inputs. The complementary s bounds for z and w follow from s(w)=s(q)−2, s(z)=s(w)+2K, K>2.

Both true exterior values are paid, not discarded. At v, s_Z(v)=−2, so F_Z(v)=h0(v)=−c_A. The first M branch at v is F_A(v−R)=1−c_A: t_A(−R)=1, so F_A(−R)=0 and use its V_A jet. The second is F_A(v−V_R)+b_R·(v−R)+η_R=−c_A, because s_A(−V_R)=−2, F_A(−V_R)=h0(−V_R)=−η_R, and b_A·(−V_R)+b_R·v=0. Hence F_Z(v)=M_Z(v); the true common affine reflection yields F_Z(H−v)=M_Z(H−v). Since q∈E as well, both midpoint inputs and the center in (*) can now legitimately use F_Z. This proves (G1).

For emphasis, a direct substitution of (*) on EVERY earlier restored alternate point, suppressing q∈dom(native Z), is false. In the genuine word323 earlier Z example, q=(−27,9), z=(−22,16) is restored-native alternate but q is outside the needed standard crop; J(z)=−173 versus the proposed raw transplant −174. This is not a counterexample to (G1) or to the desired recurrence.

## 3. The entire second reflected contact (G2)

Let w be ACTUALLY native standard A, z=Z+w actually native restored ALT_Z. Then

    J(z)=F_A(w).                                          (G2)

Use only the support bounds in §0. As s_Z(Z)=T, we have s_Z(w)≤max(2N+2,c)≤L (since c≥2). The determinant gives the exact identities

    T_A t_Z(w)=K t_A(w)+s_A(w),        T_A s_Z(w)=K s_A(w)+2t_A(w),
    K d=D T_A+d−n,                    K L_A=L T_A−2n.

Hence s_A(w)≤(T_A L+2T_A−2)/K = L_A+(2n+2T_A−2)/K < L_A+2, using K>2T_A and n<T_A. With s_A(w)≥−d this places w in A's entire harmonic strip. Conversely s_Z(w)≥(−Kd−2T_A+2)/T_A>−D−3; since D≥3 this and s_Z(w)≤L place w inside Z's harmonic strip. Thus F_A(w)=F_Z(w)=h0(w).

Also t_Z(w)≥−K+(K−d)/T_A>−K using t_A(w)≥1−T_A,s_A(w)≥−d. And t_Z(w)≤K max(d,2n)/T_A+2+L_A/T_A<K+3, since 2d<T_A and L_A<T_A. Both inequalities lie safely inside the earlier central D+ interval [3−D−K,N+2D−1+K]. As t_Z(z)=t_Z(w), |D+(z)|≤1. Its true ALT native width gives D+(z)≥0; rounding F_Z(z)−floor(D+(z)/2) thus returns F_Z(z)=F_Z(w)=F_A(w). No division into principal/middle/terminal owners, no putative raw retaining scalar, and no current native admission was used.

## 4. How this pays an actual head, and where it stops

The earlier literal strict saved3 frame theorem (frozen in historical_sources/) gives the TRUE restored first right odd-L head as J_Z(y−v−Z)+b_A·y+κ. Its already-retained last G1 is standard Z, G2 is standard A at V_Z with slope b_Z and scalar η_Z. Earlier G1 copies are excluded geometrically; the genuine touching site V_A+Z is present. The two genuine reflected excesses reduce to

    F_Z(q)+b_A·t−J_Z(t)+2η_A+2,      F_A(u)−J_Z(Z+u)+η_A+1.

(G1) and (G2) make BOTH identically η_A+1 on their entire respective native intersections. Thus the actual first touching scalar is η_A+1, and the new head has zero excess at EVERY previously owned overlap. Every later head misses the standard prefix and is aligned by true adjacent native contacts and earlier displacement characters. The identical same-order reflection gives the paired LEFT if that actual reflection is licensed. This deduces the previously detailed strict-saved3 internal contact/retention from the ordinary earlier P/D/J invariant and source geometry, without carrying the calibrated RIGHT/common chart, middle-R and principal-A earlier owner scalars as separate value inputs.

Still required are the proper source selection and its true phase/shift, the genuine earlier midpoint in the restored frame with the correct scalar, previously retained ordinary prefix, touching ports/exclusions and source reflection; their age is explicit. Whole-head retention inside a helper does NOT automatically identify all fresh head values with the *current* target, compare it against other earlier outer sources, fix the whole output's maximum, establish the eight constructors or repair finite padding. This is the induction implication, not an all-word proof.

## Validation

identity_audit.py freshly checks 17 exact determinant/jet/projection identities modulo det(A,R)=1 and ten strict cone inequalities without sampling (all coefficients nonnegative after shifting nonnegative variables). The rounding identity and gcd/interval uniqueness proofs are explicit above. check.py, common_full.py and unrestricted.py are finite sanity checks using the original algorithm port, not the universal argument. They confirm both complete equality windows and the two exact permitted excursions, and exhibit the counterexample to omitting the real domain guard. Original saved3 strict source and R2 convention notes are bundled; their existing provenance is not promoted to fresh reimplementation by copying. The final independent semantic audit, FINAL_INDEPENDENT_TWO_CONTACT_AUDIT.md, checks both contacts and prices the second exceptional input directly without assuming raw-sheet reflection. Its verdict is PASS under the four stated earlier inputs.
