# Independent strict-W0 all-crop parent-dominance audit

## Verdict
The proposed all-crop dominance is valid under the stated earlier-field invariant, augmented explicitly by the genuine native P span on E_Z and its deck characters. The right-transverse case requires either the authentic ALT upper-t row supplied by the parent, or the earlier negative-V sign extension below. The latter eliminates that extra geometric premise entirely. No current-child recurrence or current outer-cover claim is used.

Retain A,Z,R,U,v,K,T,L,c,cA as in SAVED3_W0_TWO_CONTACTS_FROM_RAW_MIDPOINT. At an arbitrary TRUE restored native ALT_Z point z, put q=z-v-U and

 h(z)=F_Z(q)+b_A.z+eta_A+2.

Then h(z)>=F_Z(z) on that entire crop, without requiring q to be native. This is an inequality, not an extension of the false unrestricted G1 equality.

## Exact scalar reduction and source formula
P(q)=F_Z(q)-F_Z(q+v)+b_A.q and D+(z)=F_Z(z)-F_Z(q+v). Since b_A.z=b_A.q-TA and eta_A-TA=-cA,

 h(z)-F_Z(z)=P(q)-D+(z)-cA+2.

Thus the desired inequality is precisely Phi_minus(q)>=cA-2, with Phi_minus(q)=P(q)-D+(q+v+U). The signs and additive2 are correct.

For the genuine odd child with parents (A,Z), W0, the authentic two-Z source formula is

 M_odd(z)=min(F_Z(z),F_Z(z-v-U)+b_A.z+eta_A+2).

This is exactly the W0 specialization of the recorded ordinary odd source formula in ODD_TWO_Q_DONOR_SHIELDING.md. It is the adjacent odd child A+Z when the true creator tuple is (A+Z,2A+Z,A,Z), as stipulated for this saved3 creation. This does not identify F_(A+Z) outside its own licensed closed polygon.

## Geometric exhaustion of the three cases
The restored ALT lower-t row gives

 t(q)>=L-T-h_chi+K.

For odd roots h_chi=D, so this exceeds N-T. For even roots L-h_chi=min(2N,c)>=2, so it exceeds2-T. Therefore q can never fail the lower t bound of E_Z.

The restored ALT upper-s row gives even s(q)<=T+2N+4-2K<=T+2N. At odd roots the previously checked max(c,2N+2)<=L-2 gives s(q)<=T+L-2 after subtracting2K-2. Thus q cannot fail the upper s bound either. All possible failures are therefore a lower-s failure or an upper-t failure. Handle lower s first; if it does not fail, q lies in the genuine s interval.

### Case 1: q lies in E_Z
The two sites q,z suffice. The ALT lower-t row and t(z)=t(q)-K+2 put z above E's lower t edge; q's upper t bound puts z below its upper edge. Its s lower edge follows from s(z)=s(q)+2K-2. The odd ALT upper s is already inside E. The sole even upper exception is z=H-v, by the same parity/gcd and t-interval argument audited for G1. That point's authentic value equals its raw M value by the direct source computation in FINAL_INDEPENDENT_TWO_CONTACT_AUDIT.md.

Consequently both F_Z(q) and F_Z(z) equal the two-copy raw minimum. If its gap at q is psi, the first branch gains b_A.(q-R)-cA while the gap gains1 at z=q+v+U. Hence

 F_Z(z)-h(z)=min(0,psi+1)-min(0,psi)-1 <=0.

This is an exact integer inequality (indeed true over real psi); no intermediate value at q+v is invoked.

### Case 2: q lies below E's lower s edge
Use the earlier full native P span cA-1<=P<=cA on E and characters P(Z)=-1,P(V_Z)=0. The exact parity rectangles for E have s width at least T and t width at least T. Choose i=floor((s(q)-s_min)/T)<=-1 so that q-iZ has s in [s_min,s_min+T). Then choose an integer j to place its t inside the genuine parity t interval. Both periods preserve parity, so the resulting q0 lies in E, and q=q0+iZ+jV_Z. Therefore

 P(q)=P(q0)-i>=cA.

The true restored native ALT bound D+(z)<=2 yields P(q)-D+(z)>=cA-2. The folding argument is not a claim that the literal standard crop fills E: P's span is assumed on the authenticated CLOSED POLYGON E, and the exact rectangle characterization licenses the folded point there.

### Case 3: s(q) is inside E's interval but t(q) is above its upper bound
Fold only by V_Z into E. Since its parity t interval has width at least T, this is possible at the fixed s, and P(V_Z)=0 gives P(q)>=cA-1.

The inequality t(q)>t_max implies t(z)=t(q)-K+2>=3-D-K in either parity. We need D+(z)<=1. There are two legitimate routes:

(a) Add the genuine restored ALT upper row t(z)<=h_chi, h_odd=D,h_even=max(c,2N), as an explicit old geometry premise. This upper bound is smaller than N+2D-1+K, so the complete central D+ interval gives the result.

(b) No extra ALT upper row is needed. The earlier negative-V sign lemma states t>=N+1 implies D+(t)<=0. Its proof uses only true native quotient coverage, native0<=D+<=2, ordinary zero strip, and D+(V_Z)=2. Choose native y=z+aZ+lV_Z. If t(z)>=N+1, a negative l is excluded by the native upper t bounds and T. For l>=1, D+(z)=D+(y)-2l<=0. For l=0 both y and y-U have t in the ordinary zero strip (the latter t is t(y)-2), hence D+=0. Together with the central interval [3-D-K,N+2D-1+K], this proves D+<=1 on the ENTIRE half-line t>=3-D-K. Apply it at z.

Thus P(q)-D+(z)>=cA-2 in this last case as well.

## Consequences and limitations
All three cases prove M_odd(z)=F_Z(z) on the entire true restored native ALT_Z crop. This proves a uniform source dominance/shielding fact on that crop. It does not prove that the adjacent odd native field equals its raw minimum away from its licensed polygon, does not prove its recurrence, and does not by itself compare a helper's fresh boundary with every independent outer source.

Chronological dependencies: earlier standard global deck/strip realization; earlier closed-polygon P span and exact parity rectangle geometry; earlier F_Z=M_Z on E; the already paid single reflected exceptional price; earlier restored alternate native D range and lower-t/upper-s rows; and the authentic current odd source formula. Route(a) additionally uses the old upper-t row; route(b) instead derives the needed extension from earlier cover/range/zero-strip inputs already present. No finite parameter sampling is used in this audit.

## Stationary-run extension: exact independent expansion
Let C=A+jZ with integer j>=0, and consider the actual W0 odd source formula for P=C+Z. At y=z+iZ, where z is in the true restored ALT_Z crop, set q=z-v-2A. The second source argument is

 y-V_C-2C=q+(i-2j)Z-jV_Z.

The genuine primary zero and negative secondary deck formula give

 F_Z(y-V_C-2C)=F_Z(q)-j b_Z.q+j c_Z-T_Z j(j+1)/2.

Also b_C.y=b_A.z+j b_Z.z-i, because b_A.Z=-1. The true quadratic and scalar expansions are

 T_C=T_A+2jK+j^2 T_Z,
 eta_C=eta_A+jK+j^2 T_Z/2-jL_Z/2.

Using b_Z.(z-q)=2-K and c_Z=(T_Z+L_Z)/2, every quadratic term cancels and the second offer is exactly

 F_Z(q)+b_A.z+eta_A+2+2j-i = h(z)+2j-i.

The first offer is F_Z(y)=F_Z(z). The preceding all-crop dominance therefore proves

 M_P(z+iZ)=F_Z(z) whenever j>=0 and i<=2j.

This is valid on the full restored ALT_Z crop for the analytic two-source M_P. It identifies the authentic F_P only where y=z+iZ is separately licensed to lie in its actual E(P) and where the genuine creator uses this W0 source formula. Neither condition is inferred from periodization of the old field.
