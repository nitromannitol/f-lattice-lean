# Independent final endpoint-wrap audit

**PASS**, under the explicitly earlier saved3/W0 field, scalar-window, restored-crop and longitudinal-price inputs. This closes the residual identified in endpoint/ENDPOINT_RESIDUAL_ADDENDUM.md; it does not newly prove those earlier inputs or a current constructor calibration.

Use the adjacent saved3 conventions: A=(d,n), Z=(D,N), U=2A, v=V_A, V=V_Z, T=T_Z, K=M(A,Z), c_A=(T_A+L_A)/2. P(z)=F(z)-F(z+v)+a_A.z and D(z)=F(z)-F(z-U). In the restored actual ALT crop, 0<=D<=2. The conclusion is
 P(z)<=c_A+1_{D(z)=2}.

## Exact signs and physical scalar window

The actual standard jets give
 P(z+Z)=P(z)-1, D(z+Z)=D(z),
 P(z+V)=P(z), D(z+V)=D(z)+2.
The last PLUS TWO follows from a_Z.U=2. Therefore, for x=z+Z and y=x+v,
 D(y)=D(y-V)+2,
 P(x)-P(x-U)=D(x)-D(y).
The second identity is exact cancellation of four true global F values; its affine remainder is a_A.U=0. There is no minimum representation outside E_Z in this step.

In the outstanding case y is strictly below the transverse lower row of E_Z. Since t_Z(y)=t_Z(z)-K,
 t_Z(y-V)=t_Z(z)-K+T.
At even y this is <=1; at odd y it is <=N-1. (Using parity can improve the even bound to0; this improvement is unnecessary.) The ACTUAL R2 lower row is t_Z(z)>=L-T+2-h, with h=D on odd sites and h in{D-N,2N} on even sites. Consequently
 t_Z(y-V)>=L+2-h-K > -K.
Since T>K and D>3 in the stated strict scope, -K>3-D-T. Thus the wrapped point lies in the entire earlier scalar interval
 [3-D-T, N+2D-1].
The earlier strong-price theorem supplies 0<=D<=2 on this COMPLETE physical scalar interval, not merely on a sampled/native subset. See strong_bulk/STRONG_PRICE_AND_ALTERNATE_STEP.md, the paragraph extending the zero strips to this interval. It follows that D(y)>=2. No mistaken use of the different central |D|<=1 interval occurs.

## The price at x-U, including the low-slope odd loss

Let w=x-U. Then s_Z(w)=s_Z(z)+T-2K. The actual restored W0 R2 lower row is
 s_Z(z)>=-T+2K-2-ex,
where ex=D-3N-2 only for lower-sector odd roots, and0 otherwise. Thus:
 - even w: s_Z(w)>=-2;
 - lower-sector odd w: s_Z(w)>=3N-D>=2-(D-N), since N>=1;
 - other odd w: s_Z(w)>=-2>=2-(D-N), since the present strict Z has D-N>=4.
So every odd case and every even case with s_Z(w)>=0 is licensed by the earlier longitudinal price bound after V-only/forward-primary folding. This is an earlier global P-bound input, not an assertion that w itself is necessarily native. It gives P(w)<=c_A.

The only additional even longitudinal value is s_Z(w)=-2: s_Z takes even values because D,N are odd. At that value s_Z(w+v)=-4. Both lie in the genuine earlier harmonic strip [1-2D,2L-1], so F(w)=h0(w), F(w+v)=h0(w+v). The exact harmonic character is
 h0(w+v)-h0(w)=a_A.w-c_A,
hence P(w)=c_A. This directly pays the true even -2 exception; no native membership is falsely assigned to it.

## Closing the residual

Combining the previous two sections,
 P(z)=P(x)+1=P(w)+D(z)-D(y)+1 <= c_A+D(z)-1.
For D(z)=0,1 this is <=c_A; for D(z)=2 it is <=c_A+1. Thus the desired endpoint inequality holds throughout the transverse-wrapped residual, including its endpoint D=1 cases.

Together with the already paid longitudinal high-s region, the direct matched-chart rectangle and the separately authenticated single v scalar excursion, this closes the entire restored ALT crop in the stated strict saved3/W0 setting. The proof needs no new finite census, current recurrence, global extension of the matched two-chart minimum, or assumption D=2 in the residual.

## Dependency boundary

1. Genuine earlier F_Z and its standard deck/strip jets.
2. Complete earlier nonnegative D scalar interval, as opposed to native-only D values.
3. Actual all-sector restored R2 containment (including ex).
4. Earlier native P<=c_A and the authenticated longitudinal fold price bound; the even s=-2 extension is proved above.
5. Previously paid direct matched-chart and v scalar cases.

All are strictly earlier or independently proved local inputs. The logical assembly is therefore noncircular. This audit does not substitute for the original-current head's affine scalar/phase restoration checks.
