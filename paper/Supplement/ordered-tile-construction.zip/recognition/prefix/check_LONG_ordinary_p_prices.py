import sys
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
for word in ['113','13','123']:
 k=1;m,_=alg.get_odometers(word+'2');om,_=alg.get_odometers(word+'22');cf,_,_,zf=getFracs(word+'2');of,*_=getFracs(word+'22');d,n=cf.denominator,cf.numerator;D,N=zf.denominator,zf.numerator
 FC=review.Field(n,d,alg.export_tile(m[0])).g;FO=review.Field(of.numerator,of.denominator,alg.export_tile(om[0])).g
 T=D*D+2*D*N-N*N;c=(T+D+N)//2;TA=d*d+2*d*n-n*n;L=d+n;W=word.count('1')%2;ct=Counter();ex={}
 for x in range(-3*d,4*d+1):
  for y in range(-2*d,4*d+1):
   t=n*x-d*y;s=L*x+(d-n)*y;lo,hi,sl,sh=(n-TA,d,2-d+n,2*TA+L-2)if(x+y)%2 else(1-TA,L-1,0,2*TA+2*n)
   if not(lo<=t<=hi and sl<=s<=sh):continue
   # pNear at (1-W)Z; W1 raw x=physical+Z, W0 x=physical; both x=u+Z
   X=x+D;Y=y+N
   raw=min(FO((X,Y)),FO((X+N-D,Y+N+D))-(N*X-D*Y)+c+1-2*W)
   diff=raw-FC((x,y));ct[diff]+=1;ex.setdefault(diff,(x,y,raw,FC((x,y))))
 print(word,'C',cf,'Z',zf,'O',of,'W',W,dict(ct),ex,flush=True)
