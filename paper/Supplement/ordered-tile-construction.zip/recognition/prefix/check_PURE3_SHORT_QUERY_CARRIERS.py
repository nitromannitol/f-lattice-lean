"""Uniform literal W0 seed/minimum by exact affine Presburger differences."""
from pathlib import Path
import ctypes as C,sympy as s,json
R=Path("recovery_20261101_0745");lib=C.CDLL('libisl.so.23')
def bind(n,args,ret=C.c_void_p):f=getattr(lib,n);f.argtypes=args;f.restype=ret;return f
ctx=bind('isl_ctx_alloc',[])();read=bind('isl_set_read_from_str',[C.c_void_p,C.c_char_p]);readmap=bind('isl_map_read_from_str',[C.c_void_p,C.c_char_p]);copy=bind('isl_set_copy',[C.c_void_p]);sub=bind('isl_set_subtract',[C.c_void_p,C.c_void_p]);inter=bind('isl_set_intersect',[C.c_void_p,C.c_void_p]);union=bind('isl_set_union',[C.c_void_p,C.c_void_p]);apply=bind('isl_set_apply',[C.c_void_p,C.c_void_p]);empty=bind('isl_set_is_empty',[C.c_void_p],C.c_int);txt=bind('isl_set_to_str',[C.c_void_p],C.c_char_p)
def parse(a):p=read(ctx,a.encode());assert p;return p
def S(a):return parse('{[m,x,y]:m>=1 and '+a+'}')
def is_empty(a):v=empty(a);assert v in[0,1];return v==1
def shift(a,dx,dy):mp=readmap(ctx,('{[m,x,y]->[m,u,v]:u=x+('+str(dx)+') and v=y+('+str(dy)+')}').encode());assert mp;return apply(copy(a),mp)
def allunion(seq):
 o=S('false')
 for a in seq:o=union(o,copy(a))
 return o
m,x,y=s.symbols('m x y');e=2*m+1;d=e+1;P=lambda t:t*(t+1)/2
base=-P(y)+y
Gord=S(f'{2-e}<=x<={e} and 0<=y<={e+1} and 1<=x+y<={e+2}')
Gp=[(inter(copy(Gord),S('x<=0')),base+x-1),(inter(copy(Gord),S('x>=1')),base),(S('x=0 and y=0'),base+x),(S(f'x=2 and y={e+1}'),base+1)]
Dq=allunion(a for a,h in Gp)
Pord=S(f'{2-d}<=x<={2*d} and 0<=y<={d+2} and 1<=x+y<={2*d+3} and not(y=0 and x>={d}) and not(y={d+2} and x<=2)')
seam=S(f'x+y={d+2} and 2<=y<={d}')
Pp=[]
for left in[0,1]:
 for top in[0,1]:
  for right in[0,1]:
   cond=('x<=0'if left else'x>=1')+' and '+(f'x+y>={d+3}'if top else f'x+y<={d+2}')+' and '+(f'x>={d+2}'if right else f'x<={d+1}')
   reg=inter(copy(Pord),S(cond));h=s.expand(base+(x-1 if left else 0)+(x+y-d-2 if top else 0)+(d+1-x if right else 0))
   off=sub(copy(reg),copy(seam));on=inter(reg,copy(seam))
   if not is_empty(off):Pp.append((off,h))
   if not is_empty(on):Pp.append((on,h+1))
Pp +=[(S('x=0 and y=0'),base+x),(S(f'x={d+2} and y={d+2}'),s.expand(base+(x+y-d-2)+(d+1-x)+1))]
Dp=allunion(a for a,h in Pp)


miss=sub(shift(Dq,-1,1),copy(Dp))
expected=S('x=-1 and y=1')
assert is_empty(sub(copy(miss),copy(expected))) and is_empty(sub(copy(expected),copy(miss)))
print('PASS: (Dq+V0) minus D1 exactly {V0}, every m>=1')
miss2=sub(shift(Dq,-2,2),copy(Dp))
print('second-fold excluded native region:',txt(miss2).decode())
