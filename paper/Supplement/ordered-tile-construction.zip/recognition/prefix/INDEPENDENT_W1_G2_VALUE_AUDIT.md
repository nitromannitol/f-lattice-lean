# Independent W1 G2 value audit: SHORT and LONG

## Verdict and inputs
The proposed price algebra and inequalities are correct under the explicit physical geometry, old-field bounds and source-normalization inputs below. No chronological scalar or helper-origin recognition follows solely from this calculation.

Let u in E_A, x=u+Z-2A, v=V_A, and retain the W1 Pstd,D conventions. Put r(z)=eta_A-Pstd(z) and R=r(x)-1-D(x-v). The authenticated near nesting/source identity supplies

 S=F_A(u)-F_Z(u-2A)=min(0,R).

This is an input from the genuine near p-donor theorem, not a consequence of scalar algebra alone. The commutator used in converting it is exact:

 r(z+2A)-r(z)=D(z)-D(z-v).

It follows immediately by expanding Pstd, since a_A.(2A)=0. The signs are compatible with D=F-F(.+2A).

## SHORT competing offer
Use the first-arm folded table at root x and j=k+1. Geometry must license its transverse fold e=1 and its selected longitudinal f. Subtract R from the two table constituents. Writing db=D(x-v-2A),dv=D(x-v),rm=r(x-v), one obtains

 f=0: I-R=db+3+dv, II-R=rm+1+dv;
 f=1: I-R=1+dv, II-R=r(x+2A-v)+2k-1.

All four identities are checked exactly by check_w1_g2_value_algebra.py. For the last identity use the commutator at x-v to replace rm+dv-D(x-2v) by r(x+2A-v).

The sufficient physical inputs are db,dv>=-1 on the applicable genuine central D interval; rm>=0 on the selected f=0 slice; and r(x+2A-v)>=0. Then I,II>=R>=min(0,R)=S. The independently paid other current Q offer equals the G2 target, so this establishes the minimum equality without requiring either competing constituent to attain R.

The last r term has the useful exact reduction

 r(x+2A-v)=r(u+Z-v)=r(u-v)+1,

using the real Z primary and r(.+Z)=r+1. Thus a lower harmonic-rim bound r(u-v)>=-1 suffices. It is not legitimate simply to assert u-v belongs to E_Z.

## LONG transformation and the extra unit
Put m=k+1>=2, x'=x-Z. Because r(.+Z)=r+1, D(.+Z)=D, and the Z primary has zero height character, evaluating the same first-arm table at x',j=m+1 changes its first constituent by -1 and its second by -2 relative to the table at x,m. This is true for BOTH f=0 and f=1:

 f0: (r+db+2,r+rm) becomes (r+db+1,r+rm-2);
 f1: (r,r+rm-D(x-2v)+2m-2)
     becomes (r-1,r+rm-D(x-2v)+2m-4).

Consequently, if the genuine LONG target normalization is S-1, it is enough to prove I_old>=R and II_old>=R+1.

The first inequality is exactly the SHORT argument. For f0, the LONG f0 geometry supplies r(x'-v)>=0, hence rm=r(x-v)>=1. Together with dv>=-1 this gives II_old-R=rm+1+dv>=1. For f1,
 II_old-R=r(x+2A-v)+2m-1>=3,
using the same nonnegative r bound and m>=2. Therefore both new constituents are>=R-1>=S-1. The other LONG offer, if supplied by its independently established exact nested F_A source, gives attainment.

## Dependencies deliberately kept explicit
This audit independently checks the commutator, all four SHORT differences, the different LONG -1/-2 drops, and their sufficiency. The six symbolic receipts do not prove the following geometry/source inputs:

1. x+(k+1)V_Z (respectively x'+(m+1)V_Z) uses the actual stated transverse/longitudinal folds;
2. the shifted db,dv arguments lie in the genuine central D band, and the selected f0 price bounds hold;
3. the SHORT other offer is the authenticated G2 F_A value;
4. the LONG other offer has the authenticated G2 value and the total normalized target is S-1.

In particular the algebraic -1/-2 change does NOT by itself prove item4: the original LONG source jet is still needed to identify the target gauge. W1_G2_NESTING_AND_SECOND_OFFER.md supplies an explicit SHORT source jet and true nesting, but does not state the LONG jet. Bind the separately checked LONG packet before claiming unconditional literal G2 equality. Native contacts and actual chronological min-touch normalization remain separate even after these value inputs are paid.
