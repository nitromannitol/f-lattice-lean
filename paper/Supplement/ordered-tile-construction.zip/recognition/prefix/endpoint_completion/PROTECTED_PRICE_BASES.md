# Completion of N0/R1 LONG G1 and the near-one canonical seeds

## Explicit paid statements

This packet completes the requested analytic comparisons, not merely a list of endpoint case names. It uses the independently confirmed dispatcher N0=(near-one,W0,saved3), R1=(reciprocal,W1,saved1), N1=(near-one,W1,saved1). R0 source work is deliberately untouched.

1. **N0 LONG positive G1:** for Z=(2b+1,2b-1), A=(b,b-1), b>=2, C=A+kZ, k>=1, every RIGHT carrier E_Z+jV_Z, 1<=j<=k, has the prescribed Z value in the phase-correct LONG target. Its reflected LEFT carrier has the corresponding exact jet. The already proved SHORT attainment plus the LONG final competing >=-1 bound is used.
2. **R1 LONG positive G1:** for Z=(d,1), A=(d-1,1), odd d>=3, the same conclusion holds in W1 at RIGHT carriers E_Z+2C+jV_Z and the genuine W1 reflected LEFT list. This uses W1 SHORT arm2 attainment, not only the minimum of two SHORT arms.
3. **m=1 ordinary qNear/qFar:** the UNC grammar's ordinary Z slots are paid for N0,R1,N1. There is no positive G1 index when k=0,m=1, but these ordinary slots still need their endpoint threshold. They are handled explicitly below.
4. **N0/N1 canonical near/far seed:** the actual lower odd fields satisfy the k=0 stationary formulas on their entire E_A. This is freshly proved from the genuine fields, not inferred from a current constructor or a donor name. Together with the already authenticated current canonical O and the genuine polygon nesting, it pays the k=0 ordinary near/far p slots. The selected proper C,Z geometry then propagates the ordinary near/far price to k>=1.
5. **N0/N1 middle m=1:** the actual middle G2 value comparisons are paid with their authentic LONG normalization S-1. N0 uses its real-birth central band; N1 uses the corrected guarded joint proof, never a false effective central band.

All statements retain actual restored-window/alignment and chronological gauge premises when applied to the literal implementation. They do not certify new recurrence or clipped support retention.

## Fresh LONG geometry

N0/check_long_w0_endpoint_geometry_all_proper.py was specialized to the actual birth n=b-1,d=b,R=(1,1). Its eight endpoint upper-longitudinal coefficient inequalities pass for every m>=2. N0/check_m1_w0_geometry.py repeats the bounds with m>=1, again eight passes. These are exactly the missing parameter-dependent facets in LONG_W0_ENDPOINT_FOLD.md; the remaining exact deck/fold algebra in that proof is unchanged. The logs record every positive facet, rather than treating process exit alone as a certificate.

R1/check_long_w1_endpoint_fold.py gives32/32 true endpoint alias-box facets; check_long_w1_endpoint_prices.py gives8/8 physical-price facets, all d=2u+3>=3,m>=2. The ordinary m1 versions check_m1_w1_fold.py/check_m1_w1_prices.py give another32+8, with m=j+1>=1. N1 has separately specialized32+8 m>=1 receipts.

The exact earlier value inputs are supplied by ../nearone_W1_saved1/G1: direct authentic pure-field proofs of N0 H>=0 and R1/N1 Hhat>=0, with independent raw replays and positive covers. Complete physical bands, price span, harmonic rims and high-t signs are the earlier pure-field theorems. The LONG endpoint formulas only call those complete bands on their checked guards; they never call the invalid saved1 effective-central >=-1 assertion.

## The m=1 ordinary Z threshold, including the remaining rim

For W1 R1 and N1, the m>=1 endpoint facets provide the same signed four rows as LONG_W1_ENDPOINT_AND_REFLECTION.md. The only estimate there that used m>=2 is the last constituent  r+rm-dvv+2m-2. At m=1 this requires dvv<=r+rm.

In these saved1 states K_eff>T_Z/2. On all E_Z, t_Z(u-2V_A)=t_Z(u)+2K_eff>1. The genuine zero/high-transverse sign theorem gives dvv<=0. Since r,rm>=0, the missing m1 inequality follows. This is an actual signed-slip argument, not a central-window extrapolation.

For N0 saved3, the previously proved one-row classification in M1_QNEAR_THIN_RIM_CLOSURE.md applies: same-parity points on a fixed s row differ by V_Z, and the E_Z t interval selects the listed corner/rim representatives. At the nonexceptional representatives the relevant D has positive t and is<=0. The sole W0 even corner reduces by reflection to p=2V_a+2a. Its true two birth offers agree at h0(2V_a)+2, giving D(p)=2 and the required reflected slip0. The endpoint R=(1,1) causes no exception to this calculation: t_a(-R)=1, s_a(-V_R)=-2, eta_R=0 are licensed true strip points. The fresh all-b birth minimum in ../nearone_W1_saved1/SOURCE_RECEIPT.json supplies its actual source identity on full E_Z, including corners. T_Z>2K0 and K0>D-N hold throughout b>=2. Thus the thin-row proof is genuine at the endpoint, not a proper-R assumption.

qFar is the true phase reflection of qNear. Its center and extra scalar are the already checked raw odd-alternate ones R_Q+(1-2W)Z and -eta_Q-1; standard reflection alone would give the wrong constant.

## Fresh true canonical odd seeds

N0_seed.py and N1_seed.py independently encode the genuine pure2 even field and actual odd staircase fields. They test the ENTIRE canonical parity polygon E_A, not just their native source crop. Three separate positive alias-cover gates license the two Z arguments and the actual odd field. The fourth gate proves the minimum identity. All eight gates pass producer and independent CLI for every b>=2; raw SHA values are in N0_SEED_RECEIPT.json and N1_SEED_RECEIPT.json. The E_A guards contain products of the parameter with physical coordinates, so these seed checks are exact integer-arithmetic SMT checks, not claimed QF_LIA receipts. The already earlier source/deck identities make the selected positive offers unambiguous.

For N0, A=(b,b-1), v=V_A and h(u)=F_Z(u-v-2A)+a_A.u+eta_A+2:

    F_A(u)=min(F_Z(u),h(u)-2),  u in E_A.

For N1, A=(b+1,b):

    F_A(u)=min(F_Z(u-2A),F_Z(u-v)+a_A.u+eta_A), u in E_A.

The odd source has its actual inserted corners and characters. In N1 it is the next staircase A=(b+1,b), not the creator a=(b,b-1). This distinction is explicitly represented in the source encoder.

These are exactly the replacement identities needed at k=0 in K0_UNC_ODD_ALT_FOUR_P_SLOTS.md. For W0 the one-row query miss is repaired by genuine zero strips; for W1 both E_A+Z and E_A+Z+V_Z lie in E_(A+Z). The generic near/far geometry applies to the SELECTED proper pair A,Z (its hypotheses n_A>=1,d_A-n_A>=1,n_Z>=1,d_Z-n_Z>=2 hold here), regardless of endpoint status of the birth R. The source seed itself has now been paid independently above. Authentic phase reflection transfers the near p carrier to its far p carrier with the already audited scalar.

## Middle carriers and remaining premises

N0/audit_long_w0_g2_geometry.py and audit_long_w0_g2_rim.py freshly specialize the m=1 case:32+16 facets pass. Here effective A is the REAL creator, so the central bound used in the saved3 middle proof is licensed by the actual pure2 K0 certificate. The original LONG target-jet proof supplies S-1; this is not inferred merely by observing that individual constituents dropped one/two units.

N1 middle m1 is already covered by ../nearone_W1_saved1/long_geometry.json (m=j+1), the fresh two-sheet endpoint source theorem, and ../saved1_true_birth_correction/independent_W1's guarded joint proof. Its f0 uses db>=-2 and nonnegative actual lower-rim prices. Its f1 uses r<0=>dv>=-1 only on the selected correlated sites. The false separate central-bound witnesses remain true and are not overridden.

The remaining premises for application are explicit: earlier global fields/strips/decks and authentic stationary canonical O on its polygon; actual native helper carrier restoration/alignment; source overlaps and first normalization to identify literal scalar constants. No new unpaid analytic G1, m1 ordinary-Z, or N0/N1 k0 near/far/middle price is hidden behind a case label. This packet does not itself discharge those chronological/source-support premises or R0-specific work.
