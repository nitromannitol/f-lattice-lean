import sympy as S
import json
from pathlib import Path
rows=[]
n,d,r,e,m=S.symbols('n d r e m');D,N=2*d+e,2*n+r;T=D*D+2*D*N-N*N
u,v,w,h,j=S.symbols('u v w h j');subs={n:S.Integer(0),d:S.Integer(1),r:S.Integer(1),e:2*u+1,m:j+2}
for saved in [1]:
 ad,an=(d+e,n+r)if saved==1 else(d,n);K=(ad+an)*D+(ad-an)*N;B=K+m*T;dc,nc=ad+m*D,an+m*N
 for par in [0,1]:
  lo,ht,sl0,sh0,g,sl=(2-T,D+N-2,0,T+2*N,1,0)if par==0 else(N-T,D,2-D+N,T+D+N-2,nc,2-dc+nc)
  qs={'harmonic2':T*sl-2*ht+2*m*T-B*(4-2*D),'dbupper':B*(N+2*D-3)-(T*(g+1)+2-sl0),'nonfold':T*(g+1)+2-sh0,'dblower':lo+K+2-(3-D-T)}
  for nm,q in qs.items():
   pp=S.Poly(S.expand(q.subs(subs)),u,v,w,h,j);ok=all(c>=0 for c in pp.coeffs()) and pp.TC()>0; assert ok; rows.append([saved,par,nm,bool(ok),len(pp.terms()),int(pp.TC())])

Path(__file__).with_name('LONG_W1_ENDPOINT_PRICE_FACETS.json').write_text(json.dumps(rows,indent=2)+'\n')
print('PASS',len(rows))
