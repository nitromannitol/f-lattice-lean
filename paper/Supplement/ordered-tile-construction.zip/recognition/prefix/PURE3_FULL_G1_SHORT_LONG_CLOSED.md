# Pure3 full native G1: SHORT competing arm and LONG endpoint closed

## Statement and input boundary
Let Z=(e,1), e>=3 odd, A=X=(1,0), V0=(-1,1), C=X+hZ,h>=1, O=X+(h+1)Z. On EVERY literal reciprocal standard source site u∈D_Z and every1<=j<=h, the pure3 W0 SHORT and LONG raw comparators at y=u+jV_Z both equal G(y), G=F_Z. Their reflected LEFT counterparts follow from the already audited raw reflection/frame tables.

The only non-base field input is the authentic whole-E stationary realization

 F_(X+kZ)(z)=min(G(z),G(z−(1,1))−z_y+2k), z∈E_(X+kZ), k>=1,

together with genuine global standard primary/secondary/reflection laws. For k=1 this is supplied by the parent's separate all-parameter literal doubled-ladder E proof (endpoint_G1_G2/reciprocal_pure3_initial_roof). For k>=2 it is the earlier canonical ordinary standard stage with genuinely proper parents. THIS IS AN EXPLICIT INPUT: the historical native-only two-roof theorem alone would not justify it. No current corrected/alternate native identification or recurrence is assumed.

## 1. Endpoint geometry specialized, not extrapolated
Specialize the existing exact determinant-aware G1 facet encoders to

 A=(1,0), R=(e−2,1), Z=2A+R,
 e=2a+3, a>=0, h=b+1,b>=0.

The distinct scripts in pure3_specialization freshly pass:
- check_r1_fold.py:64 first-arm four-alias support margins;
- check_r2.py:64 second-arm support margins;
- check_e0_facets.py:8 no-top-longitudinal-fold/final-nofold margins (both saved substitutions; only saved3 needed);
- check_transverse_fold.py:12 margins, including transverse fold only at j=h (only saved3 needed);
- check_long_endpoint.py:8 LONG endpoint upper-s margins, m=h+1>=2.

These are exact nonnegative-coefficient certificates after the endpoint substitution, with the same integer-slack reasoning as the original encoders. The determinant identities remain exact at the endpoint. Literal D_Z is contained in its genuine E_Z parity rows, so the geometry applies to all actual source sites. This does NOT import generic proper-birth N>=3 or D−N>=4 value bounds.

## 2. Replace generic rims by five literal base inequalities
Put F=G, v=V0, c_A=1 and

 P(w)=F(w)−F(w+v)−w_y,
 D(w)=F(w)−F(w−2X),
 P1=P(u−v), P2=P(u−2v), D2=D(u−2v), Dplus=D(u−v+2X).

On ALL literal D_Z, including every added corner, the new exact unbounded affine Presburger checker proves

 P1>=0, P2>=0, D2<=2,
 D(u+2X)>=−2,
 P1+Dplus>=0.

check_base_price_bounds.py checks34,31,27,37,40 nonempty affine regions respectively,169 total. It covers the shifted physical queries with genuine global base deck charts before comparing the literal piecewise formulas. These are not an extension of the raw staircase formula off its native domain.

Let H0(u)=F(u−(1,1))−u_y+2−F(u). The historical native seed certificate gives H0>=0 throughout D_Z. On the stronger terminal guard t_Z(u)>=1−M(A,Z)=−e, the new check_terminal_nofold_price.py proves H0>=1 on19 affine regions. The guard within D_Z is exactly (y<=1,x>=0) or(y=2,x=e): since x<=e, y>=3 is impossible; the two added corners obey the same classification. This supplies the needed extra unit without a generic harmonic-rim assumption that fails the proper-cone numerical restrictions.

## 3. SHORT: every folded first offer is >=F(y)
The second offer is exactly F(y), by r2 support and H0(u)+2h−2j>=0. For the first query r=y−Z use the genuine four-alias fold

 w=r−epsilon V_C+2fC∈E_C,
 epsilon,f∈{0,1}.

Use the authentic whole-E C roof ONLY at this licensed w and its true deck pullback. The previously exact algebra specializes as follows.

- epsilon=f=0: first-offer error is min(0,H0+2(h−j)−1). For j<h, H0>=0 pays it. For j=h, the certified nofold guard gives t_Z(u)>=−e and hence H0>=1.
- epsilon=0,f=1: its two errors are D(u+2X)+2j and P1. Both are nonnegative by Section2 and j>=1.
- epsilon=1: geometry forces j=h. The two errors are

   P1+f Dplus,
   P1+P2+(1−f)(2h−D2).

  Both are nonnegative by Section2. In particular the first f=1 case uses the directly proved combined bound P1+Dplus>=0, not an unjustified individual Dplus>=0 outside its physical band.

Thus the first offer never undercuts the exactly attaining second offer, including the terminal indexh and h=1.

## 4. LONG: the endpoint is paid by the same five base inequalities
Write m=h+1. The LONG expression is

 T(y)=min(F_O(y),F_O(y+V_Z)−a_Z·y+c_Z+1).

For1<=j<=h the first query is licensed and equals F(y), since its stationary error is min(0,H0+2m−2−2j)=0. For j<h the second query is also an interior attaining query, so its full offer is F(y)+1.

At j=h the second query z=u+mV_Z either lies in E_O or folds to w=u−v∈E_O by one V_O shift, as certified above. On the folded branch its two errors relative to F(z) are

 P1−1,
 P1+P2−2+2m−D2.

They are at least−1 and2m−4>=0 respectively, hence the full second LONG offer is >=F(y). On the nonfolded branch its error is min(0,H0−2). The exact lower-t guard gives t_Z(u)>=−e; Section2 gives H0>=1, so this error is >=−1. Again the extra+1 in the actual LONG expression prevents any undercut. First offer attains F(y).

## Scope and audit independence
This closes BOTH raw G1 value comparisons on every genuine reciprocal native copy, with all source corners included, all e>=3 and all h>=1. Historical exact actual frame and overlap results may then calibrate these sources once the surrounding prefix has the same candidate value. It does not prove the endpoint G2 or G3 exposed-price recognition being handled separately, nor claim full helper coherence at the known clipped contacts.

Geometry scripts are specialized replays of prior encoders, not independent implementations. The five base inequalities and terminal guard comparisons are newly assembled exact QF_LIA reductions from literal selectors and genuine base deck formulas. All certificate processes exited0. The two earlier native-carrier reports remain valid but their unresolved G1 terminal gate is superseded by this conditional whole-E proof.
