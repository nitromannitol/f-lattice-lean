import sympy as S,json
from pathlib import Path
out=Path(__file__).resolve().parent
import sys
saved=int(sys.argv[1]) if len(sys.argv)>1 else 3
d,n,e,r,k=S.symbols('d n e r k');D,N=2*d+e,2*n+r;T=D*D+2*D*N-N*N;ad,an=(d,n) if saved==3 else(d+e,n+r);TA=ad*ad+2*ad*an-an*an;K=(ad+an)*D+(ad-an)*N;B=K+k*T;TC=TA+2*k*K+k*k*T;dc,nc=ad+k*D,an+k*N
u,v,w,h,j=S.symbols('u v w h j',nonnegative=True);sub={n:u+2,d:u+v+5,r:w+1,e:w+h+3,k:j+1};rows=[]
for par in[0,1]:
 ts,ss=([2-T,D+N-2],[0,T+2*N])if not par else([N-T,D],[2-D+N,T+D+N-2])
 tl,th,sl,sh=(1-TC,dc+nc-1,0,2*TC+2*nc)if not par else(nc-TC,dc,2-dc+nc,2*TC+dc+nc-2)
 for je,J in enumerate([0,k]):
  for ti,t in enumerate(ts):
   for si,s in enumerate(ss):
    tc=B*t-s-J*B*T+T;sc=B*s-2*t+2*J*T-B*T
    for f,q in enumerate([tc-T*(tl-TC),T*th-tc,sc-T*(sl-2*TC),T*sh-sc]):
     if par and ti==1 and f==1:q=D-N+s+J*B*T-T # KD=dT-c
     if not par and ti==1 and f==1:q=(2*k-2)*T+2*K-2*N+s+J*B*T
     pp=S.Poly(S.expand((q+T).subs(sub)),u,v,w,h,j)
     ok=pp.TC()>0 and all(c>=0 for c in pp.coeffs())
     rows.append({'key':[par,je,ti,si,f],'pass':ok,'terms':len(pp.terms())})
print('passed',sum(a['pass']for a in rows),'/',len(rows),'failed',[a['key']for a in rows if not a['pass']]);(out/('R1_FOLD_COEFFICIENTS_saved%d.json'%saved)).write_text(json.dumps(rows,indent=2))
