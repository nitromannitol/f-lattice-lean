from pathlib import Path
import sys,json
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D.parent))
from physical_heads import *
def go(w,s):
 ow=w+s;W=ow.count('1')%2;ma,aa=alg.get_odometers(w);_,zf,af,rf=getFracs(w);a,Z=[(p.denominator,p.numerator) for p in(af,zf)];A=add(Z,scale(-1,a))if s=='1'else a
 mx,ax=alg.get_odometers(ow);of,qf,cf,zff=getFracs(ow);O=(of.denominator,of.numerator);assert O==add(A,Z),(ow,A,Z,O)
 F=review.Field(Z[1],Z[0],alg.export_tile(ma[1])).g;FO=review.Field(O[1],O[0],alg.export_tile(mx[0])).g
 S0=alg.export_tile(ma[1]);zz,n=Z;T=t(Z);L=sum(Z);c=zz-n;hist=Counter();ex={};cnt=0
 for xx in range(-2*zz,3*zz+1):
  for yy in range(-zz,3*zz+1):
   u=(xx,yy);tt=mul(b(Z),u);ss=mul((L,c),u);lo,hi,ls,hs=(2-T,L-2,0,T+2*n)if sum(u)%2==0 else(n-T,zz,2-c,T+L-2)
   if not(lo<=tt<=hi and ls<=ss<=hs):continue
   cnt+=1;y=add(u,scale(2*W,A));x=add(y,scale(W,Z));v1=FO(x);v2=FO(add(x,v(Z)))-mul(b(Z),x)+(T+L)//2-(2*W-1);err=min(v1,v2)-F(u);hist[err]+=1
   ex.setdefault(err,dict(u=u,y=y,x=x,offers=[v1,v2],target=F(u),native=u in S0))
 out=dict(word=ow,W=W,A=A,Z=Z,O=O,count=cnt,hist=dict(hist),examples=ex);print(json.dumps(out),flush=True);return out
if __name__=='__main__':
 results=[go(w,s) for w,s in zip(sys.argv[1::2],sys.argv[2::2])];D.joinpath('LONG_M1_QNEAR_DIAGNOSTICS.json').write_text(json.dumps(results,indent=2)+'\n')
