from pathlib import Path
import sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D.parent))
from physical_heads import *
def go(w,s,k):
 ow=w+s+'2'*k;W=ow.count('1')%2;m,a0=alg.get_odometers(w);_,zf,af,rf=getFracs(w);a,Z,R=[(p.denominator,p.numerator)for p in (af,zf,rf)]
 A=add(Z,scale(-1,a)) if s=='1' else a
 mx,ax=alg.get_odometers(ow);of,qf,cf,zff=getFracs(ow);C,Q,O=[(p.denominator,p.numerator) for p in(cf,qf,of)];assert C==add(A,scale(k,Z))
 S=alg.export_tile(m[1]);F=review.Field(*Z[::-1],S).g;FC=review.Field(*C[::-1],alg.export_tile(mx[2])).g;FQ=review.Field(*Q[::-1],alg.export_tile(mx[1])).g;O0=alg.export_tile(mx[0]);FO=review.Field(*O[::-1],O0).g
 st=alg.export_tile(mx[1]);hist=Counter();ex={}

 AA=alg.export_tile(m[2 if s=='3' else 0]);FA=review.Field(*A[::-1],AA).g
 H={};hh={};zq={};e={};full=0
 for xx in range(-3*A[0],5*A[0]+1):
  for yy in range(-A[0],5*A[0]+1):
   u=(xx,yy);tc=mul(b(A),u);sc=mul((sum(A),A[0]-A[1]),u);TT=t(A);LL=sum(A);nd=A[1];dd=A[0]
   tl,th,sl,sh=(1-TT,LL-1,0,2*TT+2*nd)if sum(u)%2==0 else(nd-TT,dd,2-dd+nd,2*TT+LL-2)
   if not(tl<=tc<=th and sl<=sc<=sh):continue
   full+=1;y=add(u,scale(k+1,v(Z)));r1=add(y,scale(-1,Z));r2=add(y,scale(-1,v(Z)));m1=FC(r1);m2=FC(r2)+mul(b(Z),y)+eta(Z);tar=FA(u)+F(y)-F(u);key=(u in AA,m1-tar,m2-tar)
   H[key]=H.get(key,0)+1;e.setdefault(key,(u,mul(b(Z),u)))
   f=FA(add(u,v(Z),scale(-1,Z)))-F(add(u,v(Z)))+F(u)-FA(u)
   hh[f]=hh.get(f,0)+1
   zqa=(FA(u)-F(u), F(add(u,scale(-2,A)))-FA(u),m1-F(y))
   zq[zqa]=zq.get(zqa,0)+1
 print('G2 CHECK',w,s,k,full,'bad',[(h,n,e[h])for h,n in H.items()if min(h[1:])!=0][:10],'arms',sorted(H.items())[:22], 'k0',hh,'G2+Q',zq,flush=True)
go(sys.argv[1],sys.argv[2],int(sys.argv[3]))
