# m=1 LONG qNear: the thin-rim correlation closes both phases

## Precise conditional result

In the proper saved1/3 setup, set O=A+Z (stationary parameter m=1). The raw phase-correct odd LONG target equals F_Z(u) at its nominal qNear source for every u∈E_Z: y=u in W0 and y=2A+u in W1. This is a full physical polygon statement, not finite-word extrapolation.

Inputs are the genuine earlier standard deck/reflection laws, complete physical price/slip/zero/harmonic strips, current O's authentic stationary polygon representation, W0 whole-E H≥0, W1 saved3 whole-E Hhat≥−1, and the separately proved first-offer attainments. In W0 the first attainment follows directly from E_Z⊂E_O and H≥0. In W1 it is exactly the SHORT arm2 attainment at parameter1,index1. The current conclusion does not establish those same inputs circularly and is not yet the entire uncorrected alternate constructor.

## 1. What changes from m≥2

All endpoint folds and auxiliary price facets remain valid at m=1. The distinct scripts check_m1_w0_geometry.py, check_m1_w1_fold.py and check_m1_w1_prices.py verify the extended all-proper cones:16 W0 upper-s facets,64 W1 fold facets across both saved choices, and16 W1 guarded price facets. The raw four-alias formulas retain their exact previous constants.

Only one estimate in each phase loses the extra unit:

 W0 folded second price: P(u−v)+P(u−2v)−2c_A+2−D(u−2v).
 W1 folded row(e,f)=(1,1), second price: r(u)+r(u−v)−D(u−2v).

Here W0 uses P(x)=F(x)−F(x+v)+a_A·x and D(x)=F(x)−F(x−2A); W1 uses r(x)=eta_A−[F(x)−F(x−v)−a_A·x] and D(x)=F(x)−F(x+2A). Both phases need only a lower bound−1. The already proved ranges P(u−iv)≥c_A−1, r(u−iv)≥0 and D(u−2v)≤2 leave only the possibility D(u−2v)=2. Other rows retain the earlier proof unchanged.

The complete central physical interval gives D≤1 for transverse grades at least3−D_Z−K, followed by the high-grade sign bound. Therefore D(u−2v)=2 implies t_Z(u)+2K<3−D_Z−K. In this case q=u−v has t_Z(q)=t_Z(u)+K within the genuine E_Z transverse interval: its lower row is preserved and the preceding upper bound is more than sufficient.

If q also has the correct longitudinal coordinate, the earlier full-E inequalities immediately finish:

 W0: second price=P(u−v)−c_A+H(q)≥−1;
 W1: second price=r(u)+Hhat(q)≥−1,

where H(q)=P(q−v)−c_A+2−D(q−v), and Hhat(q)=r(q)−D(q−v). No raw minimum is applied at a nonnative physical point without its full-polygon license.

Thus only one top longitudinal row in W0, or one bottom row in W1, remains. The reason it is one row, not two arbitrary integer rows, is that s_Z is always even and s_Z(v)=−2 in W0,+2 in W1.

## 2. Saved1 is simpler

Write a for the authentic old birth parent and A=Z−a. Since Z=2a+R with positive proper R,

 T_Z−2M(a,Z)=M(R,Z)>0,
 K=M(A,Z)=T_Z−M(a,Z)>T_Z/2.

Consequently t_Z(u−2v)=t_Z(u)+2K>1 on ALL E_Z, in both phases. The complete zero strip followed by the high-grade sign extension gives D(u−2v)≤0. The problematic value2 cannot occur; no thin-rim birth argument is needed for saved1.

## 3. Exact same-parity rim classification for saved3

Now A=a and K<T_Z/2. Also K>D_Z−N_Z. Because Z=(D_Z,N_Z) is primitive with both coordinates odd, gcd(D_Z−N_Z,D_Z+N_Z)=2. Integer points on one s_Z row differ by V_Z/2, which flips physical parity. Same-parity points therefore differ by V_Z and their t grades differ by T_Z. The true E_Z transverse bounds select exactly the following representatives:

 W0 even top row s=T+2N: u=R_Z=Z+V_Z+(1,−1), t=L−T.
 W0 odd top row s=T+L−2: u=Z+(1,0)+v, t=N−K.
 W1 even bottom row s=0: u=0, t=0.
 W1 odd bottom row s=2−D+N: u=−(0,1)+v, t=D−K.

Each representative lies in its proper parity row. Shifting by ±V_Z leaves that row's t interval, using T>2K and K>D−N; the even cases use T>L. Thus this list does not conceal an unbounded family of rim points.

At the last three representatives, the grade t_Z(u−2v) is respectively N+K,2K,D+K, all positive. The authentic zero/high-grade sign theorem gives D(u−2v)≤0. Only the W0 even corner requires a value computation.

## 4. W0 even corner, using the true saved3 birth

Set p=2v+2A. Its E_Z coordinates are t_Z(p)=2−2K and s_Z(p)=2K−4. Since T−2K=M(R,Z)>0 and K≥2, these satisfy all even E_Z facets. Thus the genuine old birth minimum is licensed at p.

The saved3 W0 birth Z=2A+R has the two actual A offers

 F_A(p−R),  F_A(p−V_R)+a_R·p+eta_R.

The earlier zero strip gives F_A(−R)=0 since t_A(−R)=1. The earlier harmonic strip gives F_A(−V_R)=h0(−V_R)=−eta_R since s_A(−V_R)=−2. Genuine A primary2A and secondary v laws then give

 F_A(p−R)=h0(2v)+2,
 F_A(p−V_R)+a_R·p+eta_R=h0(2v)+2,
 h0(2v)=−T_A−2c_A.

In the second line the two mixed terms cancel: a_A·(−V_R)=M(A,R) and a_R·p=2−2M(A,R). The former field value is therefore exactly F_Z(p)=h0(2v)+2. Since 2v is in the complete Z harmonic strip (s_Z(2v)=−4), F_Z(2v)=h0(2v), so D(p)=2.

The authentic Z reflection gives D(R_Z−2v)=2−D(2v+2A)=0. Thus this last rim also cannot carry the hypothetical value2. Both phase endpoint estimates are proved.

## 5. Diagnostics, independence and limits

The diagnostic script evaluates the actual original chronological standard O and old Z fields on the entire integer E_Z, using their genuine deck extensions. The first four tests, words113,13,11,111, covered519,99,99,519 sites respectively and all qNear errors were zero. Longer saved3 W0 words11333 and1133333 covered2343 and5479 sites, again all zero. The latter two are persisted in M1_QNEAR_LONG_RUN_DIAGNOSTICS.json. These observations were used to stress the candidate, not to prove the uniform claim.

The corner derivation and parity-row classification were independently checked against the actual birth and deck formulas supplied in the parent review. The geometry checks are extensions/replays of the previously audited exact encoders. The W1 Hhat theorem and first-offer attainment remain named inherited analytic inputs. This result does not itself pay pMiddle, seven-source chronological overlap/calibration, any endpoint pure family, or physical recurrence of the full uncorrected alternate.

## 6. Explicit W1 input and reflected qFar

The saved3 full-E W1 inequality Hhat≥−1 is the three-case analytic theorem W1_COMPLETE_RIGHT_PREFIX_VALUE_PROOF.md, with the all-proper extension all_proper_W1/ALL_PROPER_W1_SHORT_G1.md. The saved1 correction there uses the actual Phi_plus(u). No global recurrence assertion is substituted for either analytic inequality. The original R2 version in ../W1/WHOLE_CROP_DOMINANCE.md alone would not license the full-E argument here.

Let Q=2A+Z, R_Q=Q+V_Q+δ and R_phase=R_Q+(1−2W)Z. Both exact phase-correct raw involutions are

 T(R_phase−y)=T(y)−a_Q·y−eta_Q−1.

Reflecting qNear E_Z+2WA therefore gives qFar at

 o_far=2A+2V_A+Z (W0), or 2V_A−Z (W1).

For x=u+o_far its candidate price is exactly

 T(x)=F_Z(u)+2a_A·x+eta_Q+1−eta_Z+a_Z·o_far.

These agree with literal getAltOddTileFull natural slot1's origin and slope; qNear is natural slot0. The extra+1 in the reflected scalar comes from the odd raw involution, not the standard Q reflection. This pays the analytic qFar full window but does not assert chronological selection of that scalar.

The independent check_m1_rim_algebra.py verifies fourteen exact rim-coordinate and corner-value identities, separately modulo the true determinant sign of each phase. All residuals vanish.
