from pathlib import Path
import sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D.parent))
from physical_heads import *
def go(w,s,k):
 ow=w+s+'2'*k;W=ow.count('1')%2;m,a0=alg.get_odometers(w);_,zf,af,rf=getFracs(w);a,Z,R=[(p.denominator,p.numerator)for p in (af,zf,rf)]
 A=add(Z,scale(-1,a)) if s=='1' else a
 mx,ax=alg.get_odometers(ow);of,qf,cf,zff=getFracs(ow);C,Q,O=[(p.denominator,p.numerator) for p in(cf,qf,of)];assert C==add(A,scale(k,Z))
 S=alg.export_tile(m[1]);F=review.Field(*Z[::-1],S).g;FC=review.Field(*C[::-1],alg.export_tile(mx[2])).g;FQ=review.Field(*Q[::-1],alg.export_tile(mx[1])).g;O0=alg.export_tile(mx[0]);FO=review.Field(*O[::-1],O0).g
 st=alg.export_tile(mx[1]);hist=Counter();ex={}
 # RIGHT Q is F_Z(y−2WC) up to constant. V_Z transport of native sources is exactly this chart.

 fields={}
 for j in range(1,k+1):
  if j<k:
   mw,_=alg.get_odometers(w+s+'2'*(k-j)); _,_,bf,_=getFracs(w+s+'2'*(k-j));fields[j]=review.Field(bf.numerator,bf.denominator,alg.export_tile(mw[2])).g
  else:
   if s=='3':fields[j]=review.Field(*A[::-1],alg.export_tile(m[2])).g
   else:fields[j]=review.Field(*A[::-1],alg.export_tile(m[0])).g
 for u in S:
  for j,FB in fields.items():
   for ii,sh in enumerate([scale(-1,Z),scale(-1,v(Z))]):
    r=add(u,sh);y=add(r,scale(j,v(Z)));g=F(y)-F(r)
    key=(j,ii,FC(y)-g-FB(r));hist[key]+=1;ex.setdefault(key,u)
 print('WIN',w,ow,'W',W,'n',len(S),sorted(hist.items()),ex,flush=True)
go(sys.argv[1],sys.argv[2],int(sys.argv[3]))
