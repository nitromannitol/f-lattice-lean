import sympy as s,json
from pathlib import Path
r,rm,dv,db,dvv,k=s.symbols('r rm dv db dvv k');R=r-1-dv
rows={
 'short_f0_I':(r+db+2-R,db+3+dv),
 'short_f1_I':(r-R,1+dv),
 'short_f0_II':(r+rm-R,rm+1+dv),
 'short_f1_II':(r+rm-dvv+2*k-2-R,(rm+dv-dvv)+2*k-1),
 'long_I_lower':((R)-1,R-1),
 'long_II_lower':((R+1)-2,R-1)}
assert all(s.expand(a-b)==0 for a,b in rows.values())
Path(__file__).with_name('W1_G2_VALUE_ALGEBRA.json').write_text(json.dumps({a:str(s.expand(b))for a,(b,c)in rows.items()},indent=2));print('PASS6')
