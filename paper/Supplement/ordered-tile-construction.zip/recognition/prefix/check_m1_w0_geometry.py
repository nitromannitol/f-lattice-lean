import sympy as S
n,d,r,e,m=S.symbols('n d r e m');D,N=2*d+e,2*n+r;T=D*D+2*D*N-N*N
u,v,w,h,j=S.symbols('u v w h j');subs={n:u+1,d:u+v+2,r:w+1,e:w+h+3,m:j+1}
for saved in [1,3]:
 ad,an=(d+e,n+r)if saved==1 else(d,n);TA=ad*ad+2*ad*an-an*an;K=(ad+an)*D+(ad-an)*N;B=K+m*T;TO=TA+2*m*K+m*m*T;do,no=ad+m*D,an+m*N
 for par in [0,1]:
  ts,ss=([2-T,D+N-2],[0,T+2*N])if par==0 else([N-T,D],[2-D+N,T+D+N-2]);sh=2*TO+2*no if par==0 else 2*TO+do+no-2
  for t in ts:
   for s in ss:
    q=S.Poly(S.expand((T*sh-(B*s-2*t+2*m*T)).subs(subs)),u,v,w,h,j)
    print(saved,par,all(x>=0 for x in q.coeffs()),q.TC())
