# Direct W1 LONG G2 target jet, SHORT normalization, and both nominal sides

Let C=A+kZ, O=A+mZ, m=k+1, k>=1, W1. Use genuine earlier fields, zero primaries2C,2O,Z, a_Z.(2A)=-2, and cV_Z=-c_Z. All value uses of the iterated far p donor are licensed by the earlier nesting theorem, not current corrected recurrence.

## Actual LONG target and the minus one
The actual RIGHT G2 position is

 y=u+(2m-1)Z+mV_Z, u in E_A.

The W1 raw alternate target is evaluated at x=y+Z=u+m(2Z+V_Z):

 J(y)=min(F_O(x), F_O(x+V_Z)-a_Z.x+c_Z-1).

The iterated genuine W1 far p donor gives the FIRST offer exactly:

 N=F_O(x)=F_A(u)+F_Z(x)-F_Z(u)+2m.

For the SECOND use the zero primary2O to set

 q=x+V_Z-2O=(u-2A)+(m+1)V_Z.

The genuine Z secondary jet gives

 F_Z(q)-F_Z(x+V_Z)=D(u-2A)+2(m+1).

Here D(u-2A)=F_Z(u-2A)-F_Z(u); the extra2(m+1) has positive sign because a_Z.(-2A)=2. Also

 F_Z(x+V_Z)-a_Z.x+c_Z-1=F_Z(x)-1.

Writing S=F_A(u)-F_Z(u-2A) therefore gives, exactly,

 SECOND-N=[F_O(q)-F_Z(q)]-(S-1).

This proves the previously explicit normalization input: the normalized target for the competing O query is S-1, not S. The -1 is the actual raw alternate scalar, not an optional gauge. No midpoint or reflection is used to infer it.

Since x'=u-2A=x-Z for the SHORT auxiliary x=u+Z-2A, q=x'+(m+1)V_Z. The previous independently checked -1/-2 folded-table drops now apply to this authentic query and target. Thus the guarded inequalities of INDEPENDENT_W1_G2_VALUE_AUDIT.md establish the needed dominance; the first offer N supplies attainment.

## Common RIGHT G2 source jet for SHORT and LONG
Expand the first offer using x=u+2mZ+mV_Z. It is

 N=F_A(u)+m*a_Z.u-m*c_Z-T_Z*m(m-1)/2+2m.

Since a_Z.y=a_Z.u-mT_Z, the global-affine source is

 F_A(y-o_R)+m*a_Z.y+c_R,
 o_R=(2m-1)Z+mV_Z,
 c_R=m*eta_Z+T_Z*m(m-1)/2+2m.

This is identical to the genuine SHORT RIGHT G2 source price derived in W1_G2_NESTING_AND_SECOND_OFFER.md, with m=k+1. SHORT removes2C from its current standard arguments; LONG removes2O from the competing argument and uses x=y+Z. They have the same physical RIGHT G2 location and source jet, but different target-comparator gauges. The two normalizations must not be interchanged.

## Actual raw offsets and primitive slopes
The literal _odd_l W1 nonflip offsets are K1=V_Z,K2=V_Z+Z-2A. Their slopes, from the same function with af, are a_Z,a_Z because both primary slopes vanish. With k-1 inner repetitions this gives G2 slope k*a_Z before the outer a_Z, hence m*a_Z in the final frame. LONG changes only the number of G3 heads, not G1/G2 offsets or slopes.

The historical raw_piece_ops includes the material helper moves: flipped -Z; nonflipped2C-Z, for its internal count k-1. These are not guessed lower-left alignments. The distinct check_w1_g2_nominal.py loads the original symbolic definitions and verifies both coordinates of all four SHORT/LONG,LEFT/RIGHT G2 origins. It uses the genuine ordinary or alternate outer slot, including LONG Gl=V_C-Z, not V_C+Z.

The resulting nominal origins are

 SHORT RIGHT o_R=(2k+1)Z+(k+1)V_Z; LEFT o_L=V_C;
 LONG  RIGHT o_R=(2k+1)Z+(k+1)V_Z; LEFT o_L=V_C-Z.

In the flipped primitive slope recursion the initial slope a_(C-Z), then k-1 increments -a_Z, then -a_A, leaves0. The actual outer Gl slope a_C gives final LEFT slope a_C for BOTH siblings. This equals the reflected RIGHT slope below.

## Correct reflection for each actual raw target
For STANDARD use R_S=R_Q, gamma_S=eta_Q. For ALTERNATE in its y frame use R_L=R_Q-Z, gamma_L=eta_Q+1, as independently derived in LONG_W1_ENDPOINT_AND_REFLECTION.md. Their laws are

 T(R-y)=T(y)-a_Q.y-gamma.

The old A source reflects about R_A=2A+V_A+delta. Therefore o_L=R-o_R-R_A gives exactly V_C or V_C-Z above. Its reflected slope is

 a_Q-a_A-m*a_Z=a_C.

The exact reflected global scalar is

 c_L=gamma-eta_A+a_A.o_L+(m*a_Z).R+c_R.

This is a candidate value gauge derived from genuine target and old-source reflections. It is not a proof that chronological min-touch has chosen this constant. Nominal support/jet identities are now bound to the actual raw offset dispatch including its helper move; literal finite-canvas restoration/UR alignment/no-clipping and chronological contacts remain distinct premises.
