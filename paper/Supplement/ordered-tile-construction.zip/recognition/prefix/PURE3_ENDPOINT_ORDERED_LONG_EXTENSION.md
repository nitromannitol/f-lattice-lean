# Pure3 endpoint pieces: LONG extension and the exact two clipped contacts

## Scope
Let e=2a+1>=3, Z=q=(e,1), Y=(1-e,e+1), V0=(-1,1), B=(1,-e), A0=(0,-1), T=e²+2e−1, eta=(e²+e−2)/2, c=T−eta. Let h>=1 and k=h−1. Use the actual raw reciprocal standard G, endpoint E0 and alternate A_e, not a fictitious proper creator. This note independently derives an extension of the historical all-length SHORT ordered-height theorem to LONG, using its proved literal seed inequalities and native selector exclusions. It does not claim all outer corrected comparisons.

## Actual literal frames and endpoint shifts
RIGHT G1 copies have origins jY,0<=j<=k. The G2 origin is hY−e2, NOT hY; its slope is hB. The pure3 correction translates only that endpoint operand and does not change the running origin for G3. Restored G3 sources are A_e at kY+V0+iq, i=1,...,2h−1 for SHORT or1,...,2h for LONG, with slope kB+A0.

LEFT endpoint is at2hq+(1,−1), slope0. Restored A_e sources are at iq in descending order i=2h−1,...,1 for SHORT and2h−1,...,0 for LONG, each slope0. These are the original get_l_correct and get_odd_l_offsets W0 branches, including source-only endpoint corrections. The raw even-ALT LL=(1−e,−1); centering and all3 A4 shift(e−1,1) cancel, so A_e is genuinely read in these raw coordinates.

## LONG is the same exact ordered-height construction with one extra copy
The historical SHORT proof establishes G1 constants d_j=j eta+Tj(j−1)/2; endpoint constant d_h; RIGHT G3 constant1+k(e+1)+d_k; LEFT G3 constant0; both pieces have maximum0. Every G3 is a restriction of one global q-periodic alternate field in the respective affine gauge.

Appending RIGHT i=2h preserves its exact constant: it intersects its immediate predecessor at the literal pair(1−e,−1),(1,0), whose values are both0. Every earlier G1 except the last is disjoint by the historical y-bound. For the last G1, i>=3 is disjoint by x_min=(i−2)e+3>e. The only added exceptional case is h=1,i=2, whose sole G1 intersection is(e,2), with both heights−1. The endpoint is disjoint from all G3 by x_max=2−e <3−e<=x_min(first G3). Thus no new earlier field clips this extra copy or changes its touching constant.

The historical same-order reflection sends index i to2h−i, so the extra RIGHT index2h becomes LEFT index0. It is an actual sourcewise reflection, not an unordered support inference. RIGHT retains the initial G origin at height0 and all added values are nonpositive by the existing formula. LEFT's added i0 raw alternate has maximum0 at(1−e,−1), below all previous alternate sources (minimum y>=0), endpoint (minimum y>=2h−1), and G1 (minimum y>=2h). It therefore remains height0. Both LONG max-zero normalizations are exactly those already displayed for SHORT.

## Exact clipping set, with closed physical heights
There are exactly two noncoherent first-G3 contacts on RIGHT:

 z_j=kY+(0,j), j=1,2.

They correspond respectively to raw A_e points(1−e,−1) and(1−e,0). Both raw base values are0. Let

 g_j=−j−k(ej+c)−T k(k−1)/2.

The actual preceding standard field is G(z_j)=g_j. The aligned raw G3 offer is g_j+1. Thus the actual piece keeps g_j, not the raw G3 height. This follows from the h1 values G(0,1)=−1,G(0,2)=−2 and the genuine common transform f(z−kY)+kB·z+d_k. All other first-G3/prefix overlaps have equality. Later G3 copies are coherent with the first raw G3 field, and their only possible extra G1 intersection has equality, so no further clipping sites appear.

Under the literal same-order reflection, the LEFT clipping sites are

 z'_j=((2h−1)e+3, 2h+e+1−j), j=1,2.

In the first LEFT alternate's native coordinate these are(3,e+1) and(3,e). Direct base evaluation gives raw prices

 A_e(3,e+1)=−e(e+1)/2+1=−eta,
 A_e(3,e)=−e(e+1)/2+e+1.

The actual preceding LEFT standard price is one less at each. These values are independent of h, because every LEFT alternate occurrence has slope0 and scalar0. SHORT and LONG have the same two clipped locations in their physical frames.

This is exactly the weak first-ownership pattern: incoming source>=old prefix at the two exceptional contacts, equality somewhere on the actual overlap, and new exposed sites take the incoming price. It does NOT establish incoming source equality throughout the old overlap. Any target-recognition argument must preserve the older lower values at these two sites.

## The two R2-excess sites are different from the two contacts
The actual raw reciprocal ALT domain lies in its endpoint R2 plus L=(1−e,−1) and R=(3,e+1), both odd, each violating its R2 longitudinal edge by4. This is proved directly by the literal selector in LITERAL_RECIPROCAL_EVEN_ALTERNATE_IS_ENDPOINT_R2_PLUS_TWO_ODD_CORNERS.md and its independent audit.

L is one of the clipped RIGHT first-G3 contacts; R is the reflected LEFT contact. The second contact on each side is its adjacent ordinary corrected corner, not another R2-excess point. Thus paying the two R2-excess points does not automatically pay both clipping contacts, and enlarging only an abstract R2 cannot enforce the correct older owner.

## Minimal remaining physical recognition tests
Given a proposed raw outer target Tchild and the exact placed/priced fields above:
1. At the two clipped first-G3 contacts on each side require Tchild equal the preceding standard price (raw ALT minus1), not raw ALT equality. These four physical values are now explicit above, before the known outer translation/affine jet.
2. On exposed G3 sites, including each additional raw R2-excess corner when not already owned, require Tchild equal the calibrated ALT field. No recurrence inference fills an unoccupied native gap.
3. On the endpoint G2 use its literal six sites with RIGHT−e2 and LEFT+(1,−1), exact slope and scalar. It has only the two last-G1 contacts, at(2−e,e),(2−e,e+1) in the h1 frame, transported by kY; these are exact equality contacts. It does not meet G3.
4. Outer source recognition still needs the actual candidate target values and earlier chronological union inequalities. Historical finite touches and actual A4/A6 geometry are already available, but finite touching alone does not select the proposed value scalar.

## Pure2 is not obtained by a false native bijection
The literal near-one odd alternate has two EVEN R2-excess corners, whereas this reciprocal source has two ODD excess corners. Its endpoint is the genuine four-site1/1 atom rather than the six-site0/1 atom; its exceptional G2 shift is LEFT+(1,1). Therefore a direct crop-by-crop quarter-turn of the above piece is not licensed. A one-sided physical conjugacy/sandwich may transfer values only after its actual primitive source masks, harmonic jet and retained older owners are matched. The present note proves neither that matching nor the outer two-sibling result.

Sources read: PURE_THREE_SAVED_SHORT_A5_CHAINS_HAVE_EXACT_ORDERED_HEIGHTS.md; its INDEPENDENT_PURE_THREE_SHORT_A5_ALL_LENGTH_ORDERED_HEIGHT_AUDIT.md; CORRECTED_NEGATIVE_FIRST_SHORT_L_PIECES_HAVE_EXACT_THREE_LEAF_MINIMUM_FORMULAS.md; literal base_case.jl, get_l_correction.jl and tile_offsets.jl; both literal reciprocal/near-one endpoint R2-plus-corner proofs. The new extension and contact formulas above are symbolic derivations, not finite extrapolation.
