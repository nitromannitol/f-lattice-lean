# Reflected odd donor nesting on the integer lattice

## Theorem
Let B=(d,n) be proper odd type, Z=(e,r) proper even type, 0<n<d, 0<r<e, dr-ne=1. For the authentic closed parity polygons E,
 E_B+V_Z subset E_(B+Z).
Consequently E_A+iV_Z subset E_(A+iZ) for all integers i>=0 whenever det(A,Z)=1. No assumption Z>=2B, lower-half slope, literal crop filling, or recurrence of a new child enters this geometry.

Put T_B=d²+2dn-n², T=T_Z, K=(d+n)e+(d-n)r, C=B+Z. The exact odd E rows, obtained by the genuine swapped-even polygon conjugacy, are:
 even physical parity: t_B in[1-T_B,d+n-1], s_B in[0,2T_B+2n];
 odd physical parity: t_B in[n-T_B,d], s_B in[2-d+n,2T_B+d+n-2].
Here t_B=nx-dy and s_B=(d+n)x+(d-n)y. Since Z is even type, V_Z preserves physical parity. Direct inversion using dr-ne=1 gives
 T_B t_C(u+V_Z)=(T_B+K)t_B(u)+s_B(u)-(K+T)T_B,
 T_B s_C(u+V_Z)=(T_B+K)s_B(u)+2t_B(u)+2T_B.
Use the same displayed row formulas with C and T_C=T_B+2K+T for the target.

## Integer margins, including the fractional corner issue
For each parity, at all four rational vertices of the source (t,s) rectangle, let q be T_B times any of the four target facet slacks. We prove q+T_B>0, NOT q>=0. Each q is affine on the source rectangle, hence q+T_B>0 throughout it. At a physical integer point the actual target slack q/T_B is an integer, so q/T_B>-1 implies q/T_B>=0. This is the missing rounding step and covers closed boundary points.

check_odd_nesting.py constructs all32 margins directly from these formulas. Set c=d-n>=1 and f=e-r>=2. For28 records, substitute n=1+n0,c=1+c0,r=1+r0,f=2+f0; the resulting polynomial q+T_B has all coefficients nonnegative and constant strictly positive.
The four exceptions have keys (parity,t-end,s-end,facet)
 (1,0,0,0),(1,0,0,2),(1,0,1,0),(1,1,0,2),
where lower/upper ends are0/1 and facets are lower-t,upper-t,lower-s,upper-s. In these use cr-nf=1 to substitute f=(cr-1)/n, multiply q+T_B by positive n, and shift n,c,r by1. Again every coefficient is nonnegative and the constant strictly positive. The complete monomial/constant lists are stored in ODD_NESTING_COEFFICIENTS.json. Thus this is an exact polynomial certificate over an enlarged positive cone, not a test of fractions or a rational relaxation asserted to be exact.

The earlier fractional failure at B=(2,1), Z=(5,3), odd vertex(t,s)=(-6,1) has slack -2/7; it is correctly handled by this proof. It never was a lattice counterexample.

## Exact reflected-donor transport
Use the already proved INDEPENDENT_ODD_P_DONOR_CONJUGACY, with the independent native identity F_(B+Z)=its comparator on its own E supplied by the earlier-standard induction. The reflected W0 donor equality is
 F_(B+Z)(u+V_Z)=F_B(u)+b_Z.(u+V_Z)+eta_(B+Z)-eta_B+b_B.V_Z
 for u in E_B.
All these queries are now on genuine licensed polygons by the nesting theorem. The correction simplifies exactly to b_Z.u-c_Z, since b_Z.V_Z=-T, b_B.V_Z=-K and eta_(B+Z)-eta_B=(T+2K-e-r)/2. Therefore
 F_(B+Z)(u+V_Z)-F_Z(u+V_Z)=F_B(u)-F_Z(u).
Iterating at u+iV_Z, now licensed by nesting, gives the all-length identity
 F_(A+kZ)(u+kV_Z)-F_Z(u+kV_Z)=F_A(u)-F_Z(u), u in E_A.
Equivalently the transported odd donor has exactly the Z deck jet; no extra scalar or parity constant accumulates. This supplies the proposed G2 second-price transport wherever that second price is reduced to this formula with its authentic outer jet. It does not independently prove a different first price is above it, actual helper UR alignment, or outer chronology.

The previous exact counterexample to whole G2 far-C donor ownership modulo Q deck remains valid and does not conflict: this proof uses a chain of earlier reflected donors, not one present far-C occurrence.
