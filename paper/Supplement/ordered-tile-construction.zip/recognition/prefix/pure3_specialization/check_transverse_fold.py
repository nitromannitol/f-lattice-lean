"""Exact bounds from the two-case lower transverse facet. Uses M(A,Z)^2-T_A T_Z=2."""
import sympy as S,json
from pathlib import Path
d,n,e,r,k=S.symbols('d n e r k')
u,v,w,h,j=S.symbols('u v w h j', nonnegative=True)
D,N=2*d+e,2*n+r; T=D**2+2*D*N-N**2;subs={n:0,d:1,r:1,e:2*u+1,k:j+1}
rows=[]
for saved in [3,1]:
 ad,an=(d,n) if saved==3 else(d+e,n+r)
 K=(ad+an)*D+(ad-an)*N;B=K+k*T;nc=an+k*N
 for par,(lo,sh,g) in enumerate([(2-T,T+2*N,1),(N-T,T+D+N-2,nc)]):
  num=sh+T*(g-1)+2
  # When e=1, B(t+K+(k-i)*T)<num (i is queried layer).
  # i<=k-1 implies t+K+(k-i)*T>=lo+K+T. Contradiction.
  # Also requires effective D(u-v+2A) in its full old physical band.
  for key,pol in [('only-last',B*(lo+K+T)-num),
                  ('D-upper',B*(N+2*D-3)-num),
                  ('D-lower',lo+K+2-(3-D-T))]:
   poly=S.Poly(S.expand(pol.subs(subs)),u,v,w,h,j)
   ok=all(x>=0 for x in poly.coeffs())
   rows.append((saved,par,key,ok,len(poly.coeffs()),int(poly.TC())))
assert all(z[3] for z in rows),rows
print(rows);Path(__file__).with_name('TRANSVERSE_FOLD_CERT.json').write_text(json.dumps(rows,indent=2)+'\n')
