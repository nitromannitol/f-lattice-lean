# W1 LONG ordinary p donors: both queries are truly inside the next polygon

## Result and explicit hypotheses

Let C=(d,n) be any proper odd-type parent and Z=(e,r) any proper even-type parent, with det(C,Z)=dr−ne=−1, n≥1,d−n≥1,r≥1,e−r≥2. Set O=C+Z. Then

 E_C+Z ⊂ E_O,   E_C+Z+V_Z ⊂ E_O.

In particular the proposed upper-row exception does not occur. No physical zero-strip repair or raw-minimum extension off E_O is needed.

For the stationary situation C=A+kZ, assume the authentic earlier physical fields and true W1 polygon identities

 F_C(w)=M(w) on E_C, F_O(w)=M(w) on E_O,
 M(w)=min(F_Z(w−2A),F_Z(w−V_A)+a_A·w+eta_A).

Then the raw W1 LONG target, in its actual shifted phase x=y+Z,

 T1(y)=min(F_O(x), F_O(x+V_Z)−a_Z·x+c_Z−1),

satisfies T1(u)=F_C(u) for every u∈E_C. Its exact raw involution supplies the genuine far ordinary p window E_C+V_C+V_Z with the literal source slope and the explicit candidate scalar below. Chronological min-touch and actual native support assumptions remain separate.

## 1. Exact upper transverse margin

Write T_C=d²+2dn−n², K=M(C,Z), L_C=d+n, L_Z=e+r. Let t=t_C(u),s=s_C(u). Direct inversion using det(C,Z)=−1 gives

 T_C*t_Z(u)=Kt−s,
 Kd=eT_C−(d−n),
 K L_C=L_Z T_C+2n.

On the even E_C row, t≤L_C−1 and s≥0, hence

 t_Z(u)≤K(L_C−1)/T_C=L_Z−(K−2n)/T_C<L_Z.

Here K>2n follows directly from e≥3 and d>n. Since the physical grade is integral, t_Z(u)≤L_Z−1. On the odd row, t≤d and s≥2−d+n, hence

 t_Z(u)≤[Kd−(2−d+n)]/T_C=e−2/T_C<e,

so t_Z(u)≤e−1. Therefore

 t_O(u)=t_C(u)+t_Z(u)≤L_O−2 (even), or d_O−1 (odd).

Since t_O(Z)=1, u+Z fits the true upper t_O row. The established W1 near nesting E_C⊂E_O gives its lower row, which is preserved by this increase of1. This proof uses integer rounding of an exact strict rational inequality, not attainment of a relaxed rectangle vertex.

## 2. Longitudinal rows and reflected second query

The previously established near/far nesting gives u and u+2Z+V_Z in E_O for every u∈E_C. Put B=M(O,Z)=K+T_Z>2. The longitudinal increments from u are

 s_O(Z)=B,  s_O(Z+V_Z)=B−2,
 s_O(2Z+V_Z)=2B−2.

Both B and B−2 lie in [0,2B−2], so the parity longitudinal intervals contain both intermediate queries. Every shift preserves physical parity.

The genuine polygon reflections have R_C=2C+V_C+δ and R_O=2O+V_O+δ, δ=(1,−1). Their exact difference is2Z+V_Z, and

 R_O−(u+Z)=(R_C−u)+Z+V_Z.

Since R_C−E_C=E_C and R_O−E_O=E_O, the already proved complete inclusion of E_C+Z gives the complete inclusion of E_C+Z+V_Z as well. Thus all four raw donor evaluations below are licensed at genuine O points.

## 3. Independent four-offer calculation

For fixed u let U=F_Z(u−2A) and V=F_Z(u−V_A)+a_A·u+eta_A. The canonical Z primary is zero, a_A·Z=1, a_Z·A=−1 and a_Z·V_A=a_A·V_Z=−M(A,Z).

At x=u+Z the two licensed O constituents are exactly (U,V+1). At x+V_Z, after the raw correction −a_Z·x+c_Z−1, they are exactly (U+1,V). This follows directly from the Z secondary law F_Z(z+V_Z)=F_Z(z)+a_Z·z−c_Z. Therefore

 T1(u)=min(U,V+1,U+1,V)=min(U,V)=F_C(u).

The raw relative −1, the shift x=u+Z, and the +1 in a_A·Z are all retained. No new unknown common gauge appears.

## 4. Reflected pFar, actual nominal source and price

Use the independently checked W1 raw involution from LONG_W1_ENDPOINT_AND_REFLECTION.md:

 R1=R_Q−Z, Q=2C+Z,
 T1(R1−y)=T1(y)−a_Q·y−eta_Q−1.

It sends E_C at0 to E_C+o, o=R1−R_C=V_C+V_Z. For x=u+o the exact result is

 T1(x)=F_C(u)+(a_C+a_Z)·x+g_far,
 g_far=eta_Q+1−eta_C+a_C·(V_C+V_Z).

The slope a_C+a_Z and origin V_C+V_Z agree with literal W1 getAltOddTileFull natural slot5. Slot2 is the near C donor at0 with zero slope and scalar0. Thus these are the correct ordinary pNear/pFar candidate prices, not the standard-Q donor gauge with the missing extra1.

## Scope and noncircular order

The geometry is uniform over arbitrary proper adjacent C,Z of determinant−1, independent of birth history. The value proof consumes the actual earlier C/O stationary polygon representations, standard global deck laws, and actual centered reflections. It does not infer those representations from the desired alternate. Its only geometric inherited input is the already proved uniform odd near/far nesting; the one-row refinement is independently derived here. These full-polygon identities restrict to any genuine native source contained in E_C. They do not by themselves prove nonempty chronological overlaps, outer scalar selection, or current physical recurrence.
