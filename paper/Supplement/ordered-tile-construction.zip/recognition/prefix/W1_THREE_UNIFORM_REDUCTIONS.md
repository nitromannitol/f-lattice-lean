# Three uniform reductions for the W1 RIGHT prefix

Use the exact strict-cone saved1/3 setup, actual E_Z parity rows, W1 projections and authentic old-field conventions of W1_TWO_QUERY_FOLD.md. All statements hold for every u in E_Z and1<=j<=k.

## 1. The second query never needs a transverse fold
For q2=u+(j-1)V_Z-Z, t_C(q2)>=lo_t(E_C). Consequently e2=0 always.

## 2. The first query needs a transverse fold only at the final index
For q1=u+jV_Z and1<=j<=k-1, t_C(q1)>=lo_t(E_C). Thus e1=1 implies j=k. For k=1 the nonfinal statement is empty.

Both follow from `check_w1_no_transverse.py`: the previous exact fold-box proof is strengthened by replacing lo_t-T_C with lo_t. All64 vertex facets pass for each of the four saved/arm cases, total256. Arm1 substitutes k>=2 and j endpoints1,k-1; arm2 uses k>=1 and endpoints1,k. Physical parity is unchanged by the relevant shifts. The proof uses the W1 determinant reductions KD=d_A T+(D-N) and KL=L_A T-2N. Coefficient margins q+T>0 yield nonnegative integer margins, not an assumption that nonphysical rectangle vertices are attained.

Thus the rows e2=1 in the eight-row table never occur. They should be deleted from the active value obligations, not proved through fictitious price bounds.

## 3. No longitudinal fold on arm2 forces r=1
Suppose f2=0. From its exact s coordinate,

 B(s-T)>=T*lo_s(E_C)-2t+2(j-1)T
          >=T*lo_s(E_C)-2*upper_t(E_Z).

The four saved/parity coefficient gates in check_w1_harmonic.py prove

 T*lo_s(E_C)-2*upper_t(E_Z)>B*(2-2D).

Since s-T is an integer, s-T>=3-2D. Let w=u-Z. In W1, s_Z(v)=2, hence

 s_Z(w)=s-T>=3-2D,
 s_Z(w-v)=s-T-2>=1-2D.

The genuine E_Z upper rows also give s-T<=2N on even sites or<=L_Z-2 on odd sites. Therefore BOTH w and w-v lie in the authentic earlier harmonic strip [1-2D,2L_Z-1]. This licenses F_Z=h0 at both physical points, without asserting either point is native.

The exact harmonic identity is

 h0(w)-h0(w-v)-a_A.w=eta_A.

Indeed B_H v=a_A, v.B_H v=-T_A, and the linear term in h0 contributes -L_A/2; v preserves parity so the floor parity term cancels. Thus Pstd(w)=eta_A. The true primary Z has zero character and a_A.Z=1, so Pstd(u)=Pstd(w)-1=eta_A-1. Consequently

 r=eta_A-Pstd(u)=1.

This proves the necessary exact value, not merely a lower bound. It pays the arm2(0,0) constituent r-1 and supplies attainment there, once its other constituent d0+2j-2 is nonnegative. If f2=1, arm2(0,1) already has a zero constituent; only r-dv+2(k-j)+1>=0 remains for that row.

## Remaining scope
These reductions remove all arm2 transverse cases and every nonfinal arm1 transverse case. They do not independently prove shifted D lower bounds or final-arm1 value comparisons. All uses of F_Z=h0 and canonical primary characters concern the previously admitted genuine earlier field; no current-child recurrence or native crop recognition is used. The geometry covers saved1/3; evaluation of the stationary minimum still uses the separately authenticated corresponding source theorem.
