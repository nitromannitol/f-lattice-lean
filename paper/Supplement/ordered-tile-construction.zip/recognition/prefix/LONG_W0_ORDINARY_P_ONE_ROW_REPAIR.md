# W0 LONG ordinary p donor: independent one-row repair audit

Conditional PASS of the proposed mechanism. Let C=A+kZ,O=C+Z,det(C,Z)=1,k>=1. Assume the proved whole-polygon inclusions E_C+2Z⊂E_O and E_C+V_Z⊂E_O; genuine earlier global standard fields, deck/reflection/zero strips; stationary F_C=M_C on E_C and F_O=M_O on E_O; and the all-proper E_C bound t_Z(u)<=L_Z+1 on even sites, <=d_Z+2 on odd sites. No current alternate identification is used.

For u∈E_C set y=u+Z. Because Z is even-parity, all queried sites preserve parity. Put K=M(C,Z)>0. The target longitudinal grades are s_O(y)=s_O(u)+K and s_O(y+V_Z)=s_O(u)+K−2, since s_O(V_Z)=−2. Both lie between the grades at u+V_Z and u+2Z. Thus both have correct longitudinal coordinates. Transversely t_O(Z)=−1 and t_O(V_Z)=−(K+T_Z). The point y can miss only the upper edge, by at most1; y+V_Z can miss only the lower edge, by at most1. Here K+T_Z>=1. These conclusions use the two stated inclusions, not real rectangle containment.

Consider the possible upper miss. On even sites it would require t_O(u)=L_O+1, but t_C(u)<=L_C−1 and t_Z(u)<=L_Z+1 imply t_O(u)<=L_O, a contradiction. On odd sites it requires t_O(u)=d_O+2. The upper bounds t_C(u)<=d_C and t_Z(u)<=d_Z+2 force equality in both. Consequently F_C(u)=F_Z(u)=F_O(y)=0 by their genuine physical zero strips, and F_Z(y)=F_Z(u)=0 by the genuine Z primary law.

Write F=F_Z, M_C=min(F,h+2k−2), M_O=min(F,h+2k), with H=h−F and the exact global increments H(z+Z)=H(z)−1 and H(z+V_Z)=H(z)−2. Since M_C(u)=F_C(u)=0 and F(u)=0, we have h(u)+2k−2>=0. Therefore M_O(y)=min(0,h(u)+2k−1)=0=F_O(y), paying the exceptional row without assuming F_O=M_O outside E_O generally.

The genuine reflections R_O=2O+V_O+(1,−1), R_C=2C+V_C+(1,−1) satisfy R_O−(u+Z+V_Z)=(R_C−u)+Z. Since R_C−u∈E_C, the upper-row result, genuine F_O reflection and already algebraic M_O reflection pay the second query too. Hence F_O=M_O at BOTH needed points for every u∈E_C.

Now the four offers of T(y)=min(F_O(y),F_O(y+V_Z)−a_Z·y+c_Z+1) are exactly

 F(u), h(u)+2k−1, F(u)+1, h(u)+2k−2.

Their minimum is M_C(u)=F_C(u). Thus the complete LONG pNear identity T(u+Z)=F_C(u) holds, including boundaries. No mere minimum-attainment assertion was used to price an individual branch.

Raw reflection center R=R_Q+Z and law T(R−y)=T(y)−a_Q·y−eta_Q−1 give the far ordinary origin oFar=R−Z−R_C=V_C+V_Z+Z, matching literal W0 LONG slot5, with global price

 F_C(x−oFar)+(a_C+a_Z)·x+eta_Q+1−eta_C+a_C·oFar.

This establishes both analytic full-polygon C prices under the listed previously established geometry and field hypotheses. Actual restored support, chronological overlap and normalization remain separate. The certificate is a hand derivation audited against the named prior ingredients, not an independent reimplementation of those ingredients.
