import sympy as s,json
from pathlib import Path
rows=[]
k,j,T,K,TA,L,LA,t,a=s.symbols('k j T K TA L LA t a');etaA=(TA-LA)/2;etaC=(TA+2*k*K+k*k*T-LA-k*L)/2;c=(T+L)/2;eta=(T-L)/2;B=K+k*T
for arm in[1,2]:
 for e in[0,1]:
  for f in[0,1]:
   l,h=(j,0)if arm==1 else(j-1,1);m=l-e*k;n=2*f*k-h
   corr=e*(a+k*t-l*B-h+etaC)+(0 if arm==1 else t-j*T+eta)
   vals=[]
   for q in[0,1]:
    vcoef=-(e+q);acoef=2*(f-1+q);tt=t-vcoef*K-acoef
    extra=0 if not q else a-m*K+n+e*TA+etaA
    jet=m*tt-m*c-m*(m-1)*T/2+extra+corr-(j*t-j*c-j*(j-1)*T/2)
    vals.append(((acoef,vcoef),str(s.factor(jet))))
   expected={
    (1,0,0):[2*j,a+etaA],(1,0,1):[0,a+etaA+2*k-2*j],
    (1,1,0):[a+etaA+2*j-2*k,2*a+2*TA-LA],
    (1,1,1):[a+etaA,2*a+2*TA-LA-2*j+4*k],
    (2,0,0):[2*j-2,a+etaA-1],(2,0,1):[0,a+etaA+2*k-2*j+1],
    (2,1,0):[a+etaA+2*j-2*k-3,2*a+2*TA-LA-2],
    (2,1,1):[a+etaA-1,2*a+2*TA-LA-2*j+4*k]}[arm,e,f]
   for q in[0,1]:assert s.simplify(s.sympify(vals[q][1])-expected[q])==0
   rows.append({'arm':arm,'e':e,'f':f,'values':vals})
Path(__file__).with_name('W1_OFFER_TABLE.json').write_text(json.dumps({'identities':16,'rows':rows},indent=2));print('PASS 16 exact deck identities')
