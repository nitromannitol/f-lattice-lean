# Endpoint and literal pure-birth G3 ledger

Independent source/scope audit. No new finite samples or height theorem.

## 1. Exact exclusion, not a slope label

The current proper eight-record theorem is S1/FINAL_PRICE_ATLAS.md. Its birth is an actual proper Farey creator a=(d,n), R=(e,r), with n>=1, d-n>=1, r>=1, e-r>=2. It uses genuine earlier canonical fields and creation-R2 formulas. A later selected pair being proper does NOT prove that its consumed G3 primitive had such a birth. Literal base initializers are not synthetic seven-source creations.

The genuinely separate windows are the literal reciprocal/near-one alternate initializers and their restored occurrences: pure-run saved records, first-one saved records that still select these old primitives, and the first mixed endpoint-core saved records. This does NOT exclude every later word with a pure prefix. Once the consumed primitive is genuinely born at a proper recursive creator, the corresponding record can enter the eight-record theorem with its stated premises. Conversely, word length or a proper fraction alone does not discharge birth authentication.

## 2. Exact dispatcher inventory

Read original_port_recursion.py and original_port_base.py. Odd-L consumes qa2, with standard G1=q2 and G2=p2, from anc2 (last updated on digits1 or3); it feeds corrected EVEN standard SHORT and ODD alternate LONG when digit2 is next taken. Even-L consumes pa2, with G1=p2 and G2=q2, from anc3 (last updated on1 or2); it feeds corrected ODD standard SHORT and EVEN alternate LONG on digit3. Both flips are constructed. Pure current words are dispatched by get_base_quadruple, not by these corrected children.

| literal record | consumed exceptional G3 and separate scope |
|---|---|
| saved3^a, a>=1, odd-L/W0 | literal reciprocal even ALT q=1/(2a+1), with endpoint0/1 G2; both flips, SHORT/LONG, arbitrary helper length |
| saved2^a, a>=1, even-L/W0 | literal near-one odd ALT a/(a+1), with endpoint1/1 G2; both flips, SHORT/LONG, arbitrary helper length |
| saved3^a1, a>=0, W1 | both helpers still use selected literal P=1/d,Q=1/(d+1), d=2a+2, not newly created first-one alternates |
| saved2^a1, a>=0, W1 | selected literal P=b/(b+1),Q=(2b-1)/(2b+1), b=a+1; a=0 is the same root record1, not an additional case |
| saved3^a2, a>=1, even-L/W0 | selected literal reciprocal odd ALT P=1/(e+1), Q=1/e, e=2a+1; no pure-word G2 shift |
| saved2^a3, a>=1, odd-L/W0 | selected literal near-one even ALT Q=(2d-1)/(2d+1), P=(d-1)/d, d=a+1; no pure-word G2 shift |

These are the endpoint inventory explicitly separated by the historical pure, last-one and switch anchor papers. It is an inventory of consumed records/primitive lineages, not a claim that every occurrence has an unpaid height. Empty record satisfies BOTH all2/all3 predicates, but get_odometers('') installs endpoint/literal arrays directly and skips get_corrections: do not count nonexistent empty-ancestor helper windows. Both auxiliary types may be computed at a nonempty pure record; the historical theorem deliberately covers consumed ones, not unused opposite-type calls.

## 3. Restoration and mask facts that survive

Pure3 odd-L uses RAW even staircase coordinates: centering and A4 cancel, including the extra ey in all3 restoration. RIGHT G2 receives -ey and LEFT G2 receives ex-ey; those shifts affect ONLY G2 and do not change the continuing G3 origin. Pure2 even-L LEFT alone receives ex+ey on G2. Replacing either endpoint by a formal proper H polygon changes the source.

For saved3^a1 the reciprocal even ALT is again raw after A4, odd ALT is raw+(1,1) for d>=4, and d=2 uses the true root selector. For saved2^a1 use genuine near-one y_raw-1 frames (root b=1 separately). The switch anchors use their own literal frames, not a fictitious endpoint six-source alternate birth.

## 4. Which earlier results actually pay what

* PURE_ENDPOINT_A5_PREFIX_AND_FIRST_G3_INSERTIONS_HAVE_LITERAL_DOMAIN_ANCHORS.md, LITERAL_LAST_ONE_ENDPOINT_RECORDS_HAVE_DIRECT_FIRST_G3_ANCHORS.md and LITERAL_SWITCH_ENDPOINT_RECORDS_HAVE_DIRECT_FIRST_G3_ANCHORS.md pay actual finite internal touches/support unions, with their stated same-order reflection and consecutive-tail dependencies. They do not pay target G3 height equality, outer constants or recurrence.
* PURE_THREE_SAVED_SHORT_A5_CHAINS_HAVE_EXACT_ORDERED_HEIGHTS.md plus INDEPENDENT_PURE_THREE_SHORT_A5_ALL_LENGTH_ORDERED_HEIGHT_AUDIT.md pays ALL helper lengths for SHORT internal ordered heights and max-zero normalization, by transporting the h=1 seed. It explicitly leaves outer six-piece constants/overlap comparisons open. Raw leaves are not fully compatible: clipping at h=1 includes (0,1),(0,2). Thus the one-block calculation is not a theorem that every G3 native value survives unchanged, and SHORT cannot simply be relabelled LONG (LONG adds a terminal head).
* INDEPENDENT_PURE_TWO_CORRECTED_EVEN_HEIGHT_ENDPOINT_AND_G2_SHIFT_AUDIT.md pays a conditional finite HEIGHT/reflection mechanism for actual2^m3^h, retaining containing characters and earlier primitive HEIGHT/value premises. Its literal four-point endpoint and LEFT-only shift are essential. It is not an unconditional substitute for all proper G3 price hypotheses.
* CURRENT_ODD_ALT_PURE_TWO_LONG_CAP_INITIALIZATION_SCOPE.md has completed384 source-cap keys, including two exceptional even corners of the old near-one odd ALT. These are cap/support statements, not all-point price identities. Formal R2 without these corners is insufficient.
* The later arbitrary_one_switch/RECURRENT_ONE_BLOCKS_AND_MOVING_TAILS.md establishes both standard3^m1^j and indicated ORDINARY moving tails (j>=2); it expressly does not establish generic corrected siblings or alternates. The separate first-one midpoint/forcing theorems concern the newly created alternates at first-one. They must not be confused with the older selected literal G3 primitive in the saved-first-one helper.

## 5. Minimal remaining interface

For each exceptional lineage, bind the consumed primitive's exact raw/restored support and value, endpoint/corner extras, actual G3 indices and affine jets. Then either prove the target-price identity on those genuine occupied points, or use the weaker chronological rule: incoming>=target on overlap and incoming=target on fresh sites, with an attained nonempty touch. An all-R2 identity can replace this only if the actual literal corners are included or separately paid. Internal one-block-to-all-length transport is useful but is not outer compatibility. True helper UR placement and finite padding remain separate producer premises.

No extrapolation to all literal endpoint births is made here. In particular the proper theorem's newly widened proper cone removes old N>=3/c>=4 restrictions for PROPER creators; it does not remove 0/1,1/1 endpoint provenance or create a missing literal alternate initialization.
