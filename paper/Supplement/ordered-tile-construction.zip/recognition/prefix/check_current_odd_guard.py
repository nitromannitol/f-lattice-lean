import sympy as s,json
from pathlib import Path
c,a,e,r=s.symbols('c a e r');d,n=c+e,a+r;D,N=d+n,d-n
T=lambda x,y:x*x+2*x*y-y*y
mix=lambda x,y,X,Y:x*X+x*Y+y*X-y*Y
K=mix(c,a,e,r);Q=T(e,r)
eq=lambda x:s.expand(x)==0
checks={'norm':eq(T(D,N)-2*T(d,n)),'W0':eq(-N*(c+a)+D*(c-a)-2*(c*r-a*e)),'W1':eq(N*r+D*e-K-Q),'lowerBalanced':eq(N+3*n-d-2*n) and eq(N+d-n-2*N),'zeroUpper':eq(N+2*n-D)}
assert all(checks.values());Path(__file__).with_name('CURRENT_ODD_NATIVE_D_GUARD_IDENTITIES.json').write_text(json.dumps(checks,indent=1));print(checks)
