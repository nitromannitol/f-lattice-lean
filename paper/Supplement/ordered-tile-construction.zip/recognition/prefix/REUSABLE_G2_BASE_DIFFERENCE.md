# Reusable W0 G2 base-difference identity, both saved records

Let A be the genuine effective odd parent and Z the fixed even parent, det(A,Z)=1, and assume the already authenticated odd nesting/reflected-p-donor theorem and the genuine earlier stationary raw identity on E_(A+Z). This applies to both proper saved3 and saved1 without falsely treating Z-2A as a proper birth parent.

Define globally

 H(u)=F_Z(u-V_A-2A)+b_A.u+eta_A+2-F_Z(u).

Then for every u in E_A,

 F_A(u)-F_Z(u)=min(0,H(u)-2).

## Independent scalar derivation

The proved geometry puts u+V_Z in E_(A+Z). Exact reflected-donor transport gives

 F_(A+Z)(u+V_Z)-F_Z(u+V_Z)=F_A(u)-F_Z(u).

The genuine stationary comparator for A+Z is min(F_Z,h), where h-F_Z=H. Its value at this licensed point therefore gives the left side as min(0,H(u+V_Z)). The old global secondary law and det(A,Z)=1 yield

 H(u+V_Z)-H(u)
 =b_Z.(-V_A-2A)+b_A.V_Z
 =(K-2)-K=-2.

Thus the desired identity follows with its exact constant2. No native inclusion of u in E_Z or prior bound on H is required. The role of the current/earlier A+Z polygon realization must remain an explicit already-available input; the identity cannot establish that same realization circularly.

## Consequences

In both saved records F_A(u)<=F_Z(u) on all E_A. More precisely, this identity gives the exact transported G2 target deficit, not merely its sign. Iterated reflected nesting gives the same difference at u+iV_Z in A+iZ with the genuine Z deck jet.

For saved3 the separate authentic birth p-donor proof additionally gives F_A(u)=F_Z(u-2A), hence the identity also reads

 D(u)=max(0,2-H(u))

on E_A. That extra birth interpretation is not required for the general saved1/saved3 identity and must not be transferred to a fictitious saved1 birth.

This supplies a reusable price target for the first G2 arm and identifies exactly what a first-arm lower comparison must dominate. It does not alone prove the first arm has that lower bound, the second current source has its actual outer scalar, or the entire helper is correctly normalized.
