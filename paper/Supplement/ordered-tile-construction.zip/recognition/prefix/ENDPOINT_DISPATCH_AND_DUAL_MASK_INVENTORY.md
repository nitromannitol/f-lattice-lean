# Original endpoint dispatch and analytic-dual inventory

Verified against original_port_recursion.py:get_l_correct/get_next_mat and original_port_base.py. Vectors below are (denominator,numerator). All six historical records are listed; first-one records each produce TWO consumed helper types. W is current parity of the number of1s. Empty record is initialized directly, not a helper call.

## Exact eight helper rows from the six records

| saved record | helper,W | actual (G1,G2,G3) | odd-L analytic reduction |
|---|---|---|---|
|3^a, a>=1|odd-L,0|(Z,0/1,Z_ALT), Z=(2a+1,1)|R0: A=(1,0),Z=(2a+1,1)|
|2^a, a>=1|even-L,0|(P,1/1,P_ALT), P=(a+1,a)|dual R0, but literal G2 has FOUR rather than SIX sites|
|3^a1,a>=0|odd-L,1|(Q,P,Q_ALT),P=(2a+2,1),Q=(2a+3,1)|R1: A=P,Z=Q|
|3^a1,a>=0|even-L,1|(P,Q,P_ALT), same pair|dual N1: A=(a+2,a+1),Z=(2a+3,2a+1)|
|2^a1,a>=0|odd-L,1|(Q,P,Q_ALT),P=(a+2,a+1),Q=(2a+3,2a+1)|N1: A=P,Z=Q|
|2^a1,a>=0|even-L,1|(P,Q,P_ALT), same pair|dual R1: A=(2a+2,1),Z=(2a+3,1)|
|3^a2,a>=1|even-L,0|(P,Q,P_ALT),P=(2a+2,1),Q=(2a+1,1)|dual N0: A=(a+1,a),Z=(2a+3,2a+1)|
|2^a3,a>=1|odd-L,0|(Q,P,Q_ALT),P=(a+1,a),Q=(2a+3,2a+1)|N0: A=P,Z=Q|

At a=0 the two first-one records are the SAME word1; do not double count. Their R1 and N1 tuples coincide there, but the original two helper types and their source frames remain distinct. In every row ALT means the SELECTED literal older initializer, not the newly created current alternate. The four analytic bases are R0,R1,N0,N1. Merely naming reciprocal and near-one does not identify W or the effective A; N0 and N1 have different A for a fixed Z.

R1 is the reciprocal effective-saved1 endpoint handled by reciprocal_direct. N0 is the near-one W0 specialization in ENDPOINT_G1_G2_SCOPE_AND_OBSTRUCTION. R0 is the pure reciprocal endpoint with the actual six-site new comparison in reciprocal_actual_six. These facts do not silently certify the separate N1 protected-price instance or any ALT corner by association.

## Original masks, insertions and endpoint shifts
Odd-L is consumed on NEXT2: standard EVEN SHORT and alternate ODD LONG. Even-L is consumed on NEXT3: standard ODD SHORT and alternate EVEN LONG. For a helper call let h=len(current_s)-len(ancestor_s), exactly the code variable. BOTH flips contain h+1 G1 copies, one G2, and2h+1 G3 copies SHORT or2h+2 LONG. LONG really adds one terminal source; it is not a relabelled SHORT output.

Natural six-slot masks BEFORE chronological permutation:
* standard even: (q,q,p,Gl,Gr,p), both W;
* standard odd W0: (q,Gr,Gl,q,p,p); W1:(Gr,q,q,Gl,p,p);
* alternate odd LONG: (q,q,p,Gl,Gr,p), both W;
* alternate even LONG: (Gr,q,q,Gl,p,p), both W.
The code then permutes standard odd to natural order0,1,4,5,2,3; standard even to0,2,3,1,4,5; either corrected alternate to0,2,3,4,5,1. Do not use the standard-even mask for the alternate-even slopes or chronological owners.

Special literal G2 shifts are only: pure3 odd-L RIGHT -ey and LEFT ex-ey; pure2 even-L LEFT ex+ey, RIGHT no extra shift. They do NOT update the running origin of subsequent G3 sources. Neither first-one nor switch record receives these pure-word G2 shifts.

## Analytic dual and the actual-crop boundary
Arithmetic dual sends odd(d,n) to even(d+n,d-n), even(d,n) to odd((d+n)/2,(d-n)/2), swaps selected parent roles, exchanges2/3 and preserves W. The three all-parameter selected-pair identities above are checked in ENDPOINT_DISPATCH_DUAL_IDENTITIES.json.

For a STANDARD source X the physical map is f_X(z)=Rot(z-U_X)+e1, with U_X=2X for odd X and X for even X, and beta_X=tau_X=0. For ALT use its OWN authenticated initializer/creation tau_X and beta_X, NOT the consumer's: f_X(z)=Rot(z-U_X)+e1+tau_X. An occurrence o transforms by Rot(o-U_target+U_source)+tau_target-tau_source, and its harmonic/affine slope must be transformed as in S1/UNC_STANDARD_ALT_DUALITY_AUDIT. This specifies the frame; it does not assign a fictitious proper birth tau to a literal pure initializer. The pure literal restoration is the actual translate_alts rule; notably pure3 includes the extra ey. First-one reciprocal odd ALT uses raw+(1,1) away from its literal root, whereas even ALT is raw after A4. Near-one uses its own y_raw-1 frames. Keep those actual initializer maps when evaluating ALT corners.

The0/1 source is a literal2-by3 six-site block with row heights(0,0,-1), twice. After the pure3 RIGHT -ey shift its coordinates may be written w=(x,y), x=0,1 and y=-1,0,1, value -y(y+1)/2. This is exactly the source used by reciprocal_actual_six/prove.py. The1/1 source is a2-by2 FOUR-site block with rows(0,-1),(0,0). A rotation/translation cannot identify these entire masks (cardinalities differ). A strong six-site ANALYTIC inequality can cover an explicitly embedded four-site transformed mask, but that embedding, scalar and current-target guard must actually be checked. It does not prove equality of the original finite merges.

Likewise proper-R2 transport is not a blanket literal-pure ALT identity: reciprocal and near-one initializers retain their actual rails, diagonal increments and extra corners. A price theorem on an analytic target or a relaxed envelope transfers only where its stated guard holds. An actual-crop theorem transfers only after actual source inclusion and its height/gauge correspondence. Standard global field conjugacy supplies neither automatically.

## Strong versus ordered/clipped joins
Strong pointwise recognition on every true source site licenses source compatibility and, with a genuine prefix contact, fixes its scalar. A weaker ordered proof requires incoming>=target on overlap, incoming=target on fresh sites and an attained contact. The historical pure3 SHORT packet has genuine clipping at its first endpoint; its ordered one-block-to-all-length result is not a claim that every original G3 height survives. Use the new actual-six prices only at their stated arm/source coordinates, then the genuine ordered transport. LONG adds a source and needs its own terminal comparison. Domain-only anchor or UR facts cannot upgrade clipped joins to strong full-source equality.

This inventory authenticates dispatch, source types, masks and arithmetic dual records. It does not claim all four analytic base-price packages are complete, nor remove a remaining literal-corner/source-frame comparison by duality.
