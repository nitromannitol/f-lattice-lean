# Both LONG ordinary Z sources from the endpoint j=0

Let C=A+kZ, O=A+(k+1)Z, m=k+1>=2, Q=2C+Z. This audit consumes the earlier FULL G1 geometry and physical-value theorems, their old fields, full price span, complete physical strips and authentic O polygon identity. It does not assume current alternate recurrence or actual chronological gluing.

W0: the raw target is T(y)=min(F_O(y), F_O(y+V_Z)-a_Z·y+c_Z+1). At u in E_Z the already certified r2 support, stationary parameter m and indices1,2, puts u and u+V_Z in E_O. Their stationary errors are respectively min(0,H(u)+2m-2) and min(0,H(u)+2m-4). Whole-E_Z H>=0 makes both zero, INCLUDING m=2. Thus T(u)=F_Z(u); its second offer is exactly F_Z(u)+1. This is a genuine j=0 extension, not extrapolation of only the minimum theorem.

W1: raw x=y+Z and T(y)=min(F_O(x),F_O(x+V_Z)-a_Z·x+c_Z-1). Set y=2C+u. Zero primary2O reduces x to u-Z. The proven SHORT **individual arm2 attainment**, stationary parameter m, indices1 and2, gives F_O(u-Z)=F_Z(u) and F_O(u+V_Z-Z)=F_Z(u+V_Z). Indeed its index j identity is F_O(u+(j-1)V_Z-Z)+a_Z·(u+jV_Z)+eta_Z=F_Z(u+jV_Z); the genuine Z deck cancels the extra jet. Indices1,2 are both allowed even when m=2. Since a_Z·2C=-2, the raw second offer equals F_Z(u)+1. Hence T(2C+u)=F_Z(u), with zero near scalar and slope.

The exact already verified raw reflection is T(R-y)=T(y)-a_Q·y-eta_Q-1, with R=R_Q+Z for W0 and R=R_Q-Z for W1. Write oNear=2WC. Genuine parent reflection sends the near window to E_Z+oFar, where oFar=R-oNear-R_Z. Thus oFar=2C+2V_C+Z for W0 and2V_C-Z for W1, exactly the literal LONG qFar slot. Its value is

 F_Z(y-oFar)+2a_C·y+eta_Q+1-eta_Z+a_Z·oFar.

The extra +1 in the global scalar is essential: the raw reflection is not the standard Q reflection. Both ordinary Z windows are therefore paid as full-polygon analytic prices under the named earlier hypotheses. The actual source cropping, normalization, prior-prefix overlap and chronological touching remain separate constructor obligations. Native masks contained in these polygons inherit the identities, not vice versa.
