# Audit of the final no-fold value gate

**Verdict:** the proposed implication is correct with the genuine earlier price bound P(u-V_A)>=c_A-1, including its stated even upper-fringe payment. No full-E H>=1 premise and no current-child recurrence are needed. The geometry and negative-V sign are independently pinned below. The upper-fringe price payment must be retained as an explicit earlier source input; it cannot be replaced by native membership of u-V_A.

Let F=F_Z, v=V_A, U=2A, D(w)=F(w)-F(w-U), P(w)=F(w)-F(w+v)+a_A.w. Put w=u-v. Exact algebra gives

 H(u)=P(w)-c_A+2-D(w).

Indeed P(w)-D(w)=F(u-v-U)-F(u)+a_A.u+T_A, and T_A-c_A=eta_A. Thus there is no phase or scalar discrepancy with H(u)=F(u-v-U)+a_A.u+eta_A+2-F(u).

At the final no-fold slice, the independent polygon proof establishes t_Z(u)>=1-K. Since t_Z(v)=-K, t_Z(w)>=1. Also t_Z(U)=2, so the two D arguments have transverse coordinates t_Z(w),t_Z(w)-2.

If 1<=t_Z(w)<=N+1, both arguments lie in the genuine earlier ordinary zero strip [1-D,N+2D-1]. Their heights are0, so D(w)=0. At all larger t, use the earlier negative-V semigroup sign lemma: t_Z(w)>=N+1 implies D(w)<=0. This is Section2 of strip_geometry/ODD_TWO_Q_DONOR_SHIELDING.md with the actual saved3 old sign: its sigma is -U, hence its Dplus is exactly the present D. The sign lemma uses the previous global cover, native D range[0,2], and D(V_Z)=2. It does not presume that F vanishes throughout the half-plane.

Therefore D(w)<=0 throughout the final no-fold slice. Combining with the separately licensed P(w)>=c_A-1 yields H(u)>=1 exactly as required.

The potential upper-fringe issue is real: s_Z(w)=s_Z(u)+2, so w need not be a native E_Z point. A V_Z fold changes no s coordinate. Thus the price input must include the two-row upper longitudinal fringe (the stated physical-h0 payment after subtracting Z); mere native price span is insufficient. Saved1 already has H>=1 on the entire polygon by its genuine intrinsic-chain comparison and needs no saved3 sign conversion.
