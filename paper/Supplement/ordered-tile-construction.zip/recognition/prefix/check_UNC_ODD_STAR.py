import sympy as s,json
from pathlib import Path
d,n,e,r,x,y=s.symbols('d n e r x y');A=s.Matrix([d,n]);Z=s.Matrix([e,r]);z=s.Matrix([x,y]);O=A+Z;delta=s.Matrix([1,-1])
b=lambda X:s.Matrix([X[1],-X[0]])
v=lambda X:s.Matrix([X[1]-X[0],sum(X)])
T=lambda X:-b(X).dot(v(X))
c=lambda X:(T(X)+sum(X))/2
eta=lambda X:(T(X)-sum(X))/2
rows=[]
for W in [0,1]:
 G=s.groebner([d*r-n*e-(1-2*W)],d,n,e,r,x,y,domain=s.QQ)
 Y=z+v(A)+(Z if W==0 else 2*A-Z); X=Y+W*Z
 zp=(2*A if W==0 else 2*Z-2*A)+v(Z)+delta-z
 q=z+Z if W==0 else z+2*A
 w=zp+Z if W==0 else zp+2*A
 jet=b(A).dot(Y)+eta(A)+1-W
 old=-b(Z).dot(z)+2-eta(Z)
 checks={ 'direct_query':X+v(Z)-q-v(O), 'reflected_query':delta-X-w+2*O+v(O),
 'direct_jet':b(O).dot(q)-c(O)-b(Z).dot(X)+c(Z)+1-2*W-jet,
 'reflected_jet':-b(O).dot(w)-eta(O)-jet-(-old+1)}
 for name,expr in checks.items():
  terms=list(expr)if isinstance(expr,s.MatrixBase)else[expr]
  residual=[G.reduce(s.expand(t))[1]for t in terms]
  assert all(t==0 for t in residual),(W,name,residual)
  rows.append(dict(W=W,name=name,residual=list(map(str,residual))))
# Complete finite range of the abstract integer fringe lemma.
comb=[]
for D in [0,1,2]:
 j=min(0,1-D);jp=min(0,D-1)
 for e0 in range(j,1):
  for e1 in range(jp,1):
   assert min(e0,1-D+e1)==j
   comb.append([D,e0,e1,j])
out={'PASS':True,'formal_checks':rows,'integer_cap_cases':comb}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',len(rows),'jet identities;',len(comb),'cap cases')
