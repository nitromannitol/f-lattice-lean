# LONG W0 G1 endpoint: direct physical fold and exact last condition

Use the same proper saved1/3 effective pair A,Z and genuine earlier physical inputs as E1_TRANSVERSE_FOLD_PRICE_AUDIT.md. Write m=k+1≥2, O=A+mZ, v=V_A, K=M(A,Z), B=K+mT_Z. Assume the genuine stationary polygon identity F_O=min(F_Z,h+2m−2) on E_O. This note does not independently authenticate the actual LONG helper origin or its chronological scalar.

For the proposed raw LONG expression

 T(y)=min(F_O(y),F_O(y+V_Z)−a_Z·y+c_Z+1),

where c_Z=(T_Z+L_Z)/2 is positive, the second offer equals F_Z(y)+1+[F_O(y+V_Z)−F_Z(y+V_Z)]. Thus it suffices to bound the bracket below by −1. At y=u+jV_Z with u∈E_Z and 1≤j≤k, the only last support case is j=k, where z=y+V_Z=u+mV_Z.

## Geometry

The known r2 inclusion with parameter m gives z−V_Z∈E_O. Adding V_Z decreases t_O by B and increases s_O by 2. Therefore the upper-t and lower-s facets persist. The independent script check_long_w0_endpoint_geometry.py checks all sixteen upper-s source-rectangle vertices, in both saved choices and parities, with exact nonnegative polynomial coefficients. It uses the strict cone n≥2,d−n≥3,r≥1,e−r≥2,m≥2. Thus the upper-s facet also persists.

Moreover T_O≥B, directly from T_O=T_A+2mK+m²T. If z is below its lower-t row, subtract V_O: the result is exactly w=u−v. This adds T_O to t_O, leaves s_O unchanged, and lands within the parity t interval, whose width is at least T_O−1. Hence either z∈E_O or w=u−v∈E_O; no primary fold occurs.

## Folded prices

On the latter branch use F_O(z)=F_O(u−v)+t_O(z)+eta_O. Exact deck expansion gives its two polygon offers, relative to F_Z(z), as

 I=P(u−v)−c_A,
 II=P(u−v)+P(u−2v)−2c_A+2m−D(u−2v).

Here P,D,c_A are exactly those of E1_TRANSVERSE_FOLD_PRICE_AUDIT.md. Its uniform harmonic-rim argument gives each P≥c_A−1, and its complete physical slip/sign argument gives D(u−2v)≤2. Consequently I≥−1 and II≥2m−4≥0. This pays every folded endpoint, not just the native subset.

## Nonfolded prices: precise remaining input

When z∈E_O, direct substitution gives

 F_O(z)−F_Z(z)=min(0,H(u)−2),
 H(u)=h(u)−F_Z(u).

Thus the necessary and sufficient bound for this second arm is H(u)≥1 on the nonfolded endpoint guard. Saved1's established whole-E H≥1 already pays this branch. Saved3's whole-E H≥0 alone does not.

The guard entails B(t_Z(u)+K)≥s_Z(u)+T_Z*g+2, with g=1 on even sites and g=n_O on odd sites. The right side is positive by the E_Z lower-s rows and m≥2. Hence t_Z(u)≥1−K. It is legitimate to apply an independently established H≥1 theorem on that physical range, if available; this note does not replace such a theorem with the weaker near-bottom t≥1−D result.

There is no inference here that SHORT G1 alone gives this new pointwise bound. SHORT G1 states a minimum identity at its licensed roots; the endpoint here is a different physical argument. Actual LONG source/phase/scalar binding remains a separate chronological input.
