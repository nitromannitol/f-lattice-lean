# W1 G2: uniform odd nesting, donor jets and the second offer

## Hypotheses and notation
A=(d,n) is proper odd, Z=(e,r) is proper even, det(A,Z)=dr-ne=-1. Thus n>=1,d-n>=1,r>=1,e-r>=2. Put V_X=(n_X-d_X,n_X+d_X), a_X=(n_X,-d_X), T_X=d_X²+2d_X n_X-n_X², L_X=d_X+n_X, c_X=(T_X+L_X)/2, eta_X=(T_X-L_X)/2. Write K=(d+n)e+(d-n)r and T=T_Z. All polygon statements concern the genuine closed parity polygons E, not arbitrary native supersets. Value statements assume the earlier authenticated p-donor equality and actual polygon realization for the intermediate standards used; they cannot prove those same premises circularly.

## 1. Uniform near and far nesting
For the odd A polygon, put t=a_A·u, s=(d+n)u_x+(d-n)u_y. Its even row is t∈[1-T_A,L_A-1], s∈[0,2T_A+2n]; its odd row is t∈[n-T_A,d], s∈[2-d+n,2T_A+L_A-2]. For B=A+Z,

 T_A t_B=(T_A+K)t-s,
 T_A s_B=(T_A+K)s-2t.

Script check_W1_G2_nesting.py checks all four target margins at all four source rectangle corners for each parity. For each multiplied margin q it proves q+T_A>0, either directly by positive-cone coefficients or after the exact determinant substitution (d-n)r-n(e-r)=-1 and multiplication by positive n. The positive-cone variables are n=n0+1,d-n=c0+1,r=r0+1,e-r=f0+2. All32 checks pass; exact coefficients and producer hash are in W1_G2_NESTING_COEFFICIENTS.json.

Convexity extends the strict margin bound to the entire source rectangle. At a genuine lattice point the unmultiplied target margin is an integer >−1, hence nonnegative. This proves E_A⊂E_(A+Z), without asserting containment of the rational rectangles.

The genuine odd reflection is R_X=2X+V_X+(1,-1), with R_X−E_X=E_X. Reflecting the near inclusion gives

 E_A+2Z+V_Z ⊂ E_(A+Z).

The implication is reversible by the same two reflections. Apply it repeatedly, because det(A+iZ,Z)=-1: E_A+i(2Z+V_Z)⊂E_(A+iZ) for every i>=0.

## 2. Exact p-donor gauges
The established W1 near donor has zero shift and zero price: F_(B+Z)(u)=F_B(u) on E_B. Reflect it using the genuine old and new reflection laws. The far donor at h=2Z+V_Z has

 F_(B+Z)(u+h)=F_B(u)+a_Z·(u+h)+eta_(B+Z)−eta_B+a_B·h.

Here a_Z·h=−T, a_B·h=2−K_B and eta_(B+Z)−eta_B=(T+2K_B−L_Z)/2. Therefore the exact step is

 F_(B+Z)(u+h)=F_B(u)+a_Z·u−c_Z+2.

The constant +2 is essential and uses det(B,Z)=-1. The uniform nesting licenses iteration; for C=A+kZ,

 F_C(u+kh)=F_A(u)+k a_Z·u−k c_Z+2k−T k(k−1)/2.

No evaluation of a raw minimum outside its certified polygon is used.

## 3. Literal RIGHT layout and second current Q offer
The literal Julia get_odd_l_offsets W1/nonflip branch gives K1=V_Z, A1=a_Z, K2=V_Z+Z−2A, A2=a_Z, because genuine primary slopes vanish. The current RIGHT outer origin is2C, as in the independently established W1 prefix binding. After k G1 steps and K2, the G2 origin is

 2C+kV_Z+K2=(2k+1)Z+(k+1)V_Z,

and its slope is(k+1)a_Z. Proper ancestors do not trigger the all3 endpoint-only G2 correction in get_l_correction.jl. Thus y=u+(2k+1)Z+(k+1)V_Z is the genuine proper RIGHT G2 location.

The current Q's second offer, in the same gauge as the checked W1 eight-offer table, is

 I2(y)=F_C(y−2C−V_Z−Z)+a_Z·(y−2C)+eta_Z.

Its F_C argument is u−2A+kV_Z=u+kh−2C. Since2C is the genuine zero-character odd primary, the preceding licensed far donor evaluates it exactly. Substitution and eta_Z+c_Z=T give

 I2(y)=F_A(u)+(k+1)a_Z·u−(k+1)c_Z−T k(k+1)/2+2(k+1).

Equivalently in global y coordinates,

 I2(y)=F_A(u)+(k+1)a_Z·y+(k+1)eta_Z+T k(k+1)/2+2(k+1).

Thus the required G2 source price, if whole-value recognition is intended, has the last displayed exact global scalar. This calculation determines the second offer; it does not alone show that actual chronological min-touch chooses that scalar, that the first Q offer dominates it, or that a later helper never clips it. Those remain separate gates. No current corrected recurrence is asserted.
