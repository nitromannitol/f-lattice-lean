import sympy as s,json
from pathlib import Path
d,n,e,r,k=s.symbols('d n e r k');D=2*d+e;N=2*n+r;L=D+N;ca=d-n;c=D-N;LA=d+n;TA=d*d+2*d*n-n*n;T=D*D+2*D*N-N*N;K=(d+n)*D+(d-n)*N;TC=TA+2*k*K+k*k*T;DC=d+k*D;NC=n+k*N;LC=DC+NC;cC=DC-NC
G=s.groebner([d*r-n*e-1],d,n,e,r,k,domain=s.QQ)
u,v,w,h,j=s.symbols('u v w h j',nonnegative=True);sub={n:u+1,d:u+v+2,r:w+1,e:w+h+3,k:j+1};rows=[]
for par in [0,1]:
 tlo,thi,slo,shi=(n-TA,d,2-ca,2*TA+LA-2)if par else(1-TA,LA-1,0,2*TA+2*n)
 for ti,tt in enumerate([tlo,thi]):
  for si,ss in enumerate([slo,shi]):
   tz=K*tt+ss;sz=K*ss+2*tt
   zlo,zhi,zsl,zsh=(N-T,D,2-c,T+L-2)if par else(2-T,L-2,0,T+2*N)
   tc=(TA+k*K)*tt+k*ss+TA*(TA+(k-1)*K-k*T+1)
   sc=(TA+k*K)*ss+2*k*tt+TA*(2*TC-K-k*T+2*k+2)
   clo,chi,csl,csh=(NC-TC,DC,2-cC,2*TC+LC-2)if par else(1-TC,LC-1,0,2*TC+2*NC)
   groups={'birth_include':[tz-2*TA-TA*zlo,TA*zhi-tz+2*TA,sz+TA*(T-2*K)-TA*zsl,TA*zsh-sz-TA*(T-2*K)],'alias':[tc-TA*clo,TA*chi-tc,sc-TA*csl,TA*csh-sc],'u_s':[sz-TA*zsl,TA*zsh-sz],'central_D':[tz+TA*(K+2)-TA*(3-D-K),TA*(N+2*D-1+K)-tz-TA*(K+2)]}
   for group,qs in groups.items():
    for f,q in enumerate(qs):
     original_q=q
     # determinant identities simplify exactly the potentially tight upper t and s facets
     if group=='birth_include' and f==1 and ti==1:q=(2*TA-ca-ss)if par else(2*n+K-ss)
     if group=='birth_include' and f==3 and si==1:q=2*(n+K-TA-tt)if par else 2*(LA-tt)
     if group=='u_s'and f==0 and si==0:q=2*K-2*d+2*tt-2*TA if par else 2*tt
     assert G.reduce(s.expand(original_q-q))[1]==0
     pad=2*TA if group=='u_s'and f==0 and not par else TA
     p=s.Poly(s.expand((q+pad).subs(sub)),u,v,w,h,j)
     ok=p.TC()>0 and all(x>=0 for x in p.coeffs())
     rows.append({'group':group,'par':par,'ti':ti,'si':si,'facet':f,'ok':bool(ok),'constant':str(p.TC()),'negative_terms':[(str(m),str(c))for m,c in p.terms()if c<0]})
print('PASS',sum(x['ok']for x in rows),'/',len(rows));print([x for x in rows if not x['ok']][:15])
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2))
