# The full G1 prefix for both W0 corrected siblings

**Theorem (conditional constructor comparison).** For each truly proper W0 saved1/3 birth, every k≥1, every stationary G1 index and every point of the entire earlier standard Z polygon, the SHORT even-standard and LONG odd-alternate raw comparators each give exactly the incoming G1 height in its correct affine chart. This includes both LEFT and RIGHT. This is a genuine family-wide prefix price and a conditional chronological calibration, not proof of the original all-word recurrence theorem.

Let Z=2a+R, A=a (saved3) or Z−a (saved1), det(A,Z)=1, C=A+kZ, Q=2C+Z, O=C+Z. Put F=F_Z. The right G1 origins coincide for the two siblings: at every u∈E_Z and 1≤j≤k each target equals F(u+jV_Z). The left origins are 2C+2V_C−jV_Z for SHORT and 2C+2V_C+Z−jV_Z for LONG: the extra Z and the different reflection constant are necessary. The proof uses authentic earlier standard deck/strip and two-offer facts, but NOT the recurrence or prior native identification of the current child. Restore, actual upper-right binding, preservation of true sites, and nonempty successive overlaps are additional hypotheses for the literal implementation call.

The single mechanism is that one raw offer gives the old Z field exactly on a whole stationary window. The competing offer need not equal it, only stay above it. There are at most two independent deck folds to put that competitor in its genuine earlier polygon. On the only exceptional common boundary, the physical zero strip gives the extra unit that is false in general. For a LONG endpoint the second branch may fall one unit short, which its authentic +1 offer precisely allows. The short and long proofs appear below, followed by what remains. All coefficient proofs range over the entire proper cone, not a cutoff on size or word length.

# One stationary-prefix comparison for the corrected standard

**Conditional all-parameter theorem.** Let the earlier, truly proper birth data be odd a=(d,n), even R=(e,r), Z=2a+R, with n,r≥1, d−n≥1, e−r≥2 and the actual Farey determinant. In either saved3 or saved1 in current phase W0 let A=a or Z−a, respectively, so det(A,Z)=1. Set C=A+kZ, Q=2C+Z, k≥1. The standard SHORT's actual right G1 centers are jV_Z, 1≤j≤k, and its left centers are 2C+2V_C−jV_Z. In the correct candidate frame the analytic raw standard minimum agrees with the complete Z field on every one of these whole polygons, up to its prescribed affine jet. Explicitly, for every physical u∈E_Z,

    M_Q(u+jV_Z)=F_Z(u+jV_Z),     1≤j≤k.

The left statement is its exact Q and Z reflection. This pays both orientations of the stationary protected G1 chain in these two proper W0 records. The six separate literal endpoint/pure birth lineages are listed in ENDPOINT_AND_PURE_BIRTH_LEDGER; a rationally proper selected pair alone is not sufficient. The degree of independence, current assumptions, and what remains follow below.

Use the earlier globally admitted standard fields F=F_Z and F_C, their authentic deck jets, earlier F=M on licensed native polygons E, the established closed-E two-level prices, complete physical slip, harmonic/zero strips and high-transverse sign. W0 saved1 needs intrinsic effective-parent price transfer and the genuine predecessor chain maximum; it is not a birth at A with negative residual. Use true spatial placement or else read the statement as pricing the nominal candidate, not identifying an actual restored array. No current native recurrence or agreement is assumed. Put b_S=(n_S,−d_S), V_S=(n_S−d_S,d_S+n_S), t_S=b_S·x, s_S=(d_S+n_S,d_S−n_S)·x, T_S=−b_S·V_S, c_S=(T_S+d_S+n_S)/2, η_S=T_S−c_S. Set v=V_A, K=−t_Z(v), T=T_Z, B=K+kT.

## A single exact arm, and only one lower bound

For y=u+jV_Z the true two Q offers are F_C(y−Z) and F_C(y−V_Z)+b_Z·y+η_Z. On E_C the genuine earlier stationary identity is

 F_C(w)=min(F(w),h(w)+2k−2),   h(w)=F(w−v−2A)+b_A·w+η_A+2.

For H=h−F and D(x)=F(x)−F(x−2A), P(x)=F(x)−F(x+v)+b_A·x, one has H(u)≥0 on ALL E_Z; saved1 actually gives ≥1. For saved3, put q=u−v−2A. If q is in E_Z the two previous raw offers give H=1−[min(0,ψ+1)−min(0,ψ)]≥0. If q is below the lower s edge, a true longitudinal fold gives P(q)≥c_A and H=P(q)−D(u)−c_A+2≥0. Otherwise an off-polygon q can only be above its t edge, and the physical central range gives D(u)≤1 while P(q)≥c_A−1. For saved1 use its authentic earlier chain maximum and reflection (INDEPENDENT_W0_FULL_E_SHIELDING.md). Saved3's stronger full-E H≥1 is FALSE: actual 113 at (−10,36) gives H=0.

The second query y−V_Z is always in E_C. The exact stationary deck drift is H(u+lV_Z)=H(u)−2l, hence the second offer is F(y)+min(0,H(u)+2k−2j)=F(y). It remains only to show that the first cannot undercut it.

Write r=y−Z. With lower true parity boundaries of E_C, define e=1 if t_C(r) is below its lower edge; f=1 if s_C(r) is below its lower edge. The actual representative and its exact pullback are

 w=r−eV_C+2fC ∈ E_C,        F_C(r)=F_C(w)+e(t_C(r)+η_C).

The geometry, including the full second query, follows from the exact parity rectangles and affine projection of u,j. On multiplying by T, the margins at all rectangle/index endpoints have nonnegative coefficient certificates in the five nonnegative variables n−1,d−n−1,r−1,e_R−r−2,k−1 (here e_R is the denominator of R). Because true margins are integers, q+T>0 suffices for q/T≥0; real rectangle corners need not be lattice points. The earlier strict scripts have been replayed after widening in all_proper_G1/. The determinant identities B²−T T_C=2 etc. are used, not numerical fitting.

1. **No transverse fold, no longitudinal fold.** The relative first-offer price F_C(r)−F(r) is min(0,H(u)+2(k−j)−1). This is zero for j<k. For j=k the two no-fold facet constraints jointly imply t_Z(u)≥1−K (not necessarily 1−d_Z). As t_Z(u−v)≥1, the actual zero strip and then the high-t sign lemma give D(u−v)≤0. The exact identity H(u)=P(u−v)−c_A+2−D(u−v) and the rim bound below prove H(u)≥1 there, including saved3.
2. **Only longitudinal fold.** The two relative prices are D(u+2A)+2j and P(u−v)−c_A+1. The first is nonnegative by the complete physical D interval at t_Z(u)+2 (the whole E_Z upper row plus2 is still in range); the second by the rim bound.
3. **Transverse fold (either longitudinal choice).** It occurs only at j=k. In fact with g=1 at even roots and n_C at odd roots the lower facet yields B[t_Z(u)+K+(k−j)T]<s_Z(u)+T(g−1)+2; the upper E_Z row and twelve all-proper positive polynomial bounds imply j=k and place t_Z(u)+K+2 in the complete earlier D interval. Exact deck expansion gives the two relative prices
   P(u−v)−c_A+1+f[D(u−v+2A)−2(k−j)]
   and P(u−v)+P(u−2v)−2c_A+2+(1−f)[4k−2j−D(u−2v)].
   Both are nonnegative: use j=k, 0≤D(u−v+2A)≤2, and D(u−2v)≤2 (on the complete physical band, and beyond its top by the high-t sign). Four symbolic expansions were independently replayed.

**Rim bound used in all three cases.** P(u−iv)≥c_A−1, i=1,2, even if its argument is not native. Its s coordinate is s_Z(u)+2i. If not above E's upper edge, a V_Z translate places it into E without changing P. Otherwise subtract Z. The s coordinates of both P inputs then lie in [h−1,h+4], h=2N for even physical parity, h=D_Z+N−2 for odd. Both are in the full physical harmonic strip, so the shifted P is c_A and the true primary jet subtracts one. The widened proper conditions give N≥3 and D_Z−N≥4. These verify both rim inequalities without relying on an absent native site.

This proves the stated complete right polygon identity. The exact reflection M_Q(R_Q−x)=M_Q(x)−b_Q·x−η_Q, and the analogous authentic F_Z reflection with R_S=U_S+V_S+(1,−1), price the full opposite G1 polygon with its reflected jet: R_Q−R_Z=2C+2V_C. In particular the reflected value is uniquely determined up to the already specified inherited gauge, not fitted anew per parity or per vertex. The true canonical drift F(u+jV_Z)−F(u)=j(b_Z·u−c_Z)−j(j−1)T/2 is the literal j b_Z slope in the global coordinate. The position/gradient binding also retains the genuine helper restore/upper-right alignment hypothesis.

## Consequence for chronological touching, and what this DOES NOT pay

If the true placed G1 leaves are these restrictions and authentic successive joins meet, they all agree with one global target up to their individual scalar, so the literal max-difference calibration fixes every successive G1 scalar and the growing prefix is exactly the target up to the single scalar of its first leaf. This is a sufficient principle, not a claim that every fixed finite array has a nonempty untruncated contact. The outer initial Z source j=0 is the earlier basic donor comparison, not a positive-layer use of the r2 lemma.

G2 must still be identified on its actual fresh sites with true overlap signs/contacts. A proposed shortcut that would put ALL G2 inside the current far-C donor modulo the Q deck is FALSE at the explicit proper example in G2_NESTING_AND_FAR_DONOR.md. W1 arithmetic needs its own signed physical comparison; neither query is always directly in E_C there. LONG's actual comparator and far ordinary windows also differ. The prior eight-row G3 theorem handles proper restored G3 raw prices, not these other tasks. The ordinary near/far standard conditional prices and the exact literal outer insertion order are in ORDINARY_SOURCE_LEDGER. The present theorem is not the all-word recurrence theorem or a standalone assertion of any newly constructed native array's recurrence.
# W0 LONG G1: closed full-polygon analytic prices and nominal source binding

This supersedes the remaining-value gate in LONG_W0_ENDPOINT_FOLD.md, under its explicit genuine earlier physical inputs. It proves the raw analytic target on both nominal G1 lists. Actual helper restoration/upper-right alignment, retained support, chronological touching constants, and recurrence remain separate constructor premises.

## Complete RIGHT price

Write m=k+1≥2 and O=A+mZ. For every u∈E_Z and 1≤j≤k,

 T(u+jV_Z)=F_Z(u+jV_Z),
 T(y)=min(F_O(y),F_O(y+V_Z)−a_Z·y+c_Z+1).

The first offer equals F_Z(y): r2 support at stationary parameter m and index j+1 puts y∈E_O, and the exact error is min(0,H(u)+2m−2−2j)=0 by whole-E H≥0. For j≤m−2, the same argument applies at y+V_Z, so the second offer equals F_Z(y)+1. At j=m−1 use the endpoint fold of the preceding note. Its folded branch is already ≥F_Z(y+V_Z)−1.

In the nonfolded branch the endpoint guard gives t_Z(u)≥1−K. The exact identity

 H(u)=P(u−v)−c_A+2−D(u−v)

and t_Z(u−v)=t_Z(u)+K≥1 finish the proof. Indeed the full physical zero strip gives D=0 when 1≤t≤N+2D−1, since the two arguments have grades t and t−2; the high-t sign extension gives D≤0 above this interval. The established harmonic-rim estimate gives P(u−v)≥c_A−1. Therefore H(u)≥1, including saved3. Its endpoint error min(0,H−2) is ≥−1 as required.

This is a direct pointwise physical calculation, not an inference of a new endpoint from the SHORT minimum theorem. All unperiodized O formulas are used solely at proven E_O points.

## All-proper geometry extension

The new upper-s endpoint certificate also passes with n≥1,d−n≥1,r≥1,e−r≥2,m≥2, in both saved choices and both parities: see check_long_w0_endpoint_geometry_all_proper.py and its receipt. The same broader cone gives D_Z≥7,L_Z≥10, so all harmonic-rim inequalities used above remain valid. This extension uses the separately available all-proper r2 inclusion in all_proper_G1; it does not include literal endpoint parents or pure words. Earlier field hypotheses must likewise be available on the broader cone.

## Raw reflection and nominal LEFT source positions

Let δ=(1,−1), C=O−Z, Q=2C+Z. Define

 R_long=2O+2V_O−V_Z+δ=R_Q+Z.

Use only genuine O primary 2O, its secondary V_O jet, and its centered δ reflection. The two offers swap under reflection, with exact common affine term

 T(R_long−y)=T(y)−a_Q·y−eta_Q−1.

In direct O,Z notation the scalar is 2c_O−3T_O+2M(O,Z)−c_Z−1; expansion of Q=2O−Z reduces it to −eta_Q−1. The extra −1 is essential. Thus this is NOT the standard Q reflection law.

The genuine parent polygon satisfies R_Z−E_Z=E_Z. Consequently reflection sends the RIGHT window E_Z+jV_Z to

 E_Z+o_j,  o_j=2C+2V_C+Z−jV_Z,  1≤j≤k.

These are the nominal LONG LEFT G1 windows. Literal original_port_offsets.py gives odd-alternate outer Gl slot3=2Z+V_C and Gr slot4=V_Z. For the stored helper before the next digit2, its current odd parent is C−Z. Literal get_l_correct's flipped initial getOddTileFull slot3 equals 2(C−Z)+V_(C−Z)+Z and each G1 step is −V_Z; the unflipped initial is zero and each step +V_Z. Adding the outer positions gives exactly the two lists above, with k windows each. LONG changes only the G3 loop count, not this G1 list.

The slopes match independently: RIGHT j-th source has slope j a_Z. LEFT has slope 2a_C−j a_Z, as obtained both from the swapped reflection and the literal inner/outer affine offsets. If g_j=j eta_Z+j(j−1)T_Z/2, then the RIGHT price in global y is F_Z(y−jV_Z)+j a_Z·y+g_j. The reflected LEFT price in global x is

 F_Z(x−o_j)+(2a_C−j a_Z)·x
 + (j a_Z−a_Q)·R_long + a_Z·o_j − eta_Z + g_j − eta_Q − 1.

These constants are candidate analytic prices, not asserted original merge constants without actual overlap calibration. Any additional actual upper-right alignment displacement must already have been identified with these nominal frames; the literal slot calculation alone does not prove that alignment.

## G2 and outer chronology, not hidden in the prefix result

A reusable auxiliary result on the other primitive prefix leaf is now available. For every proper odd B and even Z with det(B,Z)=1, E_B+V_Z⊂E_(B+Z) as sets of actual integer sites. The two reflected p-donor prices at these sites have identical relative slope and constant:

 F_(B+Z)(u+V_Z)−F_Z(u+V_Z)=F_B(u)−F_Z(u).

There are 32 integer facet identities/checks, including four that need the determinant; the stronger fractional-vertex containment is not used. Iterating gives the genuine value of the SECOND standard Q offer throughout its right G2 polygon E_A+(k+1)V_Z, with exact accumulated jet. This does not prove the competing first offer stays above it. It cannot simply be put into the current far-C donor by a Q period: see the explicit proper counterexample in G2_NESTING_AND_FAR_DONOR. The G2 chain lemma and its raw-licensed earlier assumptions are in ODD_REFLECTED_DONOR_NESTING.md.

For each child with these inputs, G1 internal touching is automatic only after actual placements and successive overlaps are authenticated: subtracting an incoming leaf from an equal global target has a constant difference throughout their overlap, hence the prescribed max operation fixes that exact scalar. The eight proper G3 comparisons from the preceding atlas are distinct. The complete G2, other phase/orientation, literal endpoint-born primitives and their special shifts, genuine restore/UR, actual support/contacts/outer ordinary-source inequalities and fixed-padding issues are NOT certified by this G1 calculation. See ORDINARY_SOURCE_LEDGER and ENDPOINT_AND_PURE_BIRTH_LEDGER for precise lineage.

**Audit scope.** Independent symbolic calculations checked all transverse-fold offers, sharp H≥0 versus false H≥1, the folded LONG endpoint, and the integer polygon arithmetic; calculations are in the ZIP with notebook-free scripts and file hashes. This is a semantic and exact symbolic audit conditional on the cited inductive inputs, not a formal verification of the complete manuscript or an all-input implementation replay.
