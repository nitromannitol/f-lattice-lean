"""Independent symbolic cancellation of both actual e=1 offers; no field interpolation."""
import sympy as S,json
from pathlib import Path
T,TA,K,L,LA,k,j,t,a,F0,F1,F2,D1,D2=S.symbols('T TA K L LA k j t a F0 F1 F2 D1 D2')
cZ=(T+L)/2;cA=(TA+LA)/2;etaA=(TA-LA)/2
TC=TA+2*k*K+k*k*T;etaC=(TC-LA-k*L)/2
ell=j-k;fold=a+k*t-j*(K+k*T)+1+etaC
baseline=F0+j*(t-cZ)-j*(j-1)*T/2
P1=F1-F0+a+TA;P2=F2-F1+a+2*TA
rows=[]
for f in [0,1]:
 first=F1+f*D1+ell*(t+K+2*f-cZ)-ell*(ell-1)*T/2+fold-baseline
 expect1=P1-cA+1+f*(D1-2*(k-j))
 aw=a+TA-ell*K-2*f*k+1
 second=F2-(1-f)*D2+ell*(t+2*K+2*f-2-cZ)-ell*(ell-1)*T/2+aw+etaA+2*k+fold-baseline
 expect2=P1+P2-2*cA+2+(1-f)*(4*k-2*j-D2)
 errors=[S.expand(first-expect1),S.expand(second-expect2)]
 assert errors==[0,0],errors
 rows.append({'f':f,'first_residual':str(errors[0]),'second_residual':str(errors[1])})
Path(__file__).with_name('E1_ALGEBRA.json').write_text(json.dumps(rows,indent=2)+'\n')
print(rows)
