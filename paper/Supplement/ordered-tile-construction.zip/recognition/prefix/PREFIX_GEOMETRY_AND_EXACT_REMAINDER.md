# W0 RIGHT standard-prefix geometry and exact remaining gates

Scope: actual W0, saved3 or saved1, strict proper birth a=(d,n), R=(e,r), n>=2,d-n>=3,r>=1,e-r>=2. Let Z=2a+R=(D,N). For saved3 A=a and det(a,R)=1; for saved1 A=a+R and det(a,R)=-1. In both cases det(A,Z)=1. Put C=A+kZ, k>=1, T=T_Z, K=M(A,Z), B=K+kT. All results below concern the physical canonical polygons, not an extrapolation of native finite examples.

## Uniform complete second-arm support
For EVERY u in E_Z and 1<=j<=k,

    r2=u+(j-1)V_Z belongs to E_C.

The actual even-type E_Z rows are:
 even: t in[2-T,D+N-2], s in[0,T+2N];
 odd:  t in[N-T,D], s in[2-D+N,T+D+N-2].
The actual odd-type E_C rows (a,b,c,d below) are:
 even: [1-T_C,L_C-1] x [0,2T_C+2n_C];
 odd: [n_C-T_C,d_C] x [2-c_C,2T_C+L_C-2].
Here t=t_Z(u), s=s_Z(u). V_Z and Z both preserve physical parity. Direct inversion and det(A,Z)=1 give

    T t_C(r2)=B t-s-(j-1)BT,
    T s_C(r2)=B s-2t+2(j-1)T.

For fixed parameters the four target margins are affine in t,s,j. Thus the source rectangle's four vertices and j=1,k suffice. `check_r2.py 1` and `check_r2.py 3` check all64 facets in each case, using exact polynomial nonnegativity in n-2,d-n-3,r-1,e-r-2,k-1. They prove multiplied margin q satisfies q+T>0. Actual margins q/T are integers, hence nonnegative. This is valid even when a relaxed rectangle vertex is not a physical lattice point.

Three reductions use the genuine determinant, not an unconstrained polynomial fit:

    KD=d_A T-(D-N),
    K(D+N)=L_A T+2N,
    K(D-N)=c_A T-2D.

For odd upper-t at t=D the margin is D-N+s+(j-1)BT. For even upper-t at t=D+N-2 it is (2k-1)T+2K-2N+s+(j-1)BT. For odd lower-s at s=2-D+N it is 2(k-1)T+2K+2D-2t+2(j-1)T. These expressions are exact on the determinant locus.

## First-arm support: exactly two remaining lower facets
Let y=u+jV_Z, r1=y-Z. Then

    T t_C(r1)=Bt-s-jBT+T,
    T s_C(r1)=Bs-2t+2jT-BT.

Consequently t_C(r1)=t_C(r2)-B+1 and s_C(r1)=s_C(r2)-B+2. B>2. Since r2 is already in E_C, both upper facets for r1 are automatic. The first arm is in E_C if and only if BOTH

    Bt-s >= aT+(jB-1)T,
    Bs-2t >= cT+(B-2j)T.

Thus for 1<=j<=k the entire support gap is precisely the union of a lower-transverse strip and a lower-longitudinal strip. It is not legitimate to assert both arms belong to E_C throughout E_Z. At j=0 this theorem does not license r2: that ordinary initial Z carrier remains a separate gate.

## Exact price gate, conditional on the genuine four-offer identity
The supplied source identity has error

    min(0, h(u)-F_Z(u)+2k-1-2j),
    h(u)=F_Z(u-V_A-2A)+a_A.u+eta_A+2.

This h is NOT the harmonic h0. No harmonic envelope can replace it. Conditional on the earlier true price bound h-F_Z>=-1 on E_Z, every j<=k-1 is paid wherever both guards hold. At j=k one needs the sharper h-F_Z>=1 on the common-guard region. Outside those two facets another actual source alias or a finite physical comparison proof is still needed. The geometry certificate alone does not establish the requested global equality or recurrence.

## Finite diagnostic, not a universal proof
`test_whole_e.py 11 3 1` evaluates original chronological fields for word1132, Z=(17,7), A=(5,2). All519 E_Z sites at both j=0,1 satisfy the proposed equality and actual F_Q equality. Sixteen of the1038 tested occurrences lie outside the literal current native crop, so this genuinely tested the stronger polygon statement. The direct guard census (`test_guard_geometry.py`) is:
 j=0: both guards2; first only23; second only16; neither478.
 j=1: both guards9; second only510.
This gives no counterexample, but shows that direct simultaneous native guards alone cover only a small part of the requested set. The test is independent of the unbounded coefficient proof.
