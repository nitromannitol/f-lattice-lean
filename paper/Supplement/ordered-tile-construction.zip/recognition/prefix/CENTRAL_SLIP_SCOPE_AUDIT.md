# Urgent independent central-slip scope audit

## Exact distinction
Write the genuine creator as a, Z=2a+R, T=T_Z, K_b=M(a,Z). For saved3, A=a and K_eff=K_b. For saved1, A=Z-a and K_eff=T-K_b; the creator phase is the opposite of the consumer phase. The effective signed displacement is the SAME displacement as the genuine creator signed displacement modulo the zero Z period: 2 eps_cons A = -2 eps_cons a mod Z = 2 eps_birth a mod Z. Thus the effective D is exactly the genuine birth D, at the SAME physical point. There is no shift of its transverse argument. Its known absolute-value interval cannot consequently be widened by replacing K_b with K_eff.

No inspected producer grants a central |D|<=1 interval for an arbitrary adjacent parent chosen by a later consumer. Strong-price STRONG_PRICE_AND_ALTERNATE_STEP §5 binds the actual creator and proves the complete physical range 0<=D<=2 on [3-D_Z-T,N_Z+2D_Z-1]. It does not assert the consumer-dependent larger central interval. Changing the canonical policy sign can supply the opposite signed gap, with its translated/reflected argument; it does not change the values of an identical gap at the same point. Any alternative true analytic span must be separately stated with its argument transformation and endpoints. Recurrence, deck equivalence and an effective two-level P-price identity alone do not license the substitution.

## Directly affected proof uses
The following reports require lower bounds at effective shifted queries and currently prove only inclusion in the claimed effective central interval, not the necessary field inequalities:

* BOTH_SAVED_G2_TRANSVERSE_FIRST_ARM.md §§3-4: d_v=D(u-v)>=-1 and D(u-v+2A)>=-1. Their grades are t_Z(u)+K_eff and +K_eff+2.
* LONG_W0_G2_CLOSED.md: the same lower bounds feed I-(H-3)=1+d_v+f(d_plus+2), and the selected f1 rim gives II-(H-3)=1+d_v. The rim identity does not repair a possible d_v=-2.
* W1_G2_SHORT_LONG_GEOMETRY.md and INDEPENDENT_W1_G2_VALUE_AUDIT.md: d_b and d_v query grades t_Z(u)+K_eff+2 and +K_eff+4. The value proof explicitly needs both >=-1; for f1 its first difference is 1+d_v. Geometry alone does not supply it.
* ordinary_middle_m1/THEOREM.md consumes the same G2 bounds and inherits this issue.
* UNIVERSAL_G2_FIRST_ARM_GEOMETRY.md and all three coefficient receipts remain valid as GEOMETRY results. Their conditional implication to a field bound is not an authenticated saved1 producer.

The corresponding saved3 uses do not have this particular K substitution defect, but still require the separately authenticated genuine-creator central theorem. These reports cannot be called unconditional merely from their coefficient receipts. The all-proper corrected-constructor synthesis inherits the unresolved saved1 G2 bound unless replaced by another guarded argument.

## Uses not invalidated by this substitution

1. E1_TRANSVERSE_FOLD_PRICE_AUDIT.md proves e=1 forces its query into the FULL physical band [3-D_Z-T,N_Z+2D_Z-1]. Its other bound is D<=2 from this band followed by the high-transverse D<=0 extension. No K_eff-dependent absolute bound is needed.
2. LONG_W1_ENDPOINT_AND_REFLECTION.md uses the full band for d_b>=0 under e=1 and the zero strip/high-sign extension for d_v<=0 under e=0. Its endpoints are guarded; it is not the unguarded G2 lower-bound use. The older W1_COMPLETE_RIGHT_PREFIX_VALUE_PROOF banner overstates its input list relative to this final proof.
3. Saved1 whole-E G1 shielding, and saved1 UNC standard near-q shielding, use genuine BIRTH chain maxima via ODD_TWO_Q_DONOR_SHIELDING and INDEPENDENT_W0_FULL_E_SHIELDING, with the precise intrinsic P/Phi substitution. Their argument is not a replacement of K_b by K_eff. Saved3 shielding's central use is still K_b.
4. S1/INTRINSIC_PRICE.md uses K=M(a,Z) explicitly. Its saved1 G3 lower caps use true birth P folding and harmonic rims, and its high-fold attainment uses the full physical D band. The saved3 final seam cap INDEPENDENT_FINAL_ENDPOINT_WRAP_AUDIT and W1/INTRINSIC_CORRELATION_AUDIT likewise use wrapped full physical bands. Consequently FINAL_PRICE_ATLAS and UNC_ODD_STAR_TWO_FRINGE_AUDIT are not automatically refuted by the later saved1 G2 interval error; their actual cap proofs must be retained rather than the obsolete broad central-bound introductions.
5. Basic donor nesting and its exact price telescoping have no central-slip input. Neither source slope/covariance nor domain/frame induction is affected.

## One-sided inequalities need a real repair
A full [0,2] band proves >=-1 only when the query lies in it. Above that band's upper end, the available high-t sign is D<=0, the WRONG direction for d_v,d_b>=-1. Translating back by V gives a range [-2,0], which still allows the offending -2. Thus saying only that the proof needs a lower bound, or invoking high-sign extension, does not salvage the G2 step. A sufficient repair is a guarded true-creator central upper-end bound for every required query, or a direct commutator inequality with the actual price/flag correlated to D=-2. No such repair is proved in this audit.

## Verification scope
This is a source-level logical audit, not a new numerical counterexample or all-word failure claim. Exact linear identities above follow from A=Z-a, M(Z,Z)=T and the true zero primary character. The citations are current local proof reports, not paper theorem labels. Hashes bind this audit and inspected producer texts. No historical raw or coefficient result was changed.
