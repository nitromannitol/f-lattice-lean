# W0 RIGHT G2: exact transport and a far-donor obstruction

## Exact scalar transport, conditional only on the named polygon license
Let B odd, Z even, det(B,Z)=1. Write b_X=(n_X,-d_X), c_X=(T_X+L_X)/2 and eta_X=(T_X-L_X)/2. The reflected odd p-donor theorem gives, on E_B,
 F_(B+Z)(u+V_Z)=F_B(u)+b_Z.(u+V_Z)+eta_(B+Z)-eta_B+b_B.V_Z.
Since b_Z.V_Z=-T_Z, b_B.V_Z=-M(B,Z), and eta_(B+Z)-eta_B=(T_Z+2M(B,Z)-L_Z)/2, this is exactly
 F_(B+Z)(u+V_Z)=F_B(u)+b_Z.u-c_Z.
Subtract the genuine Z deck equation at u. Thus the proposed relative identity is correct with no residual scalar. It applies when the current physical field agrees with the donor comparator on the licensed donor, not merely from an unguarded raw minimum.

To iterate at u in E_A, sufficient geometry is E_A+iV_Z subset E_(A+iZ), for each i. The stronger one-step whole nesting E_B+V_Z subset E_(B+Z) would supply this. I have NOT completed its integer proof. Exact conjugacy gives the odd E parity rows:
 even: t in[1-T,L-1], s in[0,2T+2n];
 odd: t in[n-T,d], s in[2-(d-n),2T+L-2].
A rational vertex check is not an adequate proof method without lattice rounding. For B=(2,1),Z=(5,3), the odd rational vertex t=-6,s=1 maps below the next lower t facet by2/7. It is not an integer lattice point, hence not a nesting counterexample. No rational-vertex containment is claimed.

## Whole G2 is NOT contained in the far C donor even modulo current Q deck
This stronger shortcut has an exact proper counterexample. Set A=(5,2), R=(7,3), Z=2A+R=(17,7), k=1, C=A+Z=(22,9), Q=2C+Z=(61,25). The actual standard A origin u=0 is a G2 site. Its placed location is y=(k+1)V_Z. The far C donor origin is V_C+V_Z, so its proposed C-coordinate is w=y-(V_C+V_Z)=-V_A=(3,-7).
The Q deck is U_Q=(61,25), V_Q=(-36,86). All preserve physical parity. At w+jU_Q+hV_Q, C-coordinates are
 t=181-j-2216h, s=2+2216j+2h.
The EVEN E_C bounds are -798<=t<=30 and 0<=s<=1616. Solve for
 j=[2216(s-2)-2(181-t)]/(2216^2+2).
These bounds force -1<j<1, hence j=0. Then the t interval requires 151/2216<=h<=979/2216, impossible for integer h. Thus NO Q deck translate lands in E_C, and a fortiori none lands in a genuine far C crop contained there. All parameters are proper and A is already strictly lower-half. This is not an endpoint artifact or a finite search inference.

Consequently exact second-offer evaluation must use intermediate reflected donors/nesting or another positive atlas; it cannot be replaced by a single whole-current-G2 far-C ownership claim. This obstruction does not refute the proposed transported-height identity or whole polygon nesting.

Source: strip_geometry/INDEPENDENT_ODD_P_DONOR_CONJUGACY.md; genuine odd polygon obtained there by the exact swapped-even affine quarter-turn. No current recurrence or unproved present source equality was used to price a point outside its donor.
