from pathlib import Path
import sys
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
for word,last in [('113','3'),('13','1')]:
 m,al=alg.get_odometers(word);_,zf,af,rf=getFracs(word);a=(af.denominator,af.numerator);Z=(zf.denominator,zf.numerator);A=a if last=='3'else tuple(x-y for x,y in zip(Z,a));d,n=A;D,N=Z;T=D*D+2*D*N-N*N;L=D+N;c=D-N;VA=(n-d,n+d);eta=(d*d+2*d*n-n*n-d-n)//2
 F=review.Field(N,D,alg.export_tile(m[1])).g;cnt=Counter();ex={}
 for x in range(-2*D,3*D+1):
  for y in range(-D,3*D+1):
   t=N*x-D*y;s=L*x+c*y
   lo,hi,sl,sh=(N-T,D,2-c,T+L-2)if(x+y)%2 else(2-T,L-2,0,T+2*N)
   if lo<=t<=hi and sl<=s<=sh:
    H=F((x-VA[0]-2*d,y-VA[1]-2*n))+n*x-d*y+eta+2-F((x,y));cnt[H]+=1;ex.setdefault(H,(x,y))
 print(word,last,A,Z,sorted(cnt.items()),sorted(ex.items())[:5],flush=True)
