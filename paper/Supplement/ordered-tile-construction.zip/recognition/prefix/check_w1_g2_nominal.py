from pathlib import Path
f=Path('recovery_20261101_0745/reconstruct_direct_auxiliary_enclosure.py').read_text();ns={'__file__':str(Path('recovery_20261101_0745/reconstruct_direct_auxiliary_enclosure.py').resolve())};exec(f[:f.index('def group(')],ns)
add,mul,prime,raw=[ns[n] for n in ['add','mul','prime','raw_piece_ops']];A,B,C,D,K=[ns[n] for n in ['A','B','C','D','KLEN']];p=(A,B);q=(C,D);cp=add(p,mul(K+1,q));vc=prime(cp);vq=prime(q)
rows=[]
for long in [0,1]:
 for flip in [False,True]:
  ops=raw(p,q,1,3,True,long,flip)
  outer=add(vc,mul(-long,q))if flip else add(q,vq)
  actual=add(outer,ops[2][3])
  expected=add(vc,mul(-long,q))if flip else add(mul(2*K+3,q),mul(K+2,vq))
  assert actual==expected,(long,flip,actual,expected)
  rows.append([long,flip,'both coordinates exact'])
print(rows)
