# Adversarial final native-assembly review

## Verdict
No new concrete source-height or root-dispatch counterexample was found. Proper and endpoint source-price results can be assembled only with the exact supersessions and CURRENT target guard below. This is a logical/frame review, not a fresh replay of the historical all-word domain induction. It does not certify fixed-padding code.

## 1. Target identification is distinct from raw source pricing
SHORT: the actual standard child support is contained in the historical H hull, and ALL_SECTOR_ACTUAL_SUPPORT_SCOPE_AUDIT proves H subset of the exact current E used by canonical sewing. Thus on every actual output site the raw comparator equals the independently sewn current F. No source point outside the actual output support must be promoted to a native point.

LONG: raw two-offer comparisons are not automatically equal to the rounded global alternate. For current EVEN target, strong_bulk/STRONG_PRICE_AND_ALTERNATE_STEP §5 proves its actual own-creation R2/native and incoming halo have 0<=D<=2 on the full scalar band [3-d-T,n+2d-1]; hence min(F,Fmate+1) equals the global midpoint there. This concerns the CURRENT child, not the old G3 primitive. The actual all-word R2 containment is a geometric producer independent of current height recognition.

For current ODD LONG, use the genuine current harmonic/affine map and its OWN tau/beta, the global RAW_LONG_COMPARATOR_DUAL identity, and the current odd-R2 inverse inclusion into the dual even R2. The latter is the one-way inclusion proved in S1/DUAL_TRANSFER_SCOPE and FINAL_ALL_DISPATCH_AUDIT; no reverse equality is required. The final assembly must explicitly instantiate these at the CURRENT child in its authentic output/restored chart. A source's old R2 and its source tau do not pay this guard. The inspected FINAL_ALL_DISPATCH_AUDIT §5 deliberately retains this target condition; no additional blanket target equality is supplied by its raw theorem alone. This is the narrow binding requiring an explicit final substitution, not evidence of an actual bad site.

All corrected current children have proper current parents, including the first mixed step from a pure run. A pure-born helper primitive is a different issue. Thus literal initializer corner exceptions concern the incoming G3 price; they do not justify omitting the current nonbase target R2 theorem.

## 2. Actual alignment and chronological scalars
The recovered all-consumed domain induction supplies actual LL/A4/A6/UR and true sequential intersections. These are not again open generic gates. They fix spatial placement, not height offsets. Current source identities and slope/phase audits must be evaluated at exactly those placements; a one-scalar error cannot repair a wrong translation.

For strong proper pieces each incoming source is T+c on its whole native support. Any true nonempty prefix contact forces the unique relative scalar and hence gives the same target on the union. A max-zero helper normalization merely changes its scalar, removed by the outer touch. If a helper is FIRST (notably a phase-dependent corrected odd mask), its scalar becomes the output's common scalar. This causes no binary/recurrence or subsequent merge error, provided the result is stated projectively. Absolute canonical height needs an independent reference-site calibration; do not silently claim it from UR geometry.

The dual cocycle audits prove one scalar across both parities and all components, not independent parity gauges. Thus disconnected source domains do not create a hidden calibration freedom.

Endpoint R0 is ordered, not strong. At two first-G3 contacts incoming is one ABOVE the older G1 owner; all fresh sites take the incoming height, and an explicit zero contact calibrates it. PURE3_ENDPOINT_ORDERED_LONG_EXTENSION and the new pure2_four_site/DUAL_R0_ORDERED_G3_MERGES_CLOSED preserve this order, the root corners and the LONG appended source. The pure2 four-site G2 is a subset of the transformed six-site source; the two omitted sites are disjoint from every G3, so no clipped contact changes. Hence the preceding caution is resolved by a specific support argument, not general duality.

To identify the FINAL helper with T, the remaining outer price argument must retain the older target value at those two clips and incoming equality on fresh sites. The G1 full-carrier target theorem pays the retained clip values; the G3 exposed-price theorem must be invoked at the fresh sites. Raw G3 equality at every overlap is false and must not appear in the assembled statement.

## 3. Exact supersessions needed in the final citation list
ALL_PROPER_CORRECTED_CONSTRUCTOR's older G2 paragraph requiring the competing price >=H-2 is too strong for saved1. Replace that route by saved1_true_birth_correction/PROPER_SAVED1_REPAIR and the audited min-target consumer interface; retain the genuine counterexamples to the old central interval. LONG uses S-1, with asymmetric constituent shifts(-1,-2), including ordinary m=1.

The endpoint matrix has four distinct analytic bases R0,R1,N0,N1. endpoint_completion/PROTECTED_PRICE_BASES, nearone_W1_saved1, reciprocal_direct and actual-six/four-site packets cover different roles; do not substitute the N0 current parent for the N1 complement. G3 literal corners use the exact nominal pure ALT native bijection and actual primitive restoration, not a fictitious proper R2 assumption.

## 4. No hidden empty-root helper dispatch
get_odometers('') installs the literal root quadruple and skips get_corrections. A pure current word uses get_base_quadruple. The first nonpure digit1 uses the UNC branch; corrections are then constructed for the nonempty saved record. A first switch from nonempty pure2/pure3 uses the explicit endpoint helper, including its actual staircase root at the smallest parameter. Therefore the proof does not need a nonexistent corrected empty-ancestor helper. Auxiliary types calculated but never consumed are outside the historical consumed-domain theorem and need not be priced to establish output recognition.

## Remaining scope
The only newly highlighted final binding is CURRENT odd-LONG target chart/R2-to-D substitution, if not already included in the current synthesis. No new generic overlap/UR, scalar, root or pure-corner obstruction was found after the cited repairs. This review still depends on authentic canonical standard-stage production, the fresh endpoint exposed-price results, the exact historical domain/frame induction and the final chronological instantiation. No all-word recurrence claim follows from this review alone.

## Follow-up: other assembly edge checks
The parent is supplying the current odd-LONG guard directly. Apart from that assigned gate, the following possible cycles/omissions were checked and no new defect isolated:
* Same-level O in UNC is standard, not alternate: even standards for the whole level first, then their odd conjugates, then alternate construction/recognition. The even standard at the swapped word uses strictly shorter-word parents. This does not require native ALT recognition at the present level.
* Word1 belongs to BOTH first-one endpoint parameterizations. Use the shared literal R1 d=3 root and its exact native dual; do not feed b=1 into a near-one doubled-ladder encoder whose theorem starts b>=2. This is a dispatcher deduplication, not a missing family.
* Reversing the coherent G1 order in the pure2 dual proof changes at most the initial projective scalar. All G1 finish before G3; their union/common values are unchanged. The explicit G2 zero contact and every G3 zero contact then fix the remaining relative constants.
* Actual UR geometry depends only on the already proved support; a helper max-zero height normalization does not move it. Its additive constant is removed by outer touching or retained as the output's one scalar if first. No max-zero VALUE theorem is needed just for projective recurrence recognition.
* The generic source maps are source-dependent in their local coordinates, but after the checked outer origin/jet substitutions each is the SAME physical target comparator up to one constant. One must cite those substitutions, not merely the primitive conjugacy. The repaired pure2 proof supplies the actual common placed maps explicitly.
* A clipped internal helper can be used as a strong outer source ONLY after combining its retained G1 values and exposed G3 prices into the target on the entire final helper support. This is the ordered assembly argument already recorded, not a claim that every raw G3 leaf is strong.
* The original code comments on disjoint/negative-infinite unused endpoint auxiliaries do not contradict the adopted consumed-domain theorem. Restrict recognition to helpers actually selected by the dispatcher. Arbitrary unused helper or fixed-padding correctness remains outside scope.
No additional unprovided premise was identified by this narrow adversarial follow-up. This is not a replacement for the separate current guard producer or the canonical-stage audit.
