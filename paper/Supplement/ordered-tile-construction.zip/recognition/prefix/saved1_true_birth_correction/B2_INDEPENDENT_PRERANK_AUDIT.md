# Independent B2 producer audit

## Verdict and scope

The B2 interface is paid for every genuinely nonpure even receiver by the actual earlier **complete** standard packets, the full B0/B1 sewn-field interface, and the current W1 constructor conclusion. No further current-rank or current strong-raw inequality is needed. This is a conditional producer audit, not a verification of B0/B1 for all words, nor native recognition. One small formal strengthening of the induction statement should be made explicit: carry the two additional zero levels (Z below), or insert their elementary simultaneous induction before B2. Ordinary strips alone do not imply them.

I reviewed the semigroup proofs, local contact-transfer proof, ancestral H and V producers, physical tip proof, and literal pure zero bases. This is an independent logical/sign/domain audit of those written derivations, not a new implementation or fresh exhaustive numerical verification.

## 1. The three upper comparisons require no new exterior inequality

Write X for the strict lattice interior of the genuine closed polygon E. All physical inputs of X lie in E; an edge from X cannot jump its lattice polygon boundary. Apply recurrent comparison to M=F on E, against each globally binary shifted/affine competitor. It suffices to check the inequalities on the actual inner boundary of X, which is contained in the four boundary arcs of E. It is unnecessary to assume an unproved range on the exterior incoming halo of E.

The exact arc data are:

* P on bottom H is c0 at H0 and c0-1 subsequently; its V drift is zero, so the top H has the same values. On left V it is c0 and on right V it is c0-1, by its U drift -1.
* D+ and D- vanish on bottom H. This follows from the genuine zero strip at both the H query and its two-slip translate, not from the desired D range. On top H they are 2 and -2 by their V characters; U characters are zero.
* The genuine ancestral V cut gives D- in {-2,-1,0} and D+ in {0,1,2} on left V, hence also on right V.

Thus P<=c0, D+<=2 and D-<=0 on that inner boundary. Comparison gives the same bounds throughout X, and the explicit arc data finish E. The older pre-rank note's phrase 'incoming boundary inequalities' should be read using this domain, or replaced by this explicit argument. It need not become a new unproved full-halo hypothesis.

The primitive semigroup/reflection argument then gives P>=c0-1 on E: the parity-preserving shift v=epsilon Vp has s(v)=2, so the reflected query lies in the positive-U semigroup of E. The horizontal semigroup argument gives D+>=0 because D- has V drift -2 and E+sigma lies in the positive-V semigroup; true reflection gives D->=-2. All signs are essential: propagating D+ upper in the positive-V direction would be invalid.

## 2. The boundary producers are strictly earlier

H_SOURCE_ANCESTRAL_CLOSURE and INDEPENDENT_CHAIN_AND_H_TRANSFER_AUDIT identify the current source gap with an earlier actual qsw chain potential plus a **single global scalar**. Its old canonical V trace gives the current H gap >=1 except at the correct tied endpoint, and direct old-strip normalization fixes values 0,1. H_PRICE_VS_PINGPONG_E converts this into the current P(H) trace. The outgoing profile is therefore produced, not borrowed as an incoming same-stage hypothesis.

ANCESTRAL_PSI_V_CUT_PROOF uses earlier primitive P(H), genuine creation/sign data and true reflection to obtain psi-(V_j)=ceil(j/r), then D-(V_j)=-min(psi-,2) at all nonfinal vertices. The final -2 value is separately paid by current zero/V deck; reflection pays D+. The H0 replacements and signs in the authentic old trace do not require a false equality between old H0 and V0.

For endpoint creators, substitute actual complete pure seed packets. A theorem for a proper creator must not be applied directly to 0/1 or 1/1. The actual qsw creation word is strictly shorter than the receiver even when the saved symbol is 1.

## 3. Every required bulk edge is covered

Let c=F. At the lower P level compare with
m(z)=F(z-v)+epsilon ap.z+c0-1.
For D+ use m(z)=F(z+sigma); for D- use m(z)=F(z-sigma)-2. Each m is globally binary, and each is <=c on E by the just-proved ranges.

At a contact black root, binary admission forces both input gaps to vanish and m also to be black. Thus **both retained black inputs**, not a selected one, preserve the lower stratum.

At a contact forced-white root, induct on its actual finite contained unit proof. If its forced input were not a contact, integrality forces the other input to be a contact and makes m black at the root. Propagation around the proof square then creates a finite empty clause for m. This is impossible because m is an even-parity translate of F plus affine, so the current W1 global no-refutation statement transfers to it. Merely an acyclic selected graph would not suffice; W1_CONSTRUCTOR explicitly proves no empty clause for the full unseeded closure.

All squares and their actual input stars used here lie in E by the current contained-W1 conclusion. No full exterior range and no recurrence of the shifted current child are invoked.

Rounding loses no needed case:
D+ = 0,1,2 gives J+ = 0,1,1;
D- = -2,-1,0 gives J- = -1,0,0.
Only the respective minimum-contact strata require the transfer. At the upper rounded value the whole-E range suffices. Thus P and J_eta are nonincreasing on every retained black edge and each actual forced-white edge. Common integer deck drift transports this statement to every physical lift, not just quotient representatives. It does not assert raw D monotonicity at the middle stratum.

## 4. The extra zeros and tip licensing

Carry the additional invariant Z:
G_even(2-d-n)=0;
F_odd(z)=0 when t(z)=1-d-n and z has even parity.
PAIR_INDUCTION derives each from the opposite earlier parent's Z and the genuine two-source identity at a point proved to lie inside E. The W0 near-one odd-parent exception is handled by the genuine pure staircase value -1, not by extending an old h0 strip. BASE_TWO_PIXEL_ZEROS proves all pure runs and both endpoint atoms from actual initializers and true zero-character primary periods; the odd doubled ladder requires its literal +1 diagonal correction.

These Z statements are not among the ordinary strips. To make the synchronization theorem literally closed, append Z to S, or prove Z simultaneously at stage 0 from earlier Z before invoking B2. For each tip only an earlier parent or its earlier actual dual is needed, so this introduces no same-level rank cycle.

TIP_THEOREM uses the correct distinct phase paths. W0 uses Vp+e1 -> Vp+(1,1) -> Vp+e2; its east star pixel requires the earlier even Z. W1 uses Vp -> Vp-e1 -> Vp-e1+e2; its grade uses the earlier odd Z and a translated query inside E. The W1 surrounding star must NOT be replaced by M: the documented word1 counterexample shows that replacement is false. The central-rectangle guard licenses exactly the queries at which F=M is used.

The minus grades are (P,J-)=(c0,0),(c0,0),(c0,-1). The middle is genuinely nonfree by actual H/V spectra. Its rejected-input three-edge return follows from its contained finite unit proof; rounded monotonicity already proved in section 3 forces the desired lower-grade input to be selected. This does not need the later global private-return theorem. Reflection through I-z gives the plus grades with the correct deck cancellation; P on the reflected off-V W1 endpoint is paid directly by h0, not a false P reflection-invariance assertion.

At H0 the actual down input I=Vend-V has P(I)=c0 by the genuine V trace and zero V drift. This explicitly pays the exterior endpoint; a native maximum alone would not.

## Conclusion

No additional B2 inequality was found after the actual full antecedents and Z induction are installed. In particular neither current strong raw-slip monotonicity nor current recurrence is used to produce its own rank. What remains outside this audit is universal authentication of the full B0/B1 inputs and complete signed pure packets, and optional native corrected recognition. The result must not be stated as unconditional all-word recurrence on the strength of this B2 review alone.
