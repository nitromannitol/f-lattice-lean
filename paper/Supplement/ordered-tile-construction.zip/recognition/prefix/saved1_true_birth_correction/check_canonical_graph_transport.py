from pathlib import Path
from math import gcd
import json
G=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies')
O=G/'recognition_ledger/saved3_gate/prefix/saved1_true_birth_correction'
def edges(a,b):
 c=[b*(i+1)//(a+b)-b*i//(a+b) for i in range(1,a+b-1)]
 return [0]+[e for bit in c for e in ([1] if bit else [0,0])]+[0]
def arcs(d,n,mu):
 H=[(1,0)]; V=[(0,0)]
 for e in edges(mu*(d-n)//2,mu*n):H.append((H[-1][0]+1,H[-1][1]+e))
 for e in edges(n,d-n):V.append((V[-1][0]-e,V[-1][1]+1))
 return H,V
def plus(arc,j,z,b):
 if arc=='H':return (0,-1) if j==0 else (0,-b) if j==-1 else (-1,0) if sum(z)%2==0 else (0,-1)
 return (b,0) if j==0 else (-1,0) if j==-1 else (b,0) if sum(z)%2==0 else (0,-b)
def minus(arc,j,z,b):
 # reflection of (+,-b), reversed arc indices
 jj=-1 if j==0 else 0 if j==-1 else 1
 v=plus(arc,jj,z,-b);return (-v[0],-v[1])
def rot(v):return (-v[1],v[0])
count=0
for D in range(2,61):
 for N in range(1,D):
  if gcd(D,N)!=1 or (D+N)%2==0:continue
  H,V=arcs(D,N,2); hp,vp=arcs(D+N,D-N,1); U=(D+N,D-N)
  assert [( -y,x-1)for x,y in H]==vp
  assert [(-y,x-1)for x,y in V]==[(x-U[0],y-U[1])for x,y in hp[::-1]]
  for eps in [-1,1]:
   for name,arc,targetname in [('H',H,'V'),('V',V,'H')]:
    for i,z in enumerate(arc):
     j=0 if i==0 else -1 if i==len(arc)-1 else 1
     tj=j if name=='H' else -1 if j==0 else 0 if j==-1 else 1
     src=plus(name,j,z,1) if eps==1 else minus(name,j,z,1)
     zz=(-z[1],z[0]-1)
     dst=minus(targetname,tj,zz,eps)
     assert rot(src)==dst,(D,N,eps,name,i,z,src,dst)
     count+=1
(O/'CANONICAL_GRAPH_TRANSPORT_RECEIPT.json').write_text(json.dumps({'max_denominator':60,'free_arrow_checks':count,'all_pass':True,'scope':'finite arithmetic regression only; universal proof is separate'},indent=2))
print(count)
