# Narrow standard-stage synchronization recheck

The corrected G2 joint proofs repair a NATIVE RECOGNITION edge, not a producer of canonical standard dynamics. They must not be used to establish the same standard fields that appear in their inequalities. No additional specific circular edge was found by rereading the frozen CHRONOLOGICAL_LEDGER and current ONE_PAGE_ACYCLIC_INDUCTION_DAG, but neither document is an all-history assembled producer theorem.

The minimal synchronization obligations remain:
1. Raw M recurrence consumes strictly earlier clean bands with actual matched source phases and constants. Standard boundary, donor, and strip producers must be instantiated before its sewn F's current rank/strong-price conclusions.
2. The old-source p-donor equality is a real comparison on its licensed polygon, not merely the source slope-conjugacy formula; the chronological ledger explicitly separates these. Actual native contact fixes additive gauge only after those analytic prices are paid.
3. In ordinary UNC m=1 the field O=A+Z is a SAME-STEP canonical standard sibling. Finish its standard-stage E identity, decks and donor theorem independently before evaluating the ALT slots or star. It cannot be admitted by the very alternate-native recognition being proved. The fact that its source parents are older is compatible with this order.
4. The pure2/pure3 initializer packets supersede the frozen seed HOLD, but must furnish the full relevant signed policies, P/D and chain ranges in their actual creator phases, not just recurrence. Literal endpoint-born later helpers remain separate from those initializations.
5. The new saved1 proof must cite true-birth full bands and joint implication, not resurrect the larger effective central interval by citing the old all-proper constructor theorem. Old G2 and m=1 prose requiring D>=-1 remains withdrawn even after the weaker target inequality is repaired.

Current support/UR/domain-contact induction is independent of heights and already adopted; no new generic geometry gap is asserted. Fixed implementation padding and optional absolute export calibration remain outside the abstract/projective all-word theorem. This is a narrow dependency audit, not an independent reproof of all standard-stage source producers.
