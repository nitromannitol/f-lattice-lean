# Explicit W1 joint-defect corner from the genuine W0 birth

Use a=(d,n), R=(e,r), det(a,R)=1, Z=2a+R. The special u=0 gives the point p=2a+V_a. Its even grades are t_Z(p)=2-K0, s_Z(p)=2K0-2, K0=M(a,Z). They belong to E_Z because 0<K0<T/2, T-2K0=M(R,Z)>0, and K0>=1. Thus the two true W0 birth sheets at p are precisely

    F_a(p-R),    F_a(p-V_R)+b_R.p+eta_R.

The true old a zero strip gives F_a(-R)=0, since t_a(-R)=1. The old harmonic strip gives F_a(-V_R)=h0(-V_R)=-eta_R, since s_a(-V_R)=-2. Both strips include those levels for a proper birth (d>=2, n>=1). The zero authentic primary 2a and the jet of V_a give first sheet F_a(V_a-R)=1-c_a. The second sheet is 2-c_a: the mixed terms b_a.(-V_R)=M(a,R), b_R.p=2-M(a,R) cancel. Therefore F_Z(p)=1-c_a. As s_Z(V_a)=-2 is also in Z's genuine complete harmonic strip, F_Z(V_a)=h0(V_a)=-c_a. Consequently D_b(p)=F_Z(p)-F_Z(V_a)=1. Notice the difference is one, not the two from the strictly negative raw-gap contradiction elsewhere.

This calculation requires neither the price on a wider central D interval nor recurrence of the currently recognized native object. The true sheet formulas and deck increments here coincide with the explicit W0 saved3 derivation in M1_QNEAR_THIN_RIM_CLOSURE §4, with ONE V_a instead of two; thus the extra constants in that two-V_a computation have not been transferred blindly.
