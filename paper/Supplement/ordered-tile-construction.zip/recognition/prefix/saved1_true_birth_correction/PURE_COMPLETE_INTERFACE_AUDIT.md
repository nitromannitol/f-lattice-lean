# Pure seeds: complete abstract incoming interface audit

## Verdict and independence
The two genuine EVEN pure families supply the old inputs actually used by B0/B1/B2, not just recurrence, with the root and signed-price exceptions retained below. Odd inputs transfer by the authenticated harmonic identity AND the now-proved canonical graph bijection. I found no additional unprovided pure-seed input in those consumers. This is an independent consumer-by-consumer semantic/dependency audit of the uniform source/certificate reports, not fresh solver replay or independent recoding of every seed certificate.

Families: reciprocal1/d, d=2K+3,K>=0, including the empty root; near-one(a-1)/(a+1), a=2K+2,K>=1. Never insert K0 into the doubled-ladder formula. Endpoint0/1,1/1 creator templates are not recurrent standard fields asserted by this audit. When a later old field has endpoint birth, use the corresponding genuine pure even field and its intrinsic signed data.

## Interface ledger
1. Global binary values, correct actual decks/reflection and cover: pure3 forced/native proofs and ENTIRE_STANDARD_STRIPS; pure2 nativechecks plus COMPLETE_CANONICAL_CLASSIFICATION. Native corner bonuses and deleted regions are retained. Odd fields use AUTHENTIC_RECIPROCAL_EVEN_TO_PURE2_ODD and odd_standard_symmetry, not a guessed finite-domain rotation.

2. Actual canonical graphs, finite nonfree square proofs and genuine private returns: pure3 forced/EXACT_FORCED_CLASSIFICATION_AND_THREE_STEP_RETURNS; pure2 UNIFORM_DOUBLED_LADDER_BULK_DIRECTIONS, COMPLETE_CANONICAL_CLASSIFICATION and GLOBAL_BINARY_AND_FREE_RETURN_SQUARES. The latter permits other FREE corners on a free return; the required nonfree witness has forced/black prerequisites. The endpoint table itself has no root modification. CANONICAL_GRAPH_TRANSPORT now identifies old p(epsilon,+) with qsw(-,epsilon), so a pure-born old parent supplies the correct source graph, not just some recurrent graph.

3. Full physical raw inequalities: pure3 raw/UNIFORM_RECIPROCAL_RAW_PRICE_PROOF gives P,D,Phi monotonicity on black, forced and selected free edges and the necessary P/D no-X properties. Its older statement only bounds |deltaPhi| by2, but clean/CLEAN_PHYSICAL_BAND_AND_ALL_THRESHOLD_BINARY explicitly supersedes this with four universal |deltaPhi|<=1 gates. Pure2 theorem §3 and rawall/pure2_arc give all the same raw input laws. Thus there is no residual Phi-unit hole from reading the older reciprocal raw summary alone.

4. All integer thresholds and recurrent comparison minima: pure3 clean proves binary admission for arbitrary threshold variable; pure2 rawall checks all finitely many nontrivial root offsets after its genuine global gradient bound. Both families have actual canonical zero-pitch strict ranks and direct clean BAND quotas. To obtain physical recurrence of an entire chain minimum, use the earlier two-rank minimum lemma: the reflected/translated second sheet has the opposite Phi monotonicity and a genuine reflected strict rank. This follows from standard reflection/decks and the SAME actual free graph (not from clean-band binary admission alone). These are exactly the ingredients of STRONG_PRICE_AND_ALTERNATE_STEP §4, with its local proof independent of a proper birth. Hence every threshold min consumed in B1 is recurrent.

5. True E/halo scalar windows: pure3 raw/CLOSED_POLYGON_HALO_AND_TRANSVERSE_WINDOWS and pure2 profile_window/transverse_windows give P's two levels, D+ in[0,2], D- in[-2,0], physical full transverse[0,2] windows and genuine birth central windows. A later effective creator does NOT enlarge those central windows. This audit imports no withdrawn saved1 effective-K statement.

6. Ordinary full strips: pure3 ENTIRE_STANDARD_STRIPS gives t in[1-d,2d], s in[1-2d,2d+1]; pure2 ENTIRE_ZERO_AND_HARMONIC_STRIPS gives t in[-a,3a], s in[-2a-1,4a-1]. These equal the required ordinary formulas at their parameters. Stronger parity strips and both extra zero seeds are initialized directly by newzeros/BASE_TWO_PIXEL_ZEROS and NO_ODD_SLIP_AUDIT §4, without nonbase P estimates or current recurrence. Their odd companions follow by the actual quarter-turn with phase tracked. These pay the earlier strengthened-strip queries in H source and W1 collars.

7. Abstract alternates: the actual pure even midpoint identities, global characters, physical D-star lemma and strict lex rank are proved in the respective alternate_native packets. Authentic odd alternate restoration/rotation is separately established in odd_alternate_symmetry. Abstract B1 does not consume literal helpers, but the requested A seed is indeed available. No implication that every later endpoint-helper occurrence is already priced is included.

## Exact boundary profiles needed by the current consumers
Write h_eta=Phi_eta(H0), v_eta=Phi_eta(V0). On every genuine pure H, P(H0)=c0 and P(Hi)=c0-1 for i>0; on V, P=c0. D± vanish on H. Preserve the following intrinsic V arrays and actual Phi endpoints/orders rather than imposing proper-creator cut lengths.

Reciprocal d>=3:
 D+(V)=[0]^(d-1),1,2;
 D-(V)=0,-1,[-2]^(d-1).
 For d>=5: Phi+(H)=1,1,1,[0]^(d-3); Phi+(V)=[1]^(d-2),2,3,3.
 For d3: Phi+(H)=1,1,1; Phi+(V)=2,2,3,3.
 All d: Phi-(H)=0; Phi-(V)=0,[-1]^d.
 Therefore plus h=1 always, v=1 except ROOT v=2; minus h=v=0. These follow PURE_BOUNDARY_TABLES by direct legal native evaluations including the two raised corners.

Near-one a>=4, c0=K²+3K+1:
 D+(V)=0 for j<a,1 for a<=j<2a-1,2 at last;
 D-(V)=0 at0,-1 for1<=j<a,-2 thereafter.
 Phi+(H)=c0; Phi+(V)=c0+1 for j<a and c0+2 thereafter.
 Phi-(H)=c0-1 through j1 and c0-2 thereafter;
 Phi-(V)=c0-1 at0,c0-2 for1<=j<=a+1,c0-3 thereafter.
 These are the 124 exact parameter-cell arc checks in pure2_arc, not extrapolated values. Here plus v=h+1, minus v=h=c0-1.

Consequences checked against B1 consumers:
* Earlier H traces are nonincreasing in actual index; earlier V traces are increasing for plus and decreasing for minus, with real secondary drift2eta.
* Plus Phi(I)=Phi(Vlast)-2=Phi(H0) in both families INCLUDING root. Thus V-source's plus core substitution is exact.
* Minus replacement of Hlast-U by V0 preserves order. For reciprocal, Hlast-U has Phi1 while V0=H0=0: this is NOT equality. For near-one these values agree at c0-1. V_SOURCE_TRACE_TRANSFER_FINAL explicitly uses the sandwich when equality fails.
* The polygon chain maxima used in p-donor shielding are h+2 for plus and h for minus. On reciprocal root the plus V maximum is3=h+2 despite v=h+1. On near-one plus it is likewise h+2 despite v=h+1. Reflected/translated arcs add their genuine characters; no fictitious h=v is used.
* The odd q-donor maxima maxPhi+<=c0+2 and maxPhi-<=c0 remain valid: reciprocal c0=1 has maxPhi+=3,maxPhi-=0; near-one has maxPhi+=c0+2,maxPhi-=c0-1. Stronger lower values are harmless.
* In the W1 k0 p-donor calibration, a pure predecessor has birth epsilon_old=-1, so only the s1 branch is applicable, never the formal s2/epsilon_old=+1 branch. Its index is Lprime-rprime-1. At reciprocal rprime=1 this is d-1, with Phi+-h=2. At near-one rprime=a-1 this is a, also Phi+-h=2. Hence the required >=1 is paid with actual pure cuts.

## Rank strength: the seed packet is not limited to one pitch
The saved explicit ranks Reta=c Phi_eta+r prove strictness with zero pitch. The broader S packet also requests arbitrary positive signed weights. This follows without new numerical ranks. On every actual policy cycle of deck winding iU+jV, P and Deta monotonicity give i>=0 and eta*j<=0. If i=j=0 the saved strict Reta forbids the physical lifted cycle. Therefore any positive weight character -A*i+C*eta*j is strictly negative on every nonempty quotient cycle. The finite difference-constraint/simple-cycle argument in the zero-pitch report constructs a periodic correction to the corresponding character, giving a strict physical rank. Reflection gives the other two signs; exact graph conjugacy gives odd policies. Thus no extra arbitrary-slope seed theorem is missing.

## Resulting scope
For the abstract chronological induction, complete pure S/A initialization is supported by the existing uniform packets plus the graph transport and elementary rank-strength argument above. This closes the pure-interface reservation in QUANTIFIED_PRODUCER_SYNCHRONIZATION at the level of proof assembly. Remaining proper B2 work is separate. No assertion about arbitrary corrected native arrays, old endpoint-template helper recognition, implementation padding or independently replayed certificates is made.
