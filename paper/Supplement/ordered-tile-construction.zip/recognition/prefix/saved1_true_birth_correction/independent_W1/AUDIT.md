# Independent saved1 W1 repair audit

## Verdict
The proposed repair has the correct signs and sufficient offer inequalities. It does not require the false effective-parent central bound db>=-1. The correlation needed for the first f1 constituent is only

    r(x)<0 ==> D_birth(u+2a+V_a)>=1.

Below is an independent geometric/minimum proof of this implication, with the precise earlier price-localization and source premises exposed. No current recurrence, native recognition, or effective-parent central-window theorem is used. This packet is not a new proof of those earlier source premises.

Write a=(d,n), R=(e,r0), d*r0-n*e=1, Z=2a+R=(D,N), A=Z-a, v=V_A, va=V_a, K0=M(a,Z), K=M(A,Z), T=T_Z. The scope of the coefficient checks is genuine proper birth d>=n+1,n>=1,e>=r0+2,r0>=1. Put cgeom=D-N and c_a=(T_a+L_a)/2. The earlier W0 birth quantities are P_b(w)=F(w)-F(w+va)+a_a.w and D_b(w)=F(w)-F(w-2a).

The exact conversions are r(x)=c_a-P_b(x), x=u+Z-2A=u-Z+2a, z=x+Z=u+2a, w=z+va, and dv=D_b(w)-2. In particular t_Z(z)=t_Z(u)+2, NOT t_Z(u)-2. The minus2 in dv is the actual secondary character.

## Exact projection of the true E_A polygon
The symbolic replay verifies

 K*c_Ageom=cgeom*T_A-2d_A;
 K*L_A=L_Z*T_A+2n_A;
 K*d_A=D*T_A-c_Ageom;
 K+K0=T; K0*L_Z=L_a*T+2N.

It also verifies positive-coefficient sufficient inequalities K>T_A, K>=T_A+2n_A, T_A>=L_A, and K0>=L_Z. Therefore for u in E_A:

* odd: s_Z(u)>=4-cgeom, t_Z(u)<=D-1 (in fact <=D-2 by parity);
* even: s_Z(u)>=0, t_Z(u)<=L_Z-1 (in fact <=L_Z-2);
* both: t_Z(u)>=-K-1.

For example the odd s bound follows from s_Z>2-cgeom and the even-valued s_Z lattice. The even lower bound follows from s_Z>-2. These are true lattice bounds, not merely continuous rectangle inequalities.

At an even u with s_Z(u)=0, u=ell*V_Z: gcd(D+N,D-N)=2 and physical even parity exclude odd half-V_Z multiples. Since |t_A(V_Z)|=K>T_A and exceeds the positive E_A upper t bound, necessarily u=0. Thus the unique lower-s exceptional point really is 0.

## Correlation geometry and precise localization premise
Use the earlier price localization on the present query set:

 (L) P_b(x)>c_a implies s_Z(x)<lo_s(E_Z),
     and the strict lower-primary fold has no additional exceptional value.

This implication must include the possible one-row transverse upper fringe of x. Merely quoting the P_b span ON E_Z does not by itself prove (L). Once (L) is licensed, all the remaining geometry below is direct.

Under r(x)<0, s_Z(z)<T+lo_s. Since s_Z(z)=s_Z(u)+2K0, the lower s bound holds and z is below the upper s bound. Its lower transverse bound follows from t_Z(z)>=-K+1=-T+K0+1. Odd z already satisfies the upper bound by parity.

There is no even upper-transverse exception under (L). The sole possible row is t_Z(u)=L_Z-2. Then s_Z(u)>=0 implies

 t_a(u)=(K0*t_Z(u)-s_Z(u))/T < L_a,

using K0>L_Z>=N. But (L) gives s_Z(u)<T-2K0, and the exact K0*L_Z identity gives t_a(u)>L_a-1. This contradicts integrality. Thus z is genuinely in E_Z; the additional proposed zero-strip argument for a point just above E_Z is unnecessary in this proper cone.

The longitudinal bounds for w and w-2a follow from

 s_Z(w)=s_Z(u)+2K0-2,  s_Z(w-2a)=s_Z(u)-2.

They are genuine E_Z bounds except for u=0 in the even case. The upper bounds follow directly from s_Z(z)<T+lo_s.

Transversely, -T+1<=t_Z(w)<=1, so the genuine complete physical D_b band gives D_b(w)>=0. If w is below its native lower t edge plus2, then w-V_Z has t in the genuine physical band, and D_b(w)=D_b(w-V_Z)+2>=2. Consequently, if D_b(w)=0, both w and w-2a satisfy the native transverse bounds. This proves the required guards under the only bad value, rather than assuming every w is native.

## Native two-sheet contradiction
Because z is native and x=z-Z, primary price drift and the native price span imply P_b(z)=c_a. Hence

 F(w)=F(z)+a_a.z-c_a.

Let A0 be the genuine first birth sheet. Its actual raw identity is

 A0(w)=A0(z)+a_a.z+1-c_a,

and native F(z)<=A0(z) gives F(w)<=A0(w)-1. At the two licensed sites w,w-2a, the true birth minimum has first sheet unchanged under -2a and second-sheet gap decreased by2. If psi is the second-minus-first gap at w, then psi<=-1 and

 D_b(w)=min(0,psi)-min(0,psi-2)=2,

contradicting D_b(w)=0. This argument needs only F(z)<=A0(z), NOT equality or ownership of z by that sheet.

At u=0 the second source guard has the unique s=-2 exception. The earlier direct birth corner values stated in the proposed repair,

 F(2a+va)=1-c_a, F(va)=-c_a,

give D_b(w)=1. These values must be bound to the genuine earlier source/corner packet; this audit has not independently rerun that packet. The min(1-c_a,2-c_a) expression selects 1-c_a with the indicated sign.

## Actual offers, rather than the unnecessarily stronger R comparison
Let R=r(x)-1-dv and S=min(0,R).

For SHORT f0 the actual constituents are r+db+2 and r+rm. With the paid f0 lower-rim prices r,rm>=0 and the valid physical db>=-2, both are>=0>=S. No dv bound is needed.

For LONG use x'=x-Z and r'=r-1, rm'=rm-1. Its actual f0 constituents are r'+db+2 and r'+rm'. Their nonnegativity follows from the LONG f0 bounds r',rm'>=0 and db>=-2. This is stronger than the required S-1.

For f1 the first constituent is r (SHORT), r-1 (LONG). If r>=0 it dominates S (respectively S-1). Otherwise the proved correlation gives dv>=-1, hence R=r-1-dv<=r and the same comparison follows. The separately paid second f1 constituent retains its earlier rim proof; no claim that db>=-1, or dv>=-1 everywhere, has been made.

## Scope and exact remaining binding
This repairs the algebra and reduces the nontrivial correlation to genuine earlier source facts, with all parity projections checked independently. Before unconditional closure, bind (L) on the actual one-row fringe and the u=0 birth corner values. The finite witnesses of false separate central bounds in AUDIT.md one directory above remain valid and are not overwritten. The six polynomial identities and five coefficient inequalities here do not themselves certify (L) or native source identities.

## Completion addendum: localization and all f0 rims, including m=1

The two open bindings in the preceding audit are now discharged from the named earlier strip/native field premises; this addendum preserves the chronology of the audit instead of silently deleting its caution.

### Longitudinal saturation proves (L) without a transverse restriction

P_b is invariant under V_Z and has P_b(y+Z)=P_b(y)-1. At each fixed longitudinal grade s in the actual E_Z parity interval, its t interval has length T+L_Z-4 (even) or T+D-N (odd), at least T. Translation by an integer V_Z keeps s and physical parity fixed and changes t by -T. Thus every physical point at such an s has an actual E_Z representative. The native span implies P_b<=c_a there, regardless of transverse grade.

The longitudinal intervals also have length at least T: T+2N (even), T+2D-4 (odd). For a point above the upper s edge, subtract jZ, j>=1, into that interval, then fold transversely. Its price is the representative price minus j, hence <=c_a. Consequently P_b>c_a forces s<lo_s. This proves (L) on the entire plane, including the one-row transverse fringe, using only genuine earlier native coverage/span and exact price characters. No gap remains at that fringe.

### Physical lower rim and the three f0 prices

For any y with s_Z(y)>=3-2D one has P_b(y)<=c_a. Indeed saturation pays s>=lo_s. Below lo_s, both y and y+va have their s grades in the true full harmonic strip [1-2D,2L_Z-1], since s_Z(va)=-2. Their actual heights equal h0, and direct expansion gives

 h0(y)-h0(y+va)+a_a.y=c_a.

The parity term causes no error: va has even coordinate sum. Hence r(y)>=0 on this entire half-plane, with equality on the lower strip.

On SHORT f0 the actual fold geometry gives s_Z(x)>=5-2D; since s_Z(v)=+2, this pays r(x)>=0 and rm=r(x-v)>=0. On LONG f0 the same geometry at the actual x'=x-Z gives s_Z(x')>=5-2D, paying r(x')>=0 and r(x'-v)>=0. Equivalently r(x)>=1 and rm>=1. These are the three price bounds used in the earlier SHORT/LONG comparison (the shifted LONG pair is the stronger form of the last two).

Fresh copies short_f0.py and long_f0_all_m.py prove 58 facets each, restricted to the genuine saved1 branch. The latter uses m=j+1, j>=0, rather than the obsolete m>=2 substitution. Thus m=1 is included in the single coefficient argument; no unproved thinner-rim limit is taken. The other geometry facets in those receipts retain their geometric meaning only: a facet placing a query in an effective central interval does NOT restore the false |D|<=1 interpretation. The value proof uses solely the valid >=-2 wrapped physical bound.

### Genuine u=0 source binding

I independently checked W1_TRUE_BIRTH_ZERO_CORNER.md. At p=2a+va the true even grades are (2-K0,2K0-2), inside E_Z using K0>=L_Z and T>2K0. The first sheet, by the authentic a primary and va secondary, is F_a(va-R)=1-c_a. The second is

 F_a(-V_R)+a_a.(-V_R)-c_a+b_R.(2a+va)+eta_R
 = -eta_R+M(a,R)-c_a+2-M(a,R)+eta_R=2-c_a.

Here t_a(-R)=1 licenses the genuine zero strip, and s_a(-V_R)=-2 licenses the genuine harmonic strip. The same harmonic strip at va in the Z field gives F_Z(va)=-c_a. Thus the special D_b(p)=1 is authentic. No current-child admission is used.

Accordingly the saved1 W1 correlation and repaired f0/f1 first-constituent comparisons are closed in the proper real-birth cone, under their previously authenticated stationary nesting, full earlier strips, native span and selected fold formulas. This is not a claim of chronology/calibration of the current native constructor, nor a replacement for the separately paid second f1 constituent.
