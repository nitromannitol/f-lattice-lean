import sympy as s,json,hashlib
from pathlib import Path
d,n,e,r=s.symbols('d n e r');D,N=2*d+e,2*n+r;ad,an=d+e,n+r
T=lambda d,n:d*d+2*d*n-n*n
TA=T(ad,an);TZ=T(D,N);K=(ad+an)*D+(ad-an)*N;K0=(d+n)*D+(d-n)*N
G=s.groebner([d*r-n*e-1],d,n,e,r)
exprs={'Kc':K*(ad-an)-(D-N)*TA+2*ad,'KL':K*(ad+an)-(D+N)*TA-2*an,'Kd':K*ad-D*TA+(ad-an),'birthKL':K0*(D+N)-(d+n)*TZ-2*N,'Ksum':K+K0-TZ,'sva':(D+N)*(n-d)+(D-N)*(d+n)+2}
assert all(G.reduce(s.expand(x))[1]==0 for x in exprs.values())
a,b,c,f=s.symbols('a b c f',nonnegative=True);sub={n:a+1,d:a+b+2,r:c+1,e:c+f+3}
ps={}
for name,x in {'K_gt_TA':K-TA-1,'K_ge_TA_2nA':K-TA-2*an,'TA_ge_LA':TA-ad-an,'cZ_gt_cA':D-N-ad+an,'K0_ge_LZ':K0-D-N}.items():
 p=s.Poly(s.expand(x.subs(sub)),a,b,c,f);assert min(p.coeffs())>=0;ps[name]=str(p.as_expr())
out=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/recognition_ledger/saved3_gate/prefix/saved1_true_birth_correction/independent_W1')
(out/'GEOMETRY_REPLAY.json').write_text(json.dumps({'identities':list(exprs),'nonnegative_coefficients':ps,'scope':'proper real birth W0; all variables nonnegative; determinant d*r-n*e=1','producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
print('PASS',len(exprs),'identities',len(ps),'coefficient polynomials')
