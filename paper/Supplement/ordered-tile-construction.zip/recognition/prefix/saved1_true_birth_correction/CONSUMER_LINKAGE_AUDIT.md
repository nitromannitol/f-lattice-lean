# Independent audit of repaired saved1 G2 consumer linkages

## Scope
The joint physical implications are owned by separate proofs. This audit verifies their exact sufficient interfaces to BOTH SHORT and LONG, including the separately licensed ordinary m=1 UNC specialization. It does not recover the false lower bound D>=-1. All four computations use the unchanged true polygon alias e=1 and the actual lower-s flag f. The previously verified donor supplies attainment; these computations exclude undercut by BOTH competing constituents.

## W0 SHORT
Write p1=P(u-v)-c_A, p2=P(u-2v)-c_A, d=D(u-v), e=D(u-v+2A). The target relative to F_Z(u) is S=min(0,H-2)=min(0,p1-d). The repaired physical premises are p1>=-2,d,e>=-2 and NOT(p1=-2 AND d=-2).

For f0 the first constituent is I=p1+1. If p1>=-1 it is nonnegative; otherwise integrality gives p1=-2 and d>=-1, so S=p1-d<=-1=I. The second constituent's exact commutator reduction gives II-(H-2)>=2k-1, using P(u-2v-2A)>=c_A-1. Thus II>=S for k>=1. This second bound has no hidden central-slip input.

For f1 the ACTUAL constituents are I=p1+3+e and II=p1+p2+2. The selected-flag geometry supplies p1,p2>=-1, hence both are >=0>=S. Comparing either with H-2 was unnecessarily stronger.

## W0 LONG, including m=1
The actual target allowance is S-1, NOT S or H-3. The genuine root change by Z decreases the preceding first and second constituents by1 and2, respectively, with stationary parameter m.

For f0, I=p1. If p1>=-1 then I>=-1>=S-1; if p1=-2 the joint exclusion gives S<=-1 and again I>=S-1. The second commutator difference is II-(H-3)>=2m-2>=0 for every m>=1. The borderline m=1 has equality allowance, not a missing extra unit.

For f1 the actual constituents are I=p1+e+2 and II=p1+p2. The repaired rim proof supplies p1>=0,p2=0, so both >=0>=S-1. At the single lowest even s layer one must use p1>=0 by backwards folding, NOT falsely claim harmonic equality there.

## W1 SHORT
Set x=u+Z-2A, r=eta_A-Pstd(x), rm=eta_A-Pstd(x-v), rplus=eta_A-Pstd(x+2A-v), d=D(x-v), b=D(x-v-2A). Set R=r-1-d and S=min(0,R), the genuine near-donor target. Exact expansions of the former SHORT table give

 f0: (I,II)=(r+b+2,r+rm);
 f1: (I,II)=(r,R+rplus+2k-1).

Required repaired interfaces:
* b>=-2;
* f0 implies r>=0 and rm>=0;
* f1 uses r<0 implies d>=-1, and rplus>=0.

The f0 pair is nonnegative. For f1, if r>=0 then I>=S. If r<0, R=r-1-d<=r, so I>=R>=S. Also II>=R+1>=S for k>=1. No unconditional d>=-1 is being used. In particular the joint implication alone does not pay f0 unless its separate r bound is supplied.

## W1 LONG, including m=1
Use x'=u-2A=x-Z and the independently proved LONG target S-1. The authentic source/deck transformation is asymmetric: I'=I-1 and II'=II-2. It is NOT a common scalar subtraction. Therefore

 f0: (I',II')=(r+b+1,r+rm-2);
 f1: (I',II')=(r-1,R+rplus+2m-3).

For f0 require the selected-LONG-flag bounds r>=0,rm>=1 and b>=-2. Both constituents are >=-1>=S-1. For f1 the joint implication proves r>=S exactly as above, and rplus>=0 gives II'>=R-1>=S-1 for all m>=1. At m=1 the coefficient2m-3 is -1; this is precisely the available allowance, so no invalid m>=2 estimate survives.

## Ordinary m=1 linkage and actual costs
ordinary_middle_m1/THEOREM.md separately certifies the m=1 geometry (not a nonexistent literal k=0 LONG helper). Its W0 competing q=u+2V_Z and W1 q=u-2A+2V_Z are exactly the LONG queries above at m=1. The nested attaining offer and relative target S-1 are unchanged. Thus these repaired implications replace that theorem's obsolete central-bound paragraphs, in BOTH phases.

The literal ordinary RIGHT prices remain
 W0 at y=u+V_Z: F_A(u)+b_Z.u-c_Z;
 W1 at y=u+Z+V_Z: F_A(u)+b_Z.u-c_Z+2.
The common global slope is b_Z, with constants eta_Z+2W. The raw reflection constant remains -eta_Q-1, not the standard reflection constant. It yields LEFT origins2Z+V_A (W0), V_A-Z (W1), slope b_A and scalar eta_A+1-W. The repair changes no origin, cost, source mask, parity, or reflection premise.

## Producer status and regression
W0 physical interfaces are supplied by AUDIT.md and W0_F0_JOINT_DEFECT_EXCLUSION.md. At this audit's writing the W1 joint proof is in progress; its requested interface is displayed above explicitly, including the important f0 r>=0. Do not label W1 globally closed from the joint statement alone.

check_consumer_algebra.py independently tested29,040 bounded exact integer assignments (the exact per-case counts are in its receipt); all eight implications passed. This is an arithmetic regression only. The preceding case splits and linear inequalities prove the implications for unbounded integers and m,k>=1. The physical source inequalities and geometry are separate hypotheses, not inferred from that enumeration.
