# Independent proof: saved1 W0 joint-defect exclusion and repaired G2 prices

## Result and inputs

Use the genuine birth-W1 pair a=(d,n),R, Z=2a+R=(D,N), effective current-W0 A=Z-a. Write K0=M(a,Z), K=M(A,Z)=T-K0, T=T_Z, L=D+N, c=D-N. Retain the actual birth standard raw representation on E_Z, full physical D/zero strips, true standard characters, and actual E_A geometry. For u in E_A put v=V_A,

 P1=P_eff(u-v), d_v=D(u-v).

Then the previously dangerous joint values

 P1=c_A-2 and d_v=-2

are IMPOSSIBLE. This closes the saved1 W0 f=0 first-constituent gap for SHORT and LONG, including m=1, without the false enlarged central window. Together with the separately repaired f=1 branches and still-valid geometry/other-offer attainment, the W0 saved1 G2 price proof is restored under its original genuine earlier inputs.

## 1. Exact reduction to true-birth quantities

Write v_a=V_a, U_a=2a and

 Pb(z)=g(z)-g(z-v_a)-b_a.z,
 Db(z)=g(z)-g(z+U_a), g=F_Z,
 x=u+v_a-Z.

The genuine birth-W1 characters are Pb(Z)=-1,Pb(V_Z)=0,Db(Z)=0,Db(V_Z)=2. The effective-price substitution gives

 P1-c_A=Pb(x)-eta_a-1,
 d_v=Db(x)-2.

Thus the dangerous pair is equivalent to Pb(x)=eta_a-1 and Db(x)=0. Every sign and the extra1 are indispensable; the effective central interval is nowhere invoked below.

## 2. Longitudinal licensing and the odd top exception

The full effective E_Z P span gives P_eff>=c_A-1 at every physical point whose s is no larger than E's upper longitudinal row, by nonpositive-primary folding. Thus P1=c_A-2 forces s_Z(u)+2 above that row.

Since s_Z(x)=s_Z(u)+2-T, x and x-v_a are above E's lower s edge. The exact E_A upper estimates are

 s_Z(u)<=2K+2N-2 (even),
 s_Z(u)<=2K+L-2 (odd).

Hence x and x-v_a are below E's upper s edge as well. The point x+2a has s=s_Z(u)+2-T+2K0, so it too is below that upper edge except possibly the odd layer

 s_Z(u)=2K+L-2,

which would give s_Z(x+2a)=T+L, two above the odd upper row.

That layer has the odd reference point u0=2A+e1+V_A. Its t_Z is N-K+2. Same-s points of the same physical parity differ by integer V_Z (coprimality, D,N odd). The actual E_A t_Z interval is [N-K,D+2] at odd sites. The +V_Z neighbor lies below it; the -V_Z neighbor has t=N+K0+2>D+2, because K0>c. Thus u0 is the only possible point in that layer. But s_A(u0)=2T_A+L_A, whereas the odd E_A upper row is2T_A+L_A-2. It is not in E_A. The purported exception is impossible, so x+2a is longitudinally licensed too.

## 3. Transverse licensing from Db(x)=0

We have t_Z(x)=t_Z(u)-K0. The general E_A t_Z bounds give upper t of x at most D+2-K0 odd or L+1-K0 even, within E_Z because K0>2. The point x+2a has t two smaller, so its upper edge is safe too.

Let hi=N+2D-1 be the genuine complete physical D-band upper endpoint. If t_Z(x)+T<=hi, then x-V_Z belongs to the complete [0,2] band: its lower bound is automatic from t_Z(u)+K>=N (odd) or>=1 (even), well above the band's lower endpoint. The genuine V_Z character would give

 Db(x)=Db(x-V_Z)+2>=2,

contradicting Db(x)=0. Therefore t_Z(x)>hi-T. This puts BOTH x and x+2a above E_Z's actual lower t edge, even after the latter's -2 shift. Thus x,x+2a genuinely lie in E_Z.

## 4. The only potentially off-polygon first primitive is paid by zero strips

The point x-v_a=u-Z has the already licensed longitudinal coordinate. If it is in E_Z, the actual two-source minimum gives g(x-v_a)<=F_a(x-v_a) directly.

Its only possible remaining failure is above the E_Z transverse upper edge, since t_Z(x-v_a)=t_Z(u). The E_A bounds then put it inside the complete ordinary zero strip of g: the high condition gives t>=D+1 odd or>=L-1 even, and its upper bound is D+2 or L+1. Hence g(u-Z)=0.

The exact birth-W1 coordinate identity is

 T t_a(u-Z)=K0*t_Z(u)+s_Z(u)-T.

The high-s defect above gives s_Z(u)>=T+h_E, and in this high-t case t_Z(u)>0, so this numerator is nonnegative. For its upper bound use t_Z(u)<=L+1, s_Z(u)<=2K+L-2, K=T-K0 and K0*L=L_a*T-2N:

 K0*t_Z(u)+s_Z(u)-T
 <=(L_a+1)T+c-K0-2
 <(L_a+1)T.

Integer t_a therefore lies in[0,L_a], inside the genuine a zero strip[1-d,n+2d-1]. Thus F_a(u-Z)=0 also. This proves g(x-v_a)<=F_a(x-v_a) even at the possible transverse escape. No whole-plane raw-minimum extension was used.

## 5. Contradiction from the authentic birth gap

At x and x+2a the genuine birth-W1 raw formula has first primitive F_a and relative second-offer gap psi(x). The first primitive is unchanged under2a and the gap decreases by2. Therefore

 Db(x)=min(0,psi)-min(0,psi-2)=0

forces psi>=2, hence g(x)=F_a(x). Section4 gives g(x-v_a)<=F_a(x-v_a). The TRUE a secondary jet now yields

 Pb(x)=g(x)-g(x-v_a)-b_a.x
 >=F_a(x)-F_a(x-v_a)-b_a.x
 =eta_a.

This contradicts Pb(x)=eta_a-1 and proves the joint-defect exclusion.

## 6. Correct min-target inference for SHORT and LONG

The E_A upper longitudinal bounds show P1>=c_A-2 globally: at most one positive Z fold is needed, and the old E span has lower value c_A-1. The correct earlier correction gives d_v>=-2. Both are integer-valued.

For SHORT f=0, its first constituent is I=P1-c_A+1, and the target is S=min(0,H-2), H-2=P1-c_A-d_v. If P1>=c_A-1 then I>=0>=S. If P1=c_A-2, the joint exclusion forces d_v>=-1, so S=H-2<=-1=I. Thus I>=S.

For LONG f=0, the first constituent is I=P1-c_A and the target is S-1. If P1>=c_A-1, I>=-1>=S-1. If P1=c_A-2, the same exclusion gives S<=-1 and I=-2>=S-1. This works at m=1 with no additional slack.

The second f0 constituent retained its valid commutator/nonpositive-longitudinal-fold proof: SHORT II-(H-2)>=2k-1>=1; LONG II-(H-3)>=2m-2>=0. Hence it dominates S or S-1 without a central-D assumption. Combined with the repaired f1 direct bounds in AUDIT.md, all W0 saved1 G2 competing-price branches are now paid. Actual fold geometry, exact attaining donor, literal origins and chronological calibration remain the independent premises already listed in those results.

This proof does not repair W1 by analogy; its true-birth correction remains a separate task.
