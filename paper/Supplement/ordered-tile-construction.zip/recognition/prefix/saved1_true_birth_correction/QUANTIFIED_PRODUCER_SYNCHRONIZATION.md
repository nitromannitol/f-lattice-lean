# Quantified chronological producer theorem (conditional analytic interface)

## Statement
Let W be the finite words in {1,2,3}, with swap exchanging2,3. Use the actual Farey registers, source phases and creation words of the mathematical untruncated construction. For every word w, let S(w) mean the following COMPLETE standard packet for both actual standard children, in their genuine spatial frames:

(1) globally binary normalized standard fields with correct decks, reflection and harmonic odd/even conjugacy; genuine polygon/halo equality and ordinary/strengthened strips;
(2) exact physical W1 forced/free classification, contained finite interior unit proofs and quotient bulk DAG;
(3) all four actual canonical policies, strict physical ranks with arbitrary positive signed weights and in particular zero pitch along their true chain kernel, plus physical rejected-input three-edge square returns;
(4) both signed primitive/short-slip/chain potentials with the required full-star unit and no-opposing-increment properties, their actual canonical edge monotonicities, exact incoming/outgoing boundary traces/cuts, and recurrent binary chain minima with clean bands for every integer threshold.

Let A(w) mean the two globally sewn midpoint alternates, their genuine characters and binary admission, physical strict ranks and recurrence. A(w) does NOT assert equality with literal native alternate arrays.

Define B(w), for a nonpure word, to be the analytic pre-rank standard-stage interface specified below, with all old fields taken from their actual creation occurrences. Then the saved conditional constructor lemmas and the proved canonical graph transport give the implication

  [S(v) and A(v) for every |v|<m] and
  [B(w) for every nonpure |w|=m]
       ==> [S(w) and A(w) for every |w|=m],

provided the pure words of level m carry their separately verified COMPLETE seed packets. In fact the abstract nonbase producer does not need earlier A(v); those are included only to make the eventual recognition schedule clear. Consequently complete pure seed packets plus B(w) for EVERY nonpure word imply S(w),A(w) for every word by strong induction. This is a quantified implication, NOT an assertion here that all B(w) have independently been verified.

## Actual occurrence and sibling binding
For each nonpure even receiver w=u s 3^k, s the last1 or2, its actual odd parent p is the odd standard CHILD created at u. If its creation pair was r,qold, then p=r+qold. Its actual selected even parent is q=qold+2kp for s2, and q=(2+2k)p-qold for s1. The receiving sign is epsilon=epsilon_u for s2 and -epsilon_u for s1. The genuine conjugate qsw is the EVEN child at swap(u), and |u|<|w|. Its intrinsic odd creator is B(qold), where B(d,n)=((d+n)/2,(d-n)/2).

The all-creator scalar identity and CANONICAL_GRAPH_TRANSPORT identify the current A-source graph precisely with qsw(-1,epsilon), including the antagonistic s1 case. Thus the earlier chain Phi supplies incoming Psi and its true rank/private squares. Endpoint births give actual pure qsw fields, with their real seed convention. No proper-creator theorem is applied to endpoint0/1 or1/1. A nonpure current pair is proper: retaining1/1 throughout gives only the pure2 branch, and after replacement it cannot return. The conjugate assertion for odd receivers uses swap(w), not an assumed same-word numerical rotation.

## Required analytic interface B(w)
B is deliberately decomposed so that a proof cannot hide the desired current rank or strong monotonicity in an input.

B0. Actual Farey/source/deck identities, genuine polygon coverage and boundary class geometry, and the all-creator single-constant source-chain matching in the stated frames. Current fields are NOT yet presumed recurrent.

B1. From earlier clean bands, authenticate the globally recurrent binary two-source comparison M=min(A,C), including its actual reflected source. Prove source H/V full-star values and inequalities, preserving the exceptional exterior star. Sew a globally binary current standard F, with F=M on the LICENSED closed polygon E, true halo/decks/reflection and usual plus strengthened strips. Prove the actual donor boundary comparisons needed to extend those strips using recurrence of M and earlier standards, not recurrence of current F. Existing source, FOUR_MEMBERSHIPS, donor/strip and sewing notes are proposed producers of this interface, not replacements for its quantifiers.

B2. Before any current rank, establish the primitive two-level range and rounded J signed ranges, the genuine boundary P trace and signed V cut, corner/tip prices and two-extra-zero guards. Establish the rounded bulk-transfer implication from contained current W1 unit proofs and those ranges. It must concern every retained black input and forced white input. It may use earlier raw monotonicity but NOT current strong raw monotonicity. The ancestral H/V cut notes supply a triangular route: earlier chain trace -> current source halo -> current sewn P(H), and earlier P(H) -> current V cut. Pure predecessor substitutions use their actual seed tables.

These are nontrivial analytical premises. A slope identity, binary admission alone, or an E-domain inclusion alone does not prove them. This audit has not found an additional cycle in their proposed derivations, but does not silently promote the list of references to an unconditional proof of B for all histories.

## Correct within-level schedule
For each m perform the following in order. Pure words are installed from their complete seed producers.

0. Construct the level-m EVEN standard fields from earlier packets by B0-B1 for all nonpure w. Define their level-m ODD conjugates using the even field at swap(w); this is a simultaneous algebraic definition, not a same-level recurrence dependency. Authenticate its actual source pair and scalar formula. No alternate at level m is used.

1. CURRENT W1 FIRST. Apply W1_CONSTRUCTOR using the earlier matched canonical ranks, earlier zero-pitch tie rank/clean band and earlier private squares, plus current sewn F and strengthened strips. Its collar proof supplies inward squares; arbitrary older returns cannot be assumed inward. This gives contained finite current unit proofs, the exact protected web and bulk DAG. It consumes no current rank.

2. CURRENT RANK SECOND. Apply B2's pre-rank rounded transfer on these now-produced unit proofs. With actual cuts/tip values apply ALL_SLOPE_STEP and its canonical-free-slot addendum. This yields strict physical ranks for the actual current policies and current standard recurrence. The global square/zero-pitch report then gives genuine current three-edge private returns and the balanced kernel-periodic ranks. Reflection supplies the opposite signs, and the proved physical graph conjugacy supplies the odd siblings. This is not a rank inferred from a quotient burn.

3. CURRENT STRONG RAW/CLEAN THIRD. Apply STRONG_PRICE_AND_ALTERNATE_STEP to current W1, ranges, canonical ranks and the earlier matched raw policies. Its common-chart and boundary arguments give current strong P,D, then the physical two-rank lemma gives chain Phi and recurrent clean bands at all thresholds. No current clean band was used in steps0-2. The midpoint-star lemma then constructs the current globally binary recurrent alternates A(w), using full raw D and its true physical rank, not a general claim that averages preserve recurrence.

4. OPTIONAL NATIVE RECOGNITION LAST. Only now use genuine old native fields, actual creator restoration and source prices to recognize current standard/alternate arrays. Ordinary k0 alternate O=A+Z is the same-step STANDARD already constructed in0 and certified in1-3. It is not supplied by current alternate recognition. Proper and endpoint native prices, actual overlap/scalar binding and fixed-padding issues remain separate.

## Acyclicity proof and precise status
Order stages lexicographically by (word length, stage number). Each old source, qsw and its intrinsic creator lies at a smaller length. All step1 rank/clean/private-square inputs are old. Step2 current inputs are only stage0/1 objects and B2 pre-rank comparisons. Step3 uses current ranks from2, not its own conclusions. The same-level swap is algebraic at stage0: construct the even orbit first, then define the odd orbit, so it introduces no directed proof cycle. Step4 never points backward to canonical stages0-3. This proves well-foundedness of the synchronization schedule.

The specific free-arrow transport reservation is CLOSED by the exact arc/phase table in CANONICAL_GRAPH_TRANSPORT. Endpoint birth and sibling-antagonistic choice do not create another age or sign gap. What remains for an unconditional ABSTRACT theorem is a fully quantified verification of B0-B2 at the actual chronological occurrences, together with the complete signed pure seed interface, rather than merely pure recurrence. The published local conditional implications do not supply that verification automatically. Native corrected recognition and implementation claims remain additional and are not conclusions of this theorem.
