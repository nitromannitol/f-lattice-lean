# Urgent correction: saved1 effective central window is not a birth theorem

## Confirmed error

The genuine central |D|<=1 interval uses K0=M(a,Z), where a is the TRUE odd creator. In saved1 the effective A=Z-a has K=M(A,Z)=T_Z-K0. One cannot replace K0 by the larger K in that earlier scalar theorem. The geometric certificates that put queries in the larger coordinate interval remain valid geometry; their subsequent invocation of |D|<=1 is invalid.

Fresh genuine-field probes find D=-2 in BOTH phases, including strict interior creators, so this is not just a widened-cone endpoint defect.

### Exact witnesses

1. Birth13, current W0: a=(2,1),Z=(11,5),A=(9,4),K0=38,K=168,T=206. At u=(0,0) in E_A, q=u-V_A=(5,-13). Genuine heights F_Z(q)=-62 and F_Z(q-2A)=-60 give D(q)=-2. Another u=(-3,8) gives q=(2,-5), heights-8,-6 and t_Z(q)=65, exactly ONE beyond the true central upper endpoint64.

2. Strict birth123, current W0: a=(5,2),Z=(23,9),A=(18,7),K0=188,K=674,T=862. At u=(0,0), q=(11,-25), heights-251,-249 give D=-2. At u=(-7,16), q=(4,-9), heights-30,-28 and t_Z(q)=243, again ONE beyond the genuine central upper endpoint242.

3. Strict birth113, current W1: a=(5,2),Z=(27,11),A=(22,9),K0=222,K=980,T=1202. At u=(2,0) in E_A, x=u+Z-2A=(-15,-7). The queries q=x-V_A=(-2,-38) and q-2A=(-46,-56) both have D=-2, where now D(z)=F_Z(z)-F_Z(z+2A). Their genuine height pairs are(-403,-401) and(-405,-403).

These values are independent of the later stationary length m/k. Thus the false central premise affects the cited saved1 G2 SHORT and LONG proofs and their m=1 specialization wherever they require these values>=-1. It does NOT by itself disprove the final target inequality: comparison to H-2 or R can be unnecessarily stronger than comparison to min(0,H-2) or min(0,R).

The saved probe.py directly rebuilds genuine original standard fields and evaluates the full E_A set. No invented effective-birth field is used.

## Exact transport and a valid replacement bound

Write v_A=V_Z-v_a. Current W0 is birth W1, and current D equals its true birth D by the zero Z period. Hence

 D(u-v_A)=D_birth(u+v_a)-2,
 D(u-v_A+2A)=D_birth(u+v_a-2a)-2.

Current W1 is birth W0. With x=u+Z-2A, its two queried differences similarly become

 D(x-v_A)=D_birth(u+2a+v_a)-2,
 D(x-v_A-2A)=D_birth(u+4a+v_a)-2.

The -2 is the genuine V_Z deck character, not an error that can be discarded by periodicity.

The geometric query bounds previously proved with effective K still place these queries in
 [lo,hi+K] subset [lo,hi+T],
where lo=3-D_Z-T and hi=N_Z+2D_Z-1. For t<=hi the complete physical birth band gives D>=0. For t>hi, translate by +V_Z: the new t=t-T lies in[lo,hi], so D(original)=D(translated)-2>=-2. Therefore D>=-2 is a valid uniform replacement; D>=-1 is false.

## Repaired W0 SHORT e=1,f=1 branch

Retain the already proved actual fold geometry and full E_Z effective P span. At j=k+1 the actual f=1 lower-s condition gives s_Z(u)<T. Therefore P_1=P(u-v_A) and P_2=P(u-2v_A) are both>=c_A-1 by nonpositive-primary folding into E_Z (their upper s coordinates remain below its upper row).

The ACTUAL normalized SHORT constituents are
 I=P_1-c_A+3+D(u-v_A+2A),
 II=P_1+P_2-2c_A+2.

The correct D>=-2 now gives I>=0 and II>=0. Since the actual G2 target is S=min(0,H-2)<=0, this closes the branch without comparing to H-2 itself. Thus this branch survives the correction.

## Repaired W0 LONG f=1 branch, including m=1

The actual LONG f=1 condition gives s_Z(u)<0. The previous valid harmonic-rim geometry gives s_Z(u)>=-1-2D_Z. Since s_Z is even, its only possible point below the full harmonic strip's lower edge1-2D_Z is s_Z(u)=-2D_Z.

At ordinary points of this slice P_1=c_A by the harmonic strip. At the exceptional s_Z(u)=-2D_Z, u-v_A lies strictly below the E_Z lower longitudinal edge, so backward-primary folding gives P_1>=c_A. In every case P_2=c_A, since both its inputs are in the harmonic strip. Consequently

 I=P_1-c_A+D(u-v_A+2A)+2>=0,
 II=P_1+P_2-2c_A>=0.

This is stronger than the required S-1<=-1 and works for every m, including m=1. Do not claim P_1 equals c_A at the exceptional rim; the lower bound is sufficient.

## Remaining unclosed pieces

The saved1 W0 f=0 branch and the W1 branches still require a corrected correlation/actual-guard or direct min-target argument. The old >=-1 proofs cannot be cited for them. No new target counterexample has been established in this audit. Saved3, where effective and true birth parents coincide, is not affected by this K substitution error.

The intrinsic saved1 all-R2 G3 price proof uses direct birth-price substitutions/full physical windows rather than this enlarged central band; it is not automatically invalidated. Dependencies should be checked individually, not all discarded or all preserved by association.
