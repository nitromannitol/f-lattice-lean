import itertools,json,hashlib
from pathlib import Path
counts={}
# Independent exact arithmetic regression of the explicit sufficient premises.
# The accompanying inequalities, not bounded enumeration, prove uniformity.
for kind in ['W0_short_f0','W0_long_f0','W0_short_f1','W0_long_f1','W1_short_f0','W1_long_f0','W1_short_f1','W1_long_f1']:
 count=0
 for a,b,d,e,m in itertools.product(range(-4,5),range(-4,5),range(-2,3),range(-2,3),range(1,5)):
  if kind.startswith('W0'):
   # a=P1-c, b=P2-c; d=dv,e=dplus.
   S=min(0,a-d)
   if kind.endswith('f0'):
    if a< -2 or (a==-2 and d==-2):continue
    I=a+1 if 'short' in kind else a
    target=S if 'short' in kind else S-1
    assert I>=target
   else:
    if 'short' in kind:
     if a< -1 or b< -1:continue
     I,II,target=a+3+e,a+b+2,S
    else:
     if a<0 or b!=0:continue
     I,II,target=a+e+2,a+b,S-1
    assert min(I,II)>=target
  else:
   # a=r, b=rm for f0 or rplus for f1; d=dv,e=db.
   R=a-1-d;S=min(0,R)
   if kind.endswith('f0'):
    if a<0 or b<(1 if 'long' in kind else 0):continue
    I,II=a+e+2,a+b
   else:
    if b<0 or (a<0 and d< -1):continue
    I,II=a,R+b+2*m-1
   if 'long' in kind:I-=1;II-=2
   target=S-1 if 'long' in kind else S
   assert min(I,II)>=target
  count+=1
 counts[kind]=count
out=Path(__file__).with_suffix('.json')
out.write_text(json.dumps({'all_pass':True,'counts':counts,'scope':'bounded exact regression; uniform implications proven in CONSUMER_LINKAGE_AUDIT.md','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
print(counts)
