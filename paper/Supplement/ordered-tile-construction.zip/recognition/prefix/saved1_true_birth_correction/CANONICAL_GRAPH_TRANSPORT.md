# Canonical signed graph transport: the reserved free-arrow check closes

Let p=(D,N) be a reduced odd-type proper vector (D+N odd), let q'=(D+N,D-N), and Z(x,y)=(-y,x-1). Assume the genuine global field conjugacy Fp=Fq'∘Z+h0 and the established canonical forced/free descriptions. Then, as PHYSICAL directed graphs,

             Z G_p(epsilon,+1) = G_q'(-1,epsilon),  epsilon=±1.

No new scalar/rank inequality, native identification, or recurrence assumption is needed to prove this graph equality. The earlier audit's reserved free-choice binding is discharged by the following table.

## Actual arcs and physical phases
Write H,V for the odd p arcs and H',V' for q'. Their exact lifted identities are

  Z H_i=V'_i,                  0≤i≤2D−1;
  Z V_j=H'_(D+N−1−j)−U',      0≤j≤D+N−1.

The first is immediate directly from the doubled Christoffel definition: odd H uses the axial word edges(D−N,2N), exactly q' V. The second is the reverse horizontal/vertical Christoffel correspondence already used with these SAME physical endpoints in ANCESTRAL_PSI_V_CUT_PROOF §1 and ACTUAL_CHAIN_AND_H_TRANSFER audit; no creator parameter enters it. Its endpoints are ZV0=(0,−1)=H'last−U' and ZVlast=(1−D−N,N−D)=H'0−U'. The floor-word reversal (reverse the paired lower mechanical word, exchange its horizontal and vertical traversals) gives the intervening path. This is the usual exact arc identity, not merely equality modulo a deck lattice. Z sends even physical sites to odd and vice versa. U' has even sum, so the displayed deck translation does not change physical phase.

## Complete direction table
Directions E,N,W,S below are displacements. In each row the target is the corresponding ACTUAL primed endpoint or interior arc position above. Rot maps E→N, N→W, W→S, S→E.

source class             p(+,+)   rotated   p(-,+)   rotated
H0                        S         E         S         E
H interior even           W         S         E         N
H interior odd            S         E         N         W
Hlast                     S         E         N         W
V0                        E         N         E         N
V interior even           E         N         E         N
V interior odd            S         E         S         E
Vlast                     W         S         E         N

For epsilon=+ the rotated column is exactly q'(-,+): internal H' uses positive axial input, H'0 S, H'last N; V'0 E, V'last E, internal V' even E/odd S. For epsilon=− it is exactly q'(-,−): internal H' positive axial, H'0 N, H'last N; V'0 E,V'last W, internal V' even W/odd N. In reading the table remember V0 maps to H'last, not H'0, and the site phase reverses. These two facts eliminate the apparent sign mismatch.

The odd (-,+) column follows directly by reflecting (+,-) through Rp=Up+Vp+I. Reflection reverses each arc and exchanges its endpoint labels, preserving physical parity. No rank formula is being reflected in place of an actual arrow. Every deck translate follows because Z_linear Up=V' and Z_linear Vp=−U'.

## Forced and black roots
The harmonic conjugacy preserves the true color and maps BOTH black inputs to BOTH black inputs. It also maps each finite elementary-square unit proof to a finite proof with exactly the rotated direction. Applying the inverse map gives equality of the forced sets and their unique arrows, not just inclusion. Thus, with the genuine canonical forced/free classification, the free table establishes equality of the ENTIRE graphs. This argument does not require a numerical rank or a false single-parent-containment theorem.

## Pure families and the genuine root
The reciprocal-even pure package forced/EXACT_FORCED_CLASSIFICATION_AND_THREE_STEP_RETURNS gives precisely the same table, explicitly including d=3 and all four endpoints. Its §42 reflection check identifies the canonical (-,eta) policy, not just a convenient free completion. The pure2 COMPLETE_CANONICAL_CLASSIFICATION and PURE2_ACTUAL_STANDARD_AND_ALTERNATE_THEOREM likewise give this table at all K≥1, including native exceptional outgoing stars. Consequently no arrow exception remains for the pure conjugates in this lemma. In particular p=1/2 maps to the genuine q'=1/3 root; p=1/(2K+2) maps to near-one even (2K+1)/(2K+3), K≥1. The root is NOT obtained by illegally putting K=0 in the doubled-ladder formula. The pure scalar exceptions Phi(H0)≠Phi(V0), and special rank values at V0, change neither the free arrow table nor the arc identities.

## Consequence and limits
In the source-chain formula Psi=constant−Phi'_epsilon∘Z, the earlier genuine Phi monotonicity on q'(-,epsilon) now transfers to precisely the old p(epsilon,+) graph used in the current A chart, including actual pure-born fields. Its strict rank and finite private-square paths transport too; the affine chart origin is translated on both sides. Antagonistic current siblings still use their actual epsilon, not the birth epsilon, as proved in the all-creator scalar note. There is NO alternative-policy substitution needed.

This closes the free-arrow reservation in GLOBAL_SCALE_PRODUCER_SYNCHRONIZATION_AUDIT. It does not by itself instantiate every other current standard-stage boundary/donor/halo input, identify literal corrected helpers, or prove fixed-padding correctness. It removes the specific graph-label obstruction, not all assembly bookkeeping.

Verification: check_canonical_graph_transport.py independently constructs both doubled floor-word arcs and both signed free tables for every coprime odd-type 0<N<D≤60. All 207582 physical arrow checks and exact arc checks pass, including the genuine root and both pure families. This finite regression is supplementary to the parameter-free arc identities and eight-row table above, not an all-parameter proof by sampling. No old policy solver or native values are used in this check.
