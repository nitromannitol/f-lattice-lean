# B0/B1 closure relative to the complete strictly-earlier packet

## Result
The B0/B1 portion of QUANTIFIED_PRODUCER_SYNCHRONIZATION is dischargeable from the saved universal producers and the complete earlier signed packet, with the ordering correction below. This is a logical assembly/review of the cited proofs, not an independent reimplementation of all their geometry. No current recurrence or native recognition enters. In particular this is stronger than leaving unspecified “full binding remains”.

The necessary correction is to split the pre-rank range calculation from the pre-rank EDGE transfer: pointwise boundary comparison comes BEFORE strengthened strips/W1; rounded edge transfer comes AFTER W1. Putting all of B2 after W1 would conceal this dependency.

## 1. Comparison M is genuinely recurrent, not an assumed minimum
For w=u s 3^k use the actual source pair and signs from the quantified theorem. Set zeta=Z(z-lv). The all-creator identity gives A(z)=F'(zeta)+h0(z-lv) and Psi(z)=K-Phi'_epsilon(zeta), hence

 M(z)=h0(z-lv)+min(F'(zeta), F'(zeta)-Phi'_epsilon(zeta)+K).

K is an integer: evaluate at any physical lattice site, since every field, affine term and harmonic h0 is integral. The earlier all-integer-threshold chain-minimum theorem therefore makes M globally binary and physically recurrent. Z is an actual input-graph isomorphism, h0(z-lv) harmonic; lv has even phase. This proves M recurrence without current F and without assuming that minima of recurrent fields generally recur. Canonical graph transport pays the exact old sign used in Psi, including pure-born q' and saved1 antagonism.

## 2. Source halo and sewing
H_SOURCE_ANCESTRAL_CLOSURE proves the entire H/input halo from the earlier signed chain V trace and its core bounds, calibrated at indices0,1. V_SOURCE_TRACE_TRANSFER_FINAL proves the entire V/input halo from the earlier chain H trace, with the genuine core substitutions and terminal gap0/penultimate gap1. Pure predecessor tables replace nonbase cut formulas at their actual own creation; the exceptional W0 near-one source contributes h0-1 at the single exterior port, not an invented proper extension.

FOUR_MEMBERSHIPS_CLOSED supplies every exiting directed input representative, using the actual parity rectangles. BOUNDARY_DECK_HALO_REDUCTION gives all boundary duplicate cocycles, global periodization and input compatibility from these full halos and the genuine raw reflection. At the exceptional exterior (-1,0), periodization changes its value from -1 to0; the sole affected root is V0 and its Laplacian changes from -1 to0. Preserve its reflected counterpart. All other stars are unchanged from M. Thus the current F is globally binary, has its true deck/reflection and agrees with M on E. This step is independent of W1, rank and current recurrence.

B0 consists of actual Farey identities, exact source-character cancellation, graph transport, and genuine boundary geometry just used. The source and deck pieces have explicit all-creator proofs; the staircase cover/inner-boundary characterization is the already established geometric input to these saved producers. It is not a finite-data extrapolation or a claim that an arbitrary convex hull is E.

## 3. Ordinary strips before any current range or W1
The basic p-donor shielding is stage1_audit/P_DONOR_SHIELDING_AUDIT: earlier chain maxima plus actual W0/W1 calibration yield Psi>=0 on the full basic Ep+lv. Its W1 k0 cases use the TRUE earlier birth sign and actual pure table when applicable.

For the q donor use c0_audit/C0_REFLECTION_AND_BOUNDARY with the subsequent ARC_INCLUSIONS_WITH_EXACT_ENDPOINT_REPAIRS. The latter supersedes the earlier full-arc inclusion sentence: W0's missing Vq+I and W1's missing Up+Hq0 are actual directed-halo inputs whose values were paid in step2. The exact difference involution then pays the four donor arcs. Two-sided recurrent comparison of the old Fq with recurrent M gives equality on all E(q)+WUp; no current recurrence or whole-donor nesting is needed for that comparison.

NEAR_BOTTOM_TWO_DONOR_COVER §5 gives actual child-E representatives for BOTH physical parities at every integer t in [1-d,L/2]. Their donor coordinates lie in the old ordinary zero strips. Consequently current F=0 there. I-reflection t->L-t and zero primary periodicity extend this to the full ordinary interval [1-d,n+2d-1]; there is no integer gap between the two halves.

For the odd conjugate use ODD_NEAR_BOTTOM_COVER_PROOF, INDEPENDENT_ODD_P_DONOR_CONJUGACY and ODD_TWO_Q_DONOR_SHIELDING. Its s1 branch pays entire q donors by earlier maxima; s3 only needs the near-bottom subset, where the earlier D sign extension pays the competing offer. This is enough for the cover, so no stronger all-donor assertion is imported. The odd cover includes BOTH opposite-parity representatives modulo the doubled primary. Reflection completes its ordinary zero strip. Genuine simultaneous odd/even conjugacy transfers the ordinary h0 strips, without requiring a same-level recurrence theorem. All these donor values are earlier-field evaluations against already recurrent raw M.

## 4. Pointwise ranges can precede W1: explicit boundary guards
This is the missing ordering detail, not an additional analytic hypothesis.

Put v=epsilon Vp, sigma=epsilon Up and
 P=F-F(.-v)-epsilon ap.z,
 Dplus=F-F(.+sigma), Dminus=F-F(.-sigma).
On the actual native H and V boundary roots the paid data are

 H: P(H0)=c0, P(Hi)=c0-1 for i>0; Dplus=Dminus=0;
 V: P=c0; 0<=Dplus<=2, -2<=Dminus<=0.

The H price follows H_PRICE_VS_PINGPONG_E plus the strict SOURCE inequality already paid in step2, not an assumed outgoing pair invariant. The shifted H query used there is H+Vp. Its t interval is the H interval shifted by -K, K=-t(Vp), 0<K<T; its s interval is shifted by2epsilon. The H bounds L<=s<=T-(d-n) put it in the true E rectangle in both parities; hence the raw minimum formula is licensed at that shifted query. The H slip values follow the ordinary zero strip, since sigma changes t by-2 and its physical phase is even.

The V price follows the ordinary h0 strip at z,z-v. The V slip ranges follow ANCESTRAL_PSI_V_CUT_PROOF, using strictly earlier P(H), exact V lifts and the already paid current ordinary strip for the terminal value. It never uses current strong raw monotonicity. Pure predecessor formulas remain their genuine literal ones.

Deck drifts are P(U)=-1,P(V)=0; Dplus(U)=Dminus(U)=0, Dplus(V)=2,Dminus(V)=-2. Thus on the OTHER boundary arcs H+V and V+U, the same three upper bounds hold:

                   P<=c0, Dplus<=2, Dminus<=0.

Apply recurrent comparison to M versus each globally binary shifted-F affine competitor on X=E minus its four closed arcs. Every incoming exit from X lies on those actual arcs. F=M at X and its exits. Therefore these upper bounds hold throughout E. This comparison uses recurrence of M, NOT recurrence of F; shifted F need only be binary superharmonic. The boundary here is the incoming boundary of the strict interior, not an unpriced exterior halo of E. No W1 is needed for this pointwise comparison.

## 5. Strengthened strips, then W1
The two extra zero seeds propagate by newzeros/PAIR_INDUCTION, from earlier standard seeds and genuine F=M on the explicitly enclosed point b+(-1,1), with its separate W0 near-one exception. BASE_TWO_PIXEL_ZEROS and NO_ODD_SLIP_AUDIT §4 initialize both genuine pure families including root.

The pointwise Dminus<=0 plus its actual secondary drift supplies the needed negative transverse semigroup (ALL_SLOPE_STEP strip paragraph); the native northwest H shifts and zero endpoint sandwich give the enlarged even zero strip. For h=F-h0, the EXACT identity P-c0=h(s,parity)-h(s-2,parity), proved in NO_ODD_SLIP_AUDIT, uses the now-paid P upper bound. The odd conjugate seed, reflection, and native northeast V shifts then sandwich the enlarged odd-parity h0 strip. No odd-slip hypothesis and no current rank is used. These are exactly the strengthened strips required by W1_CONSTRUCTOR.

The corrected schedule is consequently:

 earlier complete signed packet
 -> recurrent M -> full source halo -> sewn binary F
 -> ordinary donor strips -> actual boundary P,D values
 -> pointwise upper ranges + extra zero seeds -> strengthened strips
 -> current W1 -> rounded EDGE transfer -> current ranks -> strong raw/clean.

## Scope of the closure
Relative to the genuine earlier complete packet and the cited proved staircase geometry, no additional B0/B1 inequality remains unidentified in this assembly. The nontrivial guards have been located and paid above, rather than absorbed into current recurrence. The strongest remaining synchronization task is B2 beyond these pointwise bounds: the precise two-sided semigroup/range and rounded edge-transfer/cut-tip inputs used by the rank theorem, followed by current strong-step assembly. This note does not assert those remaining steps, literal native endpoint recognition, or implementation correctness. Its independence is a mathematical dependency and substitution audit of the named producers, not a second derivation of every producer theorem.
