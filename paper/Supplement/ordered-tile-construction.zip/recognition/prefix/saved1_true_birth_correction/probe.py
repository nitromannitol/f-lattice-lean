import sys
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
add=lambda *v:tuple(map(sum,zip(*v)));sc=lambda k,v:tuple(k*x for x in v);b=lambda v:(v[1],-v[0]);vv=lambda v:(v[1]-v[0],sum(v));dot=lambda x,y:sum(a*b for a,b in zip(x,y))
for word in sys.argv[1:] or ['13','113','123']:
 ms,_=alg.get_odometers(word);_,zf,af,rf=getFracs(word);a=(af.denominator,af.numerator);Z=(zf.denominator,zf.numerator);A=add(Z,sc(-1,a));W=1-word.count('1')%2;d,n=A;TA=-dot(b(A),vv(A));LA=sum(A);ca=d-n;T=-dot(b(Z),vv(Z));K0=-dot(b(a),vv(Z));K=-dot(b(A),vv(Z));F=review.Field(Z[1],Z[0],alg.export_tile(ms[1])).g
 D=lambda z:F(z)-F(add(z,sc(2*(2*W-1),A)))
 hist=Counter();ex={}
 for x in range(-3*d,4*d+1):
  for y in range(-2*d,4*d+1):
   t=n*x-d*y;s=LA*x+ca*y;lo,hi,sl,sh=(n-TA,d,2-ca,2*TA+LA-2)if(x+y)%2 else(1-TA,LA-1,0,2*TA+2*n)
   if not(lo<=t<=hi and sl<=s<=sh):continue
   u=(x,y)
   if W==0:queries=[add(u,sc(-1,vv(A))),add(u,sc(-1,vv(A)),sc(2,A))]
   else:
    xx=add(u,Z,sc(-2,A));queries=[add(xx,sc(-1,vv(A))),add(xx,sc(-1,vv(A)),sc(-2,A))]
   ds=tuple(D(z)for z in queries);hist[ds]+=1
   if min(ds)<-1:ex.setdefault(ds,{'u':u,'queries':queries,'heights':[(F(z),F(add(z,sc(2*(2*W-1),A))))for z in queries],'t':[dot(b(Z),z)for z in queries]})
 print(word,'W',W,'a,A,Z',a,A,Z,'K0,K,T',K0,K,T,'hist',hist,'bad',list(ex.items())[:4],flush=True)
