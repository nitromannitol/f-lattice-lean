# Actual ordinary outer-source ledger

Scope: current parents C odd,Z even; Q=2C+Z even STANDARD SHORT, O=C+Z odd ALTERNATE LONG. This audits literal order, origins, affine slopes and minimal remaining proof gates. It does not assume helper upper-right dimensions, finite padding or outer touching constants.

## 1. Literal six-slot tables (zero-based natural indices)
From original_port_offsets.py and original_port_recursion.py, ordinary slots are0,1,2,5; Gl occupies3 and Gr4 in both constructors.

Even STANDARD:
|slot|source|W0 origin|W1 origin|slope|
|0|Z|0|2C|0|
|1|Z|2C+2VC|2VC|2bC|
|2|C|Z|0|0|
|5|C|VZ+VC|VZ+Z+VC|bZ+bC|

Chronological order is[0,2,3,1,4,5], hence qNear,pNear,Gl,qFar,Gr,pFar. The first actual owner is qNear, not the first helper and not the freshly computed child.

Odd ALTERNATE:
|slot|source|W0 origin|W1 origin|slope|
|0|Z|0|2C|0|
|1|Z|2C+2VC+Z|2VC-Z|2bC|
|2|C|Z|0|0|
|5|C|VZ+Z+VC|VZ+VC|bZ+bC|

Chronological order is[0,2,3,4,5,1], hence qNear,pNear,Gl,Gr,pFar,qFar. Compared with STANDARD, far ordinary origins shift+Z in W0 and-Z in W1. These are literal source displacements, not inferred rotations. The Gl outer origin changes as well; neither helper mask is inferred here.

## 2. STANDARD full-polygon shielding: exact conditional closure
Let M_Q be the independently admitted raw two-C comparator in the actual standard frame. Supply stage1/c0 full-polygon identities

 M_Q(v+o0)=F_Z(v), v in genuine E_Z,
 M_Q(v+o2)=F_C(v), v in genuine E_C,

where o0=2WC, o2=(1-W)Z. These are stronger than native-only claims and must have their actual earlier source/deck proof. They directly price both near ordinary sources at additive0.

Let R_X=U_X+V_X+delta, and assume the true current comparator reflection M_Q(R_Q-y)=M_Q(y)-b_Q·y-eta_Q. Parent full polygons are invariant under their own native reflections with the same height jets. Reflection then sends the near masks exactly to the far masks:

 o1=R_Q-o0-R_Z=2C+2VC-o0,
 o5=R_Q-o2-R_C=Z+VC+VZ-o2.

The reflected global-affine prices are

 Z far: F_Z(y-o1)+2b_C·y+g1,
 g1=eta_Q-eta_Z+b_Z·o1;

 C far: F_C(y-o5)+(b_C+b_Z)·y+g5,
 g5=eta_Q-eta_C+b_C·o5.

These gains follow by direct substitution, using b_Q·R_Q=-2eta_Q. They are not claimed to be the original merge's constants until chronological contacts are paid. Actual ordinary native domains are subsets of these full polygons, so those two near identities and current reflection suffice for all four candidate ordinary windows.

## 3. What chronology additionally requires
First qNear fixes the absolute output frame and height. For EACH subsequent insertion with candidate price equal to target throughout its genuine support, one still needs a nonempty overlap with the true prior prefix, where both values equal target. This gives touching minimum0 and forces the candidate calibration. The prefix before qFar is qNear∪pNear∪Gl, not an unordered union containing Gr; before pFar it also contains qFar and Gr. A later contact cannot authorize an earlier scalar.

Full-crop G3 recognition is only the head part of each helper. Complete helper use still requires its G1/G2 values, its internal chronological calibration, actual restored spatial origin, and actual upper-right alignment. A formal source rectangle does not replace any of these premises. Source padding must preserve all claimed sites and contacts.

## 4. Odd LONG ordinary slots: exact smaller gate
The ordinary LONG far masks differ from standard by±Z; they are not images of the near masks under the STANDARD Q reflection. Nor does merely substituting O for C preserve the target raw comparator or its phase gauge. Thus the four standard payments above do not prove the corresponding LONG claims. The actual odd raw target must be evaluated in its correct phase chart (W1 uses x=y+Z), with the verified common gauge in S1/RAW_LONG_COMPARATOR_DUAL.md when duality is used.

For a proof maintaining exact target on every growing prefix, whole-support equality of an incoming source is sufficient but not necessary. Let prefix P already equal target T on D_P, and incoming calibrated source g have true support D_g. The exact sufficient-and-necessary requirements for this insertion to keep the enlarged prefix equal T are:

 g>=T on D_g∩D_P,
 g=T on D_g\D_P,
 and min_(D_g∩D_P)(g-T)=0 for its proposed touching calibration.

The first two imply g>=T on the entire true source support. An incoming source may be strictly above T on old overlap without affecting the merged field. Equality on fresh sites is essential to this prefix invariant. If only final equality is sought, later sources could correct some temporarily high fresh sites; then a different, explicitly tracked invariant is needed.

This ledger does NOT assert that actual LONG ordinary sources match the target on their entire supports. The minimal unsupplied gates are these guarded overlap/fresh-site/contact statements in the real order above. They require actual masks, not an ideal full-polygon source union. Current G3 equality alone cannot discharge them.

## 5. Smallest remaining source obligations after proper G3 recognition
1. Actual helper G1/G2 recognition and internal normalization, if not already sealed.
2. Actual helper restore/UR spatial binding and preservation under padding.
3. STANDARD: stage1/c0 near shielding plus current reflection (then all four candidate ordinary values follow with g1,g5 above).
4. Actual chronological zero contacts for each outer insertion; final canonical LL/height normalization where relevant.
5. LONG: near and far ordinary overlap/fresh-site gates against its own phase-correct target; standard masks are not interchangeable.

No new child recurrence is used to prove these identities. An independent analytic target and earlier fields/geometry must supply them. This is a producer ledger, not a completion announcement.
