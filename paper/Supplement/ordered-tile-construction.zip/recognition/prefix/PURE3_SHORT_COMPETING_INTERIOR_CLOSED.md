# Pure3 SHORT competing arm: every nonterminal index closed uniformly

Let e>=3 odd, q=(e,1),Y=(1−e,e+1),V0=(−1,1), C=P_h=(he+1,h),h>=2. Let u belong to the entire literal reciprocal Dq and1<=j<=h−1. Then

 F_C(u+jY−q)>=G(u+jY).

Combined with PURE3_OUTER_ORDINARY_NATIVE_REDUCTION.md's exactly attaining second arm, this proves the actual analytic SHORT target equals G on all these RIGHT G1 native windows. All e and h are unbounded. Terminal j=h is NOT included.

## Reflection into an actual native carrier
Set Rq=q+Y+(1,−1)=(2,e+1), u'=Rq−u∈Dq, t=h−j−1>=0. The genuine C reflection has center R_C=2C+hY. For r=u+jY−q, its reflected point modulo zero primary2C is

 v=R_C−r−2C=u'+V0+tY.

The independent exact selector difference check_PURE3_SHORT_QUERY_CARRIERS.py proves

 (Dq+V0) minus D_1 = {V0}

for all e>=3. Thus, unless u'=0, v belongs to D_1+tY⊂D_h. The earlier genuine finite roof theorem can be used there, not elsewhere:

 F_C(v)=min(G(v),G(v−(1,1))−v_y+2h).

Reflection gives F_C(r)=F_C(v)+a_C·r+eta_C.

## Two exact base inequalities
Expand the true G secondary jet and its reflection, using t=h−j−1. After subtracting G(u+jY), the two roof offers reduce exactly to

 L(u)=G(u+(1,−1))−G(u)+1−u_y,
 U_j(u)=G(u+2e1)−G(u)+2j.

All h dependence cancels. check_PURE3_SHORT_BASE_ARMS.py uses the literal base selectors and finitely many genuine deck charts to cover both shifted queries, then proves, by exact unbounded affine Presburger emptiness over e=2a+1,a>=1,

 L(u)>=0,
 G(u+2e1)−G(u)+2>=0,

on the ENTIRE Dq. It checks32 nonempty affine regions, including all added q corners; no parameter cutoff or global raw-base-formula extension is used. Since j>=1, both actual offers are nonnegative.

## Sole missing native-carrier point paid physically
If u'=0, then u=Rq and v=V0+tY. Its C harmonic grade is s_C(v)=−2h−2t, lying in the authentic complete harmonic strip [1−2(he+1),2((he+1)+h)−1], because0<=t<=h−2 and e>=3. Therefore F_C(v)=H(v) physically. The site's parity is even, so H(x,y)=x(x−1)/2−((y+1−x)^2−1)/4. Substitution gives identically

 H(v)+a_C·r+eta_C−G(Rq+jY)=0.

Here G(Rq)=−eta_Z by its genuine base reflection. This is a direct physical zero-excess calculation, not a fictitious occupied native site. It pays the whole exceptional branch.

## Exact remaining endpoint geometry
At j=h the same reflected query is u'+V0−Y. Adding V_C moves it to u'+2V0+(h−1)Y. The analogous base inclusion Dq+2V0⊂D_1 is false. The exact missing set in coordinates w=u'+2V0 is:

 * x=−e, e+1<=y<=e+3;
 * y=e+3, 1−e<=x<=0;
 * w=(−2,2).

Union overlaps are harmless. These are boundary families, not the two alternate R2-excess corners being handled elsewhere. A valid terminal proof must pay their physical values or choose another genuine deck representative. The checker prints their exact unbounded Presburger set. No terminal inequality or full LONG endpoint claim is inferred from the interior result.
