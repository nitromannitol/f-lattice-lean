# One stationary-prefix comparison for the corrected standard

**Conditional all-parameter theorem.** Let the earlier, truly proper birth data be odd a=(d,n), even R=(e,r), Z=2a+R, with n,r≥1, d−n≥1, e−r≥2 and the actual Farey determinant. In either saved3 or saved1 in current phase W0 let A=a or Z−a, respectively, so det(A,Z)=1. Set C=A+kZ, Q=2C+Z, k≥1. The standard SHORT's actual right G1 centers are jV_Z, 1≤j≤k, and its left centers are 2C+2V_C−jV_Z. In the correct candidate frame the analytic raw standard minimum agrees with the complete Z field on every one of these whole polygons, up to its prescribed affine jet. Explicitly, for every physical u∈E_Z,

    M_Q(u+jV_Z)=F_Z(u+jV_Z),     1≤j≤k.

The left statement is its exact Q and Z reflection. This pays both orientations of the stationary protected G1 chain in these two proper W0 records. The six separate literal endpoint/pure birth lineages are listed in ENDPOINT_AND_PURE_BIRTH_LEDGER; a rationally proper selected pair alone is not sufficient. The degree of independence, current assumptions, and what remains follow below.

Use the earlier globally admitted standard fields F=F_Z and F_C, their authentic deck jets, earlier F=M on licensed native polygons E, the established closed-E two-level prices, complete physical slip, harmonic/zero strips and high-transverse sign. W0 saved1 needs intrinsic effective-parent price transfer and the genuine predecessor chain maximum; it is not a birth at A with negative residual. Use true spatial placement or else read the statement as pricing the nominal candidate, not identifying an actual restored array. No current native recurrence or agreement is assumed. Put b_S=(n_S,−d_S), V_S=(n_S−d_S,d_S+n_S), t_S=b_S·x, s_S=(d_S+n_S,d_S−n_S)·x, T_S=−b_S·V_S, c_S=(T_S+d_S+n_S)/2, η_S=T_S−c_S. Set v=V_A, K=−t_Z(v), T=T_Z, B=K+kT.

## A single exact arm, and only one lower bound

For y=u+jV_Z the true two Q offers are F_C(y−Z) and F_C(y−V_Z)+b_Z·y+η_Z. On E_C the genuine earlier stationary identity is

 F_C(w)=min(F(w),h(w)+2k−2),   h(w)=F(w−v−2A)+b_A·w+η_A+2.

For H=h−F and D(x)=F(x)−F(x−2A), P(x)=F(x)−F(x+v)+b_A·x, one has H(u)≥0 on ALL E_Z; saved1 actually gives ≥1. For saved3, put q=u−v−2A. If q is in E_Z the two previous raw offers give H=1−[min(0,ψ+1)−min(0,ψ)]≥0. If q is below the lower s edge, a true longitudinal fold gives P(q)≥c_A and H=P(q)−D(u)−c_A+2≥0. Otherwise an off-polygon q can only be above its t edge, and the physical central range gives D(u)≤1 while P(q)≥c_A−1. For saved1 use its authentic earlier chain maximum and reflection (INDEPENDENT_W0_FULL_E_SHIELDING.md). Saved3's stronger full-E H≥1 is FALSE: actual 113 at (−10,36) gives H=0.

The second query y−V_Z is always in E_C. The exact stationary deck drift is H(u+lV_Z)=H(u)−2l, hence the second offer is F(y)+min(0,H(u)+2k−2j)=F(y). It remains only to show that the first cannot undercut it.

Write r=y−Z. With lower true parity boundaries of E_C, define e=1 if t_C(r) is below its lower edge; f=1 if s_C(r) is below its lower edge. The actual representative and its exact pullback are

 w=r−eV_C+2fC ∈ E_C,        F_C(r)=F_C(w)+e(t_C(r)+η_C).

The geometry, including the full second query, follows from the exact parity rectangles and affine projection of u,j. On multiplying by T, the margins at all rectangle/index endpoints have nonnegative coefficient certificates in the five nonnegative variables n−1,d−n−1,r−1,e_R−r−2,k−1 (here e_R is the denominator of R). Because true margins are integers, q+T>0 suffices for q/T≥0; real rectangle corners need not be lattice points. The earlier strict scripts have been replayed after widening in all_proper_G1/. The determinant identities B²−T T_C=2 etc. are used, not numerical fitting.

1. **No transverse fold, no longitudinal fold.** The relative first-offer price F_C(r)−F(r) is min(0,H(u)+2(k−j)−1). This is zero for j<k. For j=k the two no-fold facet constraints jointly imply t_Z(u)≥1−K (not necessarily 1−d_Z). As t_Z(u−v)≥1, the actual zero strip and then the high-t sign lemma give D(u−v)≤0. The exact identity H(u)=P(u−v)−c_A+2−D(u−v) and the rim bound below prove H(u)≥1 there, including saved3.
2. **Only longitudinal fold.** The two relative prices are D(u+2A)+2j and P(u−v)−c_A+1. The first is nonnegative by the complete physical D interval at t_Z(u)+2 (the whole E_Z upper row plus2 is still in range); the second by the rim bound.
3. **Transverse fold (either longitudinal choice).** It occurs only at j=k. In fact with g=1 at even roots and n_C at odd roots the lower facet yields B[t_Z(u)+K+(k−j)T]<s_Z(u)+T(g−1)+2; the upper E_Z row and twelve all-proper positive polynomial bounds imply j=k and place t_Z(u)+K+2 in the complete earlier D interval. Exact deck expansion gives the two relative prices
   P(u−v)−c_A+1+f[D(u−v+2A)−2(k−j)]
   and P(u−v)+P(u−2v)−2c_A+2+(1−f)[4k−2j−D(u−2v)].
   Both are nonnegative: use j=k, 0≤D(u−v+2A)≤2, and D(u−2v)≤2 (on the complete physical band, and beyond its top by the high-t sign). Four symbolic expansions were independently replayed.

**Rim bound used in all three cases.** P(u−iv)≥c_A−1, i=1,2, even if its argument is not native. Its s coordinate is s_Z(u)+2i. If not above E's upper edge, a V_Z translate places it into E without changing P. Otherwise subtract Z. The s coordinates of both P inputs then lie in [h−1,h+4], h=2N for even physical parity, h=D_Z+N−2 for odd. Both are in the full physical harmonic strip, so the shifted P is c_A and the true primary jet subtracts one. The widened proper conditions give N≥3 and D_Z−N≥4. These verify both rim inequalities without relying on an absent native site.

This proves the stated complete right polygon identity. The exact reflection M_Q(R_Q−x)=M_Q(x)−b_Q·x−η_Q, and the analogous authentic F_Z reflection with R_S=U_S+V_S+(1,−1), price the full opposite G1 polygon with its reflected jet: R_Q−R_Z=2C+2V_C. In particular the reflected value is uniquely determined up to the already specified inherited gauge, not fitted anew per parity or per vertex. The true canonical drift F(u+jV_Z)−F(u)=j(b_Z·u−c_Z)−j(j−1)T/2 is the literal j b_Z slope in the global coordinate. The position/gradient binding also retains the genuine helper restore/upper-right alignment hypothesis.

## Consequence for chronological touching, and what this DOES NOT pay

If the true placed G1 leaves are these restrictions and authentic successive joins meet, they all agree with one global target up to their individual scalar, so the literal max-difference calibration fixes every successive G1 scalar and the growing prefix is exactly the target up to the single scalar of its first leaf. This is a sufficient principle, not a claim that every fixed finite array has a nonempty untruncated contact. The outer initial Z source j=0 is the earlier basic donor comparison, not a positive-layer use of the r2 lemma.

G2 must still be identified on its actual fresh sites with true overlap signs/contacts. A proposed shortcut that would put ALL G2 inside the current far-C donor modulo the Q deck is FALSE at the explicit proper example in G2_NESTING_AND_FAR_DONOR.md. W1 arithmetic needs its own signed physical comparison; neither query is always directly in E_C there. LONG's actual comparator and far ordinary windows also differ. The prior eight-row G3 theorem handles proper restored G3 raw prices, not these other tasks. The ordinary near/far standard conditional prices and the exact literal outer insertion order are in ORDINARY_SOURCE_LEDGER. The present theorem is not the all-word recurrence theorem or a standalone assertion of any newly constructed native array's recurrence.
