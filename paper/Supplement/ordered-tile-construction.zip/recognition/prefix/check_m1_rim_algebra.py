import sympy as s,json,hashlib
from pathlib import Path
d,n,e,r=s.symbols('d n e r');A=s.Matrix([d,n]);R=s.Matrix([e,r]);Z=2*A+R;v=lambda X:s.Matrix([X[1]-X[0],sum(X)]);a=lambda X:s.Matrix([X[1],-X[0]]);T=lambda X:-a(X).dot(v(X));c=lambda X:(T(X)+sum(X))/2;eta=lambda X:(T(X)-sum(X))/2;ss=lambda X,Y:s.Matrix([sum(X),X[0]-X[1]]).dot(Y);h=lambda X:(X[0]**2+2*X[0]*X[1]-X[1]**2-2*X[1])/4
K=-a(A).dot(v(Z));VV=v(A);D,N=Z;TT=T(Z);L=sum(Z);delta=s.Matrix([1,-1]);out={}
for W in[0,1]:
 G=s.groebner([d*r-n*e-(1-2*W)],d,n,e,r,domain=s.QQ)
 pts=[Z+v(Z)+delta,Z+s.Matrix([1,0])+VV]if W==0 else[s.zeros(2,1),s.Matrix([0,-1])+VV]
 grades=[L-TT,N-K]if W==0 else[0,D-K];longs=[TT+2*N,TT+L-2]if W==0 else[0,2-D+N]
 expressions={f'rim{j}_t':a(Z).dot(p)-grades[j]for j,p in enumerate(pts)};expressions.update({f'rim{j}_s':ss(Z,p)-longs[j]for j,p in enumerate(pts)})
 if W==0:
  p=2*VV+2*A
  expressions.update({'p_t':a(Z).dot(p)-(2-2*K),'p_s':ss(Z,p)-(2*K-4),'harmonic2v':h(2*VV)+T(A)+2*c(A),'birth_first':2*a(A).dot(-R)-2*c(A)-T(A)-h(2*VV)-2,'birth_second':-eta(R)+2*a(A).dot(-v(R))-2*c(A)-T(A)+a(R).dot(p)+eta(R)-h(2*VV)-2,'harmonic_minusVR':h(-v(R))+eta(R)})
 for key,val in expressions.items():
  rem=G.reduce(s.expand(val))[1];assert rem==0,(W,key,rem);out[f'{W}/{key}']=str(rem)
p=Path(__file__);p.with_suffix('.json').write_text(json.dumps({'identities':out,'producer_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n');print('PASS',len(out))
