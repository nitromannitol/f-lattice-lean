# All-proper W1 SHORT G1: cone extension, birth sign, and reflection

## Exact scope
The W1 RIGHT standard-prefix value proof extends to the true proper birth cone

 n>=1, d-n>=1, r>=1, e-r>=2,

with birth a=(d,n),R=(e,r),Z=2a+R. Saved3 uses A=a, det(a,R)=-1; saved1 uses A=a+R,det(a,R)=+1. Thus det(A,Z)=-1. Actual fraction parity and determinant constraints are retained; polynomial certificates prove inequalities even on a larger relaxed positive cone.

For C=A+kZ,k>=1 and u in E_Z, all RIGHT G1 scans at y=2C+u+jV_Z,1<=j<=k satisfy the genuine canonical W1 two-offer target M_Q(y)=F_Z(u+jV_Z), provided the earlier-field and stationary-source premises in the preceding proof are supplied. Reflection gives the matching LEFT scans. This is a canonical full-polygon value statement. Actual helper UR alignment, chronology, scalar normalization and inclusion of the nominal charts remain separate recognition inputs.

## Fresh widened certificates, originals preserved
All four scripts were copied into this directory, replacing only the strict-cone substitution by
 n=u+1,d=u+v+2,r=w+1,e=w+h+3,
with nonnegative u,v,w,h. k=j+1, except the nonfinal arm1 proof uses k=j+2.

* Four-alias boxes:256 facets.
* e2 never, e1 only final:256 facets.
* f2=0 harmonic r=1:4 facets.
* Final e0/e1 slip guards:8 facets.

All524 facets pass exact nonnegative-polynomial checks. No original strict-cone script or receipt is overwritten. The remaining elementary inequalities in the value proof remain valid: D_Z>=7, K>2, and the harmonic-strip/zero-strip endpoint inclusions need only these bounds and D_Z+N_Z>=3. The earlier actual-field premises must themselves be available at the relevant proper fractions; widening a geometry certificate does not establish an unavailable source theorem.

## Explicit saved1 Hhat orientation
The global signed donor identity in strip_geometry/ODD_TWO_Q_DONOR_SHIELDING.md is evaluated in current W1, saved-last1, k=0 of that identity. Its effective odd parent is A=Z-a, while the genuine old birth parent is a. In that document eps=2W-1=+1 and eps0=-1. Therefore

 Psi(u)=c0+2-Phi_plus(u),  c0=(T_a+L_a)/2.

The actual source expression for the same Psi is

 F_Z(u-V_A+2A)-F_Z(u)+a_A.u+eta_A,

because the extra2(1-W) is0. This is exactly Hhat(u)=r-D(u-V_A), with no scalar change. Since u itself is in E_Z, the earlier intrinsic-chain maximum max_E Phi_plus<=c0+2 proves Hhat>=0 throughout E_Z. One must use Phi_plus, not Phi_minus, and the actual birth a, not an artificial positive Z-2A. The earlier maximum theorem includes its mate-admission premises and is not inferred from recurrence alone.

Saved3 uses the separate authentic three-case full-E argument giving Hhat>=-1. All active offer checks in W1_COMPLETE_RIGHT_PREFIX_VALUE_PROOF.md then apply without alteration on this wider cone.

## Genuine W1 standard reflection and the scan origins
Let U_C=2C,U_Z=Z,Q=2C+Z,V_Q=2V_C+V_Z and
 R_X=U_X+V_X+delta, delta=(1,-1).
The actual W1 target in its standard frame is

 M_Q(y)=min(F_C(y),F_C(y-V_Z-Z)+a_Z.y+eta_Z+2).

Use ONLY the earlier genuine C reflection
 F_C(R_C-x)=F_C(x)-a_C.x-eta_C,
and its primary/secondary characters. The two offers interchange under y->R_Q-y, with common added jet

 M_Q(R_Q-y)=M_Q(y)-a_Q.y-eta_Q.

For an explicit check put w=y-V_Z-Z. The reflected first offer is
 F_C(w)-2a_C.y-2B+2-T_C-2eta_C,
where B=M(C,Z), a_C.Z=1. The target second offer plus the claimed common jet is the same, because
 eta_Q=T_C+2eta_C+2B+eta_Z.
The other offer follows by applying this involution twice: a_Q.R_Q=-2eta_Q, so the common jets cancel. This proves reflection for the canonical comparator without assuming current Q recurrence or current native recognition.

The RIGHT G1 origins (including the near ordinary Z carrier at j=0) are

 o_R(j)=2C+jV_Z, 0<=j<=k.

Reflecting the whole genuine parent polygon E_Z about R_Z gives LEFT origins

 o_L(j)=R_Q-o_R(j)-R_Z=2V_C-jV_Z.

Thus o_L(0)=2V_C is precisely the actual W1 far ordinary Z origin in the literal standard six-slot table. The j>=1 origins are the nominal reflected SHORT G1 scan origins. These are physical origins, not residue classes or a parity-changing rotation.

In global-affine coordinates the RIGHT scan slope is j*a_Z; the reflected LEFT slope is2a_C-j*a_Z. More precisely, if the RIGHT calibrated source is F_Z(y-o_R)+ell_R.y+c_R, its reflected source is

 F_Z(y-o_L)+(a_Q-a_Z-ell_R).y
   + eta_Q-eta_Z+a_Z.o_L+ell_R.R_Q+c_R.

This follows by substituting the two genuine reflections, and records the scalar needed for actual calibration. Equality to a normalized raw helper cannot be inferred from the nominal origin alone.

## Conclusion
The RIGHT G1 values for1<=j<=k and their reflected LEFT values are uniformly paid for both saved1/3 throughout the true proper cone, conditional only on the explicitly earlier canonical source/price/strip premises. The ordinary j=0 carrier uses the separate near shielding theorem; the G1 proof does not bootstrap that premise from current recurrence. G2/G3, helper alignment and chronological contacts are not newly certified by this addendum.
