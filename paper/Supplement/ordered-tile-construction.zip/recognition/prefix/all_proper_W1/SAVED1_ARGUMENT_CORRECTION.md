# Saved1 argument correction

The previous version incorrectly wrote Phi_plus(R_Z-u) in the W1,saved1 equality. The authenticated ODD_TWO_Q_DONOR_SHIELDING.md Section1 says Psi(u)=c0+2-Phi_plus(u). The main paper now uses that exact argument and does not invoke reflection in this step. The upper bound is unchanged because u is in E_Z. No coefficient script or receipt changes. This correction also supersedes the same reflected-argument equality in my earlier parent progress message.
