# Proper UNC odd-ALT ordinary middle p slots: both phases, m=1

## Conditional pointwise theorem

Let A be the actual odd parent, Z the actual even parent, O=A+Z, Q=2A+Z. Use the genuine proper birth records saved3 (A=a,Z=2a+R) or saved1 (A=a+R,Z=2a+R, opposite birth phase), with all-proper bounds n_a>=1,d_a-n_a>=1,r>=1,e-r>=2 and det(A,Z)=1-2W. Retain the genuine earlier standard fields, parent nesting/donor identities, physical price/slip/harmonic bounds and the licensed stationary F_O polygon identity.

Define the RAW odd-alternate comparator in the actual y frame by

 T_W(y)=min(F_O(x),F_O(x+V_Z)-b_Z.x+c_Z+1-2W), x=y+WZ.

For every u in the WHOLE E_A, its ordinary RIGHT p slot satisfies

 W0: T_0(u+V_Z)=F_A(u)+b_Z.u-c_Z,
 W1: T_1(u+Z+V_Z)=F_A(u)+b_Z.u-c_Z+2.

The reflected LEFT slots are respectively E_A+2Z+V_A and E_A+V_A-Z. Their complete canonical global-affine prices are

 RIGHT: F_A(y-o_R)+b_Z.y+eta_Z+2W, o_R=WZ+V_Z;
 LEFT:  F_A(y-o_L)+b_A.y+eta_A+1-W,
        o_L=2Z+V_A for W0, V_A-Z for W1.

These are exactly natural ordinary p slots4 and3 of getAltOddTileFull, respectively (zero-based). No helper-origin, helper-slope or helper-UR hypothesis is used: they are ordinary standard-parent occurrences.

## 1. Why m=1 is licensed, rather than extrapolated

The prior LONG G2 proofs use O=A+mZ and were stated for m>=2. Their geometry has now been independently rerun with m FIXED TO1, not inferred from those statements. The copied scripts in this directory use the exact proper-cone substitution and retain both real saved birth cases:

 - audit_long_w0_g2_geometry.py:64/64 actual polygon/fold facets pass;
 - audit_long_w0_g2_rim.py:32/32 harmonic-rim and transverse margins pass;
 - audit_w1_g2_long_geometry.py:116/116 polygon/fold, central-slip, and selected-f0 lower-rim margins pass.

Every check is an unbounded positive-coefficient certificate, with the existing exact determinant reductions and integer-slack argument. No extra alias is needed. In both phases the same actual lower-longitudinal failure indicator f licenses w=w0+2fO in E_O.

W0: the competing query is q=u+2V_Z and w0=q-V_O=u-V_A+V_Z.

W1: after removing the genuine zero primary2O from the second query, q=u-2A+2V_Z and w0=q-V_O=u-2A-V_A+V_Z.

The old W1 script comment includes a misleading +Z in its description of w0; the polynomial formulas themselves correctly describe the LONG coordinate just displayed, with NO +Z. The m=1 rerun checks those formulas. The auxiliary SHORT variable x=u+Z-2A is distinct from the LONG root x'=u-2A.

## 2. W0: exact nested first offer and competing lower bound

Reflected odd p-donor nesting, used just once, gives F_O(u+V_Z)=F_A(u)+b_Z.u-c_Z. This point lies in E_O by the already proved whole-polygon nesting. It supplies attainment independently of the competing offer.

Put F=F_Z, v=V_A, P(z)=F(z)-F(z+v)+b_A.z, D(z)=F(z)-F(z-2A), H=h-F, and S=F_A(u)-F(u)=min(0,H(u)-2). The normalized competing query needs F_O(q)-F(q)>=S-1, exactly as in LONG_W0_G2_CLOSED.

At the freshly licensed fold w0+2fO, the exact two constituents relative to F(q) obey

 I-(H-3)=1+D(u-v)+f[D(u-v+2A)+2],
 II-(H-3)=P(u-2v-2A)-c_A+2m-1, if f=0,
 II-(H-3)=P(u-2v)-c_A+1+D(u-v), if f=1.

Here m=1. The genuine central D interval gives both displayed D values>=-1. The shifted longitudinal fold gives P(u-2v-2A)>=c_A-1, so the f0 difference is >=2m-2=0, still sufficient at1. On f1 the actual lower-edge condition forces s_Z(u)<0; the independently rerun harmonic-rim bounds give P(u-2v)=c_A exactly. Therefore the f1 difference is>=0 too. Both competing constituents are >=H-3, hence >=S-1. This proves the W0 RIGHT identity without presuming the old m>=2 threshold.

## 3. W1: exact nested first offer and the surviving extra unit

The W1 far p donor at x=u+2Z+V_Z gives

 F_O(x)=F_A(u)+b_Z.u-c_Z+2.

The actual target y=x-Z=u+Z+V_Z is therefore the stated ordinary RIGHT location. The second argument may be replaced by q=x+V_Z-2O=u-2A+2V_Z. Exact Z-deck normalization gives its target relative to F_Z(q) as S-1, where S=F_A(u)-F_Z(u-2A). This is the genuine LONG minus-one normalization, not the SHORT one.

Use x0=u+Z-2A, r(z)=eta_A-Pstd(z), R=r(x0)-1-D(x0-v), and S=min(0,R). The exact LONG transformation decreases the two old SHORT table constituents by1 and2 respectively. Thus it is enough that I_old>=R and II_old>=R+1.

The fresh m=1 geometry supplies the same actual central D bounds and selected-f0 lower harmonic bound as the earlier proof. For f0, r(x0-v)>=1 and D(x0-v)>=-1 give II_old-R>=1. For f1,

 II_old-R=r(x0+2A-v)+2m-1>=1

because the genuine lower harmonic range gives r(x0+2A-v)>=0 and m=1. The earlier first-constituent inequality still gives I_old>=R. Hence both LONG constituents are >=R-1>=S-1, while the nested first offer supplies exact attainment. The old numerical bound >=3 is replaced by the correct >=1, which is exactly sufficient.

## 4. Genuine raw reflection and literal ordinary slots

The raw comparator reflection, not the standard Q reflection, is

 T_W(R_W-y)=T_W(y)-b_Q.y-eta_Q-1,
 R_W=Q+V_Q+(1,-1)+(1-2W)Z.

Using the actual old A reflection center R_A=2A+V_A+(1,-1), the reflected ordinary origin is R_W-o_R-R_A. This equals2Z+V_A in W0 and V_A-Z in W1, exactly the literal ordinary middle LEFT slot. Its slope is b_Q-b_A-b_Z=b_A.

source_binding.py independently checks these vector identities, the actual getAltOddTileFull middle-slot formulas, and the full reflected scalar. The latter reduces to eta_A+1-W, while RIGHT has eta_Z+2W. Both phase scalar reductions are exact modulo the proper determinant relation. The extra1 in the RAW reflection constant is essential.

No current alternate height theorem was used to infer this reflection; it is the independently established algebraic reflection of the global two-offer comparator using genuine standard fields.

## 5. Native and chronological limits

Because actual earlier native A is contained in E_A, the full-polygon statement covers each authentic ordinary middle p occurrence at its literal source position. It establishes the canonical nominal price there. Actual greedy scalar selection still requires the genuine chronological contact/normalization argument; the theorem does not fill absent native vertices, identify unspecified current native values outside their licensed chart, or prove other ordinary/G3 sources. It is not a recurrence assertion.

The genuine standard O and its stationary polygon representation must be available from the independent standard stage before this alternate step. The m=1 argument is an analytic specialization with freshly checked geometry, not a claim that a nonexistent zero-length LONG helper was run by the implementation.
