import sympy as s
import json,hashlib
from pathlib import Path
rows=[]
for saved in [3,1]:
 d,n,e,r,k=s.symbols('d n e r k');D=2*d+e;N=2*n+r;ad,an=(d,n)if saved==3 else(d+e,n+r);TA=ad*ad+2*ad*an-an*an;K=(ad+an)*D+(ad-an)*N;T=D*D+2*D*N-N*N;TC=TA+2*k*K+k*k*T;DC=ad+k*D;NC=an+k*N
 G=s.groebner([d*r-n*e-(1 if saved==3 else -1)],d,n,e,r,k,domain=s.QQ)
 a,b,c,f,j=s.symbols('a b c f j');sub={n:a+1,d:a+b+2,r:c+1,e:c+f+3,k:s.Integer(1)}
 for p in [0,1]:
  tl,th,sl,sh=(an-TA,ad,2-ad+an,2*TA+ad+an-2)if p else(1-TA,ad+an-1,0,2*TA+2*an)
  cl,ch,cs,ct=(NC-TC,DC,2-DC+NC,2*TC+DC+NC-2)if p else(1-TC,DC+NC-1,0,2*TC+2*NC)
  zh=T+D+N-2 if p else T+2*N
  for it,t in enumerate([tl,th]):
   for iss,ss in enumerate([sl,sh]):
    tz=K*t+ss;sz=K*ss+2*t
    tc=(TA+k*K)*t+k*ss+TA*(TA+(k-1)*K-k*T)
    sc=(TA+k*K)*ss+2*k*t+TA*(2*k+2)
    qs=[tc-TA*cl,TA*ch-tc,sc+2*TC*TA-TA*cs,TA*ct-sc,tz+TA*(K-1),tz+TA*K-TA*(3-D-K),TA*(N+2*D-1+K)-tz-TA*(K+2),TA*zh-sz-TA*(4-2*K),TA*zh-sz-4*TA]
    for fi,q in enumerate([sz+TA*(1+2*D),TA*T-tz-TA]):
     pp=s.Poly(s.expand((q+TA).subs(sub)),a,b,c,f,j)
     assert all(z>=0 for z in pp.coeffs())and pp.TC()>0
     rows.append({'key':[saved,p,it,iss,fi],'constant':str(pp.TC()),'terms':len(pp.terms()),'pass':True})

p=Path(__file__);p.with_suffix(".json").write_text(json.dumps({"complete":True,"count":len(rows),"producer_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"rows":rows},indent=2)+"\n");print("PASS",len(rows))
