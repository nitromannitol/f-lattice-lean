import sympy as s,json
from pathlib import Path
d,n,e,r=s.symbols('d n e r');A=s.Matrix([d,n]);Z=s.Matrix([e,r]);Q=2*A+Z;I=s.Matrix([1,-1]);b=lambda v:s.Matrix([v[1],-v[0]]);V=lambda v:s.Matrix([v[1]-v[0],sum(v)]);T=lambda v:-b(v).dot(V(v));eta=lambda v:(T(v)-sum(v))/2;out=[]
for W in [0,1]:
 G=s.groebner([d*r-n*e-(1-2*W)],d,n,e,r,domain=s.QQ)
 R=Q+V(Q)+I+(1-2*W)*Z;oR=W*Z+V(Z);oL=(2*(1-W))*Z+V(A)-W*Z;RA=2*A+V(A)+I
 assert s.simplify(R-oR-RA-oL)==s.zeros(2,1)
 ellL=b(Q)-b(A)-b(Z);assert ellL==b(A)
 cR=eta(Z)+2*W;cL=eta(Q)+1-eta(A)+b(A).dot(oL)+b(Z).dot(R)+cR
 want=eta(A)+(1-W);assert G.reduce(s.expand(cL-want))[1]==0
 # All positions in literal _alt_odd/getAltOddTileFull and their slopes.
 v3=(1-W)*Z;vs=V(A)+(1-2*W)*Z;v4=W*Z+V(Z)
 assert v3+vs==oL and v4==oR
 assert G.reduce(s.expand(b(Q).dot(R)+2*(eta(Q)+1)))[1]==0
 out.append({'W':W,'left_natural_slot':3,'right_natural_slot':4,'left_origin':list(map(str,oL)),'right_origin':list(map(str,oR)),'left_slope':list(map(str,b(A))),'right_slope':list(map(str,b(Z))),'left_scalar':str(want),'right_scalar':str(cR),'raw_reflection_constant':'eta_Q+1','status':'PASS'})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print('PASS both ordinary middle source frames/slopes/reflected scalars')
