# Exact four-alias fold for the whole W0 RIGHT prefix

Under the same strict birth cone and true saved1/3 interpretation as `PREFIX_GEOMETRY_AND_EXACT_REMAINDER.md`, let u belong to E_Z and 0<=j<=k. Write y=u+jV_Z and r=y-Z. Put B=K+kT. Then the following statement is uniform in every parameter:

    w = r - e V_C + 2f C belongs to E_C,
    e = 1_{t_C(r)<lo_t(E_C)},
    f = 1_{s_C(r)<lo_s(E_C)}.

The lower bounds use r's actual physical parity. Both shifts preserve it. Thus precisely four candidate aliases suffice, including j=0. No current-child recurrence, native recognition, or approximate clipping is used.

## Proof
Direct physical coordinate inversion gives

    T t_C(r)=Bt-s-jBT+T,
    T s_C(r)=Bs-2t+2jT-BT.

The exact vertex certificate `check_r1_fold.py` proves

    lo_t-T_C <= t_C(r) <= hi_t,
    lo_s-2T_C <= s_C(r) <= hi_s

for the true E_Z parity rectangles. In each saved1/3 case all64 target facet/rectangle/index-endpoint tests pass, with j=0,k. The same three determinant reductions as the preceding certificate are used. Each polynomial margin q obeys q+T>0 by positive constant and nonnegative coefficients in five nonnegative strict-cone variables. Physical integer margins q/T are therefore >=0.

Since t_C(-V_C)=T_C and s_C(-V_C)=0, the first fold adds T_C only when below the lower t row. E_C's t width is T_C+L_C-2 on even sites and T_C+c_C on odd sites, hence at least T_C-1. Every folded t is in the correct row. Since s_C(2C)=2T_C and t_C(2C)=0, the second fold similarly works; the s widths are 2T_C+2n_C on even sites and 2T_C+2d_C-4 on odd sites, both at least2T_C-1. The two folds commute and do not interfere with the other coordinate.

## Exact height pullback, not an inequality
For the genuine standard C field, write its actual deck character as

    F_C(z+V_C)=F_C(z)+a_C.z+cV_C,
    F_C(z+2C)=F_C(z).

Then, exactly,

    F_C(r)=F_C(w)+e*(t_C(r)+T_C+cV_C).

Indeed when e=1, r=w-2fC+V_C and a_C(w)=t_C(r)+T_C; the primary shift has zero character and a_C.C=0. In the canonical standard gauge cV_C=-(T_C+L_C)/2 this is

    F_C(r)=F_C(w)+e*(t_C(r)+eta_C).

The sign before T_C is PLUS. A formula with t_C+cV_C-T_C would be incorrect. The longitudinal fold has no scalar cost.

Physical source arguments for subsequent stationary comparison are now completely specified:

    w=u+jV_Z-Z-e(V_A+kV_Z)+2f(A+kZ).

This is a genuine point of E_C. It does not by itself assert that any particular constituent donor is active there; the actual stationary min formula must still be evaluated with this point and the above affine correction.

## Exact remaining value obligation
For 1<=j<=k the already proved r2=u+(j-1)V_Z lies directly in E_C. If the genuine shifted-parent calculation proves its normalized Q offer equals F_Z(y), then the entire prefix claim reduces to the ONE lower inequality

    F_C(w)+e*(t_C(r)+T_C+cV_C) >= F_Z(y).

No equality for this first offer is required. This is the precise geometric reduction, not a proof of that scalar inequality. In particular the earlier h(u)=F_Z(u-V_A-2A)+a_A.u+eta_A+2 is not h0. The parent notes that saved1 pays its required bound on all E_Z, whereas saved3's earlier two-q shielding result covered only a near-bottom portion; this document does not globalize that premise.
