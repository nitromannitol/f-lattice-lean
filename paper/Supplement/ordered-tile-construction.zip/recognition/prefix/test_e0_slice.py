from pathlib import Path
import sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D.parent))
from physical_heads import *
def go(w,s,k):
 ow=w+s+'2'*k;W=ow.count('1')%2;m,a0=alg.get_odometers(w);_,zf,af,rf=getFracs(w);a,Z,R=[(p.denominator,p.numerator)for p in (af,zf,rf)]
 A=add(Z,scale(-1,a)) if s=='1' else a
 mx,ax=alg.get_odometers(ow);of,qf,cf,zff=getFracs(ow);C,Q,O=[(p.denominator,p.numerator) for p in(cf,qf,of)];assert C==add(A,scale(k,Z))
 S=alg.export_tile(m[1]);F=review.Field(*Z[::-1],S).g;FC=review.Field(*C[::-1],alg.export_tile(mx[2])).g;FQ=review.Field(*Q[::-1],alg.export_tile(mx[1])).g;O0=alg.export_tile(mx[0]);FO=review.Field(*O[::-1],O0).g
 st=alg.export_tile(mx[1]);hist=Counter();ex={};geo=Counter();eg={};folds=Counter();slice00=[];topbad=[]
 # RIGHT Q is F_Z(y−2WC) up to constant. V_Z transport of native sources is exactly this chart.
 Dd,Nn=Z;TT=t(Z);LL=sum(Z);cc=Dd-Nn
 native=set(S); S=[]
 for xx in range(-2*Dd,3*Dd+1):
  for yy in range(-Dd,3*Dd+1):
   tv=Nn*xx-Dd*yy;sv=LL*xx+cc*yy
   lo,hi,ls,hs=(2-TT,LL-2,0,TT+2*Nn)if(xx+yy)%2==0 else(Nn-TT,Dd,2-cc,TT+LL-2)
   if lo<=tv<=hi and ls<=sv<=hs:S.append((xx,yy))
 for u in S:
  for j in range(k+1):
   y=add(u,scale(j,v(Z)),scale(2*W,C));r=add(y,scale(W-1,Z));m1=FC(r);m2=FC(add(y,scale(-W,Z),scale(-1,v(Z))))+mul(b(Z),r)+eta(Z)+2*W;tar=F(add(y,scale(-2*W,C))); 
   # For W1 old right includes +2j scalar on actual transported V_Z chain; b_Z·2C=−2 (W1), no added translated affine term in target here
   key=(j,min(m1,m2)-tar,FQ(y)-tar, y in st)
   hist[key]+=1;ex.setdefault(key,u)
   def inside(z):
    tc=mul(b(C),z);sc=mul((sum(C),C[0]-C[1]),z);TC=t(C)
    aa,bb,cc,dd=(1-TC,sum(C)-1,0,2*TC+2*C[1])if sum(z)%2==0 else(C[1]-TC,C[0],2-C[0]+C[1],2*TC+sum(C)-2)
    return aa<=tc<=bb and cc<=sc<=dd
   TC=t(C);tc=mul(b(C),r);sc=mul((sum(C),C[0]-C[1]),r)
   lt,ls=(1-TC,0)if sum(r)%2==0 else(C[1]-TC,2-C[0]+C[1])
   ee=int(tc<lt);ff=int(sc<ls);ww=add(r,scale(-ee,v(C)),scale(2*ff,C))
   assert inside(ww),(r,ww,ee,ff)
   assert FC(r)==FC(ww)+ee*(tc+eta(C)),(r,ww,FC(r),FC(ww),tc)
   folds[(j,ee,ff)]+=1
   if j==k and ee==ff==0:
    uu=add(u,scale(-1,v(A)),scale(-2,A));HH=F(uu)+mul(b(A),u)+eta(A)+2-F(u)
    DD=F(u)-F(add(u,scale(-2,A)))
    slice00.append({'u':u,'t':mul(b(Z),u),'s':mul((sum(Z),Z[0]-Z[1]),u),'H':HH,'D':DD})
   upper=t(Z)+(2*Z[1]if sum(u)%2==0 else sum(Z)-2)
   if ff and mul((sum(Z),Z[0]-Z[1]),u)>upper-2:topbad.append((u,j))
   gg=(j,inside(r),inside(add(y,scale(-1,v(Z)))))
   geo[gg]+=1;eg.setdefault(gg,(u,mul(b(Z),u),mul((sum(Z),Z[0]-Z[1]),u)))
 print('SLICE00',sorted(slice00,key=lambda a:a['t']),'TOPBAD',topbad,flush=True)
 print('FOLDS',folds,flush=True)
 print('GEOMETRY',geo,'examples',eg,flush=True)
 print('ZPR',w,ow,'W',W,'n',len(S),'hist',sorted(hist.items()),'bad',[(kk,vv)for kk,vv in ex.items()if kk[1] or kk[2]][:8],flush=True)
go(sys.argv[1],sys.argv[2],int(sys.argv[3]))
