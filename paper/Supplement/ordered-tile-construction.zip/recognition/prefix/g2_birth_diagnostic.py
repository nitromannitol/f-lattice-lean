import sys
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
for word in sys.argv[1:] or ['113']:
 m,_=alg.get_odometers(word);_,zf,af,rf=getFracs(word);d,n=af.denominator,af.numerator;D,N=zf.denominator,zf.numerator;A=(d,n);Z=(D,N);R=(rf.denominator,rf.numerator);TA=d*d+2*d*n-n*n;LA=d+n;ca=d-n;T=D*D+2*D*N-N*N;L=D+N;c=D-N
 F=review.Field(N,D,alg.export_tile(m[1])).g;FA=review.Field(n,d,alg.export_tile(m[2])).g;ct=Counter();ex={};geom=Counter()
 for x in range(-3*d,4*d+1):
  for y in range(-2*d,4*d+1):
   t=n*x-d*y;s=LA*x+ca*y;lo,hi,sl,sh=(n-TA,d,2-ca,2*TA+LA-2)if(x+y)%2 else(1-TA,LA-1,0,2*TA+2*n)
   if not(lo<=t<=hi and sl<=s<=sh):continue
   u=(x,y);w=(x+R[0],y+R[1]);tz=N*w[0]-D*w[1];sz=L*w[0]+c*w[1];zl,zh,zs,ze=(N-T,D,2-c,T+L-2)if sum(w)%2 else(2-T,L-2,0,T+2*N)
   geom[zl<=tz<=zh and zs<=sz<=ze]+=1
   delta=F((x-2*d,y-2*n))-FA(u);dd=F(u)-FA(u);ct[(delta,dd)]+=1;ex.setdefault((delta,dd),u)
 print(word,A,Z,'geom',geom,'ct',ct,'ex',ex,flush=True)
