# Pure3 outer shifted G2 binding and LONG ordinary p closure

Let e>=3 odd, q=(e,1),Y=V_q,B=a_q,X=(1,0),V0=(-1,1), C=X+hq,h>=1, Q=2C+q,O=C+q. Write T=T_q,eta=eta_q,c=c_q,d_j=j eta+Tj(j−1)/2. The literal endpoint E0(x,y)=−y(y−1)/2 has domain{0,1}×{0,1,2}, reflection center R_E=(1,2), gradient a_E=(0,−1), constant eta_E=1.

## 1. RIGHT G2 equals the six-site target price, with the actual shift
The authenticated internal RIGHT endpoint is at hY−e2, slope hB and scalar d_h, for both SHORT and LONG. The literal outer Gr slot is Y with slope B in both W0 siblings. Its absolute candidate scalar eta is fixed by the preceding G1 identity: translating the first internal G by Y with this jet gives the genuine G(y) at every first G1 source point.

After that whole-helper translation, the G2 origin, slope and scalar are

 a_R=(h+1)Y−e2, b_R=(h+1)B,
 gamma_R=d_h+hT+eta=d_(h+1).

The term+hT comes from pulling the inner hB slope through translationY; dropping it would give an incorrect scalar. At y=w+(h+1)Y, w∈{0,1}×{−1,0,1}, its price is exactly

 E0(w+e2)+(h+1)B·w−(h+1)c−T h(h+1)/2.

This is the exact normalization dH used in endpoint_G1_G2/reciprocal_actual_six/prove.py. Its E0 variable is−w_y(w_y+1)/2, i.e. E0(w+e2), not the unshifted endpoint value.

Read that checker: each arm is first put in a real E_C or E_O representative by a genuine secondary/zero-primary shift, all four physical parity facets are checked, then its two global reciprocal sheets are evaluated via one genuine native G chart. Each claimed minimum has both lower inequalities and an exact attaining sheet. The parameter split e=3,e=5,e=2a+7 exhausts all odd e>=3. In its arm numbering, SHORT returns E0+2 and E0; LONG returns E0+1 and E0 (LONG arm1 is the shifted second raw comparator offer). Thus the target minimum is exactly the original placed G2 price, on all six actual sites. No ordinary six-point endpoint is moved into an unshifted abstract polygon.

## 2. LEFT follows the genuine shifted target reflection
SHORT raw reflection center is R_Q; LONG's is R_Q+q, with respective common height constants−eta_Q and−eta_Q−1. The actual endpoint reflection maps a_R to

 a_L=R_Q−a_R−R_E=(2h+1)q+hY  (SHORT),
 a_L+q=(2h+2)q+hY           (LONG).

These agree with the literal internal LEFT endpoint at2hq+(1,−1), plus the outer Gl slots q+V_C (SHORT) and2q+V_C (LONG). The nonzero endpoint shift is indispensable: (1,−1)+V0=0.

Reflected slope is a_Q−(h+1)B−a_E=a_C. Its global scalar in BOTH siblings simplifies to

 gamma_L=1+h(e+1)+d_h.

Explicitly SHORT gives a_E·a_L−eta_E+(h+1)B·R_Q+d_(h+1)+eta_Q. For LONG the extra q in both center and origin changes this by a_E·q+(h+1)B·q+1=−1+0+1=0. This exactly matches the historical internal LEFT endpoint (slope/scalar0) after its true outer placement and the known candidate outer Gl scalar. The two shifts must not be conflated with the standard reflection alone.

## 3. LONG pNear/pFar now close with the authenticated whole-E inputs
The previous LONG_W0_ORDINARY_P_ONE_ROW_REPAIR.md applies directly to the CURRENT pair C=(he+1,h),q=(e,1). Both are proper for every h>=1 and det(C,q)=1. Its all-proper geometry requires no proper retained ancestor X.

The previously missing hypotheses are now supplied explicitly: h=1 full E_C stationary realization is the separately checked literal doubled-ladder theorem in endpoint_G1_G2/reciprocal_pure3_initial_roof; h>=2 is the earlier canonical ordinary standard-stage realization with the genuinely proper previous parent P_(h−1),q. The same applies to O=P_(h+1). Retain the genuine global strip/deck/reflection hypotheses of those standard stages, not merely the native two-roof identity.

With F=G and H(z)=G(z−(1,1))−z_y+2, the actual full-E formulas are

 F_C=min(F,H+2h−2),  F_O=min(F,H+2h).

The all-proper inclusions E_C+2q⊂E_O and E_C+Y⊂E_O put y=u+q and y+Y in the correct longitudinal range; only opposite one-row transverse misses remain. The earlier one-row proof eliminates the even upper miss and reduces the odd one to t_C(u)=d_C,t_q(u)=e+2. Genuine zero strips give F_C(u)=G(u)=F_O(y)=0, while the authentic C roof implies H(u)+2h−2>=0, so the formal O roof also equals0 at that exceptional point. Genuine O and raw O reflection pay the opposite lower miss. Thus both queried O values agree with their formal roofs on every u∈E_C, not just occupied native points.

The four resulting LONG offers at y=u+q are

 F(u), H(u)+2h−1, F(u)+1, H(u)+2h−2.

Their minimum is F_C(u). Therefore the entire actual pNear source is exactly priced, provided its standard native support is in its canonical E_C, as in the standing source-support input. Raw LONG reflection then gives pFar origin o=V_C+Y+q and price

 F_C(y−o)+(a_C+B)·y+eta_Q+1−eta_C+a_C·o.

This is the literal W0 LONG pFar slot and its exact candidate scalar.

## Scope
These are analytic source-price and actual placement/jet conclusions under the authenticated earlier whole-E standard stages. They pay both genuine shifted G2 atoms and the two LONG ordinary p sources; they do not erase the two known first-G3 clipped contacts or prove arbitrary exposed G3 prices. Whole-helper original max-zero normalization was established independently and is not recomputed here. Historical actual nonempty overlaps select these candidate constants only after the remaining incoming source-price/first-ownership inequalities have been assembled in their true order.
