# W1 RIGHT G1: complete normalized folded-offer table

Use the genuine W1 convention det(A,Z)=-1, v=V_A, C=A+kZ, y=2C+u+jV_Z, 1<=j<=k, u in E_Z. The target is F_Z(y-2C)=F_Z(u+jV_Z), NOT F_Z(y). The two current offers are

 I1=F_C(q1), q1=u+jV_Z;
 I2=F_C(q2)+a_Z.(u+jV_Z)+eta_Z, q2=u+(j-1)V_Z-Z.

The preceding four-alias geometry supplies w_a=q_a-e_a V_C+2f_a C in E_C. There, and only there, use the true stationary formula
 F_C(w)=min(F_Z(w-2A),F_Z(w-v)+a_A.w+eta_A),
followed by F_C(q)=F_C(w)+e(t_C(q)+eta_C). This is not a global extension of the raw minimum.

Define the actual canonical old price and slip globally by
 P(z)=F_Z(z)-F_Z(z-v)-a_A.z,
 D(z)=F_Z(z)-F_Z(z+2A).
For the table abbreviate
 r=eta_A-P(u), rm=eta_A-P(u-v),
 d0=D(u-2A), db=D(u-v-2A), dv=D(u-v), dvv=D(u-2v).
All shifted prices remain physical global evaluations; we do not assume their arguments lie in E_Z.

Each table entry is the pair whose minimum equals the normalized indicated Q offer:

| Arm | e,f | First constituent | Second constituent |
|---|---|---|---|
| 1 | 0,0 | d0+2j | r |
| 1 | 0,1 | 0 | r-dv+2(k-j) |
| 1 | 1,0 | r+db+2(j-k) | r+rm |
| 1 | 1,1 | r | r+rm-dvv-2j+4k |
| 2 | 0,0 | d0+2j-2 | r-1 |
| 2 | 0,1 | 0 | r-dv+2(k-j)+1 |
| 2 | 1,0 | r+db+2(j-k)-3 | r+rm-2 |
| 2 | 1,1 | r-1 | r+rm-dvv-2j+4k |

`check_w1_offer_table.py` verifies all16 affine deck identities independently from the folded source arguments. Put l=j,h=0 for arm1 and l=j-1,h=1 for arm2, m=l-ek, n=2fk-h. Then
 w=u+mV_Z+nZ-ev+2fA.
For F_Z(w-2A) the residual old argument is u-ev+2(f-1)A; for F_Z(w-v) it is u-(e+1)v+2fA. The true Z primary has zero character. Its secondary law is
 F_Z(z+mV_Z)=F_Z(z)+m*a_Z.z-m*c_Z-m(m-1)T_Z/2.
Use a_Z.A=-1,a_Z.v=-K,a_A.Z=1,a_A.V_Z=-K. The second old offer adds a_A.u-mK+n+eT_A+eta_A. Finally include the C pullback and, for arm2, t_Z(u)-jT_Z+eta_Z. Subtract the target's j-th V_Z jet. These steps produce exactly the displayed16 jets, with no unknown scalar.

The conversion to prices uses
 F(u-v)+a_A.u+eta_A-F(u)=r,
 F(u-2v)+2a_A.u+2T_A-L_A-F(u)=r+rm,
and F(z+2A)=F(z)-D(z). These identities also fix the signs of db,dv,dvv.

## Concrete remaining gates
The old E_Z span gives r in{0,1}; it does not bound rm or any shifted D without their physical guards. To prove the child equals its target, every selected row's two constituents must be nonnegative, and at least one of the four selected constituents must be0. In particular:

* Any selected (0,1) row supplies exact attainment once its other constituent is nonnegative.
* Arm1 rows(0,0),(1,1) supply attainment when r=0.
* Arm2 rows(0,0),(1,1) REQUIRE r=1, and then supply attainment. The term r-1 cannot be omitted.
* Arm2(1,0) needs both r+db+2(j-k)>=3 and r+rm>=2. These are the strongest visible guards, not consequences of the unshifted price span alone.

The fold geometry forces e1>=e2 and f1<=f2, since t(q1)=t(q2)-B+1 and s(q1)=s(q2)+B-2. Thus fold choices cannot be treated independently in the final attainment argument. Still, no universal lower-bound or attainment proof is asserted here. The table isolates those exact value gates after all alias geometry is paid. Saved1 value substitution retains its separate authentic stationary-source premise; its geometry and formal deck algebra are identical.
