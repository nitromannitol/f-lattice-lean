# W0 saved1/3 prefix: independent transverse-fold price audit

## Scope and exact conclusion

Use the actual proper saved1/saved3 setup of `PREFIX_GEOMETRY_AND_EXACT_REMAINDER.md`. Set A to the effective odd parent, Z=(D,N), det(A,Z)=1, C=A+kZ, v=V_A, T=T_Z, K=M(A,Z), L=D+N. Here c_A=(T_A+L_A)/2 is POSITIVE; the actual secondary character is −c_A. Let F=F_Z and define physical earlier-field prices

 P(x)=F(x)−F(x+v)+a_A·x,
 D(x)=F(x)−F(x−2A).

For u∈E_Z, 1≤j≤k, r=u+jV_Z−Z, let e,f be the two lower-facet failure indicators of `EXACT_ALL_J_FIRST_ARM_FOLD.md`. Assume e=1 and put w=r−V_C+2fC. The earlier current-standard polygon identity is used ONLY at this proven E_C point:

 F_C(w)=min(F(w),h(w)+2k−2),
 h(w)=F(w−v−2A)+a_A·w+eta_A+2.

Then F_C(r)≥F(r)=F(u+jV_Z). This proves the first physical Q arm is not below the old prefix target in the transverse-fold case. It does not assert equality for that arm, does not cover j=0 or e=0, and is not independently a recurrence theorem.

## 1. Exact offers, before imposing any inequality

Write l=j−k. The point used in the polygon identity is exactly

 w=u−v+lV_Z+(2fk−1)Z+2fA.

Use F(x+Z)=F(x), F(x+lV_Z)=F(x)+l(t_Z(x)−c_Z)−l(l−1)T/2, and the true C pullback F_C(r)=F_C(w)+t_C(r)+eta_C. The two resulting offers relative to F(r) are

 I=P(u−v)−c_A+1+f[D(u−v+2A)−2(k−j)],
 II=P(u−v)+P(u−2v)−2c_A+2+(1−f)[4k−2j−D(u−2v)].

The included independently written `check_e1_algebra.py` expands BOTH offers directly from the preceding deck laws, separately for f=0 and f=1. All four symbolic residuals vanish identically. It uses no native samples or numerical field fitting. In particular eta_C contains its full k²T/2 and kK terms, and the primary alias in w has zero cost.

## 2. Earlier physical inputs, with quantifiers

The argument consumes the following previously established field properties in their actual effective-A orientation, not properties inferred merely from recurrence:

* c_A−1≤P≤c_A on ALL of the authenticated closed polygon E_Z, and P(x+Z)=P(x)−1, P(x+V_Z)=P(x).
* F=h0 on the complete physical strip 1−2D≤s_Z(x)≤2L−1. Its true v-jet implies P(x)=c_A when x and x+v both lie in this strip.
* 0≤D(x)≤2 throughout the complete transverse band 3−D−T≤t_Z(x)≤N+2D−1; the high-transverse sign extension D(x)≤0 for t_Z(x)≥N+1.
* The genuine current C polygon identity and global canonical C deck laws above.

For saved1 these are effective-parent statements: the actual old birth parent is a, A=Z−a. Its earlier intrinsic-price transport, not an invented birth with parent A, supplies the price and slip orientation. These are explicit hypotheses of this local audit. The preceding `S1/INTRINSIC_PRICE.md`, `S1/FINAL_PRICE_ATLAS.md`, `INDEPENDENT_ALL_CROP_DOMINANCE_AUDIT.md`, and the full-E shielding audit record their inherited role. No entire-plane raw minimum is assumed.

## 3. Two prices at the upper longitudinal rim

For i=1,2, put q=u−iv. Then s_Z(q)=s_Z(u)+2i. If this lies within E_Z's parity-dependent longitudinal interval, a V_Z translate of q is in E_Z: that row's transverse width is at least T−1. The translate preserves P, so P(q)≥c_A−1.

Otherwise q is strictly above the upper longitudinal row. Write its upper row as T+h, with h=2N on even sites and h=L−2 on odd sites. Put x=q−Z. Then

 h<s_Z(x)≤h+4,  h−2<s_Z(x+v)≤h+2.

Both points lie in [1−2D,2L−1] in the stated strict proper cone (in particular D≥3 and L≥3). The physical harmonic strip therefore gives P(x)=c_A, and the primary character gives P(q)=P(x+Z)=c_A−1. This prices the rim without claiming its points are literally native or invoking any transverse guard. Consequently

 P(u−v)≥c_A−1,  P(u−2v)≥c_A−1.

## 4. Slip estimates and the terminal layer

At u−2v the transverse coordinate is t_Z(u)+2K. Its lower value is at least lo_t(E_Z)+2K≥3−D−T. Below N+2D−1 use the complete physical D band; above it use the high-transverse sign extension. Thus D(u−2v)≤2 throughout E_Z, regardless of whether u−2v is native.

The separate exact geometry certificate `check_transverse_fold.py` proves that e=1 forces j=k. Explicitly lower transverse failure gives

 B[t_Z(u)+K+(k−j)T]<s_Z(u)+T(g−1)+2,
 B=K+kT, g=1 (even) or n_C (odd).

Its all-proper polynomial inequalities put the right side divided by B below both lo_t(E_Z)+K+T and N+2D−3. The first excludes j≤k−1; the second, together with the lower row, places t_Z(u−v+2A)=t_Z(u)+K+2 in [3−D−T,N+2D−1]. Hence 0≤D(u−v+2A)≤2. This audit reads the encoding and independently reruns its twelve exact polynomial checks; it does not claim independent reimplementation of that geometry certificate.

## 5. Conclusion and boundary of the claim

Substituting j=k gives

 I=P(u−v)−c_A+1+f D(u−v+2A)≥0,
 II=P(u−v)+P(u−2v)−2c_A+2+(1−f)[2k−D(u−2v)]≥0.

The last bracket is nonnegative because k≥1 and D(u−2v)≤2. Therefore both licensed offers are ≥F(r), proving the claimed first-arm lower bound. No equality, source scalar normalization, first layer j=0, endpoint birth extension, global Q recognition or physical recurrence is inferred by this document.
