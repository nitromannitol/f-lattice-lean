import sympy as s,json,hashlib
from pathlib import Path
c,a,e,r,x,y=s.symbols('c a e r x y',integer=True)
d,n=c+e,a+r
T=lambda d,n:d*d+2*d*n-n*n
mix=c*e+c*r+a*e-a*r
D,N=d+n,d-n
rows=[]
for W in (0,1):
 tau=(-(c+a),-(c-a)) if W==0 else (r,-e)
 f=(y-2*n+1+tau[0],-x+2*d+tau[1])
 offset=W*(2-mix-T(e,r))
 expr=s.expand(N*f[0]-D*f[1]-((d+n)*x+(d-n)*y-2*T(d,n)+N+2-offset))
 rem=s.rem(expr,s.Poly(c*r-a*e-(1-2*W),c,a,e,r,x,y),c,a,e,r,x,y)
 assert rem==0
 rows.append({'phase':W,'t_identity_remainder':str(rem)})
out=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/recognition_ledger/saved3_gate/prefix')
(out/'CURRENT_ODD_D_GUARD_INDEPENDENT_ALGEBRA.json').write_text(json.dumps({'checks':rows,'scope':'Symbolic identity modulo actual determinant; endpoint inequalities checked analytically in appended review.'},indent=2)+'\n')
