# The CURRENT odd alternate's full native midpoint guard, in four lines of algebra

This resolves the last target guard in FINAL_NATIVE_ASSEMBLY_ADVERSARIAL_REVIEW and S1/FINAL_ALL_DISPATCH_AUDIT §5, for both corrected and uncorrected NONBASE odd alternate outputs. No identification of old and current R2, no actual dual native occupancy, and no reverse inclusion between different R2 rectangles is needed.

Let the current actual odd alternate output O=C+Z=(d,n) have true creation pair C=(c,a) odd, Z=(e,r) even, phase W, det(C,Z)=cr−ae=1−2W. Set K=mixed(C,Z), T=T_O, S=(D,N)=(d+n,d−n), T_S=2T; t_S(f)=N f_x−D f_y and s_O(z)=(d+n)z_x+(d−n)z_y. Write q*=(c+a,c−a) and p*=((e+r)/2,(e−r)/2). The actual odd comparator at z uses x=z+WZ; its global raw identity S1/RAW_LONG_COMPARATOR_DUAL uses exactly f=Rot(z−2O)+e1+tau, tau=−q* in W0 and tau=−V_(p*)=(r,−e) in W1. This is the current output placement, not the old starred source placement. The odd R2 bound for THIS (C,Z,W) is stated in its true native coordinate z. Indeed the authentic geometric enclosure generator uses original alt_layout(C,Z,W,odd,letter) with target_creation=(C,Z,W), directly summing each actual leaf at its genuine origin, with no additional shift of the target. In particular the ordinary qNear origin is 2WC in BOTH the raw target and enclosure table. An implicit extra recenter of the outgoing crop would be erroneous. A4 actual stored→consumed translation is handled by the historical frame theorem; use the same intrinsic z as these two source tables.

1. t_S(f)=s_O(z)−2T+N+t_S(tau). In W0 t_S(tau)=2det(C,O)=2. In W1 it is Nr+De=mixed(O,Z)=K+T_Z. Hence b+t_S(tau)=2 in BOTH phases, where b=W(2−K−T_Z) is the authentic odd R2 longitudinal offset.
2. Even z has b≤s_O(z)≤b+2T+2n−2. Thus N+2−T_S≤t_S(f)≤D. Odd z has b+l≤s_O(z)≤b+2T+h−2 where (l,h)=(3n−d,d−n) in lower and balanced sectors or its exchange in upper. Thus the two endpoint corrections N+l,N+h are exactly the unordered pair {2n,2N}, with lower endpoint N+l+2−T_S and upper endpoint N+h.
3. Since n,N≥1 and D−N=2n≥2, both cases give 3−T_S≤t_S(f)≤D+N−1. One physical input step at S changes t_S by at most D. The corresponding full star lies in [3−D−T_S,N+2D−1]. The independently established D+ three-level theorem on that whole transverse interval therefore applies to the CURRENT f. The harmonic/affine isomorphism maps physical stars to physical stars.
4. RAW_LONG_COMPARATOR_DUAL now identifies the raw odd target with S's actual rounded midpoint plus its true harmonic gauge on the entire actual O domain, hence with the canonical odd alternate up to the chosen scalar by S1/ANALYTIC_ALT_CONJUGACY. On the even orientation use the already proved current even R2 t bound directly. The pure OUTPUTS are separate initializer theorems; pure primitive sources in a nonbase output do not change its current R2.

This argument does not prove any incoming leaf price: genuine earlier primitive source guards and possible endpoint clipping are paid separately. The same target guard applies to LONG and the uncorrected m=1 star because the raw/current comparator and its CURRENT birth R2 depend on the actual (C,Z,W), not on its list of incoming operands.

## Independent source-coordinate and endpoint audit (circuit_audit)

PASS for the stated NONBASE current-output scope, with the previously established
standard three-level theorem and actual enclosure/frame induction as inputs.
This is not a new proof of those upstream results.

I read the actual `reconstruct_direct_auxiliary_enclosure.py` functions
`bounds`, `alt_layout`, and `group`, and the separate balanced producer
`fresh_build_balanced_auxiliary_enclosure.py::bounds`. In `group`, the target is
`cp+cq` for the odd output, its creation tuple is exactly `(cp,cq,W)`, and the
leaf origins are those of `alt_layout(cp,cq,W,True,letter)`, with helper local
origins added to those origins. There is no final target translation in this
construction. In both phases its first ordinary even-donor origin is precisely
`2*W*cp`. Thus the z in the enclosure is the z in the raw comparator already
written above. The internal x=z+WZ and the tau in f are comparator coordinate
changes, not additional translations to apply to the native R2. Likewise the
historical stored-to-consumed frame conversion is to be applied once, not again
after these formulas. The current creation tuple must not be replaced by any
incoming alternate source's birth tuple.

Independent symbolic reduction of the complete t_S(f) identity modulo
`c*r-a*e=1-2*W` gives zero in both phases; see
`CURRENT_ODD_D_GUARD_INDEPENDENT_ALGEBRA.json`. The source odd R2 s bounds are
exactly those quoted. The balanced producer uses `(3n-d,d-n)`, not the upper
producer's exchanged pair; the argument correctly allows either pair and does
not confuse their ordering. More explicitly the native images are:

* even z: `[N+2-T_S,D]`;
* odd z, lower/balanced: `[2n+2-T_S,2N]`;
* odd z, upper: `[2N+2-T_S,2n]`.

Since n>=1 and N=d-n>=1, each lower endpoint is at least `3-T_S`.
Their upper endpoints are at most `D+N-1`: for 2N the margin is
`D-N-1=2n-1>=1`; for 2n it is `2N-1>=1`; for D it is `N-1>=0`.
Hence no sector, phase, or parity exception remains in this arithmetic.
A rotated physical unit step changes t_S by N or D in absolute value, with
D>=N, proving the claimed full-star interval. Rotation with the stated
translations preserves physical star incidence, including its parity change;
no assumption that z and f have the same physical parity is used, because the
three-level interval covers both.

The last step uses the already proved complete D+ interval in
`strong_bulk/STRONG_PRICE_AND_ALTERNATE_STEP.md` §5, not the narrower genuine
birth-dependent central unit-slip window. It therefore does not reopen the
saved1 central-window error. Combined with the exact global raw comparator
duality, this closes the CURRENT target guard identified in my final assembly
review. It does not replace incoming source pricing, chronological scalar
calibration, or the separate literal pure-output initialization.
