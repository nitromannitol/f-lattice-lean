# UNC odd alternate star: two fringes suffice, including m=1

## Result and scope
Conditional PASS, BOTH phases and both effective saved1/saved3 source records in the established all-proper birth cone. This closes the analytic price of the actual unreplaced restored even-ALT star in an ordinary odd-ALT constructor (last1 or last3), given the already authenticated earlier source midpoint, all-R2 stationary polygon/value hypotheses, complete physical price/slip bounds and native support/frame binding. It does not assert those earlier inputs from recurrence alone, or independently establish opposite-type dual transport.

The old LONG proof was stated k>=1, where each endpoint paired one fringe with a zero-error interior. Its proof need not be extrapolated verbatim to k=0. At k=0 both queries are fringes, but the individually proved caps suffice by the elementary lemma below. No extra attainment theorem or new finite example is required.

## Elementary paired-fringe lemma
Let D∈{0,1,2}, D'=2−D. Suppose

 min(0,1−D)<=e<=0,
 min(0,1−D')<=e'<=0.

Then min(e,1−D+e')=min(0,1−D). Both lower bounds separately exclude an undercut. If D<=1, e=0; if D=2, D'=0 forces e'=0, and the second offer attains−1. Thus a second source is never being used to hide an undercut by a first: the two individual lower bounds are essential and are precisely what the previous fringe proofs establish.

## W0: two upper fringes
Set C=A, O=A+Z, m=1. The actual star is at y=z+V_A+Z, corresponding to i=1 in the LONG formula. After subtracting a_A·y+eta_A+1 the prices, relative to F=F_Z(z), are

 e_1(z), 1−D(z)+e_1(z'),
 z'=2A+V_Z+(1,−1)−z,
 D(z)=F(z)−F(z−2A), D(z')=2−D(z).

The established all-R2 stationary polygon theorem licenses z+Z and z'+Z in E_O even at m=1: they are the single allowed upper-fringe index l=2m−1=1. On this genuine polygon,

 e_1(z)=min(0,h(z)−F(z)−1)<=0.

The earlier endpoint algebra gives the exact identity

 1−D(z)+e_1(z')=min(1−D(z),c_A−P(z)).

For saved3 the independently proved intrinsic cap is P(z)<=c_A+1_{D(z)=2}, including transverse-wrap and low-rim cases. Thus the displayed second offer is at least min(0,1−D(z)). Applying the same cap at the genuine reflected R2 point gives e_1(z)>=min(0,1−D(z)). For saved1 the effective birth-price transport proves the stronger P<=c_A on the whole restored R2, so the same inference holds. These caps do not depend on m; neither relies on availability of an interior query. The paired-fringe lemma proves the required midpoint.

## W1: two lower fringes
The actual star is y=z+V_A+2A−Z, i=−1 in the LONG formula, whose physical raw argument is x=y+Z. After subtracting a_A·y+eta_A, its two prices relative to F(z) are

 e_0(z), 1−D(z)+e_0(z'),
 z'=2Z−2A+V_Z+(1,−1)−z,
 D(z)=F(z)−F(z+2A), D(z')=2−D(z).

The query at either site is z+2A. The W1 stationary polygon range is0<=l<=2m−2, so l=0 is licensed at m=1. It is NOT the separate potentially high-folded index2m−1=1. Hence e_0=min(0,h−F)<=0 genuinely, without a periodic fold.

For saved3 the established intrinsic inequality P(z+2A)<=eta_A−1_{D(z)>0} gives h−F=eta_A−P(z+2A)−D(z)>=min(0,1−D(z)). For saved1 the effective birth-price bound P_eff(z+2A)<=eta_A−1 gives the same lower cap (indeed h−F>=1−D). Apply at both reflected R2 points. The paired-fringe lemma again gives exact midpoint, including the two simultaneous lower fringes.

## Literal source, phase and affine price
Read original final_code/odometer_recursion.jl:get_alt_child_unc and tile_decomp/tile_offsets.jl:get_odd_offset/get_odd_affine. The odd UNC source is the actual earlier Gq1_ AFTER translate_alts, inserted immediately after C0. For both allowed final letters1,3:

 W0: star origin V_A+Z, slope a_A;
 W1: star origin V_A+2A−Z, slope a_A.

The primary affine characters are zero. These are offsets from the correctly restored primitive, not from its exported lower-left coordinates. The literal current2 W1 branch has a different offset but is corrected, not this UNC case; it is not imported here. Saved1 uses the old primitive's own birth phase and restoration; the effective A=Z−a is not falsely treated as its creator.

The independently expanded algebra in check_UNC_ODD_STAR.py uses arbitrary A,Z with det(A,Z)=1−2W, not a fitted family. All eight direct/reflected-query and scalar identities pass. It also exhausts the five possible integer cap combinations in the elementary lemma. The resulting raw price is

 T_W(y)=J(z)+a_A·y+eta_A+1−W,
 J(z)=ceil((F_Z(z)+F_Z(z+2(2W−1)A))/2).

If the genuine restored primitive has height J(z)+gamma, its translated star differs from T_W by gamma−eta_A−1+W. Thus the actual touch subtracts exactly that constant once the prior first owner equals the same target and the historical finite overlap is applied. No new source normalization is chosen. Later source compatibility is separate from this star calculation.

## Inputs audited and remaining limits
Used FINAL_ALL_SHORT_AND_LONG.md §3's individual W0 cap, W1/SIGNED_STATIONARY_SUBSTITUTION.md §3 and WHOLE_CROP_AND_FINAL_PRIMARY_FOLD.md, S1/INTRINSIC_PRICE.md for genuine saved1 transport, and S1/ALL_PROPER_CONE.md for the exact unbounded widening and m>=1 stationary certificates. R2 reflection and complete D∈{0,1,2} are inherited exact earlier physical facts. No runtime-dependent helper extent is needed for this unreplaced primitive source.

This proves the odd UNC seventh-source analytic recognition under those inputs. Source-list duality alone is not a proof of the even target values: that extension additionally needs the correct primitive harmonic/affine characters, whole target-native containment in the donor native/envelope and scalar normalization. Those belong to the existing separate dual-transfer theorem and should be cited explicitly when used.
