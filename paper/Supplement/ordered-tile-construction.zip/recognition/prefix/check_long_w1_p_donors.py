import sympy as s,json,hashlib
from pathlib import Path
d,n,e,r,k=s.symbols('d n e r k');C=s.Matrix([d,n]);Z=s.Matrix([e,r]);O=C+Z;Q=2*C+Z;A=C-k*Z
v=lambda X:s.Matrix([X[1]-X[0],sum(X)])
a=lambda X:s.Matrix([X[1],-X[0]])
T=lambda X:-a(X).dot(v(X));eta=lambda X:(T(X)-sum(X))/2
K=(d+n)*e+(d-n)*r;delta=s.Matrix([1,-1]);RC=2*C+v(C)+delta;RQ=Q+v(Q)+delta;R1=RQ-Z;o=v(C)+v(Z)
G=s.groebner([d*r-n*e+1],d,n,e,r,k,domain=s.QQ)
raw={'Kd':K*d-e*T(C)+d-n,'KL':K*(d+n)-(e+r)*T(C)-2*n,'odd_upper':K*d-(2-d+n)-e*T(C)+2,'A_Z':a(A).dot(Z)-1,'Z_A':a(Z).dot(A)+1,'cross':a(Z).dot(v(A))-a(A).dot(v(Z)),'center_grade':a(Q).dot(R1)+2*eta(Q)+2,'far_constant':-a(O).dot(o)-a(Q).dot(RC)-eta(C)-eta(Q)-1-(eta(Q)+1-eta(C)+a(C).dot(o))}
for i in range(2):raw['far_origin'+str(i)]=(R1-RC-o)[i]
rows={key:str(G.reduce(s.expand(val))[1]) for key,val in raw.items()};assert set(rows.values())=={'0'},rows
# Strict positivity K>2n over independent positive proper cone.
x,y,z,w=s.symbols('x y z w');pol=s.Poly(s.expand((K-2*n).subs({n:x+1,d:x+y+2,r:z+1,e:z+w+3})),x,y,z,w);assert pol.TC()>0 and all(c>=0 for c in pol.coeffs())
p=Path(__file__);p.with_suffix('.json').write_text(json.dumps({'residuals':rows,'K_minus_2n_positive':True,'producer_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n');print('PASS',len(rows),'identities and strict positivity')
