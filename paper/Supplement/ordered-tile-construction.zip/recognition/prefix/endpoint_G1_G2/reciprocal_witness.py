import sympy as s,json
from pathlib import Path
d=s.symbols('d',integer=True,positive=True);w=s.Matrix([0,-d-1]);U=s.Matrix([d,1]);V=s.Matrix([1-d,d+1]);a=s.Matrix([1,-d]);cz=(d*d+3*d)/2
pts=[w,w-s.Matrix([2,0]),w+s.Matrix([2,0])];shift=[V+U,V+2*U,V+U];nat=[s.Matrix([1,1]),s.Matrix([d-1,2]),s.Matrix([3,1])];vals=[0,-1,0];glob=[]
for z,ss,nn,val in zip(pts,shift,nat,vals):
 assert s.simplify(z+ss-nn)==s.zeros(2,1)
 glob.append(s.simplify(val-a.dot(z)+cz))
assert s.simplify(glob[0]-glob[1])==-1
assert s.simplify(glob[2]-glob[0])==-2
Path(__file__).with_suffix('.json').write_text(json.dumps({'scope':'all odd d>=3','native_points':[str(z)for z in nat],'native_heights':vals,'global_heights':[str(z)for z in glob],'dv':-1,'db':-2,'db_plus_3_plus_dv':0},indent=2));print('PASS uniform exact reciprocal witness')
