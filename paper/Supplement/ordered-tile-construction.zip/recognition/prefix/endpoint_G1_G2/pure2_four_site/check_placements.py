import sympy as s,json,hashlib
from pathlib import Path
p=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/recognition_ledger/saved3_gate/prefix/endpoint_G1_G2/pure2_four_site')
a,h,i,j=s.symbols('a h i j',integer=True);e=2*a+1;Z=s.Matrix([e,1]);A=s.Matrix([a+1,a]);E=s.ones(2,1);ex=s.Matrix([1,0]);ey=s.Matrix([0,1]);V=lambda q:s.Matrix([q[1]-q[0],sum(q)]);rot=lambda q:s.Matrix([q[1],-q[0]]);B=2*h*A+E;C=A+B;S=C+A;rz=s.Matrix([2,e+1]);cz=s.Matrix([4-e,e]);t=s.Matrix(s.symbols('tx ty'));f=lambda q:rot(q-Z)+ex;out=[]
for name,R,o in [('short',2*C,B),('long',S,s.zeros(2,1))]:
 L=lambda q:R-ey-rot(q)
 for kind,old,cent,want in [('G1',(j+1)*V(Z),rz,o+E+2*(h-1-j)*A),('G3',h*V(Z)+s.Matrix([-1,1])+i*Z,cz,o+V(E)+(i-1)*V(A))]:
  assert all(s.expand(v)==0 for v in L(old+cent-t)-f(t)-want);out.append(name+'/'+kind)
 assert all(s.expand(v)==0 for v in L(h*V(Z)+s.Matrix([1,2]))-o-e*E);out.append(name+'/first_zero')
 for jj in [1,2]:
  want=o+V(E)+s.Matrix([e+2-jj,e-3]);assert all(s.expand(v)==0 for v in L(h*V(Z)+s.Matrix([0,jj]))-want);out.append(name+'/clip'+str(jj))
(p/'PLACEMENT_REPLAY.json').write_text(json.dumps({'all_pass':True,'exact_symbolic_identities':out},indent=2)+'\n');print(out)
