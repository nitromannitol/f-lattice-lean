# Genuine pure2 four-site G2: both siblings and both flips

Let the saved record be2^a, a>=1, and current tail length h>=1. Set A=(a+1,a), E=(1,1), B=2hA+E, C=A+B and S=C+A. C is the current odd standard; S is the current even alternate's standard comparator. The literal G2 is g_E on v=0,ex,ey,E, with heights0,0,-1,0. RIGHT G2 has zero affine slope. The SHORT occurrence is at B+v; the LONG occurrence is at v. These are the canonical original frames, not an unshifted proper endpoint polygon.

## Exact four-site pullback
Use reciprocal Z=(2a+1,1), a0=(1,0), Q=2a0+(2h+1)Z and O=a0+(h+1)Z. The genuine old six-site RIGHT coordinates are
 z=(h+1)V_Z+w, w_x=0,1, w_y=-1,0,1.
Its paid target value in BOTH sibling comparisons is E0(w)+dH(w), where E0=-w_y(w_y+1)/2 and dH=(h+1)(b_Z.w-c_Z)-h(h+1)T_Z/2. This is exactly reciprocal_actual_six/prove.py, not a formal0/1 domain extension.

For each target v set w=(v_y,1-v_x). The four correspondences are
 0 ->(0,1), ex ->(0,0), ey ->(1,1), E ->(1,0).
All belong to the paid six. No additional point is required. The source and target physical parities are opposite.

For SHORT use the exact standard map f_Q(z)=Rot(z-Q)+ex and the true target native reflection R_C=2C+V_C+delta. Direct vector expansion gives
 R_C-f_Q(z)=B+v.
Thus one must reflect AFTER the dual map; the direct dual point alone is not the actual RIGHT placement. Standard conjugacy and reflection give
 F_C(B+v)=F_Q(z)+h0(f_Q(z))-b_C.f_Q(z)-eta_C=g_E(v).
All four symbolic residuals vanish for arbitrary a,h. In particular the RIGHT slope is0, not b_B: in the literal odd source table the second near-q copy has primary slope0.

For LONG the global raw dual identity uses
 f=Rot(z-2O)+ex-B,
 H(f)=min(F_S(f),F_S(f-2A)+1),
 T_old(z)=G0(z)+H(f),
 G0=h0(z+V_Z)-b_Z.z+c_Z+1-b_S.f-eta_S.
The genuine raw H reflection is
 R_H=2A+V_S+delta,
 H(R_H-f)=H(f)-b_S.f-eta_S+1.
It follows by swapping the two standard offers; b_S.A=1. Vector expansion gives R_H-f=v. Therefore
 H(v)=T_old(z)-h0(z+V_Z)+b_Z.z-c_Z=g_E(v).
Again all four residuals vanish. The h0 parity here is the OLD parity1-parity(v), while the SHORT h0 uses the target parity. Omitting that reversal creates spurious quarter-unit errors. No native-current admission was used to derive the raw reflection.

## LEFT: the genuine endpoint correction, not a full-mask duality
The literal endpoint has reflection g_E(E-v)=g_E(v)-b_E.v, b_E=(1,-1). Its center is E, NOT the formal strict-standard center2E. The actual pure2 flipped helper adds E=ex+ey to G2 ONLY. This exactly compensates that missing E in the endpoint center, as verified in the historical INDEPENDENT_PURE_TWO_CORRECTED_EVEN_HEIGHT_ENDPOINT_AND_G2_SHIFT_AUDIT and its underlying literal same-order reflection proof. Subsequent G3 positions do not receive this correction.

Consequently the actual LEFT placements, in the aligned canonical frame, are
 L_short=R_C-B-E,  L_long=R_H-E.
Writing the local point as v' in the same four-point set, reflection of the RIGHT price gives
 SHORT: F_C(L_short+v')=g_E(v')+(b_C-b_E).v'-b_C.(B+E)-eta_C;
 LONG: H(L_long+v')=g_E(v')+(b_S-b_E).v'+1-b_S.E-eta_S.
These are a single affine jet in each sibling, on all four points. Their gradients are (2h+1)b_A and2(h+1)b_A respectively. Global-coordinate constants follow by subtracting that gradient dotted with L_short or L_long. The geometric identification of the aligned LEFT list uses the genuine endpoint-adjusted same-order reflection/UR domain theorem, not equality of four-site and six-site native masks.

The LEFT pullback is obtained by first reflecting v' to E-v': its old six-site coordinate is w'=(1-v'_y,v'_x). The four points are(1,0),(1,1),(0,0),(0,1), also all paid. Thus both flips require the SAME four old six-site points.

## Actual prefix scalar
In the actual normalized RIGHT helper the only G1 copy meeting G2 is the first G1@E. The four G1 queries are-E,-ey,-ex,0; only0 is native in the genuine near-one standard (xmin=ymin=0), with height0. Thus the contact is exactly v=E and the G2 height there is0. The exact RIGHT prices above are also0 at this contact (SHORT at B+E, LONG at E). Therefore the G2 projective scalar synchronizes with the actual prefix gauge, not an independently chosen constant. The true endpoint-adjusted same-order reflection transports this scalar calibration to LEFT; its contact is v'=0. This uses the historical actual G1 support/zero value and reflection input, not current recurrence.

Scope: all a,h>=1 including a=1, where the old standard source is its genuine root staircase. Actual-six symbolic prices cover Z denominator3,5 and all odd>=7. This pays the four G2 sites and their prefix calibration conditional on those admitted target and alignment inputs. It does not assert that every G3 native value survives a clipped join, nor prove fixed-padding safety.
