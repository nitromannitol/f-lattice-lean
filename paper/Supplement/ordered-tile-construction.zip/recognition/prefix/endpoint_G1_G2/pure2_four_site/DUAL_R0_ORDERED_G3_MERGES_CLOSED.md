# Dual R0: actual clipped merges and zero contacts

This closes the earlier generic warning in PURE_ALT_RESTORATION_CONSUMER_ADDENDUM. Use the genuine nominal standard and alternate native bijections, including the literal corners, and the paid reciprocal ordered seed. No equality between six-site and four-site endpoint masks is asserted.

Set e=2a+1>=3, Z=(e,1), A=(a+1,a), E=(1,1), Y=V_Z, V0=(-1,1), B=2hA+E, C=A+B, S=C+A, h>=1. The old RIGHT helper is translated by Y in its outer target. Its actual G1 origins are (j+1)Y, j=0,...,h-1; G2 has sites(h+1)Y+w, w in{0,1}times{-1,0,1}; G3 origins are hY+V0+iZ, i=1,...,2h-1 SHORT, and1,...,2h LONG.

## Actual placed mapping, not only primitive covariance
The physical maps from the old outer RIGHT piece are
 Lshort(z)=2C-ey-Rot(z),
 Llong(z)=S-ey-Rot(z)=Lshort(z)-B.
These are exactly reflection after the current analytic dual maps proved in FOUR_SITE_DUAL_PRICE_AND_PREFIX. The SHORT base offset is B, the LONG base offset0; write it as o.

The old standard primitive reflection center is R_Z=(2,e+1). Reflect its local point before the exact nominal standard bijection. Direct vector calculation maps G1@((j+1)Y) to the TRUE near-one G1 occurrence
 o+E+2(h-1-j)A.
Thus G1 order reverses, but its whole native union and coherent heights are preserved. All G1 are inserted BEFORE G2 and EVERY G3, so this harmless internal reversal changes neither the prefix at the first G3 nor any later overlap.

The old alternate reflection center is C_Z=(4-e,e). Reflect its local point before the newly proved exact nominal alternate bijection f_Z. Direct calculation maps G3@(hY+V0+iZ) to
 o+V_E+(i-1)V_A, V_E=(0,2).
These are the genuine original pure2 RIGHT centers: get_even_l_offsets gives the first center V_E relative to G2, and increment V_A. Most importantly, index i is PRESERVED, not reversed. SHORT and LONG have exactly their original index masks. The old source reflection is already included in this calculation; it must not be applied to the placed source a second time. Its affine jet and the nominal harmonic conjugacy give one common pointwise transform, so signed price defects are preserved.

The target four-site G2 corresponds to old w=(0,1),(0,0),(1,1),(1,0). Only old w=(0,-1),(1,-1) are omitted. The genuine old endpoint is DISJOINT from EVERY G3 by the support inequality in PURE3_ENDPOINT_ORDERED_LONG_EXTENSION. Removing these two sites therefore changes neither a G3 overlap nor its fresh set. It cannot remove a later G3 zero contact or create a new G3 clipping site. This is the specific missing condition that resolves the earlier warning.

## Exact clipped sites and attained contacts
Old RIGHT first-G3 defects are precisely the two last-G1 sites(h-1)Y+(0,j), j=1,2, before the outer Y translation. Incoming G3 is one above the prefix there. Their images in the target first-G3 native coordinates are
 (e+1,e-3), (e,e-3).
The target first-G3 origin is o+V_E. At these two sites the actual merged value remains the preceding G1 value, one below the incoming raw ALT value. Every other first-G3 overlap has equality. These points are not erased by the four-site endpoint change because G2 is disjoint.

The first G3 has an explicit equality contact independent of a finite-domain existence assertion: old last-G1 coordinate(1,2). Its raw ALT coordinate is(2-e,0), with value0. At h=1, G(1,2)=-1, and the calibrated first G3 value is0-2+1=-1. The exact common h-transport preserves equality. Its target address is
 o+eE,
 and its target first-G3 local coordinate is(e,e-2). Both are genuine native points, including e=3. Thus the new first G3 cannot have only positive-defect overlaps: its maximum touching difference is attained at zero.

Each successive G3 has the genuine old pair of raw contact coordinates(1-e,-1) and(1,0). The calibrated old fields agree there; the exact placed/native bijections preserve this equality and the index order. The potential extra i=2/G1 contact has equality by the old literal proof. For the LONG appended i=2h the same predecessor contact persists; at h=1 its sole additional G1 overlap is the already paid equality. Therefore every G3 greedy scalar is its transported candidate scalar, and there are exactly the two transported first-G3 clips, no new ones.

## LEFT and both siblings
The actual pure2 LEFT G2-only +E correction restores the endpoint reflection center. The historical endpoint-adjusted same-order helper reflection therefore sends the just-proved RIGHT ordered list to the literal LEFT list, including the added LONG endpoint. It preserves overlap defects and the zero contacts, with the affine gauges in FOUR_SITE_DUAL_PRICE_AND_PREFIX. Later G3 running origins are unchanged by the G2-only correction. This transports the entire ordered conclusion to LEFT; it is not an inference from equality of unlabelled unions.

## Consequence and scope
For both corrected siblings and flips, the actual G1/G2/G3 prefix has the transported ordered heights: strong G1 correspondence; the actual four G2 prices and scalar; exact G3 native masks/indices, two retained first-owner clips, and attained zero touching at every G3. The original alternate rails/corners and root e3 are included by the nominal native bijection. Outer chronological gluing, the separate analytic target values at the retained clips/fresh sites, and implementation padding retain their own stated producers. This proof removes the specific clipped-merge/missing-two-endpoint-sites obstruction; it does not replace those other obligations.
