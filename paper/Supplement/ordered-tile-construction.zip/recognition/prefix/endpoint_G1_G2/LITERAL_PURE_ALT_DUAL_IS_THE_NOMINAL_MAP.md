# Exact pure alternate mask, jet, and nominal source map (two families)

All old even pure primitive births are phase zero, regardless of a later consumer's phase W. Put f_Z(z)=Rot(z-Z)+e1 with Rot(x,y)=(y,-x). In the authentic consumed/LL physical frames described in ACTUAL_ODD_ALTERNATE_SYMMETRIES, f_Z bijects the entire true even alternate crop to the entire true dual odd alternate crop. Further, for every physical z, with genuine global extensions,

     ALT_odd(f_Z(z)) = ALT_even(z)+h0(f_Z(z)).

This proves the nominal *primitive source* correspondence, not automatic equality of placed helpers. True restoration offsets in particular saved records, the current target map/affine jet, possible clipping by earlier owners, and actual chronology must still match. Both added rails/corners and the d=3 literal root are retained.

1. Old reciprocal even Z=(d,1), odd d>=3; notation J for the genuine raw even ALT, A for the genuine LL near-one odd ALT. Then f_Z(x,y)=(y,d-x). The authenticated literal finite-support bijection in the pure initializer theorem maps old (x,y) directly to (d-y,x+2d-4). Compose it with the actual old support reflection about C=(4-d,d): z↦C-z. This gives EXACTLY (y,d-x). Reflection preserves the literal mask: it exchanges x+y lower/upper bands and the two side rails, and sends its two points (1-d,-1),(1-d,0) to (3,d+1),(3,d) respectively, preserving every added corner and the diagonal. The finite array x-bound 4-2d<=x<=d also exchanges endpoints. Thus no one-way crop inclusion or enlarged R2 is being substituted.

At f_Z(x,y) the authentic field formula (A) gives
  A(f_Z(z))=J(C-z)+h0(f_Z(z))+b_Z.z+c_Z-d-2.
The genuine J midpoint is symmetric about 2e1+(1,-1), before its secondary shift. Its V_Z jet has scalar -c_Z-1. Since C=2e1+(1,-1)+V_Z, one gets
  J(C-z)=J(z)-b_Z.z+1-eta_Z.
The constants cancel by c_Z-eta_Z=d+1. This proves the asserted height identity, with no residual scalar even at d=3.

2. Old near-one even Z=(a+1,a-1), even a>=4; notation J for its genuine LL/consumed ALT, B for the genuine LL reciprocal odd ALT. The true literal bijection sends (u,v) in the odd LL crop to J-coordinates (-v,u-1)+Z, by (B) of the initializer theorem. Its inverse is exactly
  f_Z(x,y)=(y-a+2,a+1-x).
Furthermore B(u,v)=J(-v,u-1)+h0(u,v). As the genuine primary Z character of J is0, substitution proves the same POINTWISE formula without any adjustment. This uses the full support bijection, not just fields modulo deck. The smallest a=2 is NOT a doubled ladder; it is the common root already handled by case1 with d=3.

Consequently a true pure G3 native-crop theorem can be transported with the same standard f_Z map used in the proper source table (beta=tau=0 for the earlier primitive), despite the failure of a literal 6-site/4-site G2 endpoint bijection. On the reciprocal side reflection precomposition is essential: the direct initializer support map alone is not f_Z. The clipped-contact pattern must be transformed as well. At a placed old address y=z+o, the corresponding new address uses the true target clock, and maps the old source z by this f_Z, not by the current child's tau.
