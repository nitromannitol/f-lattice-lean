import sympy as s,itertools,json,hashlib
from pathlib import Path
a,k=s.symbols("a k",integer=True,nonnegative=True)
Z0=s.Integer(0);ve=lambda d,n:s.Matrix([d,n]);t=lambda P,z:P[1]*z[0]-P[0]*z[1];sg=lambda P,z:(P[0]+P[1])*z[0]+(P[0]-P[1])*z[1]
V=lambda P:ve(P[1]-P[0],sum(P));T=lambda P:-t(P,V(P));c=lambda P:(T(P)+sum(P))/2
P=Path(__file__).resolve().parent;rows=[]
def nn(x):
 return min(s.Poly(s.expand(x),a,k).coeffs()+[0])>=0
def eq(x):return s.expand(x)==0
for e in [s.Integer(3),s.Integer(5),2*a+7]:
 Z=ve(e,1);Y=V(Z);h=k+1
 def G0(z):
  # Prove ONE real chart uniformly for each argument and parameter slice.
  for i,j in sorted(itertools.product(range(-4,5),range(-2,3)),key=lambda q:abs(q[0])+abs(q[1])):
   X,B=z+i*Z+j*Y
   core=all(nn(n)for n in [X+e-2,e-X,B,e+1-B,X+B-1,e+2-X-B])
   cr=(eq(X)and eq(B))or(eq(X-2)and eq(B-e-1))
   ex=[(X,B),(X-2,B-e-1)]
   if not(core or cr):continue
   if not cr and not all(any(nn(z-1)or nn(-z-1)for z in pair) for pair in ex):continue
   if nn(X-1):mn=0
   elif nn(1-X):mn=X-1
   else:continue
   return s.expand(-B*(B-1)/2+mn+int(cr)-j*t(Z,z)+j*c(Z)+j*(j-1)*T(Z)/2)
  raise Exception('G',e,z)
 for mode in [0,1]:
  m=h+mode; C=ve(m*e+1,m)
  for xx,yy in itertools.product(range(2),[-1,0,1]):
   w=ve(xx,yy);y=w+(h+1)*Y; dH=(h+1)*t(Z,w)-(h+1)*c(Z)-h*(h+1)*T(Z)/2; E0=-yy*(yy+1)//2
   for arm in [1,2]:
    # z=b+(nY), b=w or w-Z, d is actual primary cost to add after F_C
    if mode==0 and arm==1:n=h+1;ell=-1;extra=0;want=E0+2
    if mode==0 and arm==2:n=h;ell=0;extra=t(Z,y)+T(Z)-c(Z);want=E0
    if mode==1 and arm==1:n=h+2;ell=0;extra=-t(Z,y)+c(Z)+1;want=E0+1
    if mode==1 and arm==2:n=h+1;ell=0;extra=0;want=E0
    l=int(arm==1);f=l*(1-mode)
    z=w+ell*Z+n*Y;v0=z-l*V(C);v=v0+2*f*C
    d,nC=C;tc=T(C);par=(xx+yy)%2
    ends=(nC-tc,d,2-d+nC,2*tc+d+nC-2)if par else(1-tc,d+nC-1,0,2*tc+2*nC)
    tlo,thi,slo,shi=ends;sl=[t(C,v)-tlo,thi-t(C,v),sg(C,v)-slo,shi-sg(C,v)]
    assert all(nn(q)for q in sl),(e,mode,xx,yy,arm,[s.expand(q)for q in sl])
    # v=b0+(ell+2fm)Z+(n-l*m)Y with b0 independent of e,h.
    b0=w-l*ve(-1,1)+2*f*ve(1,0);gindex=n-l*m
    assert all(eq(q)for q in(v-b0-(ell+2*f*m)*Z-gindex*Y))
    def value(delta):
     b=b0+delta
     return G0(b)+gindex*t(Z,b)-gindex*c(Z)-gindex*(gindex-1)*T(Z)/2
    raw=[value(ve(0,0)),value(ve(-1,-1))-v[1]+2*m]
    prices=[s.expand(z+l*t(C,v0)-l*c(C)+extra-dH)for z in raw]
    sl=[s.expand(q-want)for q in prices]
    assert all(nn(q)for q in sl) and any(eq(q)for q in sl),(e,mode,xx,yy,arm,prices,want,sl)
    rows.append(dict(region=str(e),long=mode,point=[xx,yy],arm=arm,representative=[-l,f],normalized_sheets=[str(q)for q in prices],min_expected=want))
(P/'SYMBOLIC.json').write_text(json.dumps(rows,indent=2));print(len(rows),'exact 2-arm rows, 4 true facets and 2 offer comparisons in each')
