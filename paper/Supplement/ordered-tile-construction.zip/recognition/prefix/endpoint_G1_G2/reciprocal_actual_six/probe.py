from fractions import Fraction
def add(*vs):return tuple(map(sum,zip(*vs)))
def mul(k,v):return tuple(k*i for i in v)
def T(P):d,n=P;return d*d+2*d*n-n*n
def V(P):d,n=P;return n-d,d+n
def t(P,z):d,n=P;x,y=z;return n*x-d*y
def s(P,z):d,n=P;x,y=z;return (d+n)*x+(d-n)*y
def c(P):return (T(P)+sum(P))//2
def E(P,z):
 d,n=P;W=T(P);parity=sum(z)%2
 if parity:tl,th,sl,sh=n-W,d,2-d+n,2*W+d+n-2
 else:tl,th,sl,sh=1-W,d+n-1,0,2*W+2*n
 return tl<=t(P,z)<=th and sl<=s(P,z)<=sh
def vals(e,h,mode,w):
 Z=(e,1);Y=V(Z);m=h+(mode=='long');C=(m*e+1,m)
 def G(z):
  for i in range(-10,11):
   for j in range(-4,5):
    X,Y0=add(z,mul(i,Z),mul(j,Y));core=2-e<=X<=e and 0<=Y0<=e+1 and 1<=X+Y0<=e+2;cr=(X,Y0)in[(0,0),(2,e+1)]
    if core or cr:return -Y0*(Y0-1)//2+min(X-1,0)+int(cr)-j*t(Z,z)+j*c(Z)+j*(j-1)*T(Z)//2
  raise ValueError(z)
 def F(z):
  ret=[]
  for j in [0,1,2]:
   v0=add(z,mul(-j,V(C)))
   for f in [-1,0,1]:
    v=add(v0,mul(2*f,C))
    if E(C,v):
     vG=add(v,mul(-2*m*f,Z))
     def ge(v):
      l=(v[1]+(e+1)//2)//(e+1);b=add(v,mul(-l,Y))
      return G(b)+l*t(Z,b)-l*c(Z)-l*(l-1)*T(Z)//2
     h1=ge(vG);h2=ge(add(vG,(-1,-1)))-v[1]+2*m
     fz=min(h1,h2)+j*t(C,v0)-j*c(C)-j*(j-1)*T(C)//2
     ret.append(((j,f),fz))
  assert ret and len({z for i,z in ret})==1,(e,h,mode,w,z,v0,ret)
  return ret[0]
 yy=add(w,mul(h+1,Y));dH=(h+1)*t(Z,w)-(h+1)*c(Z)-T(Z)*h*(h+1)//2
 if mode=='short':
  ff1,q1=F(add(yy,mul(-1,Z)));ff2,q2=F(add(yy,mul(-1,Y)));q2+=t(Z,yy)+T(Z)-c(Z)
 else:
  ff2,q2=F(yy);ff1,q1=F(add(yy,Y));q1+=-t(Z,yy)+c(Z)+1
 return (ff1,ff2),(q1-dH,q2-dH)
if __name__=='__main__':
 for h in [1,2,3,8]:
  for mode in ['short','long']:
   print(5,h,mode,[(w,vals(5,h,mode,w)) for w in [(x,y)for y in [-1,0,1]for x in [0,1]]])
