"""Direct QF_LIA whole E_A joint and actual literal target (2x heights)."""
import sys,itertools,json,hashlib,subprocess
from pathlib import Path
from functools import lru_cache
import sympy as sp
sys.path.insert(0,'/tmp/f_lattice_z3')
import z3 as S
p=Path(__file__).resolve().parent
d,x,y=S.Ints("d x y"); ds,xs,ys=sp.symbols("d x y"); rows=[]
a=d-1; A=ds-1; TA=A*A+2*A-1
def trans(e):
 poly=sp.Poly(sp.expand(e),ds,xs,ys);result=0
 for key,c in poly.terms():
  assert sum(key)<=1 and c.is_Integer;(result:=result+int(c)*{(0,0,0):1,(1,0,0):d,(0,1,0):x,(0,0,1):y}[key])
 return result
constant_guard=S.And(d>=3,d%2==1,x>=-5*d,x<=5*d,y>=-5*d,y<=5*d)
# For each expression, separate d*(alpha*d+beta*x+gamma*y) from affine residual.
# Need sign e>=0. Under box the affine residual <= M*d, so enumerate q in [-M,M].
def guard(e):
 P=sp.Poly(sp.expand(e),ds,xs,ys)
 q0=P.coeff_monomial(ds**2)*ds+P.coeff_monomial(ds*xs)*xs+P.coeff_monomial(ds*ys)*ys
 rem=sp.Poly(sp.expand(e-ds*q0),ds,xs,ys)
 M=sum(abs(int(rem.coeff_monomial(v)))*c for v,c in [(ds,1),(xs,5),(ys,5),(1,1)])+1
 q=trans(q0);rr=trans(rem.as_expr())
 return S.Or(q>M,*[S.And(q==i,i*d+rr>=0)for i in range(-M,M+1)])
t=xs-A*ys;s=(A+1)*xs+(A-1)*ys
E=S.Or(*[S.And((x+y)%2==b,*[guard(q)for q in (t-tl,th-t,s-sl,sh-s)])for b,(tl,th,sl,sh)in enumerate([(1-TA,A,0,2*TA+2),(1-TA,A,3-A,2*TA+A-1)])])
# The even upper transverse d_A+n_A-1=a too. Odd upper s=2TA+L_A-2=2TA+a-1.
def ck(name,bad,more=()):
 so=S.Solver();so.add(constant_guard,*more,bad);raw=so.to_smt2();(p/(name+'.smt2')).write_text(raw);ans=str(so.check()); m=str(so.model()) if ans=='sat' else '';print(name,ans,m,flush=True); rows.append((name,ans,m,hashlib.sha256(raw.encode()).hexdigest()));(p/'results.json').write_text(json.dumps(rows,indent=2));return ans
def nat(X,Y):return S.Or(S.And(X>=2-d,X<=d,Y>=0,Y<=d+1,X+Y>=1,X+Y<=d+2),S.And(X==0,Y==0),S.And(X==2,Y==d+1))
def bit(c):return S.If(c,1,0)
def min0(a):return S.If(a<0,a,0)
def max0(a):return S.If(a>0,a,0)
@lru_cache(None)
def doubled(dx,dy):
 # 2*(F_Z(u+(dx,dy))+y(y-1)/2) using genuine coherent native representatives.
 offers=[];T=ds**2+2*ds-1;cz=(ds**2+3*ds)/2
 for i,j in sorted(itertools.product(range(-4,5),range(-2,3)),key=lambda q:abs(q[0])+abs(q[1])):
  xx=x+dx+i*d+j*(1-d);yy=y+dy+i+j*(d+1)
  b=dy+i+j*(ds+1)
  rem=-2*b*ys-b*(b-1)-2*j*(xs+dx-ds*(ys+dy))+2*j*cz+j*(j-1)*T
  offers.append((nat(xx,yy),trans(rem)+2*min0(xx-1)+2*bit(S.Or(S.And(xx==0,yy==0),S.And(xx==2,yy==d+1)))))
 cover=S.Or(*[g for g,v in offers]); assert ck('cover_%s_%s'%(dx,dy),S.Not(cover),[E])=='unsat'
 z=0
 for g,v in reversed(offers):z=S.If(g,v,z)
 return z
g=doubled(2,0);gw=doubled(1,1);gp=doubled(-1,1)
P2=g-gw-2*y;Db2=gw-gp
assert ck('joint',S.And(P2>0,Db2<2),[E])=='unsat'
# actual doubled ladder E_A by original base_case for a=d-1>=4
N=S.Or(S.And(x>=2-a,x<=2*a,y>=0,y<=a+2,x+y>=1,x+y<=2*a+3,S.Not(S.Or(S.And(y==0,x>=a),S.And(y==a+2,x<=2)))),S.And(x==0,y==0),S.And(x==a+2,y==a+2),S.And(x+y==a+2,y>1,y<a+1,x>=2-a,x<=2*a))
C=min0(x-1)+max0(x+y-a-2)+min0(a+1-x)+bit(S.Or(S.And(x==0,y==0),S.And(x==a+2,y==a+2),S.And(x+y==a+2,y>1,y<a+1)))
assert ck('native_in_E',S.Not(E),[N,d>=5])=='unsat'
assert ck('target_seed',(2*C)!=S.If(g<=gp+2*y+2,g,gp+2*y+2),[N,E,d>=5])=='unsat'
# Actual d=3 odd source is a staircase, not doubled ladder a=2; certify by complete enumeration.
assert ck('root_box',S.Or(x<0,x>4,y<0,y>4),[E,d==3])=='unsat'
root_rows=[]
for ix in range(5):
 for iy in range(5):
  ok=((iy+1-ix)>=-1 and iy+1-ix<=3) or (ix,iy)in[(0,3),(4,1)]
  if ok:
   source=-((ix-iy-1)**2//4)+min(3-iy-1,0)+int((ix,iy)in[(0,3),(4,1)])
   cc=2*source+iy*(iy-1)
   root_rows.append(S.And(x==ix,y==iy,S.If(g<=gp+2*y+2,g,gp+2*y+2)!=cc))
assert ck('root_seed',S.Or(*root_rows),[d==3,E])=='unsat'
# W1 exact r_m,rplus, d_b on E; all in doubled units.
g2=doubled(0,2); g3=doubled(-2,2); g4=doubled(3,1)
rw2=gw-g2-2*(y+1); rp2=gp-g3-2*(y+1)
r=-P2; rm=-rw2;rplus=4-rp2; db=g4-gw-4; dv=Db2-4
assert ck('physical_bounds',S.Or(db < -4,dv< -4,rplus<0),[E])=='unsat'
sz=(ds+1)*xs+(ds-1)*ys;TT=ds**2+2*ds-1;K0=ds+1
# x_base=u-Z+2a, x'=x_base-Z. Threshold 5-2d applies to f0.
hS=guard(sz-TT+2*K0-(5-2*ds));hL=guard(sz-2*TT+2*K0-(5-2*ds))
assert ck('short_f0',S.Or(r<0,rm<0),[E,hS])=='unsat'
assert ck('long_f0',S.Or(r<0,rm<2),[E,hL])=='unsat'
def odd_native(X,Y):
 return S.Or(S.And(X>=2-a,X<=2*a,Y>=0,Y<=a+2,X+Y>=1,X+Y<=2*a+3,S.Not(S.Or(S.And(Y==0,X>=a),S.And(Y==a+2,X<=2)))),S.And(X==0,Y==0),S.And(X==a+2,Y==a+2),S.And(X+Y==a+2,Y>1,Y<a+1,X>=2-a,X<=2*a))
def root_native(X,Y):
 return S.Or(S.And(X>=0,X<=4,Y>=0,Y<=4,Y+1-X>=-1,Y+1-X<=3),S.And(X==0,Y==3),S.And(X==4,Y==1))
assert ck('root_native_in_E',S.Not(E),[d==3,root_native(x,y)])=='unsat'
o=[];root=[]
for i,j in sorted(itertools.product(range(-2,3),repeat=2),key=lambda q:abs(q[0])+abs(q[1])):
 X=x+i*2*a+j*(1-a);Y=y+2*i+j*(a+1)
 C=min0(X-1)+max0(X+Y-a-2)+min0(a+1-X)+bit(S.Or(S.And(X==0,Y==0),S.And(X==a+2,Y==a+2),S.And(X+Y==a+2,Y>1,Y<a+1)))
 tA=xs-A*ys; czA=(TA+A+1)/2;b=2*i+j*(A+1)
 residual=trans(-2*ys*b-b*(b-1)-2*j*tA+2*j*czA+j*(j-1)*TA)
 o.append((odd_native(X,Y),residual+2*C))
 # root is small; M polynomial piecewise via table.
 for xx,yy in itertools.product(range(5),repeat=2):
  if not(-1<=yy+1-xx<=3 or (xx,yy)in[(0,3),(4,1)]):continue
  cc=2*(-((xx-yy-1)**2//4)+min(3-yy-1,0)+int((xx,yy)in[(0,3),(4,1)]))+yy*(yy-1)
  root.append((S.And(X==xx,Y==yy),residual+cc))
def sel(offers):
 v=0
 for b,c in offers[::-1]:v=S.If(b,c,v)
 return v
for n,cond,offers in [('allEA_seed',d>=5,o),('root_allEA_seed',d==3,root)]:
 assert ck(n+'_cover',S.Not(S.Or(*[g for g,v in offers])),[E,cond])=='unsat'
 assert ck(n,sel(offers)!=S.If(g<=gp+2*y+2,g,gp+2*y+2),[E,cond])=='unsat'
for name,ans,model,hsh in rows:
 got=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(p/(name+'.smt2'))],capture_output=True,text=True,check=True).stdout.strip()
 assert got==ans=='unsat',(name,got,ans)
(p/'FRESH_CLI.json').write_text(json.dumps({name:hsh for name,_,_,hsh in rows},indent=2));print('fresh CLI passes:',len(rows))
