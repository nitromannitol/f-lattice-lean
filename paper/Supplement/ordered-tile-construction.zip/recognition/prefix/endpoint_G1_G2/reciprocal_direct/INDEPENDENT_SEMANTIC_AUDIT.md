# Independent reciprocal endpoint direct certificate audit

**PASS at its stated scope.** This checks check.py, the actual pure seed formulas in recovery_20261101_0745/f_lattice_original_tests/original_port_base.py, all19 recorded raw hashes, and19 fresh standalone Z3 replays (all UNSAT). It is not a new independent field-coherence proof. Genuine pure standard deck coherence is an adopted upstream premise.

## Geometry and exact QF_LIA reduction
Here d>=3 odd, Z=(d,1), A=(d-1,1); write a=d-1>=2 and T_A=a²+2a-1. The two E_A rows in the encoder are exactly the odd-standard rows: t=x-ay ranges[1-T_A,a] in both parities, while s=(a+1)x+(a-1)y ranges[0,2T_A+2] even and[3-a,2T_A+a-1] odd. There is no phase-swapped bound.

The global box is safe, but needs an explicit proof because the encoded E itself is only exact inside that box. Uniformly relax the rows to |t|<=T_A and -a<=s<=2T_A+a+2. Inverting gives T_A x=(a-1)t+a s and T_A y=s-(a+1)t. Since T_A>=a+2, these imply |x|<=4a-1 and |y|<=a+4, both strictly below5d. Thus no actual E point is omitted. Both actual native selectors also lie in this box by their elementary coordinate bounds.

For every polynomial guard the implementation writes e=d*q+rem, with q affine integral and rem affine integral. Its M ensures |rem|<M*d throughout the box. Therefore q>M implies e>0, q<-M implies e<0, and the enumerated middle q values test e>=0 exactly. The trans routine asserts every remaining monomial is affine with integer coefficient. Hence these are genuinely quantifier-free linear integer obligations, not a nonlinear relaxation or sampled d range.

## True seeds and positive aliases
The Z seed is precisely get_staircase_even: -y(y-1)/2+min(x-1,0), with the genuine native hexagon and the two full corners(0,0),(2,d+1), each adding1. The A seed for d>=5 is precisely get_doubled_ladder_odd at denominator a, including both removed boundary runs, restored corners and diagonal increment. The d=3 root instead uses get_staircase_odd at its authentic y+1 coordinates: the recentered exceptional points are(0,3),(4,1). It is not the false doubled-ladder endpoint.

Every offered value is guarded by a true native point after a genuine primary/secondary deck displacement. The height pullback is F(z)=F(z+iU+jV)-j*t(z)+j*c_X+j(j-1)T/2, where c_X=(T_X+L_X)/2 is POSITIVE and the actual secondary constant is -c_X, with the native quadratic baseline expanded before serialization. Z has U=Z; odd A has U=2A. All primary characters are0. The doubled residuals in check.py have exactly these signs and constants. Priority selection does not license missing points: each selector has a separate UNSAT coverage gate. Coherence of alternative offers is supplied by the genuine upstream seed extension, not by priority order.

The target_seed/root_seed checks bind the literal native values. allEA_seed and root_allEA_seed additionally prove the genuine coherent A extension equals the asserted minimum on the WHOLE E_A, with independently checked positive alias coverage. Native-only equality is not being promoted to E without these last gates.

## Signed prices and units
All quantities are doubled; the common added y(y-1) baseline cancels. In the endpoint W1 frame x_base=u+Z-2A:
 r2=-P2, d_v2=Db2-4,
 rm2=-rw2, rplus2=4-rp2, d_b2=g4-gw-4.
These match r=eta_A-Pstd(x_base), D=F-F(.+2A), and the true V_Z character. In particular joint bad condition P2>0 AND Db2<2 is exactly r<0 AND d_v<-1, not the opposite sign. physical_bounds excludes d_b<-2,d_v<-2,rplus<0 in the correct doubled units.

SHORT f0's geometric sufficient threshold is s_Z(x_base)>=5-2d, encoded hS using s_Z(u)-T_Z+2K0 with K0=d+1. LONG uses x'=x_base-Z, encoded hL=s_Z(u)-2T_Z+2K0. short_f0 proves r>=0,rm>=0; long_f0 proves r>=0,rm>=1 (doubled threshold2). These are exactly the min-target consumer interfaces in CONSUMER_LINKAGE_AUDIT, not the obsolete stronger unconditional D>=-1. The geometric implication from the actual fold flag to the threshold remains the separate earlier alias/fold theorem.

## Scope and provenance
The19 producers and19 fresh CLI results prove the specified endpoint price, coverage and whole-E seed identities for all odd d>=3. They do not themselves prove helper placement, chronological scalar normalization, global seed recurrence, or fixed-padding correctness. No expensive fresh encoder was needed: source semantics, linearization, raw hashes and standalone replays were checked independently. Existing producer files were not modified.
