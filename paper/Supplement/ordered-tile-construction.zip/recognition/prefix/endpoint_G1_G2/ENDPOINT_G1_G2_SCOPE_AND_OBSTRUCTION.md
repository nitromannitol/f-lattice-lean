# Proper-selected pure endpoints: G1/G2 audit and exact remaining comparison

This packet specializes the real source parameters, not merely an encompassing proper-cone relaxation. No G3 proof or clipped pure3 G2 proof is repeated.

## 1. Fresh one-variable geometry

W0 saved3 near-one: birth a=(a,a-1),R=(1,1), Z=(2a+1,2a-1),a>=2; effective A=a. Substitute n=t+1,d=t+2,e=r=1 in the original generic scripts.

W1 saved1 reciprocal: real birth a=(1,0), R=(d-2,1), Z=(d,1), effective A=(d-1,1), odd d>=3. Substitute birth n=0,d_birth=1,r=1,e=2t+1. The selected A is proper even though its real birth a is not.

All specialized certificates pass:

* near-one W0 G1:132 facets (direct query, four-fold box, final/longitudinal margins);
* near-one W0 G2:114 facets (SHORT, LONG and LONG rim);
* reciprocal W1 G1:262 facets (two four-fold boxes, no-transverse reductions, harmonic/terminal margins);
* reciprocal W1 G2:116 facets (SHORT and LONG).

Total624 exact coefficient facets. Copies are in separate endpoint directories, leaving all original scripts unchanged. These are unbounded parameter/rank proofs, not finite evaluations. They license the stated polygon/rim manipulations but cannot replace a missing OLD FIELD range with a wider range.

## 2. Genuine near-one old prices match the pure2 certificates directly

In pure2_initialization the parameter called A is2a and its K is a-1. The exact field is Z=(2a+1,2a-1). Its raw P uses shift(-1,2a-1)=V_A and linear(a-1)x-ay, precisely the current W0 P. Its raw D+ uses shift(1,1), congruent to-2A modulo the genuine zero-primary Z. Thus the earlier full-polygon price/halo proof supplies P in[c_A-1,c_A] and the actual D window with the correct gauge.

The earlier pure2 central parameter (2a-1)(2a+2) equals the actual K=M(A,Z)=4a²+2a-2. Its genuine closed halo and central D bands are therefore EXACTLY the ranges consumed by these W0 endpoint arguments. ENTIRE_ZERO_AND_HARMONIC_STRIPS.md includes both true added corners and all a>=2. No endpoint-corner omission is needed.

Consequently the specialized near-one geometry/rim and the old scalar/strip inputs import with the correct parameters. Any use of a current stationary representation or abstract stage2 donor remains its explicitly prior canonical premise; these endpoint checks do not reprove source recognition or chronology.

## 3. Reciprocal effective prices: exact conversion, but NOT the same central band

Let F be the genuine reciprocal pure3 standard Z=(d,1),a0=(1,0),v0=(-1,1). Define the actual raw certificate prices

 Praw(z)=F(z)-F(z+v0)-z_y,
 Draw(z)=F(z)-F(z-2e1).

For effective A=Z-a0, V_A=V_Z-v0 and a_Z-a_A=(0,-1). Genuine primary/secondary characters give

 D_effective(z)=F(z)-F(z+2A)=Draw(z),
 Pstd_effective(z)=Praw(z)+eta_A-1.

Thus the genuine raw span Praw in[0,1] gives the exact effective span[eta_A-1,eta_A]. The old physical zero/harmonic strips and native D range likewise retain their authentic meaning. The saved1 Hhat lower bound must use the TRUE birth a0 intrinsic chain, not an invented effective parent.

However K_effective=M(A,Z)=d²+d-2, whereas the REAL birth K0=d+1. The actual pure3 central |Draw|<=1 certificate is [2-2d,3d+1]. It is NOT the much larger interval [3-d-K_effective,2d+K_effective]. Therefore the G2 proof cannot import its separate db>=-1 premise merely because the specialized geometry puts the point in that larger interval.

## 4. Uniform genuine obstruction to that separate G2 premise

Take the genuine A polygon point u=0, any odd d>=3. Then x=u+Z-2A=(2-d,-1), v=V_A=(2-d,d), and

 w=x-v=(0,-d-1),
 x-v-2A=w-2A.

The effective D at w-2A equals Draw(w+2e1) by the actual primary2Z. The three relevant arguments have genuine native representatives

 w+V_Z+U_Z=(1,1), height0;
 w-2e1+V_Z+2U_Z=(d-1,2), height-1;
 w+2e1+V_Z+U_Z=(3,1), height0.

All three belong to the literal reciprocal native domain for every odd d>=3, including d3. From its exact native formula and secondary character cV=-(d²+3d)/2,

 F(w)=(-d²+d)/2,
 F(w-2e1)=F(w)+1,
 F(w+2e1)=F(w)-2.

Hence dv=D(x-v)=-1 and db=D(x-v-2A)=-2. This disproves the separate claimed db>=-1 uniformly, not just in a sampled case. `reciprocal_witness.py` verifies the exact symbolic representatives/jets. The price combination that actually matters is nevertheless

 db+3+dv=0.

So this is NOT a counterexample to G2 value recognition. It identifies precisely why the old sufficient proof cannot be imported unchanged. A joint inequality db+dv>=-3 on the selected carrier, or direct authentic pure-field evaluation of the first offer, can repair it. LONG uses the same relevant I combination after its normalized shift; the same issue remains.

## 5. Paid versus remaining

Paid: all listed endpoint geometry, actual parity/rim facets, exact price normalization to authentic pure certificates, and a source-derived all-parameter diagnosis of the false separate G2 range premise. G1 uses the genuine old halo bounds/price span and the saved1 true-birth chain; no effective-K central interval may be inserted without proof.

Remaining for a complete reciprocal G2 value theorem: replace the false separate db>=-1 by the correct guarded JOINT price bound, check the other old scalar inputs against their true pure3 range, and bind the already separately handled proper A source occurrence. These selected G2 parents A=(d-1,1) and A=(a,a-1) are proper. They are not the clipped G2 occurrence with primitive source(1,0), and this packet makes no claim about that implementation endpoint.

All conclusions here concern canonical physical values and licensed polygons. Actual original source support, helper alignment, chronology, and current recurrence remain separate.
