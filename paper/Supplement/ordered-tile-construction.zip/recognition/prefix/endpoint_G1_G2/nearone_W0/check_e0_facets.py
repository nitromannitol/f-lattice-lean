import sympy as S,json
from pathlib import Path
p=Path(__file__).resolve().parent
d,n,e,r,k=S.symbols('d n e r k');D,N=2*d+e,2*n+r;T=D*D+2*D*N-N*N
u,v,w,h,j=S.symbols('u v w h j',nonnegative=True);sub={n:u+1,d:u+2,r:1,e:1,k:j+1};rows=[]
for saved in[3]:
 ad,an=(d,n)if saved==3 else(d+e,n+r);TA=ad*ad+2*ad*an-an*an;K=(ad+an)*D+(ad-an)*N;B=K+k*T;dc,nc=ad+k*D,an+k*N;TC=TA+2*k*K+k*k*T
 for par in[0,1]:
  ht,hs,ls=(D+N-2,T+2*N,0)if not par else(D,T+D+N-2,2-dc+nc)
  # Minimal r1 s at original s=upper-1, t=upper_t, j=0.
  q=B*(hs-1)-2*ht-B*T-T*ls
  # Strict positivity of final nofold transverse lower bound addition.
  num=B if not par else B*nc+2-dc+nc
  for name,poly in [('no_top_f1',q),('final_t_above_minus_K',num)]:
   pp=S.Poly(S.expand(poly.subs(sub)),u,v,w,h,j);ok=pp.TC()>0 and all(c>=0 for c in pp.coeffs());assert ok
   rows.append({'saved':saved,'parity':par,'gate':name,'terms':len(pp.terms()),'pass':ok})
(p/'E0_FACETS.json').write_text(json.dumps(rows,indent=2));print('PASS',len(rows))
