import sympy as S,json
from pathlib import Path
p=Path(__file__).resolve().parent
d,n,e,r,k=S.symbols('d n e r k');D,N=2*d+e,2*n+r;T=D*D+2*D*N-N*N
u,v,w,h,j=S.symbols('u v w h j',nonnegative=True);sub={n:0,d:1,r:1,e:2*u+1,k:j+1};rows=[]
for saved in[1]:
 ad,an=(d,n)if saved==3 else(d+e,n+r);K=(ad+an)*D+(ad-an)*N;B=K+k*T;dc,nc=ad+k*D,an+k*N
 for par in[0,1]:
  ht,sl=(D+N-2,0)if not par else(D,2-dc+nc)
  # f2=0 implies B(s-T)>=Tsl-2ht; strict comparison yields s-T>=3-2D.
  q=T*sl-2*ht-B*(2-2*D)
  pp=S.Poly(S.expand(q.subs(sub)),u,v,w,h,j);assert pp.TC()>0 and all(c>=0 for c in pp.coeffs())
  rows.append({'saved':saved,'parity':par,'pass':True,'terms':len(pp.terms())})
(p/'W1_HARMONIC_FACETS.json').write_text(json.dumps(rows,indent=2));print('PASS4')
