exec(open(__file__.replace('check_w1_terminal.py','check_w1_harmonic.py')).read().split('for saved in')[0])
for saved in[1]:
 ad,an=(d,n)if saved==3 else(d+e,n+r);K=(ad+an)*D+(ad-an)*N;B=K+k*T;dc,nc=ad+k*D,an+k*N
 for par in[0,1]:
  ss,hs,g=(0,T+2*N,1)if not par else(2-D+N,T+D+N-2,nc)
  for name,q in [('e0_t_plus_K_nonnegative',T*g+2-hs+B),('e1_db_upper',B*(N+2*D-2)-T*g-2+ss)]:
   pp=S.Poly(S.expand(q.subs(sub)),u,v,w,h,j);assert pp.TC()>0 and all(c>=0 for c in pp.coeffs());rows.append({'saved':saved,'parity':par,'gate':name,'pass':True})
(p/'W1_TERMINAL_FACETS.json').write_text(json.dumps(rows,indent=2));print('PASS',len(rows))
