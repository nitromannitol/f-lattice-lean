from pathlib import Path
import sys,z3 as z,json,hashlib,subprocess
p=Path(__file__).parent;mode=sys.argv[1];fam='nearone'if mode in['N0','N1']else'reciprocal'
src=(p/'literal_seed.py').read_text();sys.argv=['uniform.py',fam,'geometry'];ns={'__file__':str(p/'literal_seed.py')};exec(src[:src.index('vs,gs=')],ns)
h,x,y,D,N,dd,nn,root=[ns[t]for t in['h','x','y','D','N','ad','an','root']];k=z.Int('k')
W=int(mode!='N0');ad,an=(D-dd,N-nn)if W else(dd,nn);dc,nc=ad+k*D,an+k*N;TC=dc*dc+2*dc*nc-nc*nc;T=D*D+2*D*N-N*N;sz=(D+N)*x+(D-N)*y;odd=(x+y)%2==1;U=z.If(odd,T+D+N-2,T+2*N)
lo=z.If(odd,nc-TC,1-TC);hi=z.If(odd,dc,dc+nc-1);sl=z.If(odd,2-dc+nc,0);sh=z.If(odd,2*TC+dc+nc-2,2*TC+2*nc)
rows=[]
def ck(tag,bad):
 so=z.Solver();so.set(timeout=55000);so.add(h>=0,k>=1,root,bad);f=p/(mode+'_'+tag+'.smt2');f.write_text(so.to_smt2());r=str(so.check());mdl=str(so.model())if r=='sat'else'';print(mode,tag,r,mdl,flush=True);rows.append((tag,r,mdl,hashlib.sha256(f.read_bytes()).hexdigest()));(p/(mode+'.json')).write_text(json.dumps(rows,indent=2))
for label,ell in ([('first',0),('endmid',2*k-2),('last',2*k-1)] if W else [('zero',0),('first',1),('last',2*k-1)]):
 X=x+2*W*ad+ell*D;Y=y+2*W*an+ell*N;tc=nc*X-dc*Y;sc=(dc+nc)*X+(dc-nc)*Y
 mm=[tc-lo,hi-tc,sc-sl+(2*TC if label=='zero' else 0),sh-sc+(2*TC if label=='last'and W else 0)]
 for fi,m in enumerate(mm):ck(label+str(fi),m<0)
 if label=='last'and W:ck('high_implies',z.And(sc>sh,sz<=U))
