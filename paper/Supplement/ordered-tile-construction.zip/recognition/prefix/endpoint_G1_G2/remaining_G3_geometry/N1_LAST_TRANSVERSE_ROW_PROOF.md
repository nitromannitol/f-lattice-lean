# N1 final transverse upper facet, direct proof for all k,b

Let b>=2, Z=(2b+1,2b-1), A=(b+1,b), C=A+kZ. At q=z+2A+(2k-1)Z, det(A,Z)=-1 gives t_C(q)=t_A(z)+k t_Z(z)-1. So the upper-facet margin is
  [d_A+1-t_A]+k[d_Z-t_Z]   at odd z,
  [L_A-t_A]+k[L_Z-t_Z]     at even z.
Write ell=y-x. Then t_A=-x-(b+1)ell and t_Z=-2x-(2b+1)ell.
The entire literal ALT crop has x>=-2, y>=0, ell>=-2 except for the single added odd point (2b+1,2b-2). If ell>=0 then t_A<=2, t_Z<=4 and both margins have nonnegative intercept and slope. For ell=-1 (odd), intercept x+1 and slope 2x are both nonnegative since x>=1. For ell=-2 (even), intercept x-1 and slope 2x-2 are nonnegative since x>=2. At the extra point ell=-3 both coefficients vanish identically. Hence the facet holds without any nonlinear SMT assumption or cutoff in b or k. The original undivided N1_last1 query timed out; its timeout is retained, not counted as a verification. This proof replaces it.
