from pathlib import Path
import sys,z3 as z,json,hashlib,subprocess
p=Path(__file__).parent;s=(p/'geometry.py').read_text();sys.argv=['geo','N1'];ns={'__file__':str(p/'geometry.py')};exec(s[:s.index('for label,ell')],ns)
h,k,x,y,D,N,ad,an,root=[ns[t]for t in 'h k x y D N ad an root'.split()];odd=(x+y)%2==1
# W1 det means final t_C = t_A+k*t_Z-1 exactly. Facet slack affine k.
sl0=z.If(odd,ad+1,ad+an)-(an*x-ad*y)
slk=z.If(odd,D,D+N)-(N*x-D*y)
raw=[]
for nm,q in [('slope',slk),('base',sl0+slk)]:
 a=z.Solver();a.add(h>=0,root,q<0);f=p/('N1_last1_'+nm+'.smt2');f.write_text(a.to_smt2());ans=str(a.check());print(nm,ans,flush=True);assert ans=='unsat';assert subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(f)],capture_output=True,text=True).stdout.strip()=='unsat';raw.append((nm,ans,hashlib.sha256(f.read_bytes()).hexdigest()))
(p/'N1_last1_split.json').write_text(json.dumps(raw))
