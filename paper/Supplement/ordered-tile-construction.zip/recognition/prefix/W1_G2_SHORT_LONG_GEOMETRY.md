# W1 whole-G2 geometry, SHORT and LONG

Let a=(d,n),R=(e,r) be a genuine proper birth, Z=2a+R=(D,N), with n,r>=1,d-n>=1,e-r>=2. Saved3 has A=a,det(a,R)=-1; saved1 has A=a+R,det(a,R)=1. Thus det(A,Z)=-1 in both cases. All sets here are authentic closed parity polygons, not filled literal arrays.

For SHORT let S=A+kZ,k>=1, x=u+Z-2A, q=x+(k+1)V_Z. For LONG let S=A+mZ,m>=2, x'=u-2A, q=x'+(m+1)V_Z. The latter is the COMPETING LONG query; the separate query x'+mV_Z is not silently substituted for it.

For every u in E_A, set w0=q-V_S and take f=0 when s_S(w0)>=its true lower facet, otherwise f=1. Then
 w=w0+2fS belongs to E_S.
Thus e=1 always suffices in each stated query, with one actual longitudinal lower-facet test. No other fold is required.

## Exact source-coordinate checks
Write T_A=T(A), T=T(Z), K=M(A,Z), t=t_A(u),s=s_A(u). Because det(A,Z)=-1,
 T_A t_Z(u)=Kt-s, T_A s_Z(u)=Ks-2t.
For SHORT,
 T_A t_S(w0)=(T_A+kK)t-ks+T_A[T_A+(k-1)K-kT+1+2k],
 T_A s_S(w0)=(T_A+kK)s-2kt+T_A[K+kT-2T_A-2kK-2k-2].
For LONG replace k by m and subtract T_A from the first formula and T_A(K+mT) from the second. These are just the removed Z shift, with t_S(Z)=1 and s_S(Z)=K+mT. They retain both physical parities because Z,2A,V_S preserve parity.

In each case the scripts prove both transverse facets of w0, and lower_s-2T_S<=s_S(w0)<=upper_s, at all eight parity-box vertices. The target longitudinal width is at least2T_S. The same lower-facet argument as in UNIVERSAL_G2_FIRST_ARM_GEOMETRY therefore proves w in E_S.

Additional inequalities, uniformly on E_A:
* s_Z(u)>=5-2D;
* both t_Z(u)+K+2 and t_Z(u)+K+4 lie in [3-D-K,N+2D-1+K].
These are exactly t_Z(x-V_A),t_Z(x-V_A-2A), and also the corresponding x' queries since Z is a zero transverse primary. In particular the signs are PLUS2 and PLUS4, not minus.

Each script checks112 vertex inequalities. Each multiplied slack q satisfies q+T_A>0 by nonnegative coefficients and positive constant on the proper cone n=a0+1,d=a0+b0+2,r=c0+1,e=c0+f0+3, with k=j0+1 for SHORT and m=j0+2 for LONG. Affinity extends from vertices to the rectangle; integrality gives nonnegative physical slack. These are exact arithmetic certificates, not sampled fractions.

## The f=0 lower-fringe test
The important conditional inequalities are
 SHORT f=0 => s_Z(x)>=5-2D;
 LONG f=0 => s_Z(x')>=5-2D.
All s_Z values are even. Failure in SHORT implies s_Z(u)<=4-2D-T+2K; failure in LONG implies s_Z(u)<=4-2D+2K. Using s_A=(T_A s_Z+2t_A)/K and t_A<=t_hi gives an upper bound on K[s_S(w0)-lower_s]. It simplifies to
 SHORT: T_A(4-2D)+2+kK(2-2D)+2t_hi-K(2+lower_s),
 LONG: T_A(4-2D)+mK(2-2D)+2t_hi-K(2+lower_s).
The SHORT reduction uses K²-T_A T=2; the scripts verify the original/reduced equality modulo the signed birth determinant. In both cases the NEGATIVE of the displayed polynomial has strictly positive constant and nonnegative coefficients on the same cone, for both parities and both saved records. Hence failure implies s_S(w0)<lower_s, contradicting f=0. There are four additional checks per script, making116 each.

## Scope
The requested complete geometry is established for BOTH SHORT and LONG and both genuine proper W1 records. With the separately authenticated central-slip theorem it supplies D>=-1 at the two queries. The geometric s bounds are the requested premises for the physical upper/unshifted or low-harmonic Pstd bound; this note does not replace that earlier field lemma by an assertion that an absent native point is occupied. It also does not prove the commutator identity, actual helper calibration/UR alignment, or endpoint initializer cases. The LONG first offer remains the independently handled far-p nesting term.
