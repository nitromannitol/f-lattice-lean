# W0 saved3 G2: birth donor identity and a uniform first-arm fold

## Result

Let A=(d,n) be the genuine old odd birth parent, R=(e,r), det(A,R)=1, Z=2A+R=(D,N), and C=A+kZ, k>=1. Assume the genuine earlier standard profiles/characters/closed-polygon source identities, full E_Z price span and physical slip/harmonic strips; use the genuine basic W0 p-donor shielding at R. In the all-proper birth cone n>=1,d-n>=1,r>=1,e-r>=2, for EVERY u in E_A:

 F_A(u)=F_Z(u-2A)<=F_Z(u).

For y=u+(k+1)V_Z the first current Q offer satisfies

 F_C(y-Z)>=F_Z(y).

The latter is proved by one fixed primary/secondary alias, not an enumeration of unknown fold cases. It is stronger than the requested lower bound through the G2 birth donor. It does not price the second Q offer or calibrate the actual complete helper.

## 1. Uniform geometry in old A coordinates

Write T_A=d²+2dn-n², T=T_Z, K=M(A,Z), L=D+N, v=V_A, B=K+kT. Let t=t_A(u), s=s_A(u). Then

 T_A t_Z(u)=Kt+s,
 T_A s_Z(u)=Ks+2t.

Use the genuine odd E_A parity rows, and the genuine even E_Z/odd E_C rows. The script g2_first_arm_geometry.py checks all96 facet margins under n=u0+1,d=u0+v0+2,r=w0+1,e=w0+h0+3,k=j0+1. It verifies each special determinant reduction exactly modulo dr-ne-1, then proves the required strict margin by nonnegative polynomial coefficients and positive constant. The96 checks comprise:

 -32 facets proving E_A+R is contained in E_Z;
 -32 facets proving the single alias below belongs to E_C;
 -16 longitudinal facets placing s_Z(u) inside E_Z's corresponding s interval;
 -16 transverse facets placing u-v+2A inside the complete central D interval.

The usual integer slack argument uses q+T_A>0. For the even lower longitudinal s_Z bound, its slack is an EVEN integer, so q+2T_A>0 suffices; this exact parity fact is necessary and is recorded in the script rather than rounding a nonphysical rectangle corner.

For example, at the potentially tight odd upper transverse edge of E_A+R, the multiplied margin reduces to2-2d; adding T_A is strictly positive for every proper A. The determinant identities reduce the even upper longitudinal margin to2(L_A-t), which is positive on E_A. Thus apparent negative coefficients in the un-reduced arbitrary-parameter expressions are not actual obstructions.

## 2. Genuine birth donor equality and its inequality

The earlier basic odd-parent shielding theorem, stage1_audit/P_DONOR_SHIELDING_AUDIT.md, applies to the authentic W0 p donor at R. In this exact source gauge its raw child comparator equals F_A(u) on the COMPLETE E_A+R. This consumes its stated earlier chain-mate admission, recurrence/comparison and boundary/trace calibration inputs; recurrence alone is not substituted for them.

The geometry above licenses E_A+R inside the genuine old E_Z, so its authentic standard value equals that raw comparator. Since Z is a true zero-primary period,

 F_Z(u-2A)=F_Z(u+R)=F_A(u).

The inclusion also gives t_Z(u)=t_Z(u+R)+2. This shifted E_Z transverse interval lies inside [3-D-T,N+2D-1] in the proper cone. Thus the full physical D theorem gives

 F_Z(u)-F_A(u)=F_Z(u)-F_Z(u-2A)=D(u)>=0.

No claim that u itself lies in the whole E_Z is needed. Its longitudinal position is licensed, but its transverse position can be outside E_Z.

## 3. One fixed alias at the G2 terminal layer

Put j=k+1, r=y-Z. Choose e=f=1 and

 w=r-V_C+2C=u-v+V_Z+2A+(2k-1)Z.

Its coordinates are

 T_A t_C(w)=(T_A+kK)t+ks+T_A[T_A+(k-1)K-kT+1],
 T_A s_C(w)=(T_A+kK)s+2kt+T_A[2T_C-K-kT+2k+2].

The32 alias facets in Section1 prove w in E_C for every u in E_A and every k>=1. There is no need to show that e,f are minimal lower-facet indicators. They are a legitimate fixed alias, and the global C deck/primary laws give the actual pullback from this licensed point.

## 4. Exact first-offer price

Use the authentic stationary identity F_C(w)=min(F_Z(w),h(w)+2k-2) only at w in E_C. The previously independently verified E1 algebra is an identity for arbitrary j; its later j=k restriction was an inequality step for another domain, not a restriction on the identity itself. Substituting f=1,j=k+1 gives the two offers relative to F_Z(r)=F_Z(y):

 I=P(u-v)-c_A+3+D(u-v+2A),
 II=P(u-v)+P(u-2v)-2c_A+2,

where P(x)=F_Z(x)-F_Z(x+v)+b_A.x and c_A=(T_A+L_A)/2. No new source scalar has been chosen.

Section1 places s_Z(u) in the corresponding E_Z longitudinal interval. Therefore the same exact physical rim proof as in E1_TRANSVERSE_FOLD_PRICE_AUDIT applies: P(u-v),P(u-2v)>=c_A-1. It needs only the longitudinal interval, because V_Z folding preserves P; it does NOT require u in E_Z transversely. At the possible upper excess by2 or4, subtraction of Z puts both P inputs in the full h0 strip and gives exactly c_A-1.

Section1 also places t_Z(u-v+2A)=t_Z(u)+K+2 in [3-D-K,N+2D-1+K]. Thus the complete central interval gives D(u-v+2A)>=-1. It is neither necessary nor justified to demand its nonnegativity here. Consequently

 I>=1, II>=0,

and F_C(y-Z)>=F_Z(y), uniformly. This closes the first physical Q arm for these saved3 G2 sites.

## 5. Diagnostic and scope

An independent genuine-word113 test checks99 points of E_A for A=(5,2),Z=(27,11). The birth identity holds at all99, with F_Z(u)-F_A(u) equal0 at66 and1 at33. This is only a sanity check; the proof is the donor theorem, uniform geometry and exact field algebra above.

The second Q offer, actual G2 occurrence/frame/scalar and full prefix assembly remain separate. This document uses earlier genuine source identities and the current stationary C polygon identity as explicit premises, not as consequences of the claim being established. No entire-plane unperiodized source equality, unrestricted donor halo or recurrence assertion is introduced.
