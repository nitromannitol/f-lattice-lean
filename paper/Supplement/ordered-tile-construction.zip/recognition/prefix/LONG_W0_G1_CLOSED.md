# W0 LONG G1: closed full-polygon analytic prices and nominal source binding

This supersedes the remaining-value gate in LONG_W0_ENDPOINT_FOLD.md, under its explicit genuine earlier physical inputs. It proves the raw analytic target on both nominal G1 lists. Actual helper restoration/upper-right alignment, retained support, chronological touching constants, and recurrence remain separate constructor premises.

## Complete RIGHT price

Write m=k+1≥2 and O=A+mZ. For every u∈E_Z and 1≤j≤k,

 T(u+jV_Z)=F_Z(u+jV_Z),
 T(y)=min(F_O(y),F_O(y+V_Z)−a_Z·y+c_Z+1).

The first offer equals F_Z(y): r2 support at stationary parameter m and index j+1 puts y∈E_O, and the exact error is min(0,H(u)+2m−2−2j)=0 by whole-E H≥0. For j≤m−2, the same argument applies at y+V_Z, so the second offer equals F_Z(y)+1. At j=m−1 use the endpoint fold of the preceding note. Its folded branch is already ≥F_Z(y+V_Z)−1.

In the nonfolded branch the endpoint guard gives t_Z(u)≥1−K. The exact identity

 H(u)=P(u−v)−c_A+2−D(u−v)

and t_Z(u−v)=t_Z(u)+K≥1 finish the proof. Indeed the full physical zero strip gives D=0 when 1≤t≤N+2D−1, since the two arguments have grades t and t−2; the high-t sign extension gives D≤0 above this interval. The established harmonic-rim estimate gives P(u−v)≥c_A−1. Therefore H(u)≥1, including saved3. Its endpoint error min(0,H−2) is ≥−1 as required.

This is a direct pointwise physical calculation, not an inference of a new endpoint from the SHORT minimum theorem. All unperiodized O formulas are used solely at proven E_O points.

## All-proper geometry extension

The new upper-s endpoint certificate also passes with n≥1,d−n≥1,r≥1,e−r≥2,m≥2, in both saved choices and both parities: see check_long_w0_endpoint_geometry_all_proper.py and its receipt. The same broader cone gives D_Z≥7,L_Z≥10, so all harmonic-rim inequalities used above remain valid. This extension uses the separately available all-proper r2 inclusion in all_proper_G1; it does not include literal endpoint parents or pure words. Earlier field hypotheses must likewise be available on the broader cone.

## Raw reflection and nominal LEFT source positions

Let δ=(1,−1), C=O−Z, Q=2C+Z. Define

 R_long=2O+2V_O−V_Z+δ=R_Q+Z.

Use only genuine O primary 2O, its secondary V_O jet, and its centered δ reflection. The two offers swap under reflection, with exact common affine term

 T(R_long−y)=T(y)−a_Q·y−eta_Q−1.

In direct O,Z notation the scalar is 2c_O−3T_O+2M(O,Z)−c_Z−1; expansion of Q=2O−Z reduces it to −eta_Q−1. The extra −1 is essential. Thus this is NOT the standard Q reflection law.

The genuine parent polygon satisfies R_Z−E_Z=E_Z. Consequently reflection sends the RIGHT window E_Z+jV_Z to

 E_Z+o_j,  o_j=2C+2V_C+Z−jV_Z,  1≤j≤k.

These are the nominal LONG LEFT G1 windows. Literal original_port_offsets.py gives odd-alternate outer Gl slot3=2Z+V_C and Gr slot4=V_Z. For the stored helper before the next digit2, its current odd parent is C−Z. Literal get_l_correct's flipped initial getOddTileFull slot3 equals 2(C−Z)+V_(C−Z)+Z and each G1 step is −V_Z; the unflipped initial is zero and each step +V_Z. Adding the outer positions gives exactly the two lists above, with k windows each. LONG changes only the G3 loop count, not this G1 list.

The slopes match independently: RIGHT j-th source has slope j a_Z. LEFT has slope 2a_C−j a_Z, as obtained both from the swapped reflection and the literal inner/outer affine offsets. If g_j=j eta_Z+j(j−1)T_Z/2, then the RIGHT price in global y is F_Z(y−jV_Z)+j a_Z·y+g_j. The reflected LEFT price in global x is

 F_Z(x−o_j)+(2a_C−j a_Z)·x
 + (j a_Z−a_Q)·R_long + a_Z·o_j − eta_Z + g_j − eta_Q − 1.

These constants are candidate analytic prices, not asserted original merge constants without actual overlap calibration. Any additional actual upper-right alignment displacement must already have been identified with these nominal frames; the literal slot calculation alone does not prove that alignment.
