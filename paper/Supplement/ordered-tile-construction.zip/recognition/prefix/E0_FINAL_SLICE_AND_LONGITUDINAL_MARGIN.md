# Final no-fold slice and the longitudinal two-row margin

Both results are uniform in saved1/3, W0, under the precise strict birth cone in the preceding prefix papers. Use their B=K+kT and genuine E_C parity bounds. These are geometry statements; no source-value plateau is presumed.

## 1. Every longitudinal fold is two rows below the E_Z upper side
For every j=0,...,k, if the exact first-arm fold has f=1, then

    s_Z(u) <= upper_s(E_Z,parity(u))-2.

Indeed f=1 means s_C(r1)<lo_s(E_C). Suppose instead s>=upper_s(E_Z)-1. The minimum possible multiplied s_C(r1)-lo_s is at s=upper_s-1,t=upper_t,j=0 and equals

    B*(upper_s-1)-2*upper_t-B*T-T*lo_s.

`check_e0_facets.py` proves this polynomial strictly positive in all four saved/parity cases, by nonnegative coefficients with positive constant in the five nonnegative strict-cone variables. Increasing s or j, or decreasing t, only increases it. Thus f=1 excludes both uppermost integer s rows. No exceptional harmonic endpoint is necessary for this particular guard. As s_Z(V_A)=-2, the requested shifted argument u-V_A has s_Z=s_Z(u)+2<=upper_s. This proves its upper longitudinal bound only, not its other polygon bounds.

## 2. Exact universal lower t bound on the final e=f=0 slice
At j=k, e=f=0 requires

    Bt-s >= T*(lo_t+kB-1),
    Bs-2t >= T*(lo_s+B-2k).

Eliminating s and using the genuine determinant identity B^2-2=T*T_C gives

 even: t >= -K + B/T_C,
 odd:  t >= -K + (B*n_C+2-c_C)/T_C.

For clarity the intermediate numerator is B*(1-T_A-kK)+lo_s-2k on even sites, and B*(n_C-T_A-kK)+lo_s-2k on odd sites. The simplification uses K*T_C-B*(T_A+kK)=2k. All these identities are exact, not asymptotic.

Both final added numerators are positive in the strict cone; the same coefficient script proves this in four cases. Therefore the physical integer conclusion is

    t_Z(u) >= 1-K.

This is the correct geometry scale. It does NOT imply t>=1-D. To obtain H>=1 from this statement one needs an authentic earlier price/cut assertion on this larger transverse range, or a joint s/t assertion. We do not infer a global D=0 strip from a numerical sample.

## 3. Genuine counterexample to the proposed narrower geometric bound
In the actual word1132 example, Z=(17,7), A=(5,2), k=1, K=140. The whole-E root u=(15,14) has

    t=-133, s=500, e=f=0, H=1, D(u)=0.

Thus t>=1-D=-16 is false, though the desired value inequality holds. In the independently evaluated final no-fold slice of this example there are exactly9 sites; the least t is -133, and all9 have D(u)=0. This finite statement does not prove the all-parameter D=0 implication. The exact original-source replay is `E0_LITERAL_REPLAY.txt`; its script evaluates actual global earlier fields and the independently checked deck fold.
