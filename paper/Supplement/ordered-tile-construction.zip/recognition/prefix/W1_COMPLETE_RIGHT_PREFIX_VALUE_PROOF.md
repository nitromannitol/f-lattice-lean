# W1 complete RIGHT standard-prefix value audit

## Scope and verdict
For both strict saved1/3 W1 cases, all u in genuine E_Z and1<=j<=k, the two licensed folded Q offers have minimum F_Z(u+jV_Z). This is a conditional earlier-field proof: retain the actual stationary F_C minimum on E_C, the earlier E_Z raw two-A representation, actual price span, harmonic/zero strips, physical D bands and their negative-V extension. It is not a new native-recognition, touch-scalar, or recurrence theorem. In particular saved1 needs its authentic effective-A stationary/input theorem, not a fictitious proper negative residual parent.

All aliases and 16 exact price identities are already proved in the preceding files. We audit the remaining inequalities below. Let r,rm,d0,db,dv,dvv have exactly the meanings in W1_NORMALIZED_EIGHT_OFFER_TABLE.md. In particular D(z)=F_Z(z)-F_Z(z+2A), P(z)=F_Z(z)-F_Z(z-v)-a_A.z, and r=eta_A-P(u).

## Earlier quantitative inputs actually used

* On E_Z, eta_A-1<=P<=eta_A, hence r in{0,1}.
* F_Z=0 in the physical t strip [1-D,N+2D-1]; F_Z=h0 in the physical s strip [1-2D,2L_Z-1].
* 0<=D<=2 on [3-D-T,N+2D-1], and |D|<=1 on the complete central interval [3-D-K,N+2D-1+K].
* D<=0 for t>=N+1, by the earlier negative-V sign lemma with sigma=+2A and t(sigma)=-2. This uses old cover/decks, not a zero-height half-plane.
* The authentic W1 two-source raw-gap relation when both evaluated sites are in E_Z.

These imply D<=2 whenever t>=3-D-T: use the physical band until its upper endpoint and the high-t sign afterward. **D<=2 is not asserted on the entire plane.**

## Whole-E lower bound Hhat>=-1
Define Hhat(u)=r-dv=F_Z(u+2A-v)-F_Z(u)+a_A.u+eta_A. The three-case proof in W1/WHOLE_CROP_DOMINANCE.md applies with u in E_Z directly, not just on its previous alternate crop. Put q=u+2A-v,w=u+2A. Then
 t(q)=t(u)+K-2, s(q)=s(u)+2K-2,
 t(w)=t(u)-2, s(w)=s(u)+2K.
As K>2, q has no lower-edge escape. If w exceeds the upper longitudinal row, a genuine primary fold gives P(w)<=eta_A-1; D(u)<=2 then gives Hhat=eta_A-P(w)-D(u)>=-1. Otherwise q is longitudinally inside. If it exceeds the upper transverse row, its failure forces u into the earlier central D<=1 band, and transverse folding gives P(w)<=eta_A, again Hhat>=-1. In the remaining case q and u are both in E_Z and the actual raw gap gives Hhat=-[min(0,psi+1)-min(0,psi)]>=-1. No raw minimum is used outside E_Z. Saved1 may instead use its stronger separately licensed intrinsic-chain bound; the algebraic table only needs -1.

## Additional shifted quantities

1. d0>=0: t(u-2A)=t(u)+2 is in [3-D-T,N+2D-1] by the exact E_Z parity rows. Thus the physical band applies.

2. rm>=0: s(u-v)=s(u)-2 cannot exceed E_Z's upper row. If it is longitudinally inside, transverse folding preserves P and gives P(u-v)<=eta_A. If it is below the lower row, both u-v and u-2v lie in [1-2D,2L_Z-1] (their s values differ by2). The exact harmonic identity gives P(u-v)=eta_A. Thus rm>=0 in all cases.

3. dvv<=2: t(u-2v)=t(u)+2K is above3-D-T. Apply the band/high-t extension stated above. This is a guarded bound, not a universal slip assertion.

## Final-index geometry and slips
The preceding geometry gives e2=0 and e1=0 unless j=k. At j=k, with g=1 even and g=n_C odd, the first transverse test is
 e1=0 iff B(t(u)+K)>=Tg+2-s(u).

`check_w1_terminal.py` verifies eight exact positive-coefficient facets, both saved/parity cases:

 Tg+2-upper_s+B>0,
 B(N+2D-2)-Tg-2+lower_s>0.

Therefore e1=0 implies integer t(u)+K>=0. At w=u-v this means t(w)>=0. For0<=t(w)<=N+1 both D arguments are in the zero strip (including t=-2 after the shift, allowed since D>=3); at larger t use the high-t sign. Thus dv<=0.

If e1=1, then B(t(u)+K)<Tg+2-s(u), and the second positive facet gives integer t(u)+K<=N+2D-3. Hence t(u-v-2A)=t(u)+K+2<=N+2D-1; its lower band bound follows immediately from the E_Z lower row and K>2. Therefore db>=0 on this selected slice.

## Check every active row and attainment
Arm2 always has e2=0.
* f2=0: the proved harmonic geometry gives r=1. Its row is (d0+2j-2,0), both nonnegative.
* f2=1: its row is (0,Hhat+2(k-j)+1), both nonnegative by Hhat>=-1.
Thus arm2 ALWAYS attains0.

For arm1:
* e1=f1=0: (d0+2j,r)>=0.
* e1=0,f1=1: (0,Hhat+2(k-j))>=0 for j<k. At j=k the final geometry gives dv<=0, so Hhat=r-dv>=0.
* e1=1,f1=0: necessarily j=k, and the row is (r+db,r+rm)>=0.
* e1=f1=1: necessarily j=k, and the row is (r,r+rm-dvv+2k)>=0, since r,rm>=0,dvv<=2,k>=1.

All selected constituents are nonnegative, and arm2 supplies0. Therefore the normalized two-offer minimum is exactly0. This proves the claimed RIGHT prefix identity on the stipulated canonical E_Z carriers. It neither assumes nor proves literal helper calibration or source retention by itself.
