from pathlib import Path
f=Path('recovery_20261101_0745/reconstruct_direct_auxiliary_enclosure.py').read_text();ns={'__file__':str(Path('recovery_20261101_0745/reconstruct_direct_auxiliary_enclosure.py').resolve())};exec(f[:f.index('def group(')],ns)
add,mul,prime,raw=[ns[n] for n in ['add','mul','prime','raw_piece_ops']];A,B,C,D,K=[ns[n] for n in ['A','B','C','D','KLEN']];p=(A,B);q=(C,D);cp=add(p,mul(K+1,q));vc=prime(cp);vq=prime(q)
rows=[]
for flip in [False,True]:
 ops=raw(p,q,1,3,True,1,flip)
 outer=add(vc,mul(-1,q))if flip else add(q,vq)
 for pos,j in [(0,ns['Poly'](1)),(1,K+1)]:
  actual=add(outer,ops[pos][3]);expected=add(mul(2,vc),mul(-1,q),mul(-j,vq))if flip else add(mul(2,cp),mul(j,vq))
  assert actual==expected,(flip,pos)
  rows.append([flip,pos,'both coordinates exact'])
print(rows)
