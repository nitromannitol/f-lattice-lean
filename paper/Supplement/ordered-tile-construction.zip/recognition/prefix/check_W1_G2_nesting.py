import sympy as S
import json,hashlib
from pathlib import Path
rows=[]
n,c,r,f=S.symbols('n c r f');d=n+c;e=r+f;TB=d*d+2*d*n-n*n;T=e*e+2*e*r-r*r;K=(d+n)*e+(d-n)*r;TC=TB+2*K+T;D=d+e;N=n+r
for p in (0,1):
 ts,ss=([1-TB,d+n-1],[0,2*TB+2*n]) if not p else([n-TB,d],[2-d+n,2*TB+d+n-2])
 lo,hi,sl,sh=(1-TC,D+N-1,0,2*TC+2*N)if not p else(N-TC,D,2-D+N,2*TC+D+N-2)
 for ti,t in enumerate(ts):
  for si,s in enumerate(ss):
   t1=(TB+K)*t-s;s1=(TB+K)*s-2*t
   for face,q in enumerate([t1-TB*lo,TB*hi-t1,s1-TB*sl,TB*sh-s1]):
    pol=S.Poly(S.expand((q+TB).subs({n:n+1,c:c+1,r:r+1,f:f+2})),n,c,r,f)
    method='direct positive cone'
    if any(a<0 for a in pol.coeffs()) or pol.TC()<=0:
     exact=S.cancel((n*(q+TB)).subs(f,(c*r+1)/n))
     pol=S.Poly(S.expand(exact.subs({n:n+1,c:c+1,r:r+1})),n,c,r)
     method='determinant cr-nf=-1; multiply positive n'
    ok=all(a>=0 for a in pol.coeffs()) and pol.TC()>0
    assert ok,(p,ti,si,face)
    rows.append(dict(key=[p,ti,si,face],method=method,constant=str(pol.TC()),terms=[([int(i) for i in ex],str(co))for ex,co in pol.terms()],pass_=bool(ok)))

out=Path(__file__).resolve().parent
(out/"W1_G2_NESTING_COEFFICIENTS.json").write_text(json.dumps({"complete":True,"count":len(rows),"rows":rows,"producer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+"\n")
print("PASS",len(rows))
