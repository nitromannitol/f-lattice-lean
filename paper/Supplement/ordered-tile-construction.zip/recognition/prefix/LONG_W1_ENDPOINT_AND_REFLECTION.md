# W1 LONG G1: all-proper physical endpoint paid; exact reflected frame

## Scope and RIGHT reduction

Take the genuine W1 effective pair det(A,Z)=−1, O=A+mZ, m=k+1≥2, C=O−Z. Use precisely the earlier W1 canonical fields, full E_Z price span, complete physical slip/zero/harmonic strips, and authentic O polygon formula of W1_NORMALIZED_EIGHT_OFFER_TABLE.md. No current alternate recurrence is assumed.

The actual phase raw comparator has x=y+Z and

 T1(y)=min(F_O(x), F_O(x+V_Z)−a_Z·x+c_Z−1).

At the proposed RIGHT positions y=2C+u+jV_Z, 1≤j≤k, the genuine zero primary 2O removes 2C+2Z. Since a_Z·2C=−2, its two offers become

 F_O(u+jV_Z−Z),
 F_O(u+(j+1)V_Z−Z)−a_Z·(u+jV_Z)+c_Z+1.

Thus the first equals the target F_Z(u+jV_Z) by the separately proved W1 SHORT arm2 attainment at index j+1 and stationary parameter m. All second offers except the last use that same attainment. At j=k=m−1 only the following bound is needed:

 F_O(u+mV_Z−Z)−F_Z(u+mV_Z)≥−1.

This note independently proves that bound. Application to the full RIGHT list explicitly consumes the SHORT arm2 attainment theorem, not merely the minimum of its two arms.

## All-proper endpoint fold and four exact rows

Use q=u+mV_Z−Z, and its actual lower-facet flags e,f. The two genuine deck shifts give w=q−eV_O+2fO∈E_O. The existing fold encoder was copied to a distinct script, extended to arm2 index m+1 and m≥2, and widened to n≥1,d−n≥1,r≥1,e_birth−r≥2. All64 exact vertex facets pass. This is a modified replay of that encoder, not an independently reimplemented polygon.

Keep the earlier table's symbols r=eta_A−P(u), rm=eta_A−P(u−v), d0=D(u−2A), db=D(u−v−2A), dv=D(u−v), dvv=D(u−2v), with v=V_A and D(x)=F_Z(x)−F_Z(x+2A). Substitution of index m+1, parameter m, gives exactly:

 (e,f)=(0,0): (d0+2m, r−1);
 (0,1): (0, r−dv−1);
 (1,0): (r+db−1, r+rm−2);
 (1,1): (r−1, r+rm−dvv+2m−2).

The table normalization equals the desired difference: its added last V_Z jet cancels the last increment of the table's target. No leftover affine constant occurs.

## Physical price bounds

Unconditionally on E_Z, r∈{0,1}, d0≥0, rm≥0 and dvv≤2. For d0 use the complete transverse band at t(u)+2. For dvv use the band at t(u)+2K and the high-t sign extension above it. For rm, u−v lies within the longitudinal E interval except at at most two lower rows. In those rows u−v and u−2v lie in the complete harmonic strip, giving P(u−v)=eta_A and rm=0; otherwise a V_Z fold preserves P and the E price bound applies.

Here are the additional guarded estimates. Put B=K+mT, g=1 on even sites and n_O on odd sites. Exact lower-t comparison is

 e=0 ⇒ B(t(u)+K)≥T(g+1)+2−s(u),
 e=1 ⇒ B(t(u)+K)<T(g+1)+2−s(u).

The included sixteen independent exact coefficient checks prove:

 * T(g+1)+2−upper_s(E_Z)>0, so e=0 implies t(u)≥1−K. Hence t(u−v)≥1 and dv≤0 by the complete zero strip followed by the high-t sign extension.
 * B(N+2D−3)≥T(g+1)+2−lower_s(E_Z). Thus e=1 puts t(u−v−2A)=t(u)+K+2 within [3−D−T,N+2D−1], where db≥0. The lower endpoint is separately checked.
 * If f=0 then B(s(u)−T)≥T*lower_s(E_O)−2t(u)+2mT. The certificate proves its right side is strictly greater than B(4−2D). Consequently s(u)−T≥5−2D.

In the last case w0=u−Z, w0−v, w0−2v all lie in the full harmonic strip: their lowest longitudinal grade is at least1−2D and the E upper rows bound the highest by2N orL_Z−2. Thus P(w0)=P(w0−v)=eta_A. Since P(z+Z)=P(z)−1, we obtain the exact values r=rm=1.

Now (0,0) is ≥−1 using d0≥0 and r≥0. Row(0,1) is ≥−1 using dv≤0. Row(1,0) reduces to (db,0), both nonnegative. In row(1,1), the first is ≥−1 and the second is ≥2m−4≥0. Every licensed endpoint therefore has the required lower bound.

## Correct raw involution and remaining source-frame binding

In x coordinates the raw involution center is R_x=2O+2V_O−V_Z+δ and its common scalar is −eta_Q+1, Q=2C+Z. Returning to y=x−Z gives

 R1=R_x−2Z=R_Q−Z,
 T1(R1−y)=T1(y)−a_Q·y−eta_Q−1.

The raw relative sign −1 and the phase shift +Z are both indispensable. If the actual RIGHT G1 windows are E_Z+2C+jV_Z, reflection sends them to exactly

 E_Z+2V_C−Z−jV_Z, 1≤j≤k.

This is the necessary reflected LEFT list, not an assertion that the actual helper already has this origin. Literal _alt_odd(W1) gives outer Gl slot3=V_C−Z and Gr slot4=Z+V_Z. The older W1/INDEPENDENT_SIBLING_GAUGES.md paragraph claiming Gl slot3=V_C+Z does not agree with the literal offset formula. Its difference does not change the endpoint calculation above, but source binding must use the literal formula.

Before helper lower-left recentering, its flipped initial G1 at the stored C−Z parent is V_C−V_Z+Z. Combining these bare inner/outer slots gives2V_C−V_Z, which still differs from the required reflected list. Therefore authentic helper lower-left recentering and, on W1 RIGHT, upper-right alignment are material inputs. This note does not silently identify those frames. Once the actual RIGHT and LEFT windows/affine gauges are bound to the displayed reflected lists, the raw reflection transfers the RIGHT result to LEFT. Chronological merge constants and physical recurrence are not concluded here.


## Nominal-frame resolution and scope of the old prose correction

The historical reconstruct_direct_auxiliary_enclosure.py raw_piece_ops supplies precisely the missing formal helper moves: W1 flipped −Z, unflipped 2A+(2h+1)Z with h=k−1, hence2C−Z. These are added BEFORE outer slots. The distinct check_long_w1_nominal_sources.py loads only its definitions and independently checks both vector coordinates of both endpoint sources on both sides, without any determinant specialization. All four vector equalities hold. Affine progression then covers every index. Thus the formal nominal RIGHT and LEFT windows do match the lists proved here.

This establishes the explicit historical candidate-frame binding, not a new verification that an arbitrary finite implementation's helper lower-left/upper-right axes realize that candidate. Actual restoration, alignment and no-clipping inputs remain inherited.

The erroneous +Z sentence in W1/INDEPENDENT_SIBLING_GAUGES.md is isolated from its exact G3 algebra: independent_sibling_algebra.py uses Y=z+V_C+2A+iZ, X=Y+Z and true deck identities, not that prose slot. The historical check_saved3_corrected_odd_long_covariance_binding.py obtains origins directly from alt_layout and raw_piece_ops, including the correct W1 helper moves. Its fresh replay again reports PASS28 both-phase LONG/ordinary endpoint bindings. The older stated LONG masks RIGHT i=0..2k−1, LEFT i=−1..2k−2 agree with those bindings. Therefore this local prose correction does not alter those previously verified G3 numerical/symbolic placements. It does not strengthen their separately stated actual-UR premise.
