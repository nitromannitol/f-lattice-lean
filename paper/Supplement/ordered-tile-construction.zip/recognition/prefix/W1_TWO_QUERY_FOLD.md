# W1 RIGHT prefix: two exact four-alias queries

Use strict birth a=(d,n),R=(e,r), n>=2,d-n>=3,r>=1,e-r>=2, Z=2a+R=(D,N), and k>=1. Saved3 has A=a,det(a,R)=-1; saved1 has A=a+R,det(a,R)=+1. Hence det(A,Z)=-1 in BOTH cases. Set C=A+kZ, T=T_Z,K=M(A,Z),B=K+kT. Take u in the genuine E_Z polygon and 1<=j<=k.

## Actual orientation and an obstruction to a direct-carrier claim
The stated W1 two queries after removing the true primary2C are

 q1=u+jV_Z,
 q2=u+(j-1)V_Z-Z.

The inverse projection is t_A=(Kt+s)/T, s_A=(Ks+2t)/T. Consequently

 Tt_C(q1)=Bt+s-jBT,
 Ts_C(q1)=Bs+2t-2jT;
 Tt_C(q2)=Bt+s-(j-1)BT-T,
 Ts_C(q2)=Bs+2t-2(j-1)T-BT.

Thus t_C(q1)=t_C(q2)-B+1 and s_C(q1)=s_C(q2)+B-2. The opposite sign in the latter formula matters. The W0 direct-second-query theorem cannot be copied.

Indeed u=0 is an actual even E_Z point. At j=1, s_C(q1)=-2 and s_C(q2)=-B, whereas the even E_C lower row is0. Neither unshifted query is in E_C. This is a uniform geometric counterexample to either proposed always-direct assertion, not a counterexample to the price identity.

## Uniform licensed replacements
For each a=1,2 independently,

 lo_t-T_C <= t_C(qa) <= hi_t,
 lo_s-2T_C <= s_C(qa) <= hi_s.

Therefore set ea=1 iff t_C(qa)<lo_t and fa=1 iff s_C(qa)<lo_s. Then

 wa=qa-ea V_C+2fa C belongs to E_C.

The same parity-dependent genuine odd E_C rows as in the W0 proof apply. A -V_C shift adds T_C only to t; a 2C shift adds2T_C only to s. Widths of the rows guarantee that these conditional single folds suffice, and all shifts preserve physical parity.

`check_w1_folds.py saved arm` proves all four cases by64 exact coefficient facets each (256 total). It tests actual E_Z row vertices and index endpoints1,k. Multiplied facet margins q satisfy q+T>0, with positive constant/nonnegative coefficients in the five nonnegative strict-cone variables; integer margins are thus nonnegative. Upper-t simplifications use the correct W1 determinant identities KD=d_A T+(D-N), K(D+N)=L_A T-2N. The general identities and physical projections have not been inferred from a finite sample.

The true height pullback for either query is

 F_C(qa)=F_C(wa)+ea*(t_C(qa)+T_C+cV_C)
        =F_C(wa)+ea*(t_C(qa)+eta_C)

in the canonical standard gauge cV_C=-(T_C+L_C)/2. No primary scalar occurs.

## Licensed stationary substitution
Section1 of the genuine W1 instance in `W1/SIGNED_STATIONARY_SUBSTITUTION.md` gives, on E_C,

 F_C(x)=min(F_Z(x-2A), F_Z(x-V_A)+a_A.x+eta_A).

This is obtained by taking its z=x-2A,l=0. The old h there is h(z)=F_Z(z+2A-V_A)+a_A.z+eta_A, so a_A.(2A)=0 leaves exactly the displayed scalar. There is no extra+1 or+2. This uses the actual admitted stationary polygon identity, not a minimum extended to the full plane.

Accordingly both Q offers can now be evaluated by this identity at w1,w2, followed by their exact deck corrections. This document settles geometry and gauge, not their remaining comparison or attainment. The cited W1 source theorem explicitly covers saved3; using the same stationary expression for saved1 still requires the separately established authentic saved1 stationary theorem. The polygon proof itself covers BOTH effective A choices without treating Z-2A as a positive parent.
