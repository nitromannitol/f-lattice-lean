# W0 whole-G2 first-arm geometry: both proper saved records

Let the genuine birth be a=(d,n),R=(e,r), Z=2a+R=(D,N). For saved3 set A=a and det(a,R)=1; for saved1 set A=a+R and det(a,R)=-1. Then det(A,Z)=1 in both cases. Assume n,r>=1,d-n>=1,e-r>=2, k>=1. Put C=A+kZ, T_A=T(A), T=T(Z), K=M(A,Z), and V_X=(n_X-d_X,d_X+n_X).

For EVERY physical u in the exact closed odd polygon E_A, set y=u+(k+1)V_Z, r0=y-Z, w0=r0-V_C. Let c_s be the lower s_C facet for its parity. Choose
 f=0 if s_C(w0)>=c_s, and f=1 otherwise; w=w0+2fC.
Then w belongs to E_C. Thus secondary choice e=1 always works, and the primary choice is exactly the genuine lower-facet test, not a presumed fixed f=1.

## Coordinates and certified inequalities
Write t=t_A(u),s=s_A(u). Then
 T_A t_Z(u)=Kt+s, T_A s_Z(u)=Ks+2t.
Direct substitution gives
 T_A t_C(w0)=(T_A+kK)t+ks+T_A[T_A+(k-1)K-kT+1],
 T_A s_C(w0)=(T_A+kK)s+2kt+T_A[-K-kT+2k+2].
The primary2C changes only s_C, by2T_C. The exact odd parity rows are those in ODD_REFLECTED_DONOR_NESTING.md.

The executable audit_g2_universal_geometry.py proves at each of the eight parity vertices, for both saved records:
1. both t_C(w0) facets;
2. s_C(w0)>=c_s-2T_C and s_C(w0)<=upper_s_C;
3. t_Z(u)+K>=1;
4. t_Z(u)+K and t_Z(u)+K+2 lie in [3-D-K,N+2D-1+K];
5. s_Z(u)+4-2K<=upper_s_Z.
Every multiplied margin q satisfies q+T_A>0 by positive coefficients after n=a0+1,d=a0+b0+2,r=c0+1,e=c0+f0+3,k=j0+1. Convexity gives the same strict rational bound everywhere; integer physical slacks then give the claimed weak inequalities. There are128 such checks, no determinant reduction needed after these coordinate formulas.

The target s width is at least2T_C (even width2T_C+2n_C, odd width2T_C+2d_C-4). If f=0 both s facets already hold. If f=1 the lower follows from item2, while s_C(w0)<c_s gives s_C(w)<c_s+2T_C<=upper_s_C. This proves full guarded coverage.

## Additional upper s bound in the f=1 branch
Let H=upper_s_Z-T, namely2N at even physical sites and D+N-2 at odd sites. All s_Z coordinates and this upper bound are even. Suppose s_Z(u)+4>upper_s_Z. Then s_Z(u)>=T+H-2.
The exact identity K²-T_A T=2 follows from det(A,Z)=1. Since s_A=(T_A s_Z-2t_A)/K and t_A<=t_hi, it yields
 K[s_C(w0)-c_s] >= T_A(H-2)+kKH+2K-Kc_s-2t_hi-2.
For each saved record and parity this final polynomial has strictly positive constant and all nonnegative coefficients on the same translated proper cone. These are four further exact checks. Hence s_C(w0)>c_s, contradicting f=1. Therefore f=1 implies s_Z(u)+4<=upper_s_Z, with NO harmonic fringe needed. For f=0 item5 already supplies s_Z(u)+4-2K<=upper_s_Z.

## Consequence and scope
All requested geometric inputs for the proposed commutator proof hold on the WHOLE E_A, both proper W0 lineages and every k>=1. The central interval hypothesis, when separately supplied for the genuine earlier field, gives the requested two slip lower bounds >=-1. This note does not itself rederive the field commutator, its lower longitudinal bounds, source chronology, helper UR placement, or literal endpoint initializers. In particular f=1 was not imposed on saved1; the actual lower-s branch is retained.
