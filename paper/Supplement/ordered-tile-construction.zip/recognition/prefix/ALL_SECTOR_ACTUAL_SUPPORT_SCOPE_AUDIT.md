# Actual support and frame audit: all sectors

## Verdict
The archived final induction, not merely the individual conditional coefficient modules, DOES close actual all-word STANDARD support containment and NONBASE alternate creation-R2 containment in the authentic restored frames. Its later chronological domain induction also closes consumed finite touching, exact support unions, domain reflection and actual LL/A4/A6/UR geometry. Thus these purely geometric prerequisites need not remain open for consumed original words in the mathematical unbounded-support interpretation. This does NOT close values, outer normalization constants, height reflection, current admission or recurrence, and it does not repair historical fixed-size padding.

The unqualified statement “every alternate is contained in its formal R2” is FALSE: literal pure-base alternates are deliberately excluded from that invariant and retain explicit corner corrections/literal selectors.

## Which archive actually assembles the implications
FRESH_ORDINARY_A3_HULL_ENCLOSURE_PROOF gives576 ordinary rows; FRESH_DIRECT_OUTER_AUXILIARY_ENCLOSURE_CERTIFICATES_AND_AUDIT gives4480 lower/upper rows; FRESH_BALANCED_THIRTY_TYPE_ENCLOSURE_REPLAY_AUDIT gives4816 inequalities, including six literal-root types. Read alone, these are conditional support implications.
ORIGINAL_ALL_WORD_SUPPORT_RECORD_EXHAUSTION_AND_INDUCTION and INDEPENDENT_ALL_WORD_SUPPORT_RECORD_INDUCTION_AUDIT assemble them with literal pure-standard initialization, all four first-mixed families, and all16 nonroot endpoint persistence cases. A saved endpoint predecessor can occur only at the pure initializer or its first mixed refresh. After both retained parents become strict they stay strict. The odd record refreshes after1/3 and the even record after1/2, AFTER current outputs. Thus every generic alternate enclosure input is earlier, with last1 birth phase flipped and last2/3 birth phase unchanged; pure-base alternates are never silently fed into the generic R2 hypothesis.
ORIGINAL_CONSUMED_FINITE_DEFINEDNESS_AND_BASIC_DOMAINS_CLOSE_BY_CHRONOLOGICAL_MUTUAL_INDUCTION subsequently supplies the actual support-union premise, ports, active ALT trace, and frames without current cover/heights. The unused initial auxiliary calls are explicitly outside its scope. Reading the earlier “finite touching remains assumed” banners without this later addendum gives an obsolete dependency status.

## Independent H-to-E arithmetic
The historical files call nx-dy “s” and (d+n)x+(d-n)y “t”; current G1/G2 files reverse those letter names. In CURRENT notation put t=nx-dy,s=(d+n)x+(d-n)y, c=d-n,L=d+n,T=d²+2dn-n²,mu=2 for odd type and1 for even type. The audited safe H enclosure is
 even physical sites: t in[min(2n,c)-T,max(2n,c)], s in[0,mu*T+2n];
 odd physical sites: t in[n-T,d], s in[min(c,2n-c),mu*T+max(c,2n-c)].
This safe envelope is sufficient even when a sector packet proves a sharper hull.

For odd type, E has even t[1-T,L-1], even s[0,2T+2n], odd t[n-T,d], odd s[2-c,2T+L-2]. Because n,c>=1,
 min(2n,c)>=1, max(2n,c)<=L-1,
 min(c,2n-c)>=2-c, max(c,2n-c)<=L-2.
For even type n,d are odd and c>=2 even. E has even t[2-T,L-2],s[0,T+2n], and odd t[n-T,d],s[2-c,T+L-2]. Now min(2n,c)>=2 and max(2n,c)<=L-2, with the same odd longitudinal inequalities. Hence H subset E for EVERY proper standard fraction, all sectors including their boundaries. This is a direct proof, no new coefficient replay needed. It includes the genuine standard roots1/2 and1/3 via their separately proved H initialization. Endpoint atoms0/1 and1/1 are not proper fractions and are not included.

Thus all actual proper standard native sites are inside exactly the E used in current ordinary/G1/G2 arguments, not just an unrelated relaxed box. Containment is not E occupancy or whole-hull equality.

## R2 and its precise exception
The producer's bounds(frac,odd,parity,creation) retains the OWN birth pair and birth phase. The balanced producer's odd longitudinal bounds use3n-d on the lower side and d-n on the upper; those are intentionally not the upper-sector exchange. The direct producer supplies the separate lower/upper formula. Current source queries must therefore retain their actual creation sector and raw/A4-restored frame, not infer them solely from consumer W or current fraction.

For a genuine nonbase alternate the chronological theorem pays this exact R2 containment. Literal pure-base sources are a separate class. For example LITERAL_RECIPROCAL_EVEN_ALTERNATE_IS_ENDPOINT_R2_PLUS_TWO_ODD_CORNERS proves raw ALT1/f, f>=3 odd, misses the formal endpoint R2 at L=(1-f,-1) and R=(3,f+1), by four longitudinal units. The all3 A4 extra ey is essential for that precise raw frame. Near-one odd literal alternates similarly require their two even corners. The completed all-word induction uses dedicated literal source modules for these cases, not a false blanket R2 inclusion. Consequently a current price proof only on formal R2 does not automatically pay these pure-base corners.

## Raw piece coordinates and actual UR shifts
INDEPENDENT_BALANCED_ENCLOSURE_ENGINE_LITERAL_LAYOUT_AUDIT binds std_layout,alt_layout,raw_piece_ops to actual K tables, natural replacement indices, flipped starts, source birth phases and A6 effective shifts. It distinguishes raw-stage parents p+kq versus next consumer p+(k+1)q (and the doubled even analog), and LONG endpoint2k+2 versus SHORT2k+1. Generic formulas omit literal endpoint-only G2 shifts by design.
INDEPENDENT_ALL_WORD_DOMAIN_REFLECTION_CENTER_AND_SCOPE_AUDIT initially recorded a missing anchor proof, then its09:58 appendix recovered and audited ANCHOR-GEOMETRY-ANALYSIS. It verifies all LL/A4 and A5/A6 lexicographic extrema, including the special pure3 extraey and pure2 LEFT G2 shift, with112 effective-shift identities and114 source-center identities. The later consumed-domain induction supplies finite nonempty supports chronologically, closing those geometric premises.
Common unpad is a rectangular coordinate crop removing no finite site, not independent LL normalization. The next center_mats aligns all current/retained fields and pieces to one actual anchor BEFORE source selection. A6 reads true UR and aligns the appropriate piece. This is exactly why earlier independent stored unpads do not create an untracked shift. Raw/restored origins in current price formulas must still be matched to these tables; a scalar max-zero normalization is a different, unpaid HEIGHT operation. Geometry of UR is paid; values of normalization are not.

## Evidence checked now and remaining limits
I read the named assembly, independent chronology/frame audits, source bounds and literal dispatcher; I did not rerun all thousands of coefficient rows. The three principal restored packet hashes match their archived fresh-replay receipts exactly (balanced e6553c33..., lower cc212fe3..., upper ba647cc7...). A companion manifest pins the current files. The ordinary576 packet is present and hashed too.

No additional generic all-sector native inclusion gate is missing under this actual chronological support theorem. Remaining scope errors would be: using R2 for a pure initializer without its corners; substituting the wrong birth/restoration; treating E/R2 as occupied; replacing same-order support reflection by value reflection; claiming height scalar calibration from UR geometry; or assuming arbitrary finite padding is safe. Those distinctions remain substantive in the current constructor proof.
