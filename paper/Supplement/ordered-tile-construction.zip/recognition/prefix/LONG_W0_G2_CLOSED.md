# W0 LONG G2: complete analytic price from genuine nested donors

Let A,Z be the proper effective saved1/3 pair with det(A,Z)=1, C=A+kZ, O=A+mZ, m=k+1≥2. Let u∈E_A and y=u+mV_Z. Assume the genuine earlier canonical fields, odd reflected-donor/nesting theorem, actual stationary O polygon identity and the effective old physical price/central-slip bounds recorded in BOTH_SAVED_G2_TRANSVERSE_FIRST_ARM.md. Neither E_A⊂E_Z nor a fictitious saved1 positive residual creator is assumed.

Then the raw W0 odd-alternate comparator

 T(y)=min(F_O(y),F_O(y+V_Z)−a_Z·y+c_Z+1)

equals the genuine transported G2 value

 F_A(u)+m a_Z·u−m c_Z−m(m−1)T_Z/2.

This is an analytic full-E_A result. Actual helper alignment and chronological calibration are separate premises.

## 1. Attainment by the first offer

The proved repeated odd reflected-donor nesting places E_A+mV_Z inside E_O and gives the first offer exactly as displayed above. Put F=F_Z and S(u)=F_A(u)−F(u). The independently established reusable G2 base identity is

 S(u)=min(0,H(u)−2),
 H(u)=F(u−V_A−2A)+a_A·u+eta_A+2−F(u).

The zero-primary/secondary law for F shows that the target relative to F(y) is precisely S(u). Therefore the second offer only needs

 F_O(q)−F(q)≥S(u)−1,  q=u+(m+1)V_Z.

## 2. Actual guarded O alias

Put v=V_A, w0=q−V_O=u−v+V_Z. Choose f=1 exactly when s_O(w0) is below its true parity lower row, and otherwise f=0. Then w=w0+2fO belongs to E_O.

The new exact coefficient audit audit_long_w0_g2_geometry.py verifies all64 parity/source-vertex facets in both effective saved cases, with n≥1,d−n≥1,r≥1,e_birth−r≥2,m≥2. It checks both t_O(w0) facets and the interval lo_s−2T_O≤s_O(w0)≤hi_s. The genuine row width and the actual f condition finish the primary fold. As before q+T_A>0 for each multiplied slack implies a nonnegative integer physical slack, so no nonphysical rectangle corner is asserted attainable. The script is an explicit modification of the previous G2 geometry encoder.

Writing t=t_A(u),s=s_A(u), its exact new coordinates are

 T_A t_O(w0)=(T_A+mK)t+ms+T_A[T_A+(m−1)K−mT],
 T_A s_O(w0)=(T_A+mK)s+2mt+T_A(2m+2).

These differ from the SHORT G2 alias by +Z: t decreases1 and s increasesK+mT. The old coverage alone therefore was not silently reused.

## 3. Both folded offers, including the extra primary shift

Use P(z)=F(z)−F(z+v)+a_A·z, D(z)=F(z)−F(z−2A), c_A=(T_A+L_A)/2. Abbreviate P_i=P(u−iv), d_v=D(u−v), d_2=D(u−2v), d_+=D(u−v+2A). The exact O pullback and the genuine stationary minimum at w give offers relative to F(q):

 I=P_1−c_A+f(d_++2),
 II=P_1+P_2−2c_A+(1−f)(2m−2−d_2).

One can obtain them from the earlier E1 table at root u+Z and index m+1: P shifts by−1 under Z, while D is invariant. Thus I decreases by1 and II by2 compared with the old unshifted-root G2 table. The true O primary shift has zero character.

Use H−2=P_1−c_A−d_v and the exact commutator P(x)−P(x−2A)=D(x)−D(x+v). They yield

 I−(H−3)=1+d_v+f(d_++2),
 II−(H−3)=P(u−2v−2A)−c_A+2m−1  if f=0,
 II−(H−3)=P_2−c_A+1+d_v  if f=1.

The earlier G2 central physical band gives d_v,d_+≥−1. Hence the first difference is nonnegative. For f=0 the earlier longitudinal bound and true nonpositive-primary folding give P(u−2v−2A)≥c_A−1; its difference is at least2m−2≥0.

## 4. The f=1 harmonic gain is essential

The actual f=1 condition implies

 (K+mT)s_Z(u)−2t_Z(u)+2(m+1)T<T*lo_s(E_O)≤0.

Since t_Z(u)<T, this forces s_Z(u)<0. The new independent32-facet receipt audit_long_w0_g2_rim.json proves throughout E_A that s_Z(u)≥−1−2D and t_Z(u)<T, with both saved choices and all proper parameters. Therefore u−v and u−2v, whose longitudinal grades are s_Z(u)+2 and s_Z(u)+4, lie in the complete harmonic strip [1−2D,2(D+N)−1]. The exact harmonic v-jet gives P_2=c_A, not merely c_A−1. Thus the last difference is1+d_v≥0. This extra unit is what pays the LONG endpoint; the weaker price span alone is insufficient.

Both offers are now ≥H−3. If H−2≤0, this is S−1. If H−2>0, it is stronger than S−1=−1. Consequently the second raw LONG offer cannot undercut the nested first donor, proving the displayed equality.

## Scope and dependency order

The argument consumes genuine earlier A+iZ polygon realization and reflected-donor nesting, the reusable base identity, full physical h0 and central D bounds, and the actual O stationary source formula. It does not prove these inputs from this LONG result. It supplies the full analytic G2 value at its nominal RIGHT window, not original min-touch constants, actual helper UR positioning, no-clipping, LEFT binding, or a standalone physical recurrence theorem.
