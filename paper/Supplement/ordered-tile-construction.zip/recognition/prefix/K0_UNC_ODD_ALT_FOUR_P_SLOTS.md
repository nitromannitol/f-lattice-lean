# k=0 uncorrected odd alternate: both-phase four-p-slot audit

Set C=A, O=A+Z, Q=2A+Z, with A proper odd,Z proper even and det(A,Z)=1-2W. The current standard O below is the authenticated stage2 ABSTRACT canonical field, independently constructed before current alternate native recognition. No identity of the current original native array is used to justify its donor values.

## Replacement for the nonexistent earlier stationary C identity

### W0
Use genuine E_A+V_Z subset E_O and the stage2 reflected p-donor identity

 F_O(u+V_Z)=F_A(u)+a_Z.u-c_Z.

On this licensed O polygon the raw stationary representation is M_O=min(F_Z,h), with
 h(z)=F_Z(z-V_A-2A)+a_A.z+eta_A+2.

Both constituents at u+V_Z have the common jet a_Z.u-c_Z; the h constituent additionally loses2. Therefore

 F_A(u)=min(F_Z(u),h(u)-2), u in E_A.

This is the exact missing k=0 identity. It uses an independently admitted canonical O, not a current native equality or a claim that A has earlier stationary ancestry.

### W1
The genuine nesting E_A subset E_O and stage2 near p donor F_O(u)=F_A(u), together with the actual raw O representation, give

 F_A(u)=min(F_Z(u-2A),F_Z(u-V_A)+a_A.u+eta_A).

Again this is canonical stage2 data, independent of the target alternate recognition.

## pNear, including the W0 possible one-row exception

For W0 the existing LONG_W0_ORDINARY_P_ONE_ROW_REPAIR.md uses only arbitrary proper A,Z for the two nesting inclusions and one-row geometry. Replace its old F_C=M_C premise by the identity just proved. Its exceptional upper odd row has F_A(u)=F_Z(u)=0, so h(u)-2>=0, exactly the inequality needed by the repair. Even upper-row escape remains excluded. The reflected second query is paid by the same genuine O and raw-minimum reflections. The four target constituents at y=u+Z are now

 F_Z(u), h(u)-1, F_Z(u)+1, h(u)-2.

Their minimum is F_A(u). Thus W0 pNear has origin Z, slope0, scalar0.

For W1, LONG_W1_ORDINARY_P_DONORS.md proves both needed queries u+Z and u+Z+V_Z genuinely belong to E_O for arbitrary proper A,Z. Its geometric proof is independent of a positive run length. Write U=F_Z(u-2A), V=F_Z(u-V_A)+a_A.u+eta_A. In the actual W1 shifted phase x=y+Z at y=u, the four constituents are

 U, V+1, U+1, V.

Their minimum is F_A(u). W1 pNear therefore has origin0, slope0, scalar0. No off-polygon minimum is invoked.

## pFar from the correct raw alternate involution

Use R_A=2A+V_A+delta. The raw target center and jet are

 W0: R=R_Q+Z; W1: R=R_Q-Z;
 T(R-y)=T(y)-a_Q.y-eta_Q-1.

Reflecting pNear gives

 W0 origin V_A+V_Z+Z, slope a_A+a_Z, scalar eta_O;
 W1 origin V_A+V_Z, slope a_A+a_Z, scalar eta_O+1.

The unsimplified scalar is eta_Q+1-eta_A+a_A.oFar. Simplification uses a_A.Z=2W-1, a_A.V_Z=-K and
 eta_Q=T_A+2eta_A+2K+eta_Z,
 eta_O=eta_A+eta_Z+K.

## All four ordinary p slots, once m=1 G2 is separately closed

The natural original odd-alternate slots2,3,4,5 are all A sources. At k=0 the middle two slots are the G2 candidates; LONG helper recognition is not being assumed to prove them. The independently supplied m=1 G2 value theorem must give the RIGHT candidate below. Its reflected LEFT follows from the same raw target involution and genuine A reflection.

| W | Natural slot | Origin | Slope | Global scalar |
|---|---|---|---|---|
|0|2|Z|0|0|
|0|3|2Z+V_A|a_A|eta_A+1|
|0|4|V_Z|a_Z|eta_Z|
|0|5|Z+V_Z+V_A|a_A+a_Z|eta_O|
|1|2|0|0|0|
|1|3|V_A-Z|a_A|eta_A|
|1|4|Z+V_Z|a_Z|eta_Z+2|
|1|5|V_Z+V_A|a_A+a_Z|eta_O+1|

The positions and slopes agree directly with literal _alt_odd/getAltOddTileFull, including W1 slot3 V_A-Z. For W0 RIGHT G2 the licensed O donor at u+V_Z yields global scalar eta_Z. W1 RIGHT G2 has the directly proved LONG target scalar eta_Z+2 at m=1. These identify candidate jets; dominance of the competing offer at m=1 is a separately required theorem, as stipulated.

For the reflected middle slot use
 c_left=eta_Q+1-eta_A+a_A.o_left+a_Z.R+c_right.
Substitution gives eta_A+1 in W0 and eta_A in W1. Thus no extra unknown phase constant remains in the candidate table.

## Exact noncircular assembly order
1. Independently authenticated stage2 abstract O, its donor values and polygon realization.
2. Arbitrary-proper nesting/one-row geometry from the two named LONG pNear proofs.
3. Derive the k=0 A identities above; pay pNear and reflect to pFar.
4. Supply independent m=1 G2 dominance/attainment; then both middle A slots follow with the listed jets.
5. Only afterward use actual native supports, chronological contact minima and normalization to recognize the original uncorrected alternate.

This audit settles pNear/pFar and the candidate four-slot assembly conditional on item4. It does not assume current native equality, prove all seven-source contacts, or assert recurrence from this value table.
