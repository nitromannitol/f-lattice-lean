import sys,itertools,json,hashlib,subprocess
from pathlib import Path
sys.path.insert(0,'/tmp/f_lattice_z3');import z3 as z
import sympy as s
P=Path(__file__).resolve().parent
d,x,y=z.Ints('d x y');D,X,Y=s.symbols('d x y');mn=lambda a:z.If(a<0,a,0)
def conv(a):
 p=s.Poly(s.expand(a),D,X,Y);assert p.total_degree()<=1,p
 return sum(int(c)*d**i*x**j*y**k for(i,j,k),c in p.terms())
def nd(u,v):return z.Or(z.And(u>=2-d,u<=d,v>=0,v<=d+1,u+v>=1,u+v<=d+2),z.And(u==0,v==0),z.And(u==2,v==d+1))
def corr(u,v):return mn(u-1)+z.If(z.Or(z.And(u==0,v==0),z.And(u==2,v==d+1)),1,0)
def charts(sx,sy,extra=0):
 arr=[];T=D*D+2*D-1;cv=-D*(D+3)/2
 for i,l in sorted(itertools.product(range(-3,4),repeat=2),key=lambda a:abs(a[0])+abs(a[1])):
  u=X+sx+i*D+l*(1-D);v=Y+sy+i+l*(D+1)
  poly=-2*v*(v-1)+2*Y*(Y-1)-4*l*(X+sx-D*(Y+sy)+cv)+2*l*(l-1)*T+extra
  gu=nd(conv(u),conv(v));val=conv(poly)+4*corr(conv(u),conv(v));arr.append((gu,val))
 vv=z.IntVal(0)
 for g,h in reversed(arr):vv=z.If(g,h,vv)
 return z.Or(*[g for g,h in arr]),vv
c0,f=charts(0,0);c1,g=charts(3*D-4,2-D,4*(X-(D-1)*Y+(D*D-D-2)/2))
# actual reciprocal native polygon equals native domain, including both corners
checks={'R1_root_cover':z.And(nd(x,y),z.Not(c0)),'R1_shift_cover':z.And(nd(x,y),z.Not(c1)),'R1_Hhat_nonnegative':z.And(nd(x,y),g<f)}
rows=[]
for name,bad in checks.items():
 q=z.Solver();q.set(timeout=120000);q.add(d>=3,d%2==1,bad);p=P/(name+'.smt2');p.write_text(q.to_smt2());ans=str(q.check());print(name,ans,flush=True)
 if ans=='sat':print(q.model(),flush=True)
 assert ans=='unsat'
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(p)],capture_output=True,text=True,timeout=150).stdout.strip();assert fresh=='unsat'
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (P/'R1_HHAT_RECEIPT.json').write_text(json.dumps(rows,indent=2))
