import sys,itertools,json,hashlib,subprocess
from pathlib import Path
sys.path.insert(0,'/tmp/f_lattice_z3');import z3 as z
import sympy as s
P=Path(__file__).resolve().parent
b,x,y=z.Ints('b x y');B,X,Y=s.symbols('b x y');mn=lambda a:z.If(a<0,a,0);mx=lambda a:z.If(a>0,a,0)
def conv(a):
 p=s.Poly(s.expand(a),B,X,Y);assert p.total_degree()<=1,p
 return sum(int(c)*b**i*x**j*y**k for(i,j,k),c in p.terms())
def zn(u,v):
 h=v+1-u
 return z.Or(z.And(u>=-1,u<=2*b+1,v>=0,v<=6*b-2,h>=-1,h<=4*b+1,z.Not(z.Or(z.And(u==-1,v<=2*b),z.And(u==2*b+1,v>=4*b-2)))),z.And(u==-1,v==4*b),z.And(u==2*b+1,v==2*b-2))
def zc(u,v):return mn(2*b-v-1)+mx(v+1-u-2*b)+mn(4*b-v-1)+z.If(z.Or(z.And(v+1-u==2*b,u>0,u<2*b),z.And(u==-1,v==4*b),z.And(u==2*b+1,v==2*b-2)),1,0)
def an(u,v):return z.Or(z.And(u>=0,u<=2*b,v>=0,v<=4*b-4,v+1-u>=-1,v+1-u<=2*b-1),z.And(u==0,v==2*b-1),z.And(u==2*b,v==2*b-3))
def ac(u,v):return mn(2*b-2-v)+z.If(z.Or(z.And(u==0,v==2*b-1),z.And(u==2*b,v==2*b-3)),1,0)
def charts(kind,sx,sy,extra=0):
 if kind=='Z':U=(2*B+1,2*B-1);V=(-2,4*B);aa=(2*B-1,-2*B-1);T=8*B*B+8*B-2;cv=-4*B*B-6*B+1;nd,cr=zn,zc
 else:U=(2*B,2*B-2);V=(-1,2*B-1);aa=(B-1,-B);T=2*B*B-1;cv=-B*B-B+1;nd,cr=an,ac
 arr=[]
 for i,l in sorted(itertools.product(range(-2,3),repeat=2),key=lambda a:abs(a[0])+abs(a[1])):
  u=X+sx+i*U[0]+l*V[0];v=Y+sy+i*U[1]+l*V[1]
  # 4F(point)+base H^2, parity correction identical across even shifts
  poly=-(v+1-u)**2+(Y+1-X)**2-4*l*(aa[0]*(X+sx)+aa[1]*(Y+sy)+cv)+2*l*(l-1)*T
  gu=nd(conv(u),conv(v));val=conv(poly+extra)+4*cr(conv(u),conv(v));arr.append((gu,val))
 vv=z.IntVal(0)
 for g,h in reversed(arr):vv=z.If(g,h,vv)
 return z.Or(*[g for g,h in arr]),vv
E=z.Or(zn(x,y),z.And(x==-1,y==2*b),z.And(x==2*b+1,y==4*b-2))
c0,f=charts('Z',0,0)
c1,g=charts('Z',2*B+3,-1,4*(B*X-(B+1)*Y+B*B+B))
checks={'root_cover':z.And(E,z.Not(c0)),'shift_cover':z.And(E,z.Not(c1)),'Hhat_nonnegative':z.And(E,g<f)}
rows=[]
for name,bad in checks.items():
 q=z.Solver();q.set(timeout=120000);q.add(b>=2,bad);p=P/(name+'.smt2');p.write_text(q.to_smt2());ans=str(q.check());print(name,ans,flush=True)
 if ans=='sat':print(q.model(),flush=True)
 assert ans=='unsat'
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(p)],capture_output=True,text=True,timeout=150).stdout.strip();assert fresh=='unsat'
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (P/'HHAT_RECEIPT.json').write_text(json.dumps(rows,indent=2))
