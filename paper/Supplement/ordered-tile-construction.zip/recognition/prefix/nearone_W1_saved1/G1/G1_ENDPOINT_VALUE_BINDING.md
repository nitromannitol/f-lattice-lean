# N1 G1 SHORT/LONG and direct N0/R1 endpoint value inputs

## N1 theorem

For b>=2 take the actual near-one even standard Z=(2b+1,2b-1), its true creator a=(b,b-1), R=(1,1), and the effective saved1 W1 parent A=Z-a=(b+1,b). For C=A+kZ, k>=1, the W1 SHORT G1 and W1 LONG G1 proofs apply on every complete genuine E_Z carrier and every positive G1 index. The independently confirmed four-state dispatcher identifies this as N1; its necessity is no longer an inferred source-name analogy.

This remains an analytic carrier/value statement with the existing actual alignment/chronological normalization premises. No new current-child recurrence is assumed.

## Fresh geometry and a direct old-field value proof

The endpoint substitutions n=u+1,d=u+2,r=e=1 were made in distinct copies of the genuine W1 encoders. All 302 relevant facets pass:

* SHORT four-alias boxes:128;
* e2 never/e1 final only:128;
* harmonic f2=0:2;
* final transverse guards:4;
* LONG endpoint alias box:32;
* LONG endpoint physical price guards:8.

The LONG endpoint uses m=k+1>=2. It does not need a separate positive G1 at m=1: that range has no positive index.

The value input Hhat>=0 is independently proved directly from the true pure2 native field, not by an unverified endpoint extension of a proper predecessor chain. In actual physical coordinates,

 Hhat(u)=F_Z(u+(2b+3,-1))-F_Z(u)+b*u_x-(b+1)*u_y+b^2+b.

Here (2b+3,-1)=2A-V_A and eta_A=b^2+b. direct_hhat.py proves positive cover of both evaluations and nonnegativity on the entire E_Z, including its two extra polygon corners. All three unbounded gates are QF_LIA and have fresh independent CLI replays. They use the true native formula and deck characters already bound in ../source_identity.py. The common parity/floor term is cancelled exactly before the affine-arithmetic check.

Equivalently this is the intrinsic saved1 expression c_a+2-Phi_plus(u), with the unreflected u. But the proof here does not depend on importing that maximum theorem or its endpoint predecessor convention.

## Check of the actual W1 offer wiring

Set r=eta_A-Pstd(u), rm=eta_A-Pstd(u-V_A), d0=D(u-2A), db=D(u-V_A-2A), dv=D(u-V_A), dvv=D(u-2V_A), where D=F_Z-F_Z(.+2A). The authentic pure2 birth shift -2a is congruent to +2A modulo Z, so the true full physical D band applies. No enlarged effective central |D|<=1 assertion is used.

The old pure2 price span gives r in{0,1}; transverse/longitudinal saturation and the full harmonic rim give rm>=0. The actual physical band gives d0>=0 and the band/high-transverse extension gives dvv<=2 at the queried roots.

SHORT arm2 has e2=0. Its f2=0 row attains0 by the checked harmonic r=1; its f2=1 row is (0,Hhat+2(k-j)+1), so also attains0. For arm1, the nonfinal Hhat terms are nonnegative by the direct proof. At the final index the checked e0 guard gives dv<=0, or the e1 guard gives db>=0; the remaining constituent uses dvv<=2 and k>=1. These are exactly the signed eight-offer rows, with no source exchange or new gauge.

LONG first offers are these already proved SHORT arm2 attainments at the next index and stationary parameter m. Only the last competing endpoint is new. Its four rows are

 (d0+2m,r-1), (0,r-dv-1),
 (r+db-1,r+rm-2), (r-1,r+rm-dvv+2m-2).

The 40 LONG facets pay e0=>dv<=0, e1=>db>=0, f0=>r=rm=1. Thus every row is >=-1, precisely the authentic LONG allowance, and the first offer attains the target. LEFT follows from the earlier genuine field reflection with the already audited raw LONG phase center R_Q-Z (SHORT uses R_Q). Those are value/reflection statements; actual helper recentering is not inferred merely from the list of nominal origins.

## N0 and R1 value wiring audited directly

N0 is the same near-one F_Z but W0 saved3 A=a. N0_direct_H.py proves, directly on full E_Z,

 H(u)=F_Z(u+(1-2b,3-4b))-F_Z(u)+(b-1)u_x-bu_y+b^2-b+2 >=0.

This is the actual nonharmonic competing h-F quantity, NOT h0. It supplies the whole-E lower bound used in the W0 G1 wiring. The stronger last no-fold H>=1 remains the already proved guarded physical-strip consequence t(u)+K0>=1, not an unsupported global improvement. Pure2 K0 is the real creator size, so the physical-window uses in N0 have no saved1 effective-parent error. The known SHORT geometry and corresponding LONG endpoint geometry remain separately required; this packet does not relabel a SHORT-only receipt as a LONG receipt.

R1 is the actual reciprocal F_Z with Z=(d,1), odd d>=3, effective A=(d-1,1). R1_direct_hhat.py independently proves on its true polygon, including the two inserted corners,

 Hhat(u)=F_Z(u+(3d-4,2-d))-F_Z(u)+u_x-(d-1)u_y+(d^2-d-2)/2 >=0.

The explicit native reciprocal formula and genuine deck extension are used. Separate root/shift coverage gates prevent an incomplete-alias proof. All three gates have fresh CLI replays and include d=3. Consequently the W1 G1 value wiring uses a genuine endpoint price bound, without a false effective central bound or a guessed predecessor. Its d0/db uses are the complete physical band on the selected guards, not the invalid G2 central interval; this distinction is essential.

Across N1,N0,R1, nine fresh gates and their raw hashes are recorded in HHAT_RECEIPT.json, N0_H_RECEIPT.json, R1_HHAT_RECEIPT.json. They prove the indicated full-E old-field inequalities, not recurrence or chronological retention of a current source union.
