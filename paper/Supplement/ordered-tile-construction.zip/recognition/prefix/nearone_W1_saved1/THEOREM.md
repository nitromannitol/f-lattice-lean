# Near-one real-birth extension of the saved1 W1 G2 repair

For every integer b>=2, let a=(b,b-1), R=(1,1), Z=2a+R=(2b+1,2b-1), A=Z-a=(b+1,b). The guarded joint saved1 W1 G2 comparison extends to this endpoint state, with all stationary lengths covered by the existing SHORT/LONG formulas, including LONG m=1. The conclusion concerns these analytic native carriers and their authenticated stationary nesting; it does not certify a fresh constructor's chronological alignment or say that every arbitrary history reaches this state.

## The real endpoint birth minimum is now proved

The four fresh universal integer-linear gates in SOURCE_RECEIPT.json prove on the ENTIRE authentic E_Z, including both extra polygon corners,

 F_Z(z)=min(F_a(z-R), F_a(z-V_R)+x-y),  V_R=(0,2).

Here F_Z is the true standard pure2 even field and F_a the true odd staircase field, with their actual exported coordinates and primary/secondary characters. This is not a fictitious invocation of a proper R theorem.

source_identity.py independently encodes their explicit native domains and heights. For F_Z the native height is -floor((y+1-x)^2/4)+corr_Z. For F_a it is -floor((y+1-x)^2/4)+min(2b-2-y,0)+the two literal inserted-corner indicators. These are precisely the source formulas in pure2_initialization/uniform_bulk.py and pure3_initialization/rotation.py (the latter uses its d=2b-1).

Each queried field uses 25 positive native aliases. Separate gates prove their union covers the entire target E_Z; an omitted alias therefore cannot make the equality proof vacuous. The selected offers use the genuine inverse deck formula. The already authenticated global fields make simultaneous positive offers coherent. The common floor/parity term cancels because all offsets and actual periods preserve physical parity. Every remaining polynomial is asserted affine before translation to Z3, so all four raw gates are QF_LIA, not a numerical interpolation or nonlinear timeout. Each was freshly replayed with the independent CLI and its raw SHA recorded.

## All necessary geometry survives at R=(1,1)

short_geometry.py and long_geometry.py substitute the real one-variable birth into the original source/fold formulas. They prove 58 facets each. LONG uses m=j+1, j>=0, so it includes m=1 directly. projection_geometry.py separately verifies six determinant identities and five nonnegative-coefficient inequalities used in the guarded correlation proof.

Useful exact sizes are

 T_Z=8b^2+8b-2,
 K0=M(a,Z)=4b^2+2b-2,
 K_eff=M(A,Z)=4b^2+6b,
 T_A=2b^2+4b+1.

In particular K0>=L_Z, K_eff>T_A, K_eff>=T_A+2n_A, and T_Z>2K0. All inequalities include b=2. No positive e-r margin is imported.

## Source and price inputs needed by the repair

The true pure2 profile-window certificate gives the birth price span [c_a-1,c_a] on E_Z (indeed its incoming halo), c_a=b^2+b-1. Its complete physical harmonic/zero strip certificates include the two exceptional polygon corners. The earlier pure2 physical D band has its REAL K0, not K_eff. The repair uses the complete band plus a V_Z wrap to get db>=-2; it never claims the enlarged effective central >=-1 bound.

Longitudinal saturation uses only the exact E_Z parity rows and P_b's V invariance/primary drift. Hence it pays the same global localization P_b>c_a => s_Z<lo_s. On the physical lower harmonic rim, P_b=c_a; thus r>=0 on s>=3-2D. The fresh f0 facets place SHORT x and LONG x'=x-Z at s>=5-2D, paying both shifted prices, even at m=1.

For f1 the sole additional correlation is r(x)<0 => D_b(u+2a+V_a)>=1. The independent_W1 proof applies unchanged after the five inequalities above are specialized. All its native uses now refer to the freshly proved two-sheet identity. At u=0 the corner calculation uses F_a(-R)=0 and F_a(-V_R)=-eta_R=0; these are genuine old zero/harmonic-strip points, even though R is an endpoint. The two source prices at 2a+V_a are 1-c_a and 2-c_a, while F_Z(V_a)=-c_a, so D_b=1. At other roots, the native first-sheet inequality and the second-sheet gap decrement2 give the contradiction to D_b=0 exactly as in the proper repair.

Thus f0 constituents are nonnegative; f1 first constituents dominate S=min(0,r-1-dv), or S-1 for LONG. The existing separately paid second-f1 rim comparison uses the same actual strips and the specialized geometry, not a stronger central estimate.

## Scope of the extension

This closes the stated near-one W1/saved1 G2 analytic state, including its real source identity. It neither duplicates G3 nor treats the primitive selected A=(1,0) clipped G2 problem: here A=(b+1,b) is proper. The actual history-to-state dispatcher remains a separate input. If an original trace never presents this state, the theorem is a valid redundant endpoint certificate, not evidence that the trace does present it.
