# Both W0 saved records: G2 first-arm price after a transverse fold

## Conditional theorem

Let A=(d,n) be the genuine effective odd parent, Z=(D,N) the fixed even parent, det(A,Z)=1, C=A+kZ, k>=1. This includes saved3 A=a and saved1 A=Z-a without a fictitious creator. Let u in E_A, y=u+(k+1)V_Z, r=y-Z. Assume the independent actual fold geometry has supplied

 e=1, f=1_{s_C(r)<lo_s(E_C)}, w=r-V_C+2fC in E_C.

Retain the authentic stationary C polygon source identity, genuine global deck laws, full E_Z effective P span and complete physical central D interval. Then

 F_C(r)-F_Z(y) >= min(0,H(u)-2)=F_A(u)-F_Z(u).

The last identity is the already proved reflected donor/base-difference identity. This proves the required first-arm lower comparison for both saved records on the e=1 region. It does not assert the missing e=0 geometry/price, actual helper alignment or a current normalization.

## 1. Exact algebra, with all constants

Write v=V_A, U=2A, c_A=(T_A+L_A)/2,
 P(x)=F_Z(x)-F_Z(x+v)+b_A.x,
 D(x)=F_Z(x)-F_Z(x-U), P_i=P(u-iv), d_v=D(u-v).
The exact commutator is

 P(x)-P(x-U)=D(x)-D(x+v).

Therefore the global earlier offer H obeys

 H(u)-2=P_1-c_A-d_v.

The E1 two-offer formula is algebraic for arbitrary j. At j=k+1, after the genuine C pullback from w, it gives offers I,II relative to F_Z(y):

 I=P_1-c_A+1+f[D(u-v+U)+2],
 II=P_1+P_2-2c_A+2+(1-f)[2k-2-D(u-2v)].

Hence

 I-(H-2)=1+d_v+f[D(u-v+U)+2].

For f=1,
 II-(H-2)=P_2-c_A+2+d_v.

For f=0, applying the commutator at u-2v cancels the two slip terms and yields exactly

 II-(H-2)=P(u-2v-U)-c_A+2k.

In particular the constant in this last line is2k, not2k-2. These expansions use no native sample or guessed scalar.

## 2. General E_A transverse bounds

Set T_A=d²+2dn-n², T=T_Z, K=M(A,Z), L_A=d+n, L=D+N, c_Ageom=d-n. The determinant identities are

 T_A t_Z=K t_A+s_A,
 T_A s_Z=K s_A+2t_A,
 Kd=D T_A+c_Ageom,
 Kn=N T_A-L_A,
 KL_A=L T_A-2n.

Substitution of the exact E_A parity rows gives

 odd: -K+N <= t_Z(u) <= D+2,
 even: -K+1 <= t_Z(u) <= L+1.

For example the odd lower rational endpoint is -K+N-(2d-2)/T_A, and the upper is D+2+(2d-2)/T_A. The proper odd inequality T_A>2d-2 and integer t_Z give the displayed bounds. The even endpoints are >-K and <L+2. These bounds hold for an arbitrary proper pair, not just Z=2A+positive R.

Both t_Z(u-v)=t_Z(u)+K and t_Z(u-v+U)=t_Z(u)+K+2 lie in the complete central D interval [3-D-K,N+2D-1+K]. The lower bound is immediate from the displayed inequalities; the upper uses D>=4 and N>=3 in the present proper-birth family. Thus

 d_v>=-1, D(u-v+U)>=-1.

Consequently I-(H-2)>=0 for either f, and is at least1 when f=1.

## 3. f=1 gate: use the ACTUAL lower-facet condition

Let B=K+kT. The exact first-arm coordinate at j=k+1 is

 T s_C(r)=B s_Z(u)-2t_Z(u)+2(k+1)T-BT.

Both parity lower edges lo_s(E_C) are nonpositive. Therefore f=1 implies

 B s_Z(u)<BT+2t_Z(u)-2(k+1)T+T lo_s(E_C)<BT,

because t_Z(u)<=max(D+2,L+1)<T and k+1>=2. Hence s_Z(u)<T. It follows that s_Z(u-2v)=s_Z(u)+4<T+4, which is below E_Z's upper longitudinal row in both parities (even T+2N, odd T+L-2).

Whenever a physical point's s is no larger than that upper row, a genuine longitudinal fold into E uses a nonpositive primary index, and a subsequent V_Z fold completes E membership without changing P. The full E price span and P(Z)=-1 give P>=c_A-1; no lower s restriction is necessary. Apply this to u-2v to obtain P_2>=c_A-1. Thus

 II-(H-2)>=(-1)+2+(-1)=0.

This gate depends on f being the actual lower-facet indicator, not an arbitrary positive-primary alias chosen for another proof.

## 4. f=0 gate: shifted price has a small upper longitudinal bound

From the E_A upper rows and the determinant identities,

 even: s_Z(u)<=2K+2N-2,
 odd: s_Z(u)<=2K+L-2.

The even rational upper endpoint is2K+2N-2/T_A. Since s_Z is even, its largest possible integer value is at most2K+2N-2. The odd rational endpoint is2K+L+2(c_Ageom-K)/T_A<2K+L, since K>c_Ageom; its evenness gives the stated bound.

For x=u-2v-U this implies

 s_Z(x)=s_Z(u)+4-2K <=2N+2 (even), or L+2 (odd).

Both are below E_Z's upper s row, so the same exact nonpositive-index folding gives P(x)>=c_A-1. It follows that

 II-(H-2)>=2k-1>=1.

There is no lower-s obstruction: a point farther below the polygon only increases P under the true primary character. In particular the saved1 effective parent creates no exception.

## 5. Conclusion and scope

Both licensed offers are >=H-2. If H-2<=0 this is the desired target; if H-2>0 it is stronger than the target0. Thus their minimum is >=min(0,H-2). The actual G2 target is exactly that quantity relative to F_Z by REUSABLE_G2_BASE_DIFFERENCE.md, consuming its prior odd nesting/reflected-donor identity.

The argument does not need the saved3 birth identity F_A=F_Z(.-2A), nor does it assume E_A is contained in E_Z. It uses only determinant-controlled coordinates, true E spans/central physical D values, exact stationary offers and the licensed actual e=1 fold. It applies equally to both saved records. The actual fold geometry, remaining e=0 price cases and source/prefix gauge are separate obligations, not conclusions smuggled into this estimate.
