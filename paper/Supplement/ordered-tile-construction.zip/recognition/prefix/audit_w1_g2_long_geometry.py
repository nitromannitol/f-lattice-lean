import sympy as s
import json,hashlib
from pathlib import Path
rows=[]
for saved in [3,1]:
 d,n,e,r,k=s.symbols('d n e r k');D=2*d+e;N=2*n+r;ad,an=(d,n)if saved==3 else(d+e,n+r);TA=ad*ad+2*ad*an-an*an;K=(ad+an)*D+(ad-an)*N;T=D*D+2*D*N-N*N;TC=TA+2*k*K+k*k*T;DC=ad+k*D;NC=an+k*N
 a,b,c,f,j=s.symbols('a b c f j');sub={n:a+1,d:a+b+2,r:c+1,e:c+f+3,k:j+2}
 for p in [0,1]:
  tl,th,sl,sh=(an-TA,ad,2-ad+an,2*TA+ad+an-2)if p else(1-TA,ad+an-1,0,2*TA+2*an)
  cl,ch,cs,ct=(NC-TC,DC,2-DC+NC,2*TC+DC+NC-2)if p else(1-TC,DC+NC-1,0,2*TC+2*NC)
  for it,t in enumerate([tl,th]):
   for iss,ss in enumerate([sl,sh]):
    # det(A,Z)=-1: tZ=(Kt-s)/TA, sZ=(Ks-2t)/TA
    tz=K*t-ss;sz=K*ss-2*t
    # x=u+Z-2A; w0=u+Z-2A-v+VZ
    tc=(TA+k*K)*t-k*ss+TA*(TA+(k-1)*K-k*T+2*k)
    sc=(TA+k*K)*ss-2*k*t+TA*(-2*TA-2*k*K-2*k-2)
    # tZ(x-v)=tZ(u)+2+K; tZ(x-v-2A)=tZ(u)+4+K
    qs=[tc-TA*cl,TA*ch-tc,sc+2*TC*TA-TA*cs,TA*ct-sc,tz+TA*(K+2)-TA*(3-D-K),TA*(N+2*D-1+K)-tz-TA*(K+4),sz-TA*(5-2*D)]
    for fi,q in enumerate(qs):
     pp=s.Poly(s.expand((q+TA).subs(sub)),a,b,c,f,j)
     assert all(z>=0 for z in pp.coeffs())and pp.TC()>0
     rows.append({'key':[saved,p,it,iss,fi],'constant':str(pp.TC()),'terms':len(pp.terms()),'pass':True})
  upper=(TA+k*K)*(4-2*D+2*K)+2*th+K*(-2*TA-2*k*K-2*k-2-cs)
  # simplify K² = TA*T+2: expansion equals following
  red=TA*(4-2*D)+k*K*(2-2*D)-K*(2+cs)+2*th
  G=s.groebner([d*r-n*e-(-1 if saved==3 else 1)],d,n,e,r,k,domain=s.QQ)
  assert G.reduce(s.expand(upper-red))[1]==0
  pp=s.Poly(s.expand((-red).subs(sub)),a,b,c,f,j)
  assert all(z>=0 for z in pp.coeffs())and pp.TC()>0
  rows.append({'key':[saved,p,'f0_lower'],'constant':str(pp.TC()),'terms':len(pp.terms()),'pass':True})

p=Path(__file__);p.with_suffix(".json").write_text(json.dumps({"complete":True,"count":len(rows),"producer_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"rows":rows},indent=2)+"\n");print("PASS",len(rows))
