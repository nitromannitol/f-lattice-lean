# Pure3 outer ordinary sources: native carrier reduction, no false full-polygon extension

Let e=2a+1>=3, Z=q=(e,1), Y=V_Z, P_h=(he+1,h), h>=1. Write G=F_Z, B=(1,-e), T=e²+2e−1,c=(T+e+1)/2,eta=T−c. Let D_h be the genuine standard native domain of P_h, and Dq the literal reciprocal standard domain. The current corrected siblings have parents C=P_h,Z, and O=P_(h+1).

Use the historical exact native theorem NEGATIVE_RECIPROCAL_TWO_RUN_HEIGHTS_REDUCE_TO_A_LITERAL_TWO_ROOF_SEED.md and its independent audit. On D_h the actual standard height is

 F_(P_h)(z)=min(G(z),G(z−(1,1))−z_y+2h).

This is a native identity. We do NOT replace the global periodic F_(P_h) by this minimum outside D_h.

## 1. Entire ordinary reciprocal carriers, all h
The literal selectors give Dq⊂D_1. A separate exact unbounded Presburger difference is empty for every a>=1 in check_PURE3_G1_NATIVE_CARRIER.py. This is the true reciprocal odd doubled base, including all native corners, not an endpoint H approximation.

The ordinary source union for D_h contains D_(h−1)+Y. Therefore, by induction,

 Dq+jY ⊂ D_h, 0<=j<=h−1.

The recursion is a genuine earlier ordinary odd constructor, with finite touching already certified. This is actual native support, not a claim that every point of an abstract E polygon is occupied.

Define H0(z)=G(z−(1,1))−z_y+2−G(z). The historical exact literal seed certificate gives0<=H0(u)<=2 on ALL Dq. The genuine G deck gives H0(u+jY)=H0(u)−2j. Consequently, on every carrier above,

 F_(P_h)(u+jY)−G(u+jY)=min(0,H0(u)+2h−2−2j)=0.

Thus each of these whole native copies attains the physical global reciprocal field exactly, including all added q corners. This conclusion does not use current corrected output values.

## 2. SHORT RIGHT G1: an exact attaining arm everywhere
In the actual SHORT raw comparator

 M_Q(y)=min(F_C(y−q),F_C(y−Y)+B·y+eta), Q=2C+q,

put y=u+jY,1<=j<=h,u∈Dq. The second query lies in Dq+(j−1)Y⊂D_h and equals G(y−Y). Its offer is therefore exactly G(y) by the genuine G secondary jet. This covers the ENTIRE actual RIGHT G1 chain, not just interior j. The current price equals G there if and only if the single remaining physical inequality

 F_C(u+jY−q)>=G(u+jY)

holds. No support of its query is inferred from the attaining second arm. This isolates one lower comparison rather than two unknown source values. Reflection transfers the completed RIGHT statement once this inequality is paid; no scalar can hide an undercut.

## 3. LONG ordinary qNear and qFar paid directly on their actual domains
The raw LONG target is

 Tlong(y)=min(F_O(y),F_O(y+Y)−B·y+c+1).

For u∈Dq, BOTH u and u+Y are licensed by Section1 for O=P_(h+1), including h=1. Both fields equal G. Thus its offers are G(u) and G(u)+1, and

 Tlong(u)=G(u) on the whole ACTUAL qNear domain.

More generally, the same exact argument gives Tlong(u+jY)=G(u+jY) for0<=j<=h−1. The last RIGHT helper indexj=h needs its separate endpoint inequality; no improper extension of the ordinary carrier range is made here.

The already algebraic raw reflection has center R=R_Q+q and law Tlong(R−y)=Tlong(y)−a_Q·y−eta_Q−1. The literal G domain is invariant under its own genuine reflection. Hence the entire qFar source at o=2C+2V_C+q has exact candidate price

 G(y−o)+2a_C·y+eta_Q+1−eta_Z+a_Z·o.

The relative extra+1 is essential. This proves both actual LONG outer ordinary Z prices from literal seed/native identities only, with no unproved whole-E realization assumption.

## 4. Current ordinary parent versus retained endpoint
Both CURRENT outer parents C=(he+1,h),Z=(e,1) are proper and det(C,Z)=1. Their generic basic standard qNear/pNear comparisons and reflected sources, where the previous proof's parent-profile premises are available, are not invalidated by the retained helper's older endpoint A=(1,0). This distinction avoids treating the whole corrected outer call as an endpoint creation.

For LONG pNear/pFar the earlier general one-row proof would apply if its full E_C,E_O stationary identities are available. The historical native two-roof theorem alone does not supply those larger-domain identities. A native alternative is to prove the two exact query licenses (or boundary exceptions) for u in the actual D_h at u+q and u+q+Y, then use the same four-offer algebra. The current source union immediately contains D_h+2q and D_h+Y, but that alone does not imply containment at the middle translate D_h+q. This is a precise remaining coverage/value gate, not a finite-touch problem.

## Nonduplication and scope
This note treats ordinary native ranges and source splitting. It does not reprove the internal SHORT/LONG normalization, nor the two isolated R2-excess alternate corner prices assigned elsewhere. It proves actual qNear/qFar LONG prices and a whole-G1 SHORT attaining arm uniformly. The competing SHORT arm, last LONG G1 endpoint and LONG p-parent query coverage remain stated explicitly unless supplied by separate exact physical theorems. Chronological finite contacts and literal frame tables are already historically available; actual recognition still requires no undercut on every incoming support.
