# W0 prefix G1: independent full-E shielding audit

## Exact conclusion

For genuine W0 saved3, the existing three-case proof extends from the old restored ALT R2 to EVERY u in E_Z and gives

 H(u)=F_Z(u-v_A-2A)+b_A.u+eta_A+2-F_Z(u)>=0.

For genuine W0 saved1, the earlier signed intrinsic-chain maximum theorem gives H(u)>=1 on EVERY u in E_Z. The stronger H>=1 is FALSE on full E_Z for saved3; it is proved on its near-bottom portion t_Z(u)>=1-D_Z, not throughout E_Z.

These are conditional earlier-field results. The saved1 full-E bound consumes the earlier intrinsic-chain maximum theorem, including its mate-admission/max-principle hypotheses; it is not a consequence of recurrence alone.

## 1. Saved3 full-E proof

Write v=V_A, U=2A, K=M(A,Z), c_A=(T_A+L_A)/2, and q=u-v-U. The exact scalar identity is

 H(u)=P(q)-D(u)-c_A+2,
 P(q)=F_Z(q)-F_Z(q+v)+b_A.q,
 D(u)=F_Z(u)-F_Z(u-U).

Here t(q)=t(u)+K-2 and s(q)=s(u)-2K+2. Since u belongs to E and K>2, q can fail only its lower longitudinal edge or upper transverse edge. No special nonnative upper point for u is needed: u is itself licensed in E by hypothesis. The complete physical D window contains the ENTIRE E transverse interval, hence0<=D(u)<=2 without a native-occupation assumption.

Case1: q in E. Both values F_Z(q),F_Z(u) equal their genuine two-A raw minimum. The exact raw-gap comparison from the previous all-crop proof gives

 H(u)=1-[min(0,psi+1)-min(0,psi)]>=0.

This can be0 or1. No intermediate field outside E is evaluated as a raw minimum.

Case2: q below its longitudinal lower edge. Fold q upwards longitudinally by genuine Z periods, then transversely by V_Z, into E. The full E price span c_A-1<=P<=c_A and characters P(Z)=-1,P(V_Z)=0 imply P(q)>=c_A. Thus H>=2-D(u)>=0.

Case3: q longitudinally inside E but above its upper transverse edge. A V_Z fold gives P(q)>=c_A-1. The failure condition gives t(u)>=D_Z-K+3 at odd roots or t(u)>=L_Z-K+1 at even roots. Together with u in E these inequalities place t(u) in the complete central interval [3-D_Z-K,N_Z+2D_Z-1+K], so D(u)<=1. Hence H>=1-D(u)>=0.

This is a uniform all-proper proof, using only genuine earlier E price/representation, complete physical D intervals and exact deck characters. It is not an extrapolation of the R2 native proof or of finite counts.

## 2. Saved1 full-E lower bound1

ODD_TWO_Q_DONOR_SHIELDING.md proves globally, for W0 saved1 and k=0,

 Psi(u)=c0+1-Phi_minus(R_Z-u),
 R_Z=Z+V_Z+(1,-1),

where c0 and Phi_minus are those of the TRUE old birth parent/sign. In the present effective A=Z-a notation Psi(u) is exactly H(u), with the same +eta_A+2 scalar. Since the genuine polygon satisfies R_Z-E_Z=E_Z and the earlier intrinsic-chain theorem gives max_E Phi_minus<=c0, it follows that H(u)>=1 throughout E_Z. This uses the real birth sign, not an invented proper effective residual parent.

For saved3 the same global table instead gives H(u)=c0-1-Phi_minus(R_Z-u). The stronger near-bottom estimate Phi_minus(R_Z-u)<=c0-2 needs t_Z(u)>=1-D_Z. It does not follow over the entire polygon from the generic maximum bound. The three-case proof in Section1 supplies the correct whole-polygon lower bound0.

## 3. Literal strict saved3 counterexample to H>=1 on full E

Fresh original-port evaluation at actual saved word113 has A=(5,2), R=(17,7), Z=(27,11), W0. Let u=(-10,36); then q=u-v_A-2A=(-17,25), b_A.u=-200, eta_A=17. Its E_Z coordinates are

 t_Z(u)=-1082, s_Z(u)=196, physical parity even.

Here T_Z=1202,L_Z=38 and the true even E rows are t in[-1200,36], s in[0,1224], so u is unambiguously in E_Z. Direct genuine periodic field evaluation gives F_Z(u)=-503 and F_Z(q)=-322, hence H(u)=-322-200+17+2+503=0. It is outside the near-bottom region t>=-26, so this does not contradict the actual donor-shielding theorem.

The saved independent_full_E_H_probe.py retains the literal evaluation. It enumerated the full E lattice set for this example and found428 H=0 sites,571 H=1,235 H=2,33 H=3. These counts only provide a falsifying diagnostic for the overstrong H>=1 statement; the proof of the valid H>=0 is Section1.

## 4. Prefix-use boundary

When the separately proved positive-layer r2 belongs to E_C, these H bounds may be inserted into the exact authentic second-offer algebra. This audit supplies the bound, not a substitute for that actual scalar/source formula or for the first-arm support guard. In particular one must not use saved1's full-E H>=1 bound in the saved3 terminal layer. No complete prefix normalization, UR placement, or recurrence conclusion follows merely from H>=0.
