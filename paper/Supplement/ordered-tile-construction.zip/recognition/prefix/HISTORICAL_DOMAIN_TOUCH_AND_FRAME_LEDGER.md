# Historical actual finite-touch/frame ledger, revisited 2026-11-19

## Verdict
The previously presumed generic missing finite touches and merely nominal LL/UR frame issue were already discharged by later recovered DOMAIN proofs. The current source-value atlas must be matched to their exact frames and record partition, but it need not invent new overlap witnesses. This is not a claim that historical domain work proved any scalar VALUE, binary admission or recurrence.

Read the primary statements and independent receipts listed below, including the 09:58 recovery appendix to INDEPENDENT_ALL_WORD_DOMAIN_REFLECTION_CENTER_AND_SCOPE_AUDIT.md. The decisive final joint theorem is ORIGINAL_CONSUMED_FINITE_DEFINEDNESS_AND_BASIC_DOMAINS_CLOSE_BY_CHRONOLOGICAL_MUTUAL_INDUCTION.md, independently adopted in ROOT_INDEPENDENT_CHRONOLOGICAL_CONSUMED_DEFINEDNESS_AND_BASIC_DOMAIN_AUDIT.md. Both are in recovery_20261101_0745. This pass audits their logical scope; fresh symbolic replays are recorded separately. It is not an independent reimplementation of the historical domain induction.

## Stage-by-stage ledger

| Actual stage | Historical proof | What is really paid |
|---|---|---|
| G1 successive copies and insertion of G2 | STRICT_A5_STANDARD_PREFIXES_HAVE_EXPLICIT_FINITE_TOUCH_ANCHORS; independent strict prefix receipt | Eight type/phase/flip port rows,32 literal layouts; finite earlier standard BASIC/reflected ports. G1 steps ±V_even or ±U_odd. No old source height retention needed. |
| First RIGHT G3 | ALL_STRICT_A5_RIGHT_FIRST_G3_INSERTIONS_HAVE_UNREPLACED_MAIN_PORT_ANCHORS; independent eight-anchor receipt | Exact K2+K3+K4 difference, original source type, creation phase and restored center. Both saved-last choices. Witness MAIN copies survive UNC and corrected constructors. |
| Every subsequent G3 | ALL_CONSUMED_A5_ALTERNATE_CHAINS_HAVE_EXPLICIT_CONSECUTIVE_DOMAIN_OVERLAPS; ROOT_INDEPENDENT_A5_TAIL_OVERLAP_UNREPLACED_MAIN_COPY_AUDIT | Odd ALT untouched slots2/5 differ by V_child; even ALT untouched slots2/1 differ by U_child. Whole support, not height, survives previous minima. All chain lengths; both signs. Literal four-family alternate bases have separate exact native pairs. |
| LEFT internal chronology | A5_ORDERED_DOMAIN_REFLECTION_TRANSFERS_RIGHT_DEFINEDNESS_TO_LEFT | Like-indexed source domains reflect under ONE cross-center, hence each incoming-versus-prior-prefix intersection reflects. No reversal of insertion order, or use of later sites to license an earlier step. |
| Corrected standard outer | ALL_STRICT_CORRECTED_STANDARD_OUTER_INSERTIONS_HAVE_PREFIX_PORT_ANCHORS; independent40-anchor receipt | All8 records×5 insertions. Exact original order; whole G1-first/G1-last/G2 carriers and earlier standard ports. Conditional internal finite-piece premise is supplied by preceding rows. |
| Corrected ALT outer, first packet | STRICT_CORRECTED_ALT_OUTER_DEFINEDNESS_REDUCES_TO_ONE_LEFT_INSERTION; independent36-anchor receipt | All but four odd-ALT principal LEFT insertions. Earlier growing parent is an actual ordinary constructor, not a guessed hull fill. |
| The four remaining ALT insertions | PHASE_ONE_CORRECTED_ODD_ALT_PRINCIPAL_LEFT_ALWAYS_MEETS_THE_OLD_STANDARD_PORT; independent principal-left domain-anchor receipt | BOTH phases, including corrected W0 appendix. W1 saved1 uses G2 BASIC port; saved3 descends authentic earlier first RIGHT protected standard chain. W0 uses earlier active ALT terminal site B−e2 and its correct creation-parent-dependent reflection. First G3 saved1, second G3 saved3; LONG has at least two even at zero suffix. Therefore ALT40/40, not36/40. |

All references above are DOMAIN-only. A nonempty overlap of finite arrays makes its touching extremum finite, regardless of whether primitive prices agree. Subsequent min insertion preserves the union support, including clipped sites.

## Record and run-length scope
Strict core means the actual earlier CREATION parents are proper, not simply that today's selected pair is proper. Saved-last1 flips creation phase, whereas saved-last3 (odd L) and saved-last2 (even L) do not. The formal inner/outer identities retain arbitrary suffix length; the shortest prefix and LONG zero-suffix two-G3 case are included in the corresponding primary proofs. The current k>=1 atlas may use historical h=k−1, so zero historical suffix cannot be discarded.

Proper selected pairs with endpoint predecessor are handled by separate firstmixed literal branches, not specialization of strict MAIN formulas. The final mutual induction explicitly exhausts strict cores, proper firstmixed records, pure2/pure3 and actual root selectors. Pure3 G2 shifts and pure2 LEFT G2 shift remain source-only corrections, never shifts of the subsequent G3 running origin. Unused malformed initializer auxiliaries are excluded by the actual consumed-state grammar.

## Actual LL/UR restoration, not just nominal algebra
The domain-reflection receipt's old missing-AG warning was superseded by its09:58 recovery appendix. It recovered ANCHOR-GEOMETRY-ANALYSIS.md and read the universal lexicographic minima proof, with all eight inverse-record phase rows and actual A4 shifts, then checked the six A5 minima rows and SHORT/LONG alignment tables. The lower-left is lexicographic min(y,x), upper-right is max(y,x); reflection reverses this order. Earlier ALT creation-parent displacement is essential.

Literal unpad is a common rectangular coordinate crop, not individual geometric LL centering. Literal center_mats aligns every selected old array to one shared geometric anchor before the next transition. Actual A6 reads the real upper-right extrema and translates the appropriate paired helper. The erased-union reflection argument shows the resulting common cross-center is the target center without needing a current height reflection or a fitted scalar. The recovered AG/CP minima proof further identifies the effective raw helper shifts used by raw_piece_ops. Its112 symbolic shift identities complement114 source-center identities.

Therefore there are two distinct conclusions: domain reflection needs the paired extrema cancellation; matching a new explicit value atlas to literal nominal positions additionally uses the now recovered actual A4/A6 minima/effective-shift table. Neither is merely a bounded numerical observation. A contemporary formula that disagrees with the literal table still needs correction: historical closure does not validate an incorrectly copied phase sign.

## Why earlier support assumptions are no longer open domain gates
At a transition OLD corrections feed the four current outputs; only after storing current quadruples and updating the saved ancestor are NEXT corrections built. All head MAIN witnesses are therefore earlier in constructor time. Standard BASIC/mandatory domains and ALT active BASIC domains propagate through the same exact source union, independently of source values. The final joint theorem simultaneously closes finite consumed arrays, source-union supports, ports, active traces and actual frames/reflections, using literal initialization. No quotient cover, height reflection or recurrence feeds this domain proof.

## Tight remaining recognition gates given a complete raw value atlas
1. Match each claimed polygon/carrier and affine gauge to the actual source occurrence, using the correct saved record, effective A4/A6 shifts and real native-support inclusion. H/R2 upper support is not automatically membership in any new polygon E.
2. Prove source/candidate equality (or a valid first-ownership inequality) on EVERY actual incoming support, not only the displayed overlap or a nominal hull. A full raw atlas plus the exact source mask inclusion pays this.
3. Fix the candidate's absolute gauge at the first owner and the helper's actual max-zero normalization. Finite touches prove only finite scalar, not its expected value. If every incoming source equals the same candidate plus its specified constant on its WHOLE support, historical nonempty overlaps make all relative touching constants automatic, by induction in the actual order. First-ownership versions need their own weaker inequalities.
4. Keep physical binary admission/recurrence and global deck recognition separate from finite value recognition.

There is no additional all-proper finite-overlap or LL/UR domain-geometry obligation after applying the final historical joint theorem in its actual consumed-record scope. In particular neither ALT36/40 nor the old missing-AG warning should remain on the current list of unresolved gates.
