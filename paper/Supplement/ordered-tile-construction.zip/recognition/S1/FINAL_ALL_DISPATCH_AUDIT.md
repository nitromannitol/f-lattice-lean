# Final independent logic audit: all proper corrected G3 nominal price atlas

## Verdict

PASS as a conditional all-proper pointwise RAW-COMPARATOR/G3 price atlas, up to one scalar per placed source, for all eight record/phase rows and both SHORT/LONG siblings. The scalar is common to BOTH physical parities and all components of that placed source. No source-connectedness assumption is necessary.

The stronger identification with genuine current standard heights or the current analytic alternate must retain the appropriate current E-polygon or physical D guard below. An unconditional claim of genuine target equality at EVERY nominal placed source point, without those guards, is not established by this atlas. Actual calibrated earlier primitive values, source restoration and affine jets remain inherited premises. No whole-array realization or recurrence is claimed.

## Eight rows actually covered

| Earlier primitive / helper | Saved record | Current phase | Siblings covered |
|---|---|---|---|
| even ALT / odd helper | 1 | 0 | corrected even-standard SHORT, odd-alternate LONG |
| even ALT / odd helper | 1 | 1 | same |
| even ALT / odd helper | 3 | 0 | same |
| even ALT / odd helper | 3 | 1 | same |
| odd ALT / even helper | 1 | 0 | corrected odd-standard SHORT, even-alternate LONG |
| odd ALT / even helper | 1 | 1 | same |
| odd ALT / even helper | 2 | 0 | same |
| odd ALT / even helper | 2 | 1 | same |

The last four are the arithmetic duals of the first four; saved3 maps to saved2, saved1 to saved1. The primitive uses its OWN birth phase and tau/beta, not the current target's. Earlier reports retaining the old smaller cone or saying these dual gauges are still pending are superseded only to the extent proved by ALL_PROPER_CONE, WHOLE_R2_UPGRADE, ANALYTIC_ALT_CONJUGACY and the later exact slope/global-raw identities.

## 1. Direct even-primitive rows

The signed stationary proof and saved1 birth-price substitution establish every endpoint and interior head on the entire actual creation-R2 lattice set. Their separate lower-cap and attainment arguments are both required. The widened proper cone n_a>=1,d_a-n_a>=1,r>=1,e-r>=2 was independently rechecked, including N_Z=3,c_Z=4 boundaries; no fictitious proper effective creator is introduced in saved1.

At native sites the earlier authenticated ALT midpoint identity identifies its actual field with J plus one old scalar. At R2 holes J is explicitly an analytic continuation. Nominal helper/outer slopes give the stated current affine head jet; their unproved absolute calibration is not inferred from the matching locations.

## 2. Dual guard is one-way and sufficient

The exact inverse target ODD primitive R2 is contained in the old EVEN primitive R2. A fresh replay of dual_r2_algebra gives zero endpoint differences in lower/upper sectors and the balanced even-parity case. In the remaining balanced parity the two longitudinal trims are3N-D+2 or3N-D-2. Since D,N are odd and balanced2N<D<3N, 3N-D is positive even and at least2; both trims are nonnegative.

Thus every target primitive R2 point has an old point where the direct analytic price theorem applies. Native-to-native support equality is neither needed nor asserted. The false reverse inclusion is not used. The widened proper cone is preserved under this inverse arithmetic dual: an even target birth parent gives an odd inverse parent with n>=1,d-n>=1, and an odd target birth parent gives an even inverse parent with r>=1,e-r>=2.

## 3. Analytic ALT gauges and global raw comparator identities

The canonical even midpoint reflection/secondary jet is derived from genuine standard reflection and deck characters globally, with the ceiling contribution -1 retained. The odd analytic definitions then give the exact beta values: even-to-odd beta is W_birth*a, whereas odd-to-even target beta is(1-W_current)*C. These are coordinate vectors, not affine character vectors. ANALYTIC_ALT_CONJUGACY's two rotations have a PLUS sign in front of the old field, with the additional harmonic/affine terms explicitly accounted for. Fresh replay passes its10 algebraic identities; the global reflection/ceiling steps are independently sound.

For SHORT, use the historical global RAW identity M_o(w)=M_e(Jw+U_child)+h0(w). This is not an extrapolation of current native field equality. The56-source exact slope/scalar replay includes the actual G3 occurrences and both phases/records.

For LONG, RAW_LONG_COMPARATOR_DUAL proves the whole-plane two-offer identity, including branch reversal in W0 and relative offset+1 in both phases. Its fresh symbolic replay passes. It uses genuine standard conjugacy/characters/reflection, NOT a current alternate native identity. The target/primitive beta values now supplied by the analytic conjugacy make all16 independently replayed LONG endpoint slope identities exact. Slopes and origins progress affinely along each genuine chain, hence the endpoint identities cover every head, including the proper LONG head count rather than a reused SHORT count.

## 4. One scalar, not separate parity-sheet constants

The new independent parity_audit.py reconstructs all56 transformed SHORT-source origins, including true G3s, and checks all16 LONG G3 endpoint origins. For BOTH possible opposite-parity coordinate choices of the odd birth parent and both-odd coordinates of the even birth parent, every transformed origin v* is integral and has even coordinate sum. This is a symbolic polynomial parity check for arbitrary integer parameters/run length, not sampled parity tests. Chain increments preserve even parity as well.

Write h0(x)=H(x)-par(x)/4, B_H=[[1,1],[1,-1]]/2. Since v* has even sum, par(w)=par(w-v*) and exactly

 h0(w)-h0(w-v*)=(B_H v*).w-(v*.B_H v*)/2-v*_2/2.

Hence the harmonic translation is ONE affine polynomial on the entire lattice, not merely separately on even/odd sites. After the exact slope cancellation, the remaining difference is one constant per placed source, independent of w, its parity, and connected components of its domain. The old primitive and target analytic normalization constants and the birth translation contribute only to this single constant.

The reverse analytic harmonic conversion also preserves a common constant. There f=Rot(v)+b with b odd, so par(f)+par(v)=1. The indispensable +1/4 correction is a constant, not a parity-dependent error. REVERSE_PARITY_CONSTANT.json independently verifies the full formula including that correction. Thus no undetected two-parity scalar mismatch remains.

## 5. Exactly where target identification needs a guard

- A SHORT raw comparator equals the current genuine standard F only on its independently licensed E polygon (including actual native points already proved to lie there). The global RAW dual identity does not make that equality global.
- In dual LONG, the exact global transformed comparator is a minimum min(F_S(f),F_S(f+epsilon*2p*)+1). To identify it with the canonical rounded midpoint A_S(f), one needs D_S(f)=F_S(f)-F_S(f+epsilon*2p*) in{0,1,2}. The genuine full physical D interval or a separately authenticated current native band supplies this when applicable. It must be checked at the CURRENT target point, not confused with the earlier primitive's R2 guard.
- Earlier primitive R2 inclusion, by itself, does NOT prove that current target D guard or current E membership. Thus a statement about every nominal point may freely name the raw comparator, but may name the genuine current standard/analytic ALT only with its corresponding guard. Actual literal target arrays additionally require actual occupancy; no analytic continuation fills holes or resurrects cropped/padded vertices.

## 6. Dependency and calibration limits

The price derivations consume genuine earlier standard fields, physical strips/E price spans, their global arithmetic conjugacy, and genuine prior primitive analytic/native calibration. The current stationary comparator is built from already available standard fields; no current ALT recurrence or current clipped-helper recurrence is used. LONG's current standard D guard must be supplied from the independent standard stage, not deduced from the alternate recognition it is used to prove.

This is well-founded as a conditional constructor component: earlier primitive/current-parent standards first, then the nominal G3 comparison, then any independently justified source assembly. It is NOT a closed arbitrary-history induction until all listed earlier producers and the other current sources have been authenticated. In particular this audit does not infer a full protected prefix, whole helper coherence, an upper-right placement, fixed native support/padding, nonempty overlap, touching maximum, or the actual outer gauge from G3 agreement alone.

On a genuinely coherent prefix and a genuine nonempty overlap, a single scalar may subsequently be calibrated by an actual overlap value; that is a separate argument. Scalars of different placed sources are not asserted equal here. The atlas therefore answers the nominal pointwise question across all eight rows without asserting full recurrence or a calibrated literal all-word output theorem.

## Fresh evidence

`final_dispatch_receipts/` contains copied/replayed analytic ALT, global raw LONG, inverse R2, LONG slope and56 SHORT-source checks, all successful; the new72-origin parity/cocycle audit; and the reverse harmonic parity-constant identity. Source scripts were not modified in place. This is an independent logic/parity audit plus exact replays, not a fresh reimplementation of the historical source-list generator or of earlier field realization.
