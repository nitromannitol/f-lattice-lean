# Global raw odd-LONG comparator duality

## Verdict
The proposed identity is correct for BOTH phases, pointwise on the whole physical lattice, assuming the genuine standard conjugacy, primary/secondary deck laws and delta reflection. Its relative offset is exactly+1. No old alternate native/R2 membership and no current alternate identity is used.

## Definitions and exact common gauges
Write C=(d,n) odd, Z=(e,r) even, O=C+Z, epsilon=2W-1, det(C,Z)=-epsilon. Let S=dual(O), p*=dual(Z),q*=dual(C), so S=2p*+q*. Set clockwise Rot(x,y)=(y,-x), J(x,y)=(-y,x-1), delta=(1,-1), h0(x,y)=(x²+2xy-y²-2y-par(x+y))/4. Assume F_O(x)=F_S(Jx)+h0(x), F_S(delta-v)=F_S(v), and genuine zero primary S character.

Put x=z+WZ, tau_odd=-q* forW0 and -V_(p*) forW1, and
 f=Rot(z-2O)+e1+tau_odd.

Then EXACTLY

 min(F_O(x),F_O(x+V_Z)-b_Z·x+c_Z-epsilon)
 = G_W(z)+min(F_S(f),F_S(f+epsilon*2p*)+1),

where, using positive c_X=(T_X+L_X)/2 and eta_X=(T_X-L_X)/2,

 G_0(z)=h0(z+V_Z)-b_Z·z+c_Z+1-b_S·f-eta_S,
 G_1(z)=h0(z+Z)-b_S·f-eta_S.

These gauges include every additive constant in the stated standard normalization. Each is h0(z) plus an affine polynomial because Z,V_Z preserve parity. If a standard conjugacy is specified only up to a global constant, the same constant must be added to G; it does not alter the relative+1.

## W0 derivation
Let u=Jz. Direct vector algebra gives u+f=V_S+delta-q*. Hence
 u+(f-2p*)=V_S+delta-S=R_S-2S,
 (u-2p*)+f=R_S-2S,
 where R_S=S+V_S+delta.

Standard primary periodicity and native/global reflection F_S(R_S-v)=F_S(v)-b_S·v-eta_S therefore convert F_S(u) to F_S(f-2p*)-b_S·(f-2p*)-eta_S and F_S(u-2p*) to F_S(f)-b_S·f-eta_S. Also J(z+V_Z)=u-2p*. The second odd price consequently has gauge G0; the first has gauge G0+1. The determinant condition gives this last relative1 exactly. The order of the minimum's two branches is reversed in W0, which is essential.

## W1 derivation
Let u=delta-Jx. Direct vector algebra gives f=u+V_S. Delta reflection turns F_S(Jx) into F_S(u). The negative secondary law gives
 F_S(f-V_S)=F_S(f)-b_S·f-eta_S.

For the second branch, delta-J(x+V_Z)=u+2p*, so the same law yields F_S(f+2p*)-b_S·(f+2p*)-eta_S. After adding h0(x+V_Z)-b_Z·x+c_Z-1, its gauge is G1+1. The first branch has gauge G1. No native sheet formula is extended off-domain; these are genuine global standard identities.

## Exact arithmetic and parity
raw_long_dual_algebra.py independently reduces both vector identities and both relative-offset identities modulo d*r-n*e+epsilon=0. Every remainder is0; expanded common gauges are in RAW_LONG_DUAL_ALGEBRA.json. The symbolic parity variable is the SAME in h0(x),h0(x+V_Z),h0(z), since Z has even coordinate sum and V_Z has sum2r. Thus no dropped floor/parity constant is hidden in the polynomial calculation.

## How this removes the former guard, and what it does not remove
If the relevant physical f belongs to the genuine current even S crop on which its authentic short-slip difference D=F_S(f)-F_S(f+epsilon*2p*) lies in{0,1,2}, the even raw minimum equals ceil((F_S(f)+F_S(f+epsilon*2p*))/2). Hence the odd raw comparator is this analytic rounded expression plus G_W. One does NOT need the inverse current-even point to belong to some earlier odd alternate R2: no alternate value was used to derive the identity.

The genuine current-even native D band is still a required guard for this rounding step. The raw min identity itself is global even outside that band. To recognize an ACTUAL corrected G3 source one must additionally compare its authentic source-plus-outer affine jet with G_W and its old midpoint; literal restoration, source tau, and calibrated scalar are not supplied by this global identity. Nor does it claim new alternate binary admission or recurrence by rounding alone.
