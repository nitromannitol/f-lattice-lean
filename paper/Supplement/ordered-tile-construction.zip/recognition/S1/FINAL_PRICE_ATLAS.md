# A single price calculation for every proper corrected G3 head

**Theorem (analytic constructor step, not the full recurrence theorem).** Fix any proper Farey birth pair: the odd-type parent a=(d,n) has n≥1,d−n≥1, and the even-type R=(e,r) has r≥1,e−r≥2, with the actual signed determinant. Allow every stationary length k≥1, both word phases, and every genuine corrected record in the table below. Assume the normalized earlier canonical standard fields with their genuine periods, quarter-turn conjugacy, E-polygon two-source representations, P-price spans, harmonic/zero strips and complete physical slip intervals. Assume the authentic creation-R2 geometric formulas and the indicated physical source list/upper-right alignment for the nominal coordinate frame.

At every corrected G3 placement the new analytic target comparator, on the whole corresponding *earlier* creation-R2 lattice envelope, is the analytic earlier alternate restriction plus an affine function with the actual code slope. In the original odd-helper orientation the affine function is explicitly b_C·y+eta_C+1−W in the stated lower-left/restored frames. In the dual orientation the affine function is given by harmonic conjugacy; it has one scalar per occurrence, constant across both parities, in any fixed normalized chart convention. No separate verification of each head interior, of an unbounded end sequence, or of a new burning policy on a G3 crop is needed. On an unoccupied R2 point this is an analytic identity ONLY. Native evaluation uses the genuine earlier native values and placement and the new target's licensed polygon/physical slip band, not a filling of an array.

| helper | saved digit | current phase | current siblings | result |
|---|---|---|---|---|
| odd-L, earlier even alternate | 1 or 3 | W0 or W1 | even standard SHORT; odd alternate LONG | explicit two-offer prices on full earlier even R2, all indices |
| even-L, earlier odd alternate | 1 or 2 | W0 or W1 | odd standard SHORT; even alternate LONG | same price transported to full earlier odd R2, all indices, matching physical code gradient |

There are eight record/phase/helper classes, each with the two listed siblings. Endpoint carrier templates 0/1 and 1/1 are not proper birth parents. No claim that the full literal arrays, their outer scalar maxima or arbitrary fixed padding have been identified is made here.

## 1. The two prices

In the first orientation Z=2a+R. Set A=a in saved3 and A=Z−a in saved1; in the latter the true birth phase is the opposite of the current W. Set C=A+kZ, Q=2C+Z and O=C+Z. At a genuine restored-earlier coordinate z define
 D(z)=F_Z(z)−F_Z(z+2(2W−1)A),   J(z)=ceil((F_Z(z)+F_Z(z+2(2W−1)A))/2).
The shift is allowed modulo the true Z period, which is why the same formula uses the correct mate in saved1. On *all* earlier R2 lattice points D=0,1 or2 by its complete physical transverse window. The exact old alternate reflection z↦z' exchanges D with 2−D and preserves R2, even where the literal crop has holes.

After subtracting the uniform G3 jet and F_Z(z), the two new ordinary offers are
       e(z),   1−D(z)+e'(z').
The desired value is min(0,1−D(z)). The errors are genuine stationary odd-field prices of F_C (SHORT) or F_O (LONG). In the interior both vanish. At the two ends, both are bounded below by the required minimum and one attains it. It is essential to prove attainment: individual equality fails at true sites.

W0 stationary queries are z+lZ. Their indices in C are (i−1,2k−i) and in O are (i,2k+2−i). W1 queries are z+2A+lZ, with indices (i,2k−1−i) and (i+1,2k−1−i), respectively. The only problematic polygon representative can be folded by its true primary. Its reflected endpoint is paid by a two-level price span or the h0 strip. In saved3 the key price comparison across the transverse seam is the four-value identity
 P(x)−P(x−2A)=D(x)−D(x+V_A)  (W0),
and its W1 counterpart with backward V_A. At that seam one wraps the **physical slip**, using its known deck increment 2, instead of evaluating an unperiodized old minimum off its polygon. This is what pays the genuine endcap that a separate range bound cannot settle.

In saved1 use V_A=V_Z−V_a, b_A=b_Z−b_a, and genuine deck identities to rewrite every effective price in the old a-price. The OLD R2 in this argument is the actual opposite-birth R2: Z−2A=−R, so a fictitious proper earlier parent may not be substituted. Its only extra rim is paid by the h0 strip. UNIVERSAL_ODD_HELPER_G3_PRICE.md and the signed proofs supply the complete cap proofs, geometry, indices and affine constants. ALL_PROPER_CONE.md and the widened receipts extend each relevant strict-cone inequality to every proper birth; they include 320 vertex checks and audits of the harmonic boundary exceptions. The algebraic comparison on full R2 uses no literal claim at an absent vertex.

## 2. Opposite orientation: transfer the price, not the native array

Write I=(1,−1), Rot(x,y)=(y,−x), J0(x,y)=(−y,x−1), h0(x,y)=(x²+2xy−y²−2y−par(x+y))/4, and B_H=[[1,1],[1,−1]]/2. The dual of an old odd fraction (d,n) is (d+n,d−n), that of an old even fraction is half this vector. Duality preserves W, exchanges saved2/3 and fixes1. An old object S maps by f_S(z)=Rot(z−U_S)+e1+tau_S, where tau=0 for standard targets and an alternate uses its OWN birth parameters, not its consumer's.

1. **Domain guard.** For an old even alternate primitive, the inverse image of the target odd R2 under f_S is inside its genuine old even R2. In lower/upper exchanged sectors there is equality. In the balanced sector it either agrees or trims both longitudinal endpoints by 3N−D+2 (W0) or 3N−D−2 (W1), never a negative trim for a strict proper Z. Reverse containment is false in general; e.g. the old 7/17 R2 point (−15,16) maps outside the odd 5/12 R2. The physical old point need not be literally native; section1 applies on ALL its R2, the reason this one-way inclusion is sufficient. DUAL_TRANSFER_SCOPE.md includes the exact row calculation.
2. **Primitive value, not just its character.** The old even analytic midpoint obeys H_S(H'_S−z−V_S)=H_S(z) by swapping its two standard summands and removing a primary period. Its true secondary jet is b_S·z−c_S−1. In the stated f_S frame, the genuine definition of the odd analytic mate therefore gives
     H_(S*)(f_S(z))=H_S(z)+h0(f_S(z))+beta_S·f_S(z)+constant,
     beta_S=W_birth a.
   Here a is the birth-parent COORDINATE vector. For an old odd alternate target O going to an even target, the corresponding beta_O=(1−W)C in terms of its actual selected odd parent. ANALYTIC_ALT_CONJUGACY derives both sides globally from the analytic definitions, including the parity constant. There is no unsupported assertion that a rotated finite crop is an actual array on its missing points.
3. **Standard target.** The ordinary preperiodization identity is M_odd(w)=M_even(J0(w)+U_even)+h0(w) throughout the plane, by standard conjugacy and the true two parent offers. For w=f_even(y) the query is exactly y. It carries the already proved old even-standard SHORT price to the target odd-standard SHORT price, without assuming present native recurrence. On a genuinely native target use its E-polygon licensing.
4. **Alternate target.** Let S=dual(O), p*=dual(Z), q*=dual(C); put x=y+WZ, f=f_O(y), eps=2W−1. The following raw identity is global:
   min(F_O(x),F_O(x+V_Z)−b_Z·x+c_Z−eps)
       = G_W(y)+min(F_S(f),F_S(f+eps·2p*)+1).
   Explicitly G0=h0(y+V_Z)−b_Z·y+c_Z+1−b_S·f−eta_S and G1=h0(y+Z)−b_S·f−eta_S. In W0 the order of the offers swaps. RAW_LONG_COMPARATOR_DUAL proves the exact relative +1. This step needs no inverse OLD CURRENT odd-native membership. Where the true current even field is wanted, its own complete physical D band licenses its midpoint, not a speculative halo.
5. **The code's actual slopes.** For an old placement v with slope ell, let
   v*=Rot(v−U_target+U_source)+tau_target−tau_source.
   Substitution of the two harmonic identities gives
   ell*=B_H v*+Rot(ell)+beta_target−beta_source
   (beta_target=0 for a standard target). The difference of the h0 parity terms is constant because v* has even coordinate sum. All omitted terms are thus a SINGLE additive scalar for that occurrence across all its points, NOT one constant on each parity or component. The true nominal source-list match includes both endpoints of each actual SHORT and LONG with its own saved phase, flip, target shift and primitive shift. A fresh historical replay checked 56 SHORT source-gradient identities (including all corrected head endpoints); the companion direct check proves all 16 LONG G3 endpoint gradients. Affine dependence on the index covers the whole chain. The 112/168 nominal coordinate matches alone would not have paid the slope. No assertion of reorder invariance of a clipped native assembly is used.

## 3. What remains for the original problem

For every proper corrected record the **analytic complete G3-to-target price** and matching slope are now available. Once an inherited prefix is known to equal the target on its actual sites and a true new head overlap is nonempty, the chart identity fixes the touching constant by the max operation: all differences on that overlap are equal. The same observation works recursively for a finite tree of actual restrictions if every primitive occurrence is the target up to a constant, in its actual coordinate frame, and every required join is nonempty.

Still needed are the corresponding ordinary and protected standard-prefix source comparisons where not supplied by earlier donor lemmas, actual support/anchor and upper-right normalization facts for each restored helper when instantiating a literal code path, genuine earlier native realization/initializers, any actual clipping exceptions and all consequential source maxima not already implied by those inputs. Endpoint templates and fixed finite padding remain separate. The current recurrence theorem cannot be inferred from a chart price in isolation.

**Proof status.** This is a conditional, parameter-uniform source lemma. Independent symbolic replays and separate semantic audits are bundled; they are not a formal proof assistant verification or an end-to-end Julia run of all words. Finite true examples checked clipping/phase and disprove stronger individual-source equality, but play no role in the unbounded proof.

A fresh parity replay of the 56 SHORT and 16 LONG checked origins confirms all 72 are even-sum in both possible odd-parent parity assignments. No physical-parity-dependent scalar was discarded. The word “target” on a virtual R2 head in this theorem always means the stated raw comparator; outside its own guard no equality with a globally sewn present child is asserted.
