import sympy as s,json
from pathlib import Path
p=Path(__file__).resolve().parent
x,y,d,n,e,r=s.symbols('x y d n e r');z=s.Matrix([x,y]);C=s.Matrix([d,n]);Z=s.Matrix([e,r]);O=C+Z
Rot=lambda v:s.Matrix([v[1],-v[0]]);Ji=lambda v:s.Matrix([-v[1],v[0]]);J=lambda v:Ji(v)-s.Matrix([0,1]);V=lambda v:s.Matrix([v[1]-v[0],sum(v)]);dual=lambda v,odd:s.Matrix([sum(v),v[0]-v[1]])/(1 if odd else 2)
a=lambda v:s.Matrix([v[1],-v[0]]);BH=s.Matrix([[1,1],[1,-1]])/2;e1=s.Matrix([1,0]);delta=s.Matrix([1,-1]);zero=s.zeros(2,1);rows={}
def ck(name,q):
 q=s.simplify(q);assert q==zero or q==0,(name,q);rows[name]=True
# Even old Z0=2C+Z to odd.
Z0=2*C+Z;ps=dual(Z,False);qs=dual(C,True)
for W in[0,1]:
 tau=zero if W==0 else V(ps)-qs;f=Rot(z-Z0)+e1+tau
 if W==0:ck('even_W0_query',J(f)-(z-Z0))
 else:
  ck('even_W1_query',J(f+qs)-(z-Z0-Z))
  Hp=2*Z0-2*C+V(Z0)+delta
  ck('even_W1_reflection',delta-J(f+qs)-(Hp-z-V(Z0)))
 ck('even_beta_'+str(W),BH*(W*qs)-W*C)
# Reverse odd old O=C+Z to even.
S=dual(O,True);ps=dual(Z,False);qs=dual(C,True)
for W in[0,1]:
 tau=-qs if W==0 else -V(ps);f=Rot(z-2*O)+e1+tau;v=z+W*Z;dd=s.simplify(f-Rot(v))
 if W==0:
  Hp=2*ps+V(S)+delta;ck('odd_W0_query',J(z)+f-(Hp-S))
 else:ck('odd_W1_query',f-(delta-J(z+Z)+V(S)))
 ck('odd_beta_'+str(W),a(S)-BH*dd+s.Matrix([s.Rational(1,2),s.Rational(1,2)])-(1-W)*C)
H=lambda v:(v[0]**2+2*v[0]*v[1]-v[1]**2-2*v[1])/4
bx,by=s.symbols('bx by');dd=s.Matrix([bx,by]);f=z;v=Ji(f-dd);q=s.expand(-H(v)-H(f));slope=-BH*dd+s.Matrix([s.Rational(1,2),s.Rational(1,2)])
ck('quadratic_slope',s.Matrix([s.diff(q,x),s.diff(q,y)])-slope)
const=s.simplify(q-slope.dot(f));rows['quadratic_constant']=str(const)
(p/'ANALYTIC_ALT_IDENTITIES.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS',len(rows)-1,'identities; constant',const)
