import sympy as s,json,sys
from pathlib import Path
sys.path.insert(0,'recovery_20261101_0745')
p=Path(__file__).resolve().parents[1];rows=[]
a,b,c,d,k=s.symbols('a b c d k');m,n,h,j,kk=s.symbols('m n h j kk',integer=True)
def check(vv,syms,tag):
 aa,bb,cc,dd,k0=syms
 for ep in [0,1]:
  sub={aa:2*m+ep,bb:2*n+1-ep,cc:2*h+1,dd:2*j+1,k0:kk}
  v=[s.expand(x.subs(sub))for x in vv]
  for x in v:assert all(q.q==1 for q in s.Poly(x,m,n,h,j,kk).coeffs()),(tag,v)
  q=s.Poly(s.expand(sum(v)),m,n,h,j,kk)
  assert all(x.q==1 and int(x)%2==0 for x in q.coeffs()),(tag,v,q)
 rows.append(tag)
# SHORT independently recover every transformed origin, including actual G3s.
ns={};src=(p/'dual_replay/check_corrected_even_to_odd_full_coherence_value_rotation.py').read_text();exec(src[:src.index('rows=[]')],ns)
A,B=ns['A'],ns['B'];dual,rot,V,ops=map(ns.get,['dual','rot','V','ops']);zero=s.zeros(2,1)
for W in [0,1]:
 for last in [1,3]:
  ep=1-W if last==1 else W;old,oo=ops(A,B,W,last,False);As,Bs=dual(B,False),dual(A,True);tau=zero if ep==0 else V(As)-Bs
  for alt,isp,src,v,jet,lab in oo:
   vv=rot(v-old+(2 if isp else 1)*src)-(tau if alt else zero)
   check(vv,[ns[x]for x in ['d','n','e','r','k']],['SHORT',W,last,lab,bool(alt)])
# LONG exact origin expressions from independently checked source-list identities.
for rec in json.loads((p/'DUAL_LONG_SLOPE_IDENTITIES.json').read_text()):
 for row in rec['rows']:
  check([s.sympify(x)for x in row['origin']],[a,b,c,d,k],['LONG',rec['W'],rec['last'],row['source'],True])
# Exact parity cocycle when placed shift has even sum.
x,y,vx,vy=s.symbols('x y vx vy');BH=s.Matrix([[1,1],[1,-1]])/2
H=lambda x,y:(x*x+2*x*y-y*y-2*y)/4
want=(BH*s.Matrix([vx,vy])).dot(s.Matrix([x,y]))-(s.Matrix([vx,vy]).dot(BH*s.Matrix([vx,vy])))/2-vy/2
assert s.expand(H(x,y)-H(x-vx,y-vy)-want)==0
out={'status':'PASS','origins':len(rows),'short':sum(r[0]=='SHORT'for r in rows),'long':sum(r[0]=='LONG'for r in rows),'rows':rows,'parity_substitutions':'A coordinates opposite parity, B both odd; BOTH A parity choices checked','harmonic_cocycle':'one exact affine expression for both physical parities because vstar sum even'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print('PASS',len(rows),'even-sum origins and exact harmonic cocycle')
