import sympy as s,json
from pathlib import Path
D=Path(__file__).resolve().parent
d,n,e,r,z0,z1,pa=s.symbols('d n e r z0 z1 pa');C=s.Matrix([d,n]);Z=s.Matrix([e,r]);O=C+Z;S=s.Matrix([sum(O),O[0]-O[1]]);p=s.Matrix([e+r,e-r])/2;q=s.Matrix([d+n,d-n]);z=s.Matrix([z0,z1]);delta=s.Matrix([1,-1]);rot=lambda v:s.Matrix([v[1],-v[0]]);J=lambda v:s.Matrix([-v[1],v[0]-1]);b=lambda v:s.Matrix([v[1],-v[0]]);V=lambda v:s.Matrix([v[1]-v[0],sum(v)]);T=lambda v:-b(v).dot(V(v));eta=lambda v:(T(v)-sum(v))/2;c=lambda v:(T(v)+sum(v))/2;H=lambda v:(v[0]**2+2*v[0]*v[1]-v[1]**2-2*v[1]-pa)/4
out={}
for W in [0,1]:
 eps=2*W-1;G=s.groebner([d*r-n*e+eps],d,n,e,r,z0,z1,pa,domain=s.QQ);tau=-q if W==0 else-V(p);f=rot(z-2*O)+s.Matrix([1,0])+tau;x=z+W*Z;u=J(z)if W==0 else delta-J(x)
 def eq(name,v):
  vv=list(v)if isinstance(v,s.MatrixBase)else[v];res=[s.factor(G.reduce(s.expand(a))[1])for a in vv];assert all(a==0 for a in res),(name,res);out[str(W)+'_'+name]=[str(a)for a in res]
 if W==0:
  eq('position',u+f-(V(S)+delta-q))
  g0=H(z+V(Z))-b(Z).dot(z)+c(Z)+1-b(S).dot(f)-eta(S)
  g1=H(z)-b(S).dot(f-2*p)-eta(S)
  eq('relative_one',g1-g0-1)
 else:
  eq('position',f-u-V(S))
  g0=H(x)-b(S).dot(f)-eta(S)
  g1=H(x+V(Z))-b(Z).dot(x)+c(Z)-1-b(S).dot(f+2*p)-eta(S)
  eq('relative_one',g1-g0-1)
 out[str(W)+'_common_gauge']=str(s.factor(G.reduce(s.expand(g0))[1]))
print(json.dumps(out,indent=2));(D/'RAW_LONG_DUAL_ALGEBRA.json').write_text(json.dumps(out,indent=2))
