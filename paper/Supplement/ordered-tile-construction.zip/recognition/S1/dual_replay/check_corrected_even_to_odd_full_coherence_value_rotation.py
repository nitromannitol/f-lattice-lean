"""Exact source gradients, full scalar covariance and absolute anchor. No arrays."""
import sympy as s,json
from pathlib import Path
import reconstruct_direct_auxiliary_enclosure as E
E.add=lambda *vs:tuple(sum(v[j]for v in vs)for j in(0,1));E.ZV=(0,0)
d,n,e,r,k=s.symbols('d n e r k');E.KLEN=k
A=s.Matrix([d,n]);B=s.Matrix([e,r]);rot=lambda v:s.Matrix([v[1],-v[0]]);V=lambda v:s.Matrix([v[1]-v[0],sum(v)]);a=lambda v:s.Matrix([v[1],-v[0]]);dual=lambda v,o:s.Matrix([sum(v),v[0]-v[1]])/(1 if o else 2);BH=s.Matrix([[1,1],[1,-1]])/2;zero=s.zeros(2,1)
def selected(A,B,last):return(A+B,2*A+B)if last==1 else((A+B,B)if last==2 else(A,2*A+B))
def stdjets(p,q,odd):
 ap,aq=a(p),a(q)
 return[zero,zero,ap,ap,zero,aq]if odd else[zero,2*ap,zero,ap,aq,aq+ap]
def rawjets(p,q,last,opiece,flip):
 ap,aq=a(p),a(q);N=2*k+1
 if opiece:
  return[ap+k*aq,ap,zero,zero,zero]if flip else[zero,k*aq,(k+1)*aq,ap+k*aq,ap+k*aq]
 base=aq-ap if last==2 else zero
 return[(2*k+1)*ap+aq,(2*k+1)*ap+aq,(2*k+2)*ap,(2*k+1)*ap+base,ap+base]if flip else[zero,zero,zero,ap+base,N*ap+base]
def ops(A,B,W,last,odd):
 p,q=selected(A,B,last);opiece=not odd;cp,cq=(p+(k+1)*q,q)if opiece else(p,q+2*(k+1)*p)
 lay=E.std_layout(cp,cq,W,odd);jets=stdjets(cp,cq,odd);repl=({0:False,3:True}if W else{1:False,2:True})if odd else{3:True,4:False};out=[]
 for i,(isp,off)in enumerate(lay):
  if i not in repl:out.append((False,isp,cp if isp else cq,s.Matrix(off),jets[i],f'main{i}'))
  else:
   for j,((alt,isp,src,v),jet)in enumerate(zip(E.raw_piece_ops(p,q,W,last,opiece,0,repl[i]),rawjets(p,q,last,opiece,repl[i]))):
    out.append((alt,isp,s.Matrix(src),s.Matrix(off)+s.Matrix(v),jets[i]+jet,f'long{i}/{j}'))
 return(cp+cq if odd else 2*cp+cq),out
rows=[]
for W in(0,1):
 for last in(1,3):
  ep=1-W if last==1 else W
  G=s.groebner([d*r-n*e-(-1)**ep],d,n,e,r,k,domain=s.QQ)
  As,Bs=dual(B,False),dual(A,True);old,oo=ops(A,B,W,last,False);new,no=ops(As,Bs,W,1 if last==1 else 2,True)
  tau=zero if ep==0 else V(As)-Bs
  for alt,isp,src,v,jet,lab in oo:
   vv=rot(v-old+(2 if isp else 1)*src)-(tau if alt else zero)
   target=[o for o in no if o[0]==alt and o[1]!=isp and s.simplify(o[2]-dual(src,isp))==zero and s.simplify(o[3]-vv)==zero]
   assert len(target)==1
   beta=ep*A if alt else zero
   residual=BH*vv+rot(jet)-beta-target[0][4]
   res=[G.reduce(s.expand(x))[1]for x in residual]
   rows.append(dict(W=W,last=last,source=lab,target=target[0][5],residual=[str(x)for x in res]))
assert all(all(v=="0" for v in row["residual"])for row in rows)
# Full scalar covariance under zstar=Rz+e1-RUchild, with an EVEN vstar.
x,y,vx,vy,lx,ly,bx,by,Ux,Uy,c0,kap=s.symbols('x y vx vy lx ly bx by Ux Uy c0 kap')
z=s.Matrix([x,y]);vv=s.Matrix([vx,vy]);ell=s.Matrix([lx,ly]);beta=s.Matrix([bx,by]);Uc=s.Matrix([Ux,Uy]);Ri=s.Matrix([[0,-1],[1,0]]);e1=s.Matrix([1,0]);e2=s.Matrix([0,1])
H=lambda q:s.expand((q[0]**2+2*q[0]*q[1]-q[1]**2-2*q[1])/4)
newell=BH*vv+rot(ell)-beta
newc=c0+ell.dot(Uc-e2)+beta.dot(vv)-kap-(vv.dot(BH*vv))/2-vy/2
# primitive old height is an independent variable; it cancels.
oldplaced=H(z)+ell.dot(Ri*z+Uc-e2)+c0
newplaced=H(z-vv)+beta.dot(z-vv)+kap+newell.dot(z)+newc
assert s.expand(oldplaced-newplaced)==0
# Character consistency of the nonzero even-ALT primitive rotation jet.
character_checks=[]
for ep in(0,1):
 G=s.groebner([d*r-n*e-(-1)**ep],d,n,e,r,domain=s.QQ)
 As,Bs=dual(B,False),dual(A,True);Q=2*A+B;Qs=dual(Q,False);tau=zero if ep==0 else V(As)-Bs;beta=ep*A
 for name,res in [('new primary',beta.dot(2*Qs)-a(Q).dot(Ri*tau)-2*ep),('new secondary',beta.dot(V(Qs))-ep)]:
  assert G.reduce(s.expand(res))[1]==0
  character_checks.append((ep,name))
# W1 initial target RIGHT max-zero anchor: target 2pstar = dual Q kernel.
E0,R0=s.symbols('E R',integer=True);qq=s.Matrix([E0,R0]);Tq=E0**2+2*E0*R0-R0**2;etaq=(Tq-E0-R0)/2
anchor=H(s.Matrix([E0+R0,E0-R0]))+E0+etaq-Tq
assert s.expand(anchor)==0
# Verify the target odd literal outer order maps to the recorded old-even order.
expected={0:['main2','long3','main1','main0','long4','main5'],1:['long4','main5','main0','main1','main2','long3']}
outer_orders=[]
for W in(0,1):
 old,oo=ops(A,B,W,1,False);new,no=ops(dual(B,False),dual(A,True),W,1,True)
 relevant=[row for row in rows if row['W']==W and row['last']==1]
 inv={row['target'].split('/')[0]:row['source'].split('/')[0]for row in relevant}
 repl=({0:False,3:True}if W else{1:False,2:True})
 labels=[('long' if i in repl else 'main')+str(i)for i in[0,1,4,5,2,3]]
 order=[inv[z]for z in labels];assert order==expected[W],order
 outer_orders.append({'W':W,'target_original_indices':[0,1,4,5,2,3],'old_counterparts':order})
out={'status':'PASS','gradient_checks':len(rows),'gradient_records':rows,'scalar_covariance':'PASS exact full affine/scalar identity','ALT_character_jet_checks':character_checks,'W1_absolute_initial_RIGHT_anchor':'PASS H(dual_kernel_Q)+E+etaQ-TQ=0','literal_outer_orders':outer_orders,'scope':'Earlier ACTUAL primitive cropped native value-conjugacy and source full coherence/recurrence/Hroof remain explicit hypotheses.'}
Path(__file__).with_name('CORRECTED_EVEN_TO_ODD_FULL_COHERENCE_VALUE_ROTATION.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS56 gradients + full scalar identity +4 ALT jet characters +1 absolute anchor +2 literal outer orders')
