import sys,sympy as s,json
from pathlib import Path
sys.path.insert(0,'recovery_20261101_0745')
# Load only historical definitions, without rerunning or rewriting its ledger.
f=Path('recovery_20261101_0745/check_all_alternate_creation_source_lists_arithmetic_duality.py').read_text();exec(f[:f.index('records=[]')])
BH=s.Matrix([[1,1],[1,-1]])/2;zero=s.zeros(2,1)
aj=lambda v:s.Matrix([v[1],-v[0]])
def rawjets(p,q,last,op,flip):
 ap,aq=aj(p),aj(q)
 if op:return [ap+k*aq,ap,zero,zero,zero]if flip else[zero,k*aq,(k+1)*aq,ap+k*aq,ap+k*aq]
 base=aq-ap if last==2 else zero
 return [(2*k+1)*ap+aq,(2*k+1)*ap+aq,(2*k+2)*ap,(2*k+1)*ap+base,base]if flip else[zero,zero,zero,ap+base,(2*k+2)*ap+base]
def jets(A,B,W,last,odd):
 p,q=selected(A,B,last);cp,cq=(p+(k+1)*q,q)if odd else(p,q+2*(k+1)*p)
 ap,aq=aj(cp),aj(cq);outer=[zero,2*ap,zero,ap,aq,aq+ap]if odd else[zero,ap,ap,2*ap,zero,ap+aq]
 repl={3:True,4:False}if odd else{0:False,3:True};ans={}
 for idx,flip in repl.items():
  for jj,jet in enumerate(rawjets(p,q,last,odd,flip)):ans[f'long{idx}/{jj}']=outer[idx]+jet
 return ans
out=[]
for W in[0,1]:
 for last in[1,3]:
  old,oo,cp,cq=altops(A,B,W,last,True,True);new,no,_,_=altops(As,Bs,W,1 if last==1 else 2,False,True)
  oj=jets(A,B,W,last,True);nj=jets(As,Bs,W,1 if last==1 else 2,False)
  ep=1-W if last==1 else W;tc=tau_for(cp,cq,W,True);tp=tau_for(A,B,ep,False);bp=ep*A
  rs=[]
  for alt,isp,src,v,label in oo:
   if not alt:continue
   vv=rot(v-2*old+src)+tc-tp
   hits=[r for r in no if r[0]and not r[1]==isp and s.simplify(r[2]-dual(src,isp))==zero and s.simplify(r[3]-vv)==zero];assert len(hits)==1
   tar=hits[0];needed=s.simplify(nj[tar[4]]-BH*vv-rot(oj[label])+bp)
   assert s.simplify(needed-(1-W)*cp)==zero
   rs.append(dict(source=label,target=tar[4],target_beta_needed=list(map(str,needed)),origin=list(map(str,vv)),old_jet=list(map(str,oj[label])),new_jet=list(map(str,nj[tar[4]]))))
  assert all(q['target_beta_needed']==rs[0]['target_beta_needed']for q in rs)
  out.append(dict(W=W,last=last,tau_target=list(map(str,tc)),tau_primitive=list(map(str,tp)),beta_primitive=list(map(str,bp)),cp=list(map(str,cp)),cq=list(map(str,cq)),rows=rs))
print(json.dumps(out,indent=2))
Path(__file__).with_name('DUAL_LONG_SLOPE_IDENTITIES.json').write_text(json.dumps(out,indent=2))
