# Corrected LONG G3 slopes under odd-ALT to even-ALT duality

**Result:** the four saved1/saved3 × W0/W1 slope cases match exactly, provided the genuine analytic ALT conjugacies have the target and primitive gauges displayed below. Sixteen endpoint identities are checked symbolically, hence every index of both affine LONG G3 chains. This is pointwise on the mapped genuine R2/support guard. It proves neither chronological reordering nor native crop equality, nor the analytic primitive-value conjugacy itself.

## Real birth and current parents

Let birth parents be a (odd), R (even), current phase W, and saved last digit s in{1,3}. Set
 (p,q)=(a+R,2a+R) for saved1; (p,q)=(a,2a+R) for saved3.
The primitive old even G3 field is the actual alternate at Z=q, created at phase ep=1-W for saved1 and ep=W for saved3. Its own birth parents are a,R, not the stationary effective negative parent.

For the corrected LONG odd target, current parents are p_c=p+(k+1)q, q_c=q, and target C=p_c+q_c. The LONG head count is2k+2, not the SHORT count2k+1. The arithmetic dual is v*=(d+n,d-n) for odd v and half this for even v. Rot denotes clockwise90 degrees: Rot(x,y)=(y,-x).

The source inventory used is the historical exact alternate source-list generator, restricted to corrected odd targets and mapped corrected even targets. Actual outer slopes are independently read from getAltOddTileFull/getAltEvenTileFull, with af(v)=(0,(n,-d)). Raw LONG slopes are obtained by summing the original _odd_l/_even_l increments, using2k+2 heads. No minimum/reordering operation enters a slope identity.

## Both required analytic gauges

Define rho_S(z)=Rot(z-U_S)+e1, with U_S=2S odd and S even. The POINTWISE analytic conjugacy convention is
 fhat_{S*}(rho_S(z)+tau_S)
 =H(rho_S(z)+tau_S)+fhat_S(z)+beta_S dot(rho_S(z)+tau_S)+kappa_S.
Its plus sign in front of the OLD field is essential.

For the target odd C→even C*, its own gauge must be
 tau_C=-p_c* if W0; tau_C=-V_(q_c*) if W1,
 beta_C=(1-W)p_c.
For the old primitive even Z→odd Z*, use its OWN creation ep:
 tau_Z=0 if ep0; tau_Z=V_(R*)-a* if ep1,
 beta_Z=ep*a.
Here beta values are COORDINATE vectors, not affine-slope vectors a_v=(n,-d). Scalars kappa may remain uncalibrated for this task.

The even-to-odd primitive beta convention is explicitly stated as a genuine earlier value hypothesis in FULLY_COHERENT_CORRECTED_EVEN_CONSTRUCTORS_ROTATE_TO_ACTUAL_CORRECTED_ODD_UNDER_PRIMITIVE_VALUE_CONJUGACY.md. Its character checks alone do NOT prove it. The current odd-to-even target analytic beta must likewise be supplied by the true analytic target conjugacy. The slope calculation confirms its exact required value, but is not an independent proof of that conjugacy. If that analytic ALT-gauge input is not yet admitted, the result here remains conditional on it; source-list geometry cannot remove the condition.

## Exact transported slope

For an old placed G3 source fhat_Z(z-v)+ell dot z+c, its new placed origin is
 v*=Rot(v-2C+Z)+tau_C-tau_Z.
This is exactly the origin matched by the historical alternate source-list inventory. With B_H=[[1,1],[1,-1]]/2, its transported slope is
 ell*=B_H v*+Rot(ell)+beta_C-beta_Z.

The signs follow by substituting the two analytic identities: the target adds beta_C, whereas expressing the old primitive in terms of the actual new primitive SUBTRACTS beta_Z. The harmonic translation contributes plus B_H v*. Omitting beta_C breaks both W0 cases; omitting beta_Z breaks whichever primitive creation has ep1. No source scalar can repair a nonzero slope residual.

For reference, in the polynomial harmonic part H(w)=(w1²+2w1w2-w2²-2w2)/4, the corresponding constant is
 c*=c+kappa_C-kappa_Z+ell dot(U_C-e2-Rot^-1(tau_C))
    +beta_Z dot v*-(v* dot B_H v*)/2-v*_2/2.
Only slopes are certified here. Exact parity-sheet constants must use the actual harmonic/conjugacy convention; they can be absorbed into the separately calibrated scalar on its licensed physical parity, not guessed away.

## Verified cases and head indices

The script check_dual_long_slope.py loads only the historical source-list definitions, without rerunning/writing that older ledger. It reconstructs both targets' actual raw slope tables independently. For each W and saved digit it matches both first and last G3 heads in both LONG operands, checks the actual primitive type switches even→odd, and proves the residual above is identically zero. It additionally asserts the common required target beta equals(1-W)p_c, rather than merely observing equal residuals.

All16 endpoint identities pass as exact symbolic polynomial identities. Origins and slopes are affine in the head index. The historical matched endpoint pair belongs to one entire target chain, so the identities extend to every actual head index1..2k+2 (including reversed endpoint correspondence). The restored/consumed source translation is present in the own tau_Z term. This does not authorize replacement by an arbitrary global donor outside its actual mapped guard.

## Conclusion and remaining input

The literal corrected LONG G3 gradients have the correct affine transport in all four requested cases, with the target's OWN tau/beta and the earlier primitive's OWN tau/beta. Pointwise value equality then differs by a scalar on each licensed connected source chart, conditional on the analytic parent conjugacy. Scalar calibration, actual complete source retention, guard inclusion/equality, and chronology are separate. In particular no new assertion that a coherent rotated source union is the literal target constructor is made.
