# UNC standard and alternate slots: literal duality audit

PASS:24 standard-slot identities and28 alternate-slot identities (including four stars), with both physical coordinate parity assignments. No mismatched origin, gradient, or parity was found. These are symbolic identities, not sample words.

## Actual tables and scope
check_unc_dual_slots.py reads the exact AST bodies of getOddTileAffine,getEvenTileAffine,_alt_odd,_alt_even,_odd_offset,_even_offset from original_port_offsets.py. Affine evaluation uses the genuine period pairs (0,b_p),(0,b_q), not coordinate vectors substituted as affine primary increments. In particular the deliberately different even affine expression p1+2p2 causes no mismatch because its authentic primary slope is0.

Both W phases are checked. For genuine odd UNC ALT the consuming last digit is1 or3; its dual even UNC ALT has last1 or2. The six ordinary operands and the inserted star are all checked. Standard UNC tables are independent of the final digit apart from phase and selected parents; the displayed selected substitutions are invertible linear parametrizations, and the polynomial identities therefore apply to arbitrary proper selected pairs, including the other legitimate UNC standard dispatcher branches. No corrected helper is inserted in this certificate.

## One-scalar equation
For each old occurrence (source X,origin v,slope ell), set
 v*=Rot(v-U_target+U_X)+tau_target-tau_source,
 where U_X=2X for odd standard/alternate type and X for even type. The old target here is odd, so U_target=2target. Standard source and standard target tau,beta are ZERO. For the alternate target use its own selected-parent tau and beta_target=(1-W)p. The alternate star uses its own birth phase ep=1-W for savedlast1, ep=W for last3; its own tau and beta_source=ep*a are retained. This is not the consumer's birth data substituted for the primitive's.

Every actual target slot satisfies
 ell*=B_H v*+Rot(ell)+beta_target-beta_source,
 B_H=[[1,1],[1,-1]]/2.
All transformed origins have even coordinate sum under both allowed odd-parent parities, with the even parent coordinates odd/odd. Hence the difference of harmonic parity terms is constant over the entire occurrence. Once authentic source/target value conjugacies are supplied, the difference is ONE scalar per occurrence, not unrelated constants on separate parities or components. The checker neither sets this scalar to zero nor calibrates it by choosing a convenient artificial frame.

## Domain and chronology boundary
Exact standard polygon conjugacy gives equality of corresponding complete standard E guards. It supports mapped E-joins where both operands really have these guards. For literal native contacts use the source's own independently proved native domain and true restoration/normalization. Do not transport an endpoint merely because a one-way R2 inclusion is available. The star's domain and overlap with the genuine six-source prefix retain their own source-level proofs.

Thus this is a strict-core source-origin/gradient/parity certificate. It does not prove literal source values on an absent site, an unproved star translation, nonempty chronological touches, outer scalar maxima, array padding, or recurrence. Those hypotheses cannot be removed by the all52 algebraic passes.
