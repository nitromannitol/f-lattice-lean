# Strict saved1: independent intrinsic price substitution

Conditional audit, strict proper regime. Let a be the actual odd creator of the earlier even Z=2a+R, and A=Z-a the effective current odd parent. The actual birth phase is opposite the current phase. Write v_a=V_a, v_A=V_Z-v_a, b_A=b_Z-b_a, T=T_Z, K=M(a,Z), L=D+N, c=D-N. Distinguish geometric c from c_a=(T_a+L_a)/2. Throughout retain authentic global deck laws, full E_Z price spans, complete harmonic/physical-D strips and true restored ALT crop bounds. Require N>=3 and c>=4 for the odd rim estimates below; endpoint families outside these conditions are not silently included.

The exact quadratic identities are
 c_A=c_Z+eta_a-K,
 eta_A=eta_Z+c_a-K.

## 1. Current W0, genuine birth W1

Here b_a.Z=1 and b_Z.a=-1. The genuine birth price is
 Pb(x)=g(x)-g(x-v_a)-b_a.x,
 eta_a-1<=Pb<=eta_a on E_Z,
 Pb(Z)=-1, Pb(V_Z)=0.
The effective forward price satisfies exactly

 Peff(z)=g(z)-g(z+v_A)+b_A.z=Pb(z)+c_Z-K,
 Peff(z)-c_A=Pb(z)-eta_a.

The birth-W1 crop lies above E_Z's longitudinal lower edge. Forward longitudinal folding therefore gives Pb(z)<=eta_a on the whole actual crop, so Peff<=c_A there.

For w=z+2a+v_a, the effective raw offer
 h_eff(z)=g(z-v_A-2A)+b_A.z+eta_A+2
obeys

 h_eff(z)-g(z)=Pb(w)-eta_a+4-D(z),
 D(z)=g(z)-g(z+2a).

To check the constant, z-v_A-2A=w-V_Z-2Z, so its field equals g(w)-b_Z.w-eta_Z. Substitution of b_Z.(2a+v_a)=-2-K and eta_A=eta_Z+c_a-K leaves c_a+4; expansion of Pb(w) then yields the displayed formula.

### Uniform lower price bound at w

The true birth-W1 support bounds give
 s(w)<=2T+2N+ex+2,
 s(w)>=2K+2-ex,
where ex=D-3N+2 only at lower-sector odd sites and is zero otherwise. The lower bound is above E's lower edge by the strict creator cone. The upper bound is at most E_upper+T at odd sites:
 - low sector: 2N+ex+2=c+4<=L-2 because N>=3;
 - other sectors: 2N+2<=L-2 because c>=4.
Hence at odd sites at most one forward Z fold is needed, and Pb(w)>=eta_a-2. The same holds at even sites except s(w)=2T+2N+2, the only possible extra layer since s is even.

In that even layer w0=w-2Z has s(w0)=2N+2 and s(w0-v_a)=2N. Both lie in the full physical harmonic strip [1-2D,2L-1]. Its true v_a jet gives Pb(w0)=eta_a, and the primary character gives Pb(w)=eta_a-2. This argument uses the full strip, not a uniqueness claim about a rim vertex or a presumed native inclusion.

Therefore on every genuine old crop point

 h_eff-g>=2-D>=0.

This is stronger than the requested dominance lower cap. Both the whole-crop effective Peff upper cap and raw dominance are thus paid by birth prices without falsely declaring A the original creator.

## 2. Current W1, genuine birth W0

Here b_a.Z=-1 and b_Z.a=1. The birth forward price is
 Pb(x)=g(x)-g(x+v_a)+b_a.x,
 c_a-1<=Pb<=c_a on E_Z,
 Pb(Z)=-1, Pb(V_Z)=0.
For the effective backward price,

 Pstd_eff(u)=g(u)-g(u-v_A)-b_A.u,
 Pstd_eff(u)-eta_A=Pb(u)-c_a.

Indeed the negative V_Z jet at u+v_a contributes -eta_Z and b_Z.v_a=-K, giving Pstd_eff=Pb+eta_Z-K. At u=z+2A=z-2a+2Z this yields

 Pstd_eff(u)-eta_A=Pb(z-2a)-2-c_a.

### Uniform upper bound at z-2a

Put r=z-2a. The genuine birth-W0 lower support row gives
 s(r)>=-T-2-ex,
where ex=D-3N-2 only at lower-sector odd sites. For those odd sites this is -T+3N-D, above E_lower-T=2-c-T by2N-2. At other odd sites it is -T-2, above E_lower-T since c>=4. Thus at most one backwards longitudinal fold is needed to place r into the true E interval, and Pb(r)<=c_a+1.

At even sites the only extra layer is s(r)=-T-2. Then r0=r+Z has s=-2, and r0+v_a has s=-4. Both are in the full harmonic strip; its exact v_a jet gives Pb(r0)=c_a, hence Pb(r)=c_a+1. No additional transverse geometric exception survives.

Consequently, uniformly,

 Pstd_eff(z+2A)<=eta_A-1.

With the genuine birth midpoint D(z)=g(z)-g(z-2a), which is also the effective current difference g(z)-g(z+2A), the effective fringe satisfies
 h_eff-g=eta_A-Pstd_eff(z+2A)-D(z)>=1-D(z)>=-floor(D(z)/2).
Thus h_eff>=J. This is a lower cap, not by itself an attainment claim.

## 3. Current-W1 high-fold sign and paired attainment

Retain the separately authenticated effective stationary source law and high-fold geometry; neither is reconstructed by price substitution. When a final head high-folds, its old coordinate z lies above the corresponding E_Z upper s edge. Forward longitudinal folding gives Pb(z)<=c_a-1, so Pstd_eff(z)<=eta_A-1. The genuine folded first-offer formula is

 fmax(z)=min(D(z-2A), eta_A-1-Pstd_eff(z)).

Both terms are nonnegative: the second by the price bound, the first by the old complete physical D range at the shifted query (its transverse coordinate is t(z)+2, exactly as in the saved3 high-fold proof). Thus the effective high fold cannot undercut the target.

For attainment when the reflected point z' high-folds, the true birth-W0 crop reflection center is
 H'=2a+V_Z+(1,-1)=2Z-2A+V_Z+(1,-1),
exactly the effective W1 center, with no extra primary shift of the crop. Put u=z+2A. The exact identity
 s(u)=2T+2N-s(z')
puts u below the genuine E_Z upper s edge. Its lower bound from the actual birth-W0 crop is T-2-ex: this is T-D+3N>0 at lower-sector odd points, and T-2>0 otherwise. Its transverse coordinate is t(z)-2; the genuine old ALT rows put this between E_Z's corresponding lower and upper t edges. Therefore u really belongs to E_Z.

The birth price span gives Pb(u)>=c_a-1, hence Pstd_eff(u)>=eta_A-1. Section2 gives the reverse inequality, so equality holds. If D(z)=2, the actual fringe excess is therefore -1 and attains J. This completes that paired high-fold attainment under the stated stationary/source geometry premises.

## Scope

All displayed substitutions, fold bounds and harmonic rim prices are uniform, not inferred from finite tests. They preserve the actual birth phase and its correct two-level price. Genuine restoration/scalar calibration, current occurrence origins, effective stationary source identities and actual current E/native licensing remain explicit independent premises. These results do not alone assert full all-word native realization or recurrence.
