# Corrected G3 dual transfer: exact R2 inclusion and its scope

## 1. Direction that is valid
Let the OLD primitive be an even alternate with fraction N/D, creation parents p odd,q even and phase W, so its represented vector is2p+q=(D,N), det(p,q)=1-2W. Let p*=dual(q),q*=dual(p), and target odd primitive have vector((D+N)/2,(D-N)/2). Use clockwise rotation rot(x,y)=(y,-x) and the source's OWN birth correction

 tau=0 forW0; tau=V_(p*)-q* forW1.

The physical source map is f(z)=rot(z)+e1-rot((D,N))+tau. Target parity is the opposite of old parity. This source tau is not the current child's tau or the other G3's tau.

Using the actual all-sector R2 bounds in reconstruct_direct_auxiliary_enclosure.py and balanced bounds in fresh_build_balanced_auxiliary_enclosure.py, exact symbolic endpoint subtraction gives:

- old lower ↔ target upper: inverse target R2 equals old R2;
- old upper ↔ target lower: inverse target R2 equals old R2;
- old balanced, old even physical parity: equality;
- old balanced, old odd physical parity: identical transverse t bounds, but inverse target longitudinal s interval is obtained by trimming BOTH old endpoints by
  3N-D+2 for W0, and3N-D-2 forW1.

Here t=Nx-Dy, s=(D+N)x+(D-N)y. The transformed coordinates are t*=s/2+t*(shift), s*=-t+s*(shift). Every claimed identity follows by substituting these two formulas into the authentic endpoints. dual_r2_algebra.py independently prints all12 four-endpoint residual lists. In balanced strict proper even type, D,N are odd and2N<D<3N, so3N-D is positive even and at least2. Both trims are nonnegative. Consequently EVERY target ODD R2 lattice point pulls back into the corresponding old EVEN R2. This conclusion is about the guarded rectangles, not equality of literal generated domains.

## 2. Exact balanced obstruction to the reverse inclusion
Take genuine creation parameters p=(5,2),q=(7,3),W0, det=1. Old even fraction is7/17 and target odd dual5/12; here p*=p,q*=q, tau=0, and f(x,y)=(y-6,17-x).

Old point z=(-15,16), odd parity, has(t,s)=(-377,-200). Its old balanced R2 bounds are t∈[-469,17],s∈[-200,494], so it belongs. Its image is(10,32), even parity, with(t*,s*)=(-334,394). Target balanced R2 has t*∈[-331,10],s*∈[0,486]; the point fails its lower t* bound by3. The old trim is3N-D+2=6, exactly twice that discrepancy. This is an exact R2 counterexample to reverse/equality claims. It is NOT a claim that this relaxed R2 point is an actually occupied native site.

## 3. Literal source correspondence and slopes
Historical112 standard and168 alternate creation identities prove placed-domain arithmetic covariance, including G3 chain endpoint matching and its affine index progression. Their source map explicitly subtracts the alternate leaf's OWN earlier tau. They do not prove primitive height conjugacy or equality with another independently generated native array. The constant-source/jet part must be checked separately.

In an alternate G3 value conjugacy, the birth-phase affine term beta=W_birth*a_coordinate cannot be dropped or replaced by W_current*a_coordinate. Under a map z=f^{-1}(w), that affine term is beta·f^{-1}(w), hence contributes both a rotated slope and a constant from the birth translation. A normalized G3 comparison is legitimate only after transforming the ENTIRE source-plus-outer-jet expression and subtracting the target's actual normalized jet. Neither geometric chain matching nor the R2 inclusion calculates that additive scalar. Use the explicitly calibrated source identity (or its exact polynomial certificate), not unadorned rotation of a picture. No independent universal beta/outer-scalar cancellation is established by the R2 calculation in this note.

## 4. When literal native subset is unnecessary
Suppose prior theorem has genuinely proved an analytic inequality/equality for the canonical old standard-field expressions at EVERY lattice point of its R2 rectangle, and the standards entering those expressions have an independently established whole-plane harmonic conjugacy. Then substitution through f, the above inverse inclusion, and the fully transformed affine jet prove the target analytic assertion on its entire R2. A literal-native subset is unnecessary: no claim about an actual old array is used at that step.

This is different from a theorem stated only on the ACTUAL old alternate crop. Knowing D_old⊂R2_old cannot extend a crop-only theorem to R2_old. The earlier whole-physical-head note assumes the old restored midpoint on the genuine crop; its geometric proof uses an R2 enclosure, but that does not alone upgrade its midpoint premise to every R2 lattice site. A projected native readout must therefore either (a) authenticate target-native pullback into actual old native support, or (b) separately establish the all-R2 analytic identity and all source gauges. Standard-field conjugacy by itself supplies neither the alternate source value nor its contact normalization.

## Scope
Uniform one-way R2 transport is proved here for strict proper opposite-type primitives, with actual birth parameters. Balanced reverse obstruction is explicit. Literal endpoint initialization, degenerate fractions, padding, max-normalization, actual native equality and current outer chronology remain separate. No whole-array or recurrence theorem is inferred.
