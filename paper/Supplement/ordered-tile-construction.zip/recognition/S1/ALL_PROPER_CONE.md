# Independent audit: all proper birth parameters for nominal all-R2 head pricing

## Verdict

PASS for the conditional NOMINAL priced-head theorem and its all-R2 extension in both phases of saved3 and saved1. Replace the old sufficient birth restrictions n_a>=2,d_a-n_a>=3 by

 n_a>=1, d_a-n_a>=1, r>=1, e-r>=2,

with the genuine odd/even types and the applicable determinant sign retained. For Z=2a+R this gives N_Z>=3 and c_Z=D_Z-N_Z>=4, exactly the smallest values needed by the odd rim inequalities. No required nominal inequality failed.

This conclusion retains earlier realized STANDARD field/profile/strip/E-polygon inputs, genuine source chronology, actual restoration and calibrated affine jets as assumptions. It does not establish missing earlier alternate calibration, protected-prefix/UR properties, or actual current recurrence. Analytic values at R2 holes remain the explicitly defined midpoint continuation, not newly occupied array sites.

## Independently rerun unbounded certificates

The copied scripts under `all_proper_receipts/` replace the substitutions by

 n=u+1, d=u+v+2, r=w+1, e=w+h+3, k=j+1,

with all five new variables nonnegative. Original scripts and original receipts were not overwritten. These are exact polynomial positivity/identity checks, not finite parameter samples.

- S1_check_vertices.py: all320 affine polygon/final-fold facets pass. Each multiplied slack q obeys q+T>0 by strictly positive constant and nonnegative coefficients. Target integrality then gives actual slack>=0, just as in the original proof.
- W1_check_arithmetic.py: all12 strict W1 polygon margins pass; all3 determinant identities pass.
- whole_crop_audit.py: all10 strict W0 polygon margins and all4 determinant identities pass.
- identity_audit.py: all17 source/jet/exception/projection identities and all10 strict cone margins pass.
- W1_high_fold_audit.py: all4 exact high-fold threshold identities pass.
- prose_margins.py: all31 additional scalar/geometry/rim margins have nonnegative coefficients. Strict inequalities used in the proof have positive constant; the zero-constant rows are precisely permitted weak bounds such as N>=3,c>=4 and2N>=6.

The corresponding JSON files preserve the margins/receipts. MANIFEST.json hashes this directory's scripts and results.

## Prose and exceptional-value review

### W0 old contacts and reflected outlier

All inequalities actually needed by nominal pricing remain valid: K>2, K>N, 2K>D_Z+2, T_Z>2K, T_Z>2L_Z, and hence L_Z+K<T_Z. These preserve the exact gcd/parity isolation of the even exceptional points v_a and H-v_a. The odd lower-edge comparison uses2N_Z-4>=0 and is stronger at N_Z>=3. The odd upper comparison uses c_Z>=4 and N_Z>=1; its endpoint equalities are permitted.

The actual value computations at v_a and H-v_a need only the genuine earlier a standard's period/reflection and its full strips. Their particular strip queries are t_a(-R)=1 and s_a(-V_R)=-2. Since d_a>=2 and n_a>=1, these remain inside the old zero and harmonic strips, respectively. The exact affine identities in identity_audit still hold modulo the determinant relation. No new assumption that a raw two-sheet minimum has a global reflection is introduced.

The later folded-endpoint single rim is priced by the full harmonic strip, as before. Its comparison at v_a and2v_a depends on s_Z=-2,-4, not on actual old-ALT occupation.

### W0 dominance, whole-polygon and endpoint wraps

The complete proofs use only the actual birth-R2 rows and the positive margins rerun above. In particular the reflected exceptional price, longitudinal folding of the full E_Z price span, and shifted physical D intervals remain licensed. The lower-fold primary representative z+2C has positive margin

 2T_C-K-kT=2T_a+(4k-1)K+(2k^2-k)T>0.

The endpoint transverse wrapping estimates require T>K, N_Z>=2 and c_Z>=4, all retained. Their exact P/D identity does not change with the cone.

### W1 lower cap and paired high fold

The W1 R2 odd lower loss remains inside E's lower edge because2N_Z-4>=0. The upper-t wrap comparison uses the complete physical D window and T>K, rather than an unproved native inclusion. All W1 polygon margins remain strictly positive under the widened substitution. The high-fold threshold identities still hold; K>c_Z and the required R2 lower-s separation are among the new positive prose margins. Thus the reflected E_Z license and exact price-span attainment are unchanged.

### Saved1 phase swap and both exceptional rims

The effective A=Z-a identities are exact and independent of cone size. The only potentially tight odd top estimates in the birth-W1/current-W0 lower-price argument are

 c_Z+4<=L_Z-2 iff N_Z>=3,
 2N_Z+2<=L_Z-2 iff c_Z>=4.

Both hold, possibly with equality, at the widened cone boundary. The birth-W0/current-W1 lower-price argument similarly uses c_Z>=4 and2N_Z-2>=0. The even extra layers remain exactly those priced by the full harmonic strip after true primary translation; no transverse uniqueness assumption or native-hole exclusion is needed.

The saved1 reflected lower bound T_Z-D_Z+3N_Z>0 and its other-parity version T_Z-2>0 remain strict. The320-facet proof uses the ACTUAL birth parents a,R, not a fictitious effective proper residual parent.

## Historical wording that must not be inherited literally

The earlier G2 contact audit says “indeed L_a>=7 here.” That statement is false on the enlarged cone: a=(2,1) has L_a=3. It is NOT used in the nominal-price proof reviewed here. The genuine inequality in that old line, L_a+1<=2L_a-1, only needs L_a>=2 and therefore would still hold. No old G2 proof is being imported into this extension except the separately reviewed v_a/H-v_a price calculations requested above.

Likewise phrases “strict cone n>=2,d-n>=3” in historical files describe their originally stated scope; they are superseded for this conditional NOMINAL theorem by the fresh proper-cone certificates, not silently assumed to cover the new boundary.

## Scope of the upgrade

All proper birth parameters in the displayed cone, both determinant/creation phases, all integer stationary lengths k>=1, both saved3 and saved1, and every lattice point of the actual earlier creation R2. The previous whole-R2 audit's caveats about analytic continuation, actual source calibration, current E_Q licensing and no unrestricted halo remain in force. No unsupported claim about literal raw implementation coverage, arbitrary earlier prefixes, or recurrence is added.
