import sympy as s,sys,ast,json,hashlib
from pathlib import Path
sys.path.insert(0,'recovery_20261101_0745')
f=Path('recovery_20261101_0745/check_all_alternate_creation_source_lists_arithmetic_duality.py').read_text();exec(f[:f.index('records=[]')])
BH=s.Matrix([[1,1],[1,-1]])/2;zero=s.zeros(2,1);aj=lambda v:s.Matrix([v[1],-v[0]])
P=Path('recovery_20261101_0745/f_lattice_original_tests/original_port_offsets.py')
names={'_alt_odd','_alt_even','_odd_offset','_even_offset','getOddTileAffine','getEvenTileAffine'}
ns={};exec(compile(ast.Module(body=[n for n in ast.parse(P.read_text()).body if isinstance(n,ast.FunctionDef)and n.name in names],type_ignores=[]),str(P),'exec'),ns)
def cm(v):return v[0]+s.I*v[1]
def vec(z):
 # All source variables are formal real coordinates: conjugate i only.
 z=s.expand(z);bar=z.xreplace({s.I:-s.I});return s.simplify(s.Matrix([(z+bar)/2,(z-bar)/(2*s.I)]))
def jets(p,q,W,last,alt,odd):
 ap,aq=aj(p),aj(q);ns['_parents']=lambda word,fn:(0,cm(ap),0,cm(aq));ns['af']=None
 word=('1' if W else '')+str(last)if last!=1 else('1'if W else'11')
 if alt:
  v1,v2,v3,v4,vs=ns['_alt_odd'if odd else'_alt_even'](word,None)
  vals=[v1,v2,v3,v3+vs,v4,v4+vs]if odd else[v1,v1+vs,v2,v2+vs,v3,v4]
  nsfun=ns['_odd_offset'if odd else'_even_offset'];fn=lambda v:(0,cm(aj(v)))
  vals.append(nsfun(p,q,word,fn))
 else:
  v1,v2,v3,v4=ns['getOddTileAffine'if odd else'getEvenTileAffine'](word)
  vals=[v1,v1,v2,v2,v3,v4]if odd else[v1,v2,v3,v3+cm(ap),v4,v4+cm(ap)]
 return dict(zip([f'main{i}'for i in range(6)]+(['star']if alt else[]),map(vec,vals)))
def stdops(A,B,W,last,odd):
 p,q=selected(A,B,last);return(p+q if odd else 2*p+q),[(False,isp,p if isp else q,s.Matrix(v),f'main{i}')for i,(isp,v)in enumerate(E.std_layout(p,q,W,odd))],p,q
rows=[];aa,bb,cc,dd=s.symbols('aa bb cc dd',integer=True)
for alt in[False,True]:
 for W in[0,1]:
  for last in[1,3]:
   ld=1 if last==1 else 2
   if alt:old,oo,p,q=altops(A,B,W,last,True,False);new,no,ps,qs=altops(As,Bs,W,ld,False,False)
   else:old,oo,p,q=stdops(A,B,W,last,True);new,no,ps,qs=stdops(As,Bs,W,ld,False)
   oj=jets(p,q,W,last,alt,True);nj=jets(ps,qs,W,ld,alt,False)
   ep=1-W if last==1 else W;tc=tau_for(p,q,W,True)if alt else zero;bt=(1-W)*p if alt else zero
   for isa,isp,src,v,label in oo:
    ts=tau_for(A,B,ep,isp)if isa else zero;bs=ep*A if isa else zero
    vs=s.simplify(rot(v-2*old+(2 if isp else 1)*src)+tc-ts)
    hits=[z for z in no if z[0]==isa and z[1]!=isp and s.simplify(z[2]-dual(src,isp))==zero and s.simplify(z[3]-vs)==zero];assert len(hits)==1
    dest=hits[0];res=s.simplify(nj[dest[4]]-BH*vs-rot(oj[label])-bt+bs)
    parity=[]
    for pa in[0,1]:
     pol=s.Poly(s.expand(sum(vs).subs({a:2*aa+pa,b:2*bb+1-pa,c:2*cc+1,d:2*dd+1})),aa,bb,cc,dd)
     parity.append(all(v.q==1 and v%2==0 for v in pol.coeffs()))
    rows.append(dict(alternate=alt,W=W,last=last,source=label,target=dest[4],source_tau=list(map(str,ts)),source_beta=list(map(str,bs)),target_beta=list(map(str,bt)),origin=list(map(str,vs)),residual=list(map(str,res)),pass_=bool(res==zero),even_origin_parities=parity))
print('PASS',sum(r['pass_']for r in rows),'/',len(rows));print('FAIL',[(r['alternate'],r['W'],r['last'],r['source'],r['residual'])for r in rows if not r['pass_']]);print('ODD',[r['source']for r in rows if not all(r['even_origin_parities'])])
Path(__file__).with_suffix('.json').write_text(json.dumps({'rows':rows,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
