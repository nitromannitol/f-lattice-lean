# All nominal LONG primitives: independent dual-gradient audit

The checker extends check_dual_long_slope.py from G3 alone to all14 source records in each of four W/saved cases: four untouched ordinary sources, both endpoints of each G1 chain, each G2, and both endpoints of each G3 chain. Saved1/3 odd-L maps to saved1/2 even-L, at the same current W. Endpoints certify all chain indices because origins and slopes are affine in that index.

## Literal slope binding
The standalone checker extracts the actual AST bodies _alt_odd,_alt_even,_odd_l,_even_l from original_port_offsets.py. It substitutes the genuine affine pair (primary0,secondary b_source), rather than applying coordinate formulas to a wrong primary. Both W values and all last digits are checked independently against the formulas used by the dual audit.
The natural OUTER odd-alternate slopes are
 [0,2b_cp,0,b_cp,b_cq,b_cq+b_cp],
and even-alternate slopes are
 [0,b_cp,b_cp,2b_cp,0,b_cp+b_cq].
In particular these are actual alternate tables, not a presumed standard table. Helper starts use the genuine current raw-stage standard slot3 or5 and each literal affine increment. Endpoint-only translations, when relevant, are not part of this proper-record claim.

## Exact all-slot equation
For each old occurrence (v,ell) of a source X, use U_X=2X for odd type and U_X=X for even type. The old current LONG target O is odd and has U_O=2O. Define
 v*=Rot(v-U_O+U_X)+tau_target-tau_source.
STANDARD sources have tau_source=beta_source=0, without exception for G1/G2. For G3 use the consumed alternate's OWN birth phase ep (1-W for saved1, W for saved3), tau_source=tau_for(a,R,ep,even), beta_source=ep*a. Current target beta_target=(1-W)cp.
Every nominal target match satisfies exactly
 ell*=B_H v*+Rot(ell)+beta_target-beta_source,
 with B_H=[[1,1],[1,-1]]/2.
No determinant or scalar fitting is required. The source match uses actual alt_layout/raw_piece_ops origins and source types; all matches are unique. Both allowed coordinate parities of odd a and odd/odd coordinates of even R give EVEN coordinate sum for every v*. Thus the harmonic parity correction is constant on the entire occurrence, not separately chosen on two parity components.

There are56 all-slot vector identities. The output ledger records each source, matched target, source primary, tau,beta, old/new gradient, exact residual and parity checks. A single additive constant per occurrence remains: its value is determined by authentic primitive/target normalization and actual touching, not by gradient covariance alone.

## Guards and joins: precise extent
For STANDARD primitives the exact standard polygon conjugacy in INDEPENDENT_ODD_P_DONOR_CONJUGACY (and its inverse) gives equality of the transformed complete E polygons. Combining it with the above affine origin matching transports their placed guards exactly. Hence nonempty joins between these complete standard E guards are preserved by the same affine bijection. It does NOT identify literal native arrays with E or create an actual prefix contact if literal supports occupy smaller subsets.
For the alternate G3, use DUAL_TRANSFER_SCOPE: target odd R2 pulls back into the earlier even R2; equality can fail in the balanced case. The all-R2 earlier price theorem is enough for pointwise target pricing under this inclusion. It is NOT enough to infer a chronological G3 contact merely from a nonempty contact in the larger old R2. Actual G3 joins still require the genuine native support/contact theorem. This distinction is not changed by the56 slope identities.

Helper UR placement remains the explicit premise in the nominal source-list packet. No fixed padding or reorder invariance of actual minima is asserted. The result completes all nominal LONG affine-gradient slots, not original global recurrence or unproved scalar calibration.
