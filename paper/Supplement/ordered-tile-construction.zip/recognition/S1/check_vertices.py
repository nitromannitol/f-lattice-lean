import sympy as S,json
from pathlib import Path
D0=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/recognition_ledger/saved3_gate/S1')
d,n,e,r,k=S.symbols('d n e r k');DD,N=2*d+e,2*n+r;ad,an=d+e,n+r;T=DD*DD+2*DD*N-N*N;TA=ad*ad+2*ad*an-an*an;K=(ad+an)*DD+(ad-an)*N;L=DD+N;c=DD-N;B=K+k*T;TP=TA+2*k*K+k*k*T;DP,NP=ad+k*DD,an+k*N;LP=DP+NP;CP=DP-NP
u,v,w,h,j=S.symbols('u v w h j',nonnegative=True);sub={n:u+2,d:u+v+5,r:w+1,e:w+h+3,k:j+1}
rows=[];bad=[]
for W in [0,1]:
 for par in[0,1]:
  for sec in[0,1]:
   ht=DD if par else(c if sec else 2*N);ex=DD-3*N+2*(1-2*W)if par and sec else S.Integer(0)
   ts=[L-T+2-ht,ht];ss=[-ex,2*K+2*N+ex]if W==0 else[T-2*K-2-ex,T+2*N+2+ex]
   for ie,i in enumerate([0,2*k-1] if W==0 else [0,2*k-2,2*k-1]):
    for ti,t in enumerate(ts):
     for si,s in enumerate(ss):
      tc=K*t+(2*W-1)*s+T*(k*t+(-i if W==0 else -2*k+i));sc=K*s+(2*W-1)*2*t+T*(k*s+(i*B if W==0 else 2*TA+2*k*K+i*B))
      tl,th,sl,sh=(NP-TP,DP,2-CP,2*TP+LP-2)if par else(1-TP,LP-1,0,2*TP+2*NP)
      for facet,q in enumerate([tc-T*tl,T*th-tc,sc-T*sl,T*sh-sc]):
       if par and ti==1 and facet==1:q=(1-2*W)*(c+s)-T*(-i if W==0 else -2*k+i)
       if W==1 and ie==2 and facet==3:q=T*(4*TP-1)-sc
       # strict > minus one enough for integer slack; no parity relaxation needed
       pp=S.Poly(S.expand((q+T).subs(sub)),u,v,w,h,j);ok=pp.TC()>0 and all(cc>=0 for cc in pp.coeffs())
       key=[W,par,sec,ie,ti,si,facet];rows.append((key,ok))
       if not ok:bad.append(key)
print('pass',len(rows)-len(bad),'total',len(rows),'bad',bad[:20]);(D0/'PILOT.json').write_text(json.dumps({'rows':rows,'bad':bad},indent=2))
