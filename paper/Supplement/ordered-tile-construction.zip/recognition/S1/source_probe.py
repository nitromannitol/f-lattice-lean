from pathlib import Path
import sys,json
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests');import original_port_recursion as O
D=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair');sys.path.insert(0,str(D.resolve()));from biased_terminal import field
from collections import Counter
for s in ['11','1211','111']:
 mats,alts=O.get_odometers(s);fr=O.getFracs(s);A,Z=fr[2:];birth=s[:-1];a,R=O.getFracs(birth)[2:];F,*_=field(O.export_tile(mats[3]),Z);qa=O.export_tile(alts[3]);off=(0,0)
 if birth.count('1')%2==0:
  off=(R.denominator-(a.numerator-a.denominator),R.numerator-(a.numerator+a.denominator))
  if off[1]<0:off=(0,0)
 U=(2*A.denominator,2*A.numerator);hist=Counter()
 for (x,y),h in qa.items():
  z=(x-off[0],y-off[1]);mate=(z[0]+(-1 if s.count('1')%2==0 else 1)*U[0],z[1]+(-1 if s.count('1')%2==0 else 1)*U[1]);j=(F(z)+F(mate)+1)//2;hist[h-j]+=1
 print(s,'birth',birth,'A Z a R',A,Z,a,R,'restore',off,'diffs',hist,flush=True)
