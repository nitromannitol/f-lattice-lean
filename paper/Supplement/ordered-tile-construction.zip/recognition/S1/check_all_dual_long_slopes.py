import sys,sympy as s,json
from pathlib import Path
sys.path.insert(0,'recovery_20261101_0745')
# Load only historical definitions, without rerunning or rewriting its ledger.
f=Path('recovery_20261101_0745/check_all_alternate_creation_source_lists_arithmetic_duality.py').read_text();exec(f[:f.index('records=[]')])
BH=s.Matrix([[1,1],[1,-1]])/2;zero=s.zeros(2,1)
aj=lambda v:s.Matrix([v[1],-v[0]])
def rawjets(p,q,last,op,flip):
 ap,aq=aj(p),aj(q)
 if op:return [ap+k*aq,ap,zero,zero,zero]if flip else[zero,k*aq,(k+1)*aq,ap+k*aq,ap+k*aq]
 base=aq-ap if last==2 else zero
 return [(2*k+1)*ap+aq,(2*k+1)*ap+aq,(2*k+2)*ap,(2*k+1)*ap+base,base]if flip else[zero,zero,zero,ap+base,(2*k+2)*ap+base]
def jets(A,B,W,last,odd):
 p,q=selected(A,B,last);cp,cq=(p+(k+1)*q,q)if odd else(p,q+2*(k+1)*p)
 ap,aq=aj(cp),aj(cq);outer=[zero,2*ap,zero,ap,aq,aq+ap]if odd else[zero,ap,ap,2*ap,zero,ap+aq]
 repl={3:True,4:False}if odd else{0:False,3:True};ans={f'main{i}':outer[i]for i in range(6)if i not in repl}
 for idx,flip in repl.items():
  for jj,jet in enumerate(rawjets(p,q,last,odd,flip)):ans[f'long{idx}/{jj}']=outer[idx]+jet
 return ans
# Independent literal slope-table binding, using exact AST function bodies.
import ast
literal_path=Path('recovery_20261101_0745/f_lattice_original_tests/original_port_offsets.py')
tree=ast.parse(literal_path.read_text());names={'_alt_odd','_alt_even','_odd_l','_even_l'}
ns={};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in names],type_ignores=[]),str(literal_path),'exec'),ns)
def cv(z):return s.Matrix([s.re(s.expand(z)),s.im(s.expand(z))])
# Real scalar independent variables avoid re/im assumptions on symbolic coordinates.
px,py,qx,qy=s.symbols('px py qx qy',real=True);pp=s.Matrix([px,py]);qq=s.Matrix([qx,qy]);ap=aj(pp);aq=aj(qq)
ns['_parents']=lambda word,fn:(0,ap[0]+s.I*ap[1],0,aq[0]+s.I*aq[1])
literal_checks=0
for W in [0,1]:
 for last in [1,2,3]:
  word=('1' if W else '')+str(last) if last!=1 else ('1' if W else '11')
  assert word.count('1')%2==W
  for odd in[False,True]:
   v1,v2,v3,v4,vs=ns['_alt_odd' if odd else '_alt_even'](word,None)
   vals=(v1,v2,v3,v3+vs,v4,v4+vs)if odd else(v1,v1+vs,v2,v2+vs,v3,v4)
   expected=[zero,2*ap,zero,ap,aq,aq+ap]if odd else[zero,ap,ap,2*ap,zero,ap+aq]
   assert all(s.simplify(cv(z)-want)==zero for z,want in zip(vals,expected));literal_checks+=6
   for flip in[False,True]:
    inc=[cv(z)for z in ns['_odd_l' if odd else '_even_l'](word,flip,None)]
    start=(ap+k*aq if odd else(2*k+1)*ap+aq)if flip else zero
    end=start+k*inc[0];single=end+inc[1];head=single+inc[2]
    actual=[start,end,single,head+inc[3],head+(2*k+2)*inc[3]]
    assert all(s.simplify(z-want)==zero for z,want in zip(actual,rawjets(pp,qq,last,odd,flip)));literal_checks+=5
print('literal AST slope checks',literal_checks)
out=[]
aa,bb,cc,dd,kk=s.symbols('aa bb cc dd kk',integer=True)
for W in[0,1]:
 for last in[1,3]:
  old,oo,cp,cq=altops(A,B,W,last,True,True);new,no,_,_=altops(As,Bs,W,1 if last==1 else 2,False,True)
  oj=jets(A,B,W,last,True);nj=jets(As,Bs,W,1 if last==1 else 2,False)
  ep=1-W if last==1 else W;tc=tau_for(cp,cq,W,True);tp=tau_for(A,B,ep,False);bp=ep*A
  rs=[]
  for alt,isp,src,v,label in oo:
   sourceU=(2 if isp else 1)*src
   sourceTau=tp if alt else zero
   sourceBeta=bp if alt else zero
   vv=s.simplify(rot(v-2*old+sourceU)+tc-sourceTau)
   hits=[r for r in no if r[0]==alt and r[1]!=isp and s.simplify(r[2]-dual(src,isp))==zero and s.simplify(r[3]-vv)==zero];assert len(hits)==1,(W,last,label,hits)
   tar=hits[0];needed=s.simplify(nj[tar[4]]-BH*vv-rot(oj[label])+sourceBeta)
   residual=s.simplify(needed-(1-W)*cp)
   parity=[]
   for pa in[0,1]:
    vvsub=s.expand(sum(vv).subs({a:2*aa+pa,b:2*bb+1-pa,c:2*cc+1,d:2*dd+1,k:kk}))
    pol=s.Poly(vvsub,aa,bb,cc,dd,kk)
    parity.append(all(co.q==1 and co%2==0 for co in pol.coeffs()))
   rs.append(dict(source=label,target=tar[4],alternate=alt,source_U=list(map(str,sourceU)),source_tau=list(map(str,sourceTau)),source_beta=list(map(str,sourceBeta)),origin=list(map(str,vv)),old_jet=list(map(str,oj[label])),new_jet=list(map(str,nj[tar[4]])),residual=list(map(str,residual)),pass_=bool(residual==zero),even_origin_parities=parity))
  out.append(dict(W=W,last=last,rows=rs))
print('slope passes',sum(r['pass_']for o in out for r in o['rows']),'/',sum(len(o['rows'])for o in out))
print('failures',[(o['W'],o['last'],r['source'],r['residual'])for o in out for r in o['rows']if not r['pass_']])
print('odd origins',[(o['W'],o['last'],r['source'])for o in out for r in o['rows']if not all(r['even_origin_parities'])])
Path(__file__).with_name('ALL_LONG_PRIMITIVE_SLOPES.json').write_text(json.dumps(out,indent=2))
