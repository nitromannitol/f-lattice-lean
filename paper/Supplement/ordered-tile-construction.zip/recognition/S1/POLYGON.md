# SAVED1 stationary polygons, both phases

**Uniform result under the same strict birth cone.** Let a=(d,n), R=(e,r), with n>=2,d-n>=3,r>=1,e-r>=2, and creation phase W'=1-W. Thus det(a,R)=2W-1. Set Z=2a+R=(D,N), effective A=Z-a=a+R, C=A+kZ, k>=1. Let z belong to the genuine restored alternate Z crop produced at phase W'. Then:

* Current W0: every z+iZ, 0<=i<=2k-1, lies in E(C).
* Current W1: every z+2A+iZ, 0<=i<=2k-2, lies in E(C). The final index i=2k-1 lies in E(C) or E(C)+2C. If above its actual upper longitudinal row, subtracting2C gives exactly z-Z in E(C).

There is no negative fictitious creation parent. All source rectangles below use the REAL birth parents a,R and phase W'=1-W. No source scalar or recurrence claim is made.

## Authentic swapped R2 rows

Let T=T_Z, K=M(A,Z)=T-M(a,Z), L=D+N, c=D-N. Read the actual all-sector even-alternate rows in `check_strict_corrected_even_primary_support_transport.py` using creation W', not current W. In both phases
 t in[L-T+2-h,h],
with h=D on odd sites, h=c in the lower-sector even case and2N otherwise.

Current W0 (creation W1):
 s in[-ex,2K+2N+ex], ex=D-3N+2 on lower-sector odd sites,0 otherwise.
Current W1 (creation W0):
 s in[T-2K-2-ex,T+2N+2+ex], ex=D-3N-2 on lower-sector odd sites,0 otherwise.

These are containments of actual restored crops. The proof never assumes the rectangles are filled. In particular the two different signs in ex are retained literally.

## Exact effective coordinates and parity

Write epsilon=1-2W, so det(A,Z)=epsilon and a_A.Z=-epsilon. Then
 t_A=(K t-epsilon s)/T, s_A=(K s-2epsilon t)/T.
Current W0 query z+iZ:
 t_C=t_A+k t-i, s_C=s_A+k s+i(K+kT).
Current W1 query z+2A+iZ:
 t_C=t_A+k t-2k+i,
 s_C=s_A+k s+2T_A+2kK+i(K+kT).

Both shifts preserve physical parity. The genuine odd E(C) rectangle is
 even: t_C in[1-T_C,L_C-1], s_C in[0,2T_C+2N_C];
 odd: t_C in[N_C-T_C,D_C], s_C in[2-c_C,2T_C+L_C-2].
Its derivation via (-y,x-1)+Udual was independently checked in the preceding saved3 polygon audit and does not depend on the fictitious effective R'.

## Exact uniform rectangle certificate

Each target facet is affine in (t,s,i). Therefore checking the two source t endpoints, two source s endpoints, and the two extreme i values suffices. Both physical parities and both source-sector formulas are retained. The script checks the resulting polynomial margins after multiplying by positive T.

It suffices to prove each multiplied margin q obeys q+T>0: the actual target coordinate and the target bound are integers, so the actual unscaled slack q/T is an integer greater than -1, hence nonnegative. This is an integer argument, not rounding arbitrary real vertices to source sites.

All but the odd upper-t facets have nonnegative coefficients immediately under
 n=u+2,d=u+v+5,r=w+1,e=w+h+3,k=j+1,
with u,v,w,h,j>=0. For the odd upper-t facets at t=D, first use the exact identity
 KD=d_A T-epsilon c.
The numerator of upper-t slack becomes
 epsilon(c+s)-T*offset,
where offset=-i in W0, -2k+i in W1. This is the sole determinant reduction. The identity follows from det(a,R)=2W-1; it does not require the ineffective negative parent to satisfy a proper cone.

`check_vertices.py` checks all320 margins. Every q+T has a strictly positive constant and all nonnegative coefficients in the five nonnegative variables. The receipt reports320/320 pass. Sector inequalities are not needed for coefficient positivity, so using each authentic sector's rows on its actual sector is certainly valid. This is an unbounded parameter proof, not the exploratory finite search.

## Final W1 fold

At i=2k-1 the certificate keeps the exact t lower/upper facets and exact s lower facet, replacing only the s upper facet by s_C<=4T_C-1. Thus the final point has the right t and lower s rows and s_C<4T_C. If its s is within the true upper row it is already in E(C). Otherwise subtract2C: t is unchanged and s decreases by2T_C. The new s is above2N_C at even roots or above L_C-2 at odd roots, hence above its lower row, and is below2T_C, hence below its upper row. Since
 z+2A+(2k-1)Z-2(A+kZ)=z-Z,
this is exactly the proposed physical representative.

The certificate does not assert all final W1 roots are unshifted polygon points. The primary fold is part of the proved alternative and cannot simply be discarded. For values one must use the genuine primary character of the actual C field; this support argument introduces no new gauge.

## Scope

All indices of the real old restored crop are covered in both current phases, with the stated W1 final alternative. Incoming sites not belonging to that old crop require their own halo guard. Proper stationary source recognition, head affine jets, and current constructor scalar remain separate. No current recurrence enters this proof.
