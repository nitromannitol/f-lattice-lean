# Independent audit: upgrading strict priced heads to all lattice points of creation R2

## Verdict and exact meaning

PASS for the analytic priced-head/comparator identities, conditionally on the same genuine earlier STANDARD field invariants and source/affine calibration premises. In both phases of strict saved3 and strict saved1, one may replace “z belongs to the genuine restored earlier ALT native crop” by “z is any lattice point satisfying the exact creation-R2 rows of that earlier ALT,” with physical parity and actual creation phase retained.

There are two essential limitations:

1. A literal earlier ALT array has no value at a nonnative hole. At such points the assertion concerns its explicitly defined analytic continuation J(z)+gamma, where J is the earlier standard rounded midpoint and gamma is its already authenticated native scalar. It does NOT assert that the original array, clipped helper or actual current native output acquires that vertex.
2. The unperiodized current two-offer minimum is identified on every such placed analytic head. Equality with the actual current standard F_Q still needs the licensed E_Q condition. Actual current native points have the previously authenticated license; arbitrary added R2 points are not automatically in E_Q.

No nonnative old-ALT evaluation remains in the analytic proof after making this replacement explicit. No new recurrence/admission theorem is inferred for the analytic continuation.

## 1. The full D range replaces every old-ALT native-width use

Let Z=(D,N), T=T_Z, L=D+N, and use the actual birth odd creator a and birth phase Wb. In either birth phase the exact creation R2 transverse rows are

 L-T+2-h <= t(z) <= h,

where h=D at odd physical sites and h=D-N or2N at even sites according to the actual sector. In the strict cone N>=2 and D-N>=4, all these h satisfy h<=L-2. Thus the entire R2 interval lies in the genuine complete physical window

 [3-D-T, N+2D-1].

Indeed the lower-end margin is L+D-1-h>=D+1>0, and the upper-end margin is N+2D-1-h>=D+1>0. Therefore the earlier physical theorem gives 0<=D(z)<=2 at EVERY R2 lattice point, not just native ones. The integer midpoint

 J(z)=ceil((g(z)+g(z-sigma))/2)=g(z)-floor(D(z)/2)

is consequently defined with the required three-valued slip throughout R2. For W0, sigma=2A; for W1, sigma=-2A. In saved1 these differences equal the actual opposite-birth differences by the true zero primary Z period, because A=Z-a.

This substitution is stronger than merely observing finite agreement at holes. It uses the already proved complete physical scalar interval, whose scope is explicitly all physical sites in that transverse range.

## 2. Exact R2 is reflection invariant, including its holes

Put K=M(a,Z) and I=(1,-1). The actual birth-W0 rows are

 s in[-T+2K-2-ex, T+2N+2+ex],
 ex=D-3N-2 at lower-sector odd roots, zero otherwise.

Their endpoint sum is2K+2N, equal to s(2a+V_Z+I). The birth-W1 rows are

 s in[-ex,2T-2K+2N+ex],
 ex=D-3N+2 at lower-sector odd roots, zero otherwise.

Their sum is2T-2K+2N, equal to s(2Z-2a+V_Z+I). In both cases the t endpoint sum is L-T+2, also the t coordinate of the respective center. Both centers have even physical parity. Hence z and its reflection have the same parity and use the same h and ex; the reflection preserves the EXACT R2 lattice set in both directions, including all holes.

For saved3 a=A, these are the previously used current-W0 and current-W1 centers. For saved1 A=Z-a and birth phase is opposite current phase:

 birth-W1 center2Z-2a+V_Z+I =2A+V_Z+I (current W0),
 birth-W0 center2a+V_Z+I =2Z-2A+V_Z+I (current W1).

Thus there is no unsupported support reflection or primary translation of the R2 set hidden in the saved1 substitution.

Moreover D(z')=2-D(z) follows globally from the genuine STANDARD reflection and its deck jets. It does not require an earlier ALT height at z or z'. This supplies the exact reflected endpoint algebra on nonnative R2 points.

## 3. Native-use ledger: saved3 W0

The all-crop dominance proof uses only R2 inequalities on z, the full E_Z price span, the authentic two-copy realization on E_Z, and full physical strips. Its former use of native 0<=D<=2 is replaced by Section1. The even reflected exception z=H-v is priced by the global standard reflection and h0/deck identities, not by the occupation of that point in the ALT array.

The whole-crop E_C geometry was proved from the full R2 inequalities and integer/parity arguments, not by enumeration of occupied points. Its conclusions therefore apply to every R2 lattice point directly.

The endpoint proof uses the same R2 rows to license z+2C, the full physical D window at shifted queries, the full E_Z P span, and globally valid harmonic pricing on the sole longitudinal rim. Its correlation proof uses only R2 estimates, true E_Z/raw-minimum charts, and the complete physical D range after transverse wrapping. The point x-2A=v exception is priced by the full h0 strip. None of these steps requires z itself or its reflected partner to be native; Section2 supplies their R2 membership.

## 4. Native-use ledger: saved3 W1

WHOLE_CROP_DOMINANCE and INTRINSIC_CORRELATION use only the exact W1 R2 rows, E_Z price/span/representation, and complete physical D intervals. The Pstd-versus-P0 argument is evaluated at its correctly shifted physical point and does not use an ALT value there.

WHOLE_CROP_AND_FINAL_PRIMARY_FOLD proves its polygon/fold alternatives from the complete source rectangles and integer inequalities. INDEPENDENT_HIGH_FOLD_AND_ATTAINMENT uses their actual upper facets, R2 transverse bounds and the reflected E_Z license. Since exact R2 reflection is proved in Section2, its paired-attainment argument remains valid at holes. The lower cap and attaining offer remain distinct parts of the proof; merely extending the cap would not suffice.

## 5. Native-use ledger: saved1 both phases

S1/POLYGON.md checks affine facets at every rectangle vertex, with the explicit integrality margin q+T>0. Its proof is already a theorem for every lattice point of the exact actual birth-R2 rows, despite its more conservative native-crop phrasing. It does not assume fictitious positive effective birth parents.

S1/INTRINSIC_PRICE.md uses those same actual birth-R2 rows. Its two even overshoot rims are priced by complete physical harmonic strips; no literal old-ALT occupation is used. The odd inequalities retain N>=3 and D-N>=4. Section1 replaces all native D-width assumptions.

The current-W1 high-fold/attainment portion uses actual birth-W0 R2 lower bounds, the exact effective reflection center, full E_Z birth-price span and a physical shifted D interval. Sections1-2 therefore cover its only apparent native dependencies. Source restoration and the outer scalar are inherited from their authentic native calibration, then used to DEFINE the same affine analytic continuation at added points; they do not create literal array values at holes.

## 6. Precise upgraded conclusion

Under the retained earlier STANDARD field and authentic source-jet premises, all strict saved3/saved1 heads in both current phases have the proved two-offer value

 J_Z(z) + (the authenticated current affine head jet)

for every lattice z in the exact earlier creation R2, whether occupied or a native hole. This is a uniform parameter result; no finite hole test is being extrapolated. Earlier standard E_Z price spans must be available on the WHOLE licensed polygon, and physical D/h0 strips on their WHOLE stated windows. Replacing either by a merely native statement would leave a real gap in the folding/rim arguments.

This upgrade can pay an incoming point only after that physical point, in the correct restored source coordinates, is shown to lie in R2. It does not establish a free universal halo enlargement beyond R2. Nor does it remove current E_Q licensing or the original source/outer normalization premises.
