# Canonical analytic ALT conjugacy: independent phase and gauge audit

**PASS for the globally defined canonical analytic fields**, up to one common scalar in each normalization. This discharges the two analytic beta inputs left conditional in DUAL_LONG_SLOPE.md, assuming the genuine earlier standard conjugacy/characters/reflection and the canonical analytic ALT definitions below. It does NOT recognize a literal alternate array on additional native sites, enlarge an array, reorder sources, or calibrate a current constructor.

## Conventions and analytic definitions

Rot(x,y)=(y,-x), J(x,y)=(-y,x-1), delta=(1,-1). Write a_Q=(n_Q,-d_Q), U_Q=Q for even Q, V_Q=(n_Q-d_Q,d_Q+n_Q). The genuine standard field obeys F_Q(z+Q)=F_Q(z), F_Q(z+V_Q)=F_Q(z)+a_Q.z+cV_Q, and F_Q(delta-z)=F_Q(z).

For even Q=2p+q created at phase W, set sigma=2(2W-1)p and define the canonical even analytic ALT
 A_Q(z)=ceil((F_Q(z)+F_Q(z+sigma))/2).
The canonical odd analytic definition through its even conjugate is, in phase0, A_even(Jz)+h0(z), and in phase1, A_even(delta-J(z+q))+h0(z+q), up to its chosen common scalar. Here q is the genuine even parent of that odd target. These are analytic definitions, not inferred from domain correspondence.

The exact discrete harmonic is
 h0(z)=H(z)-par(z)/4,
 H(x,y)=(x²+2xy-y²-2y)/4,
 par(z)=(x+y mod2).
This parity term is retained in all constant claims below.

## Even midpoint reflection and jets

The midpoint is invariant under z -> delta-sigma-z, since true standard reflection exchanges its two summands. It is also invariant under its zero-primary period Q. The genuine restored R2 centers are
 H'_Q=2p+V_Q+delta in phase0,
 H'_Q=2Q-2p+V_Q+delta in phase1.
Thus A_Q(H'_Q-z-V_Q)=A_Q(z), exactly: the latter center equals delta-sigma, or its translate2Q. This argument uses true normalized standard reflection and period, not a presumed symmetry of a clipped alternate crop.

Since a_Q.sigma=-2 in both phases, its true secondary jet is
 A_Q(z+V_Q)-A_Q(z)=a_Q.z+cV_Q-1.
The -1 survives the ceiling because the average shift is integral. This will fix the reverse-conjugacy sign and affine term.

## Even old Q=2a+R -> odd Q*

Let p*=R*, q*=a*, where even dual means half(d+n,d-n) and odd dual means(d+n,d-n). Put
 f=Rot(z-Q)+e1+tau,
 tau=0 in W0, tau=V_(p*)-q* in W1.

W0: J(f)=z-Q. Hence the odd analytic query is the same even midpoint by its zero-Q period.
W1: tau+q*=V_(p*), and J(f+q*)=z-Q-R. Therefore
 delta-J(f+q*)=H'_Q-z-V_Q.
The just-proved midpoint reflection makes this query equal A_Q(z).

Consequently the odd analytic ALT equals
 A_Q(z)+h0(f+Wq*)+constant.
Since q* has even coordinate sum,
 h0(f+Wq*)=h0(f)+W a.f+W h0(q*),
because B_H q*=a for B_H=[[1,1],[1,-1]]/2. Thus the exact affine gauge is beta=W a (the coordinate vector, not a_a). The extra constant is explicitly W h0(q*) plus the two chosen analytic normalization constants. The old field enters with a PLUS sign.

## Odd old O=C+Z -> even S=O*

Let p*=Z*, q*=C*, so S=2p*+q*. Define
 f=Rot(z-2O)+e1+tau,
 tau=-q* in W0; tau=-V_(p*) in W1.

W0: with u=J(z), exact coordinates give u+f=H'_S-S.
W1: with u=delta-J(z+Z), exact coordinates give f=u+V_S.

In W0, midpoint reflection about H'_S-V_S and zero-S periodicity give A_S(u)=A_S(f-V_S). In W1, apply the genuine V_S jet directly to f=u+V_S. Both cases yield the SAME relation
 A_S(f)=A_S(u)+a_S.f+T_S+cV_S-1.
Hence, putting v=z+WZ and using the odd analytic definition,
 A_S(f)=A_O(z)-h0(v)+a_S.f+constant.
Again the sign of the old alternate is PLUS. The opposite sign would contradict the exact secondary jet.

## Harmonic conversion, including parity and constants

Write f=Rot(v)+b. For these actual tau choices, b has odd coordinate sum, so par(f)+par(v)=1. Direct expansion gives
 -h0(v)-h0(f)
 =[-B_H b+(e1+e2)/2].f
   +(b1²+2b1b2-b2²-2b1+1)/4.
The +1 in the constant is the indispensable parity correction. It has no effect on the slope but must not be silently discarded in an absolute normalization.

For W0, b=-Rot(2O)+e1-q*; for W1, b=-Rot(2O+Z)+e1-V_(p*). Substitution gives
 a_S-B_H b+(e1+e2)/2 = C in W0, 0 in W1.
Therefore the reverse analytic gauge is beta=(1-W)C, exactly the target gauge required by the corrected LONG slope identities. The constant is the displayed harmonic constant plus T_S+cV_S-1 and the chosen analytic scalar difference; no root-dependent remainder remains.

## Verification and consequence

check_analytic_alt.py independently checks ten exact vector/quadratic identities, including both phase queries, both affine betas and the general harmonic slope/constant. ANALYTIC_ALT_IDENTITIES.json records the result. The midpoint reflection and ceiling jet are proved directly above for all physical sites.

Combined with DUAL_LONG_SLOPE.md, the transported LONG gradients now follow for these canonical analytic parent and target fields without an additional unexplained beta hypothesis. To identify them with genuine literal native alternate inputs, one must still use the previously authenticated restored native midpoint identity and its scalar wherever that original array is actually present. No native support equality or new producer recognition is asserted here.
