import sympy as s,json
from pathlib import Path
out=Path(__file__).resolve().parent
d,n,e,r,k=s.symbols('d n e r k');A=s.Matrix([d,n]);Z=2*A+s.Matrix([e,r]);D,N=Z
Tfun=lambda v:v[0]**2+2*v[0]*v[1]-v[1]**2
M=lambda v,w:(v[0]+v[1])*w[0]+(v[0]-v[1])*w[1]
TA=Tfun(A);T=Tfun(Z);K=M(A,Z);L=D+N;LA=d+n;c=D-N;P=A+k*Z;TP=Tfun(P);NP=P[1]
g=s.groebner([d*r-n*e-1],d,n,e,r,k,domain=s.QQ)
ids={'KD':K*D-d*T+c,'KL':K*L-LA*T-2*N,'TP':TP-TA-2*k*K-k*k*T,'discriminant':K*K-TA*T-2}
for name,v in ids.items():assert g.reduce(s.expand(v))[1]==0,(name,v)
u,v,w,h,l=s.symbols('u v w h l',nonnegative=True);sub={n:u+1,d:u+v+2,r:w+1,e:w+h+3,k:l+1}
ineq={'2K-D-2':2*K-D-2,'T-L':T-L,'K-N':K-N,'T-K':T-K,'T-2D':T-2*D,'T-2L+4':T-2*L+4,'lower_t_margin':TP-NP-(k*T+K+2*k+1),'upper_s_margin':2*TP-(2*k*k*T+2*k*K+(k+1)*L+2),'R2_lower_even_margin':T-2-2*M(A,s.Matrix([e,r]))-Tfun(s.Matrix([e,r])),'R2_lower_odd_loss_margin':T-2-2*M(A,s.Matrix([e,r]))-Tfun(s.Matrix([e,r]))+3*N-D}
polys={}
for name,q in ineq.items():
 p=s.Poly(s.expand(q.subs(sub)),u,v,w,h,l);assert all(a>=0 for a in p.coeffs())and p.TC()>0,(name,p)
 polys[name]={'constant':int(p.TC()),'terms':len(p.terms()),'polynomial':str(p.as_expr())}
(out/'WHOLE_CROP_ARITHMETIC.json').write_text(json.dumps({'identities':list(ids),'strict_positive':polys},indent=2)+'\n');print('PASS',len(ids),len(polys))
