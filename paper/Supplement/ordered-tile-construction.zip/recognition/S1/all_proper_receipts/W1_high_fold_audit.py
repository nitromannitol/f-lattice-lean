import sympy as s,json
from pathlib import Path
p=Path(__file__).resolve().parent
d,n,e,r,k=s.symbols('d n e r k');D=2*d+e;N=2*n+r;L=D+N;c=D-N;TA=d*d+2*d*n-n*n;T=D*D+2*D*N-N*N;K=(d+n)*D+(d-n)*N;B=K+k*T;LA=d+n
G=s.groebner([d*r-n*e+1],d,n,e,r,k,domain=s.QQ)
ids={'KN':K*N-n*T+L,'KL':K*L-LA*T+2*N,'even_threshold_numerator':B*2*N+2*s.Symbol('h')-T*(2*n+2*k*N)-2*(s.Symbol('h')-L),'odd_threshold_numerator':B*(L-2)+2*D-T*(LA+k*L-2)-2*(c-K-(k-1)*T)}
for key,q in ids.items():
 # h cancellation occurs before Groebner reduction.
 assert G.reduce(s.expand(q))[1]==0,(key,q)
(p/'HIGH_FOLD_IDENTITIES.json').write_text(json.dumps({'exact_mod_det_minus_one':list(ids)},indent=2)+'\n');print('PASS',len(ids))
