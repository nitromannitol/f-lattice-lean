"""Unbounded determinant-cone identities; pointwise integer rounding also proved by 3 intervals."""
import sympy as S
from pathlib import Path
import json
P=Path(__file__).resolve().parent
d,n,e,r,x,y,h=S.symbols('d n e r x y h');A=S.Matrix([d,n]);R=S.Matrix([e,r]);Z=2*A+R
b=lambda q:S.Matrix([q[1],-q[0]]);vv=lambda q:S.Matrix([q[1]-q[0],q[0]+q[1]])
lg=lambda q:S.Matrix([q[0]+q[1],q[0]-q[1]])
T=lambda q:-b(q).dot(vv(q));M=lambda q,p:-b(q).dot(vv(p));L=lambda q:sum(q);c=lambda q:(T(q)+L(q))/2;eta=lambda q:(T(q)-L(q))/2
v=vv(A);tau=2*A;K=M(A,Z);D,N=Z;te=vv(R)-R;z=S.Matrix([x,y]);Rf=Z+vv(Z)+S.Matrix([1,-1])
gb=S.groebner([d*r-n*e-1],d,n,e,r,x,y,domain=S.QQ)
ids={}
def eq(name,f):
 f=gb.reduce(S.expand(f))[1];assert f==0,(name,f);ids[name]=True
eq('raw_gap_v',-b(A).dot(te)+b(R).dot(v)+1)
eq('raw_gap_2A',b(R).dot(tau)-2)
eq('midpoint_normalization',b(A).dot(z-R)-c(A)-(b(A).dot(z+v+tau)+eta(A)+1))
eq('v_first_branch',b(A).dot(-R)-c(A)-(1-c(A)))
eq('v_second_branch',-eta(R)+b(A).dot(-vv(R))-c(A)+b(R).dot(v-R)+eta(R)+c(A))
eq('sA_negVR',lg(A).dot(-vv(R))+2)
eq('tau_v',lg(Z).dot(v)+2);eq('t_v',b(Z).dot(v)+K)
eq('tau_2A',lg(Z).dot(tau)-2*K);eq('t_2A',b(Z).dot(tau)-2)
eq('reflected_outlier_s',lg(Z).dot(Rf-v)-(T(Z)+2*N+2));eq('reflected_outlier_t',b(Z).dot(Rf-v)-(L(Z)-T(Z)+K))
eq('cross_t',T(A)*b(Z).dot(z)-K*b(A).dot(z)-lg(A).dot(z))
eq('cross_s',T(A)*lg(Z).dot(z)-K*lg(A).dot(z)-2*b(A).dot(z))
eq('K_d',K*d-D*T(A)-(d-n));eq('K_L',K*L(A)-L(Z)*T(A)+2*n)
eq('width',T(Z)-2*K-M(Z,R))
u,w,i,j=S.symbols('u w i j',nonnegative=True)
# A strict odd (d-n>=3,n>=2), R strict proper even (e-r>=2,r>=1).
sub={n:u+1,d:u+w+2,r:i+1,e:i+j+3};positive={}
def pos(name,f):
 p=S.Poly(S.expand(f.subs(sub)),u,w,i,j);assert p.TC()>0 and all(a>=0 for a in p.coeffs()),(name,p);positive[name]=True
for name,p in {'T_z_gt_2L':T(Z)-2*L(Z),'M_gt_2T_A':K-2*T(A),'M_gt_d':K-d,'M_gt_2':K-2,'T_A_gt_2d':T(A)-2*d,'L_A_lt_T_A':T(A)-L(A),'no_odd_upper_excess1':L(Z)-1-(2*N+2),'no_odd_upper_excess2':L(Z)-1-(D-N),'stable_native_lower_even':L(Z)-S.Integer(0)-(D-N)-1,'stable_native_lower_even2':L(Z)-2*N-1}.items():pos(name,p)
out={'identities':ids,'strict_positive_polynomials':positive,'rounded_min_cases':{'h<=-1':'sum=2h','h=0':'sum=-1','h>=1':'sum=0'}};(P/'SYMBOLIC_ARITHMETIC.json').write_text(json.dumps(out,indent=2));print('PASS',len(ids),len(positive))
