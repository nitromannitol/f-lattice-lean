import sympy as s,json
from pathlib import Path
u,v,w,h=s.symbols('u v w h',nonnegative=True)
n=u+1;d=u+v+2;r=w+1;e=w+h+3
D=2*d+e;N=2*n+r;L=D+N;c=D-N;T=D*D+2*D*N-N*N;TA=d*d+2*d*n-n*n;K=(d+n)*D+(d-n)*N
ex0=D-3*N-2;ex1=D-3*N+2
qs={'N_ge3':N-3,'c_ge4':c-4,'d_ge2':d-2,'TA_gt2d':TA-2*d,'TA_gtLA':TA-d-n,'K_gt2':K-2,'K_gtc':K-c,'K_gtN':K-N,'2K_gtDplus2':2*K-D-2,'T_gt2K':T-2*K,'T_gt2L':T-2*L,'T_gtK':T-K,'2K_gtL':2*K-L,'2K_gtLplusex1':2*K-L-ex1,'W0_odd_native_lower':2*N-4,'S1_odd_low_top':2*N-6,'S1_other_odd_top':c-4,'S1_W1_umin_lower':T-D+3*N,'S1_W1_umin_other':T-2,'S1_W0_wmin_even':2*K+2,'S1_W0_wmin_odd_low':2*K+2-ex1-(2-c),'S1_W0_wmin_odd_other':2*K+2-(2-c),'old_A_harmonic_minus2':2*d-3,'old_A_zero_one_lower':d,'old_A_zero_one_upper':n+2*d-2,'R2_twindow_lower_odd':L-1,'R2_twindow_lower_c':L+D-1-c,'R2_twindow_lower_2N':L+D-1-2*N,'D_shift_window_upper_c':N+2*D-3-c,'D_shift_window_upper_2N':2*D-N-3,'D_shift_window_upper_D':N+D-3}
rows={}
for name,q in qs.items():
 p=s.Poly(s.expand(q),u,v,w,h);assert all(x>=0 for x in p.coeffs()),(name,p)
 rows[name]={'constant':str(p.TC()),'polynomial':str(p.as_expr()),'strict':bool(p.TC()>0)}
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2));print('PASS prose',len(rows))
