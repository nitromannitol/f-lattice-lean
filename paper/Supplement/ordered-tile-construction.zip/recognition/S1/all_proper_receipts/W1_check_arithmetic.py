import sympy as s
from pathlib import Path
import json
D0=Path(__file__).resolve().parent
d,n,e,r,k=s.symbols('d n e r k');DD=2*d+e;N=2*n+r;L=DD+N;c=DD-N;TA=d*d+2*d*n-n*n;T=DD*DD+2*DD*N-N*N;K=(d+n)*DD+(d-n)*N;TP=TA+2*k*K+k*k*T;NP=n+k*N
u,v,w,h,j=s.symbols('u v w h j',nonnegative=True);sub={n:u+1,d:u+v+2,r:w+1,e:w+h+3,k:j+1}
g=s.groebner([d*r-n*e+1],d,n,e,r,k,domain=s.QQ)
ids={'KD':K*DD-d*T-c,'KL':K*L-(d+n)*T+2*N,'disc':K*K-TA*T-2}
for a,b in ids.items():assert g.reduce(s.expand(b))[1]==0
res={}
for label,E in [('zero',s.Integer(0)),('lower',DD-3*N+2)]:
 qs={'T-E':T-E,'2K-L-E':2*K-L-E,'lower_s':2*TA-2+2*k*K-(k+1)*E,'upper_s':2*TA+2*k*K-(k+1)*(2*N+E)-2,'lower_t':TP-NP-(k*T+K+2*k+1),'last_s_lt_4TP':4*TP-(2*k*k*T+k*T+3*k*K+(k+1)*(2*N+E)+2)}
 for name,q in qs.items():
  p=s.Poly(s.expand(q.subs(sub)),u,v,w,h,j);assert p.TC()>0 and all(x>=0 for x in p.coeffs()),(label,name,p)
  res[label+'_'+name]={'constant':int(p.TC()),'polynomial':str(p.as_expr())}
(D0/'ARITHMETIC.json').write_text(json.dumps({'identities':list(ids),'positive':res},indent=2)+'\n');print('PASS',len(res))
