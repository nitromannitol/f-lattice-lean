import sympy as s
import json
T=lambda f:f[0]**2+2*f[0]*f[1]-f[1]**2
M=lambda p,q:(p[0]+p[1])*q[0]+(p[0]-p[1])*q[1]
add=lambda p,q:(p[0]+q[0],p[1]+q[1]);mul=lambda a,p:(a*p[0],a*p[1]);rot=lambda p:(p[1],-p[0]);V=lambda p:(p[1]-p[0],sum(p));dual=lambda p,o:((p[0]+p[1])//(1 if o else 2),(p[0]-p[1])//(1 if o else 2))
def bounds(f,odd,pa,p,q,W):
 d,n=f;tt=T(f);kk=M(p,q);eps=2*W-1;lower=d>3*n;upper=d<2*n;bal=not(lower or upper)
 if odd:
  b=W*(2-kk-T(q));centre=n+d-tt-T(p)-kk-2*W;hi=d-eps if pa or lower else 2*n
  return centre-hi,hi,b+((3*n-d if lower or bal else d-n)if pa else 0),b+2*tt+((d-n if lower or bal else 3*n-d)if pa else 2*n)-2
 b=(1-W)*(-2-2*kk-T(q));centre=tt+2*n+eps*(2*kk+T(q));hi=d if pa else(d-n if lower else 2*n);ex=d-3*n+2*eps if lower and pa else 0
 return n+d-tt+2-hi,hi,b-ex,centre-b+ex
# balanced odd hi exactly code: d-eps if parity else2n

def inside(z,f,o,p,q,W):
 lo,hi,sl,sh=bounds(f,o,sum(z)%2,p,q,W);d,n=f;x,y=z;return lo<=n*x-d*y<=hi and sl<=(d+n)*x+(d-n)*y<=sh

da,na,db,nb=s.symbols('da na db nb');p=(da,na);q=(db,nb);f=add(mul(2,p),q);ps=((db+nb)/2,(db-nb)/2);qs=(da+na,da-na);g=add(ps,qs)
def bs(f,o,pa,p,q,W,sec):
 d,n=f;tt=T(f);kk=M(p,q);eps=2*W-1;lower=sec=='lower';bal=sec=='balanced'
 if o:
  b=W*(2-kk-T(q));centre=n+d-tt-T(p)-kk-2*W;hi=d-eps if pa or lower else 2*n
  return centre-hi,hi,b+((3*n-d if lower or bal else d-n)if pa else 0),b+2*tt+((d-n if lower or bal else 3*n-d)if pa else 2*n)-2
 b=(1-W)*(-2-2*kk-T(q));centre=tt+2*n+eps*(2*kk+T(q));hi=d if pa else(d-n if lower else 2*n);ex=d-3*n+2*eps if lower and pa else 0
 return n+d-tt+2-hi,hi,b-ex,centre-b+ex
for sec in ['lower','balanced','upper']:
 for W in [0,1]:
  for pa in [0,1]:
   tarsec={'lower':'upper','upper':'lower','balanced':'balanced'}[sec];a=bs(f,False,pa,p,q,W,sec);b=bs(g,True,1-pa,ps,qs,W,tarsec)
   tau=(0,0)if W==0 else add(V(ps),mul(-1,qs));sh=add((1,0),add(mul(-1,rot(f)),tau));ts=g[1]*sh[0]-g[0]*sh[1];ss=sum(g)*sh[0]+(g[0]-g[1])*sh[1]
   iv=(ss-b[3],ss-b[2],2*(b[0]-ts),2*(b[1]-ts));gaps=[iv[0]-a[0],a[1]-iv[1],iv[2]-a[2],a[3]-iv[3]]
   G=s.groebner([da*nb-na*db-(1-2*W)],da,na,db,nb,domain=s.QQ)
   print(sec,W,pa,[s.factor(G.reduce(s.expand(v))[1])for v in gaps])
