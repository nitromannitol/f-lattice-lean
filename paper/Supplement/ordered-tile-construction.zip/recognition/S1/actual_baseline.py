from pathlib import Path
import sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D.parent))
from physical_heads import *
def go(w,k):
 bo=w.count('1')%2;W=1-bo;ow=w+'1'+'2'*k
 m,aa=alg.get_odometers(w);_,zf,af,rf=getFracs(w);a,Z,R=[(p.denominator,p.numerator)for p in (af,zf,rf)]
 A=add(Z,scale(-1,a));mx,ax=alg.get_odometers(ow);of,qf,cf,zff=getFracs(ow)
 C,Q,O=[(p.denominator,p.numerator) for p in(cf,qf,of)];assert C==add(A,scale(k,Z))and Q==add(scale(2,C),Z)and O==add(C,Z) and zf==zff
 F=review.Field(*Z[::-1],alg.export_tile(m[1])).g;FC=review.Field(*C[::-1],alg.export_tile(mx[2])).g;FO=review.Field(*O[::-1],alg.export_tile(mx[0])).g;FQ=review.Field(*Q[::-1],alg.export_tile(mx[1])).g
 S0=alg.export_tile(aa[1]);tr=add(R,scale(-1,v(a)));tr=tr if bo==0 and tr[1]>=0 else (0,0);S={add(z,scale(-1,tr)):h for z,h in S0.items()}
 H=add(scale(2*(1-2*W),A),scale(2*W,Z),v(Z),(1,-1));assert set(S)=={add(H,scale(-1,z))for z in S}
 az=add(R,scale(-1,v(A)));az=(0,0)
 results=Counter(); ex={}; samples=Counter();isamples=Counter();targetSr=alg.export_tile(mx[1])
 # Actual current alternate export undo current odd W1 translation -O_w when O_w2>=0.
 oshift=add(Z,scale(-1,v(C)));oshift=oshift if W and oshift[1]>=0 else(0,0)
 AltO={add(z,scale(-1,oshift)):h for z,h in alg.export_tile(ax[0]).items()}
 for z,h0 in S.items():
  u=add(z,scale(2*(2*W-1),A));dv=F(z)-F(u);J=(F(z)+F(u)+1)//2; assert 0<=dv<=2;results['old_height−J',h0-J]+=1
  for i in range(-1,2*k) if W else range(1,2*k+2):
   y=add(z,v(C),scale(2*W,A),scale(i,Z));x=add(y,scale(W,Z));jet=mul(b(C),y)+eta(C)+(1-W)
   I=0<=i<=2*k-1 if W else 1<=i<=2*k
   if I:
    g1=FC(add(y,scale(W-1,Z))); g2=FC(add(y,scale(-1,v(Z)),scale(-W,Z)))+mul(b(Z),y)+eta(Z)+2*W
    val=min(g1,g2)-J-jet;results['short_compare',val]+=1;ex.setdefault(('short_compare',val),(z,i))
    if y in targetSr:results['actual_native_Q',targetSr[y]-J-jet]+=1
    else:results['missing_from_Q_cache',i]+=1
   g1=FO(x);g2=FO(add(x,v(Z)))-mul(b(Z),x)+t(Z)-eta(Z)+1-2*W
   val=min(g1,g2)-J-jet;results['long_compare',val]+=1;ex.setdefault(('long_compare',val),(z,i))
   if y in AltO:results['actual_native_hatO',AltO[y]-J-jet]+=1
   else:results['missing_from_hatO_cache',i]+=1
 print('S1',w,k,'W',W,'birth',a,R,Z,'Aeff',A,'sites',len(S),sorted(results.items()),ex,flush=True)
go(sys.argv[1],int(sys.argv[2]))
