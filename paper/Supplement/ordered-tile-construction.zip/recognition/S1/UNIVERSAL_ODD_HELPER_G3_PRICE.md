# The G3 price for every strict odd-helper record, on the full earlier R2

**What is now uniform.** For both saved records that actually supply an odd-L helper (last1, last3), both current phases, and every stationary run length k≥1, the same two-offer substitution gives the existing even alternate midpoint on every nominal corrected even-standard SHORT and odd-alternate LONG G3 head. In fact it holds on the entire earlier creation-R2 lattice envelope, not only its occupied native sites. There is one proof for midpoint prices, not separate burning proofs for the heads. Actual target native height identification uses genuine inherited fields, source normalization and upper-right placement as specified below. This statement neither proves all ordinary sources nor implies all-word recurrence on its own.

## Setup and the two-offer substitution

Let a=(d,n) be the true old odd birth parent, R=(e,r) the true old even birth parent, and Z=2a+R=(D,N) the stored even fraction. Work in the strict proper cone n≥2, d−n≥3, r≥1, e−r≥2, with authentic creator phase and determinant. The current stationary odd base is
 A=a for saved3 (birth phase=current W),
 A=Z−a=a+R for saved1 (birth phase=1−W).
Let C=A+kZ, k≥1, Q=2C+Z, O=C+Z. For X=(d_X,n_X), set b_X=(n_X,−d_X), V_X=(n_X−d_X,d_X+n_X), T_X=−b_X.V_X, L_X=d_X+n_X, c_X=(T_X+L_X)/2, eta_X=(T_X−L_X)/2. Use genuine zero-primary and affine-secondary standard fields F_X; in particular their actual polygon target equals their genuine two-source minimum in the stated frame. All E spans, full harmonic and physical slip-strip bounds are for the right earlier phase. See signed saved3 proof in the bundle for exact earlier hypotheses, not a generic assertion that recurrent fields can be glued.

Put sigma=2(2W−1)A, D0(z)=F_Z(z)−F_Z(z+sigma), and define J(z)=ceil((F_Z(z)+F_Z(z+sigma))/2) on the whole plane. On all old R2 lattice points D0∈{0,1,2}: the entire transverse interval is in the independently established *complete physical* D band. The earlier genuine native ALT height there, when native, is J plus its authentic constant. At an unoccupied point J is merely its analytic continuation, not a new filled array entry. Both saved records preserve the correct earlier midpoint since the two candidate displacement vectors differ by a multiple of the true zero-Z period. The genuine reflected coordinate is
 z'=2A+V_Z+(1,−1)−z (W0), or 2Z−2A+V_Z+(1,−1)−z (W1).
Exact creation R2 is invariant under this parity-preserving reflection, including the low-sector odd widening. D0(z')=2−D0(z). Nothing is inferred from a drawing of the native crop.

After subtracting the G3 affine jet, the new raw comparator has two prices relative to F_Z(z):
  e_l(z), 1−D0(z)+e_h(z′).
Exact price means their minimum equals min(0,1−D0). All interior errors vanish. Exceptional index pairs are checked by (i) lower bounds on both and (ii) one of the two offers attaining the minimum. Individual equality of each endpoint offer is false already for strict saved3 native data.

**W0.** The jet is b_C.y+eta_C+1 at y=z+V_C+iZ. Stationary errors for odd A+mZ are computed at z+lZ. SHORT indices are the pair (i−1,2k−i) in C, range i=1,...,2k; LONG indices (i,2k+2−i) in O, range i=1,...,2k+1. **W1.** The jet is b_C.y+eta_C at y=z+V_C+2A+iZ. Errors are at z+2A+lZ. SHORT indices (i,2k−1−i) in C for i=0,...,2k−1; LONG indices (i+1,2k−1−i) in O for i=−1,...,2k−1. The W1 physical odd two-slip comparator is evaluated at x=y+Z and uses c_Z−1, not c_Z+1. Genuine earlier source and target reflection give these four exact formulas; see the signed proof and symbolic gauge audits. They depend on the effective current A and slope sign, not on falsely declaring A the original creator.

## Saved3: same-birth sign

The included SIGNED_STATIONARY_SUBSTITUTION report proves the two genuine stationary polygons, stationary raw formulas, both unmatched fringes, transverse-wrap cap and attainment. At the only transverse escape the exact four-field identity P(x)−P(x−2A)=D0(x)−D0(x+V_A) (W0) or its W1 backward version replaces evaluation of a raw donor outside its polygon. In the folded cap one uses an authentic primary translate and the full physical strip, not premature equality of each source. This step is unchanged upon extension to all R2: its former native use was exactly the R2 containment, native D-range and native reflected-site hypotheses, replaced here by the exact rectangular symmetry and full transverse D band. WHOLE_R2_UPGRADE documents every prior use.

## Saved1: do not substitute a negative creator

The true creator is a with the OPPOSITE birth sign. Although A=Z−a is a true odd sibling, Z−2A=−R is not a proper earlier even parent. Instead transform the old price by genuine periods. Write K0=−b_a.V_Z, K=−b_A.V_Z=T_Z−K0.

* Current W0, birth W1. Let P_b(u)=F_Z(u)−F_Z(u−V_a)−b_a.u, with E-span [eta_a−1,eta_a]. For the effective W0 P_e(z)=F_Z(z)−F_Z(z+V_A)+b_A.z one has P_e−c_A=P_b(z)−eta_a≤0 on old R2. The second stationary offer h satisfies
 h−F_Z(z)=P_b(z+2a+V_a)−eta_a+4−D0(z).
 The birth price at the shifted point is ≥eta_a−2 by at most one longitudinal E-fold. The sole extra even layer folds to harmonic s=2N+2, where the bound follows from the full h0 strip. Thus h≥F_Z+2−D0≥F_Z. All 0≤l≤2m−1 are physically in E(A+mZ), and l=0 already has error zero; the last l=2m−1 gives min(F_Z,h−1). Its possible lower error cannot undercut the target by the effective P_e≤c_A cap, and the paired ordinary offer attains the required value. For example the SHORT endpoint relative to F is min(0,1−D0,c_A−P_e)=min(0,1−D0).
* Current W1, birth W0. Let P_b(u)=F_Z(u)−F_Z(u+V_a)+b_a.u, with genuine E-span [c_a−1,c_a]. The effective W1 price P_e=F_Z−F_Z(·−V_A)−b_A. satisfies
 P_e(z+2A)−eta_A=P_b(z−2a)−2−c_a≤−1.
 Here the low birth rim is s=−T_Z−2; its +Z translate has s=−2, with both true inputs harmonic. The low-sector odd allowance uses the real birth sign and N≥3,c=D−N≥4. The low fringe is therefore ≥J. All required 0≤l≤2m−2 queries lie in E; the last lies in E or folds to z−Z via its true primary. A high fold forces old s above E_Z's upper row, so P_e(z)≤eta_A−1 and its high error is nonnegative. If D0=2 and the opposite reflected high end folds, the low site u=z+2A belongs to E_Z and the transformed native E-span gives P_e(u)≥eta_A−1. The displayed upper bound forces equality, and the low fringe attains −1. All other cases have an error-zero or correct interior offer as in saved3.

POLYGON.md+check_vertices.py verify 320 determinant-aware facet inequalities for the two swapped birth R2s with arbitrarily large parameters, not a sample test. INTRINSIC_PRICE.md independently expands both signed substitutions and harmonic rims. The geometry works with K=T_Z−K0, not with an invented positive R'.

## Literal source scope and what remains

The price identities compare explicit analytic fields on the whole G3 R2. For an actual saved1 native readout, use the genuinely restored z, not an exported point t mistaken for z. In current W1 (birth W0) the even primitive may restore by minus (R−V_a) when its second coordinate is nonnegative. Restoration adds no height scalar in the globally affine convention. The clean W0 first touching scalar is eta_A+1−gamma4; if the earlier restored primitive is J+gamma4, the two constants cancel. No unproved outer touching maximum can be concluded just from a matched slope or G3 index. Upper-right alignment needs actual helper bounds; literal finite padding remains separate. When an independent prefix already equals the comparator on all its sites, this whole-head equality and any genuine nonempty overlap force the actual touching gauge of the new G3: all overlap differences are the same. This is a route to *derive* the gauge, not an assumption of current recurrence.

| Source/target class | Established here |
|---|---|
| Earlier even ALT source, current corrected even-standard SHORT + odd-alternate LONG | G3 comparison on the whole earlier creation R2, both current phases, each valid strict saved1/3 record, every head and both endpoints. Actual affine/source frame and target chart requirements are explicit above. |
| Opposite-type corrected odd-standard SHORT + even-alternate LONG, strict saved1/2 | The inverse target odd primitive R2 lies inside the old paired even R2, using the primitive's own birth tau. Opposite balanced inclusion can fail; the hole/union argument must not be reversed. This geometric fact does not by itself verify target/primitive harmonic jets and gauges. See DUAL_TRANSFER_SCOPE.md. |
| Entire current native array, ordinary/fixed-prefix sources and current outer gauge | Not generally identified by a G3 theorem. |
| Endpoint carrier templates, smaller excluded birth cone, fixed finite padding | Not settled by this result. No all-word recurrence theorem is claimed. |
