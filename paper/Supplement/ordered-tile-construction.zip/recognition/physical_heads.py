from check import *
def add(*x):return tuple(map(sum,zip(*x)))
def scale(k,x):return tuple(k*y for y in x)
def mul(z,w):return sum(x*y for x,y in zip(z,w))
def b(z):return (z[1],-z[0])
def v(z):return (z[1]-z[0],sum(z))
def t(z):return -mul(b(z),v(z))
def eta(z):return (t(z)-sum(z))//2
def go(w,k):
 ow=w+'3'+'2'*k
 mats,alts=alg.get_odometers(w);po,Zf,Af,Rf=getFracs(w)
 Z,A,R=[(p.denominator,p.numerator) for p in (Zf,Af,Rf)]
 mx,alx=alg.get_odometers(ow);_,Qf,Cf,Zff=getFracs(ow); assert Zf==Zff
 C=(Cf.denominator,Cf.numerator);Q=(Qf.denominator,Qf.numerator);assert C==add(A,scale(k,Z)) and Q==add(scale(2,C),Z)
 F=review.Field(Z[1],Z[0],alg.export_tile(mats[1])).g
 Fc=review.Field(C[1],C[0],alg.export_tile(mx[2])).g
 Fq=review.Field(Q[1],Q[0],alg.export_tile(mx[1])).g
 S=alg.export_tile(alts[1]);o=add(R,scale(-1,v(A)));o=o if o[1]>=0 else(0,0); S={add(z,scale(-1,o)) for z in S}
 H=add(scale(2,A),v(Z),(1,-1));assert {add(H,scale(-1,z)) for z in S}==S
 tall=Counter();examples={}
 for z in S:
  u=add(z,scale(-2,A));J=(F(z)+F(u)+1)//2;zz=add(H,scale(-1,z))
  for i in range(1,2*k+1):
   y=add(z,v(C),scale(i,Z));e1=Fc(add(y,scale(-1,Z)));e2=Fc(add(y,scale(-1,v(Z))))+mul(b(Z),y)+eta(Z)
   f1=e1-mul(b(C),y)-eta(C)-1-F(z); f2=e2-mul(b(C),y)-eta(C)-2-F(u)
   assert f1==Fc(add(z,scale(i-1,Z)))-F(z) and f2==Fc(add(zz,scale(2*k-i,Z)))-F(zz)
   D=F(z)-F(u);tar=J+mul(b(C),y)+eta(C)+1
   key=(i,D,f1,f2,min(e1,e2)-tar,Fq(y)-tar)
   tall[key]+=1;examples.setdefault(key,z)
 print(w,k,A,R,Z,'sites',len(S),'hist',sorted(tall.items()),'ex',[(key,z)for key,z in examples.items() if key[-1] or key[-2]][:10],flush=True)
 return {'word':w,'k':k,'parent':ow,'A':A,'Z':Z,'n':len(S),'rows':[{'key':key,'count':n,'example':examples[key]}for key,n in sorted(tall.items())]}
if __name__=='__main__':
 out=[go(w,int(k))for w,k in zip(sys.argv[1::2],sys.argv[2::2])];print(json.dumps(out))
