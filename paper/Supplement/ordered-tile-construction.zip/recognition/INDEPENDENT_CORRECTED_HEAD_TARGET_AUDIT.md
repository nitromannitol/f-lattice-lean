# Independent corrected-even G3 target audit

Scope: strict saved3/W0, Z=2A+R, det(A,R)=1, C=A+kZ, Q=2C+Z, k>=1. All fields below are genuine earlier STANDARD global fields in their canonical restored frames. Write b_X=(n_X,-d_X), V_X=(n_X-d_X,n_X+d_X), T_X=-b_X.V_X, eta_X=(T_X-L_X)/2, and I=(1,-1). This audit independently verifies the scalar reduction. It does not assert the missing endpoint correlation from sampled agreement.

## Exact two-offer reduction

Let z be a true restored ALT_Z native point, z'=2A+V_Z+I-z, y=V_C+iZ+z, and B(y)=b_C.y+eta_C+1. The proposed genuine raw even two-source minimum is

 M_Q(y)=min(F_C(y-Z), F_C(y-V_Z)+b_Z.(y-Z)+eta_Z).

Using the TRUE C secondary jet F_C(x+V_C)=F_C(x)+b_C.x-(T_C+L_C)/2 and b_C.Z=-1 gives, without any support assumption,

 first offer - B(y) = F_C(z+(i-1)Z).

The true standard C reflection has center 2C+V_C+I. Its reflected second-source argument is exactly

 2C+V_C+I-(y-V_Z)=z'+(2k-i)Z.

Consequently the normalized second offer is

 F_C(z'+(2k-i)Z) + b_Z.z + 2k b_Z.Z + b_Z.V_C - b_C.V_Z + eta_Z -1
 = F_C(z'+(2k-i)Z)+b_Z.z+eta_Z-1.

Here b_Z.Z=0 and b_Z.V_C=b_C.V_Z by symmetry of the quadratic polarization. The even Z reflection and its zero primary period give

 F_Z(z')=F_Z(z-2A)-b_Z.z+2b_Z.A-eta_Z
         =F_Z(z-2A)-b_Z.z+2-eta_Z.

Thus the normalized second offer is EXACTLY

 F_Z(z-2A)+1 + [F_C(z'+(2k-i)Z)-F_Z(z')].

All signs, including the final +1 and the subtraction of eta_C+1, are fixed by this calculation. No raw/normalized scalar has been interchanged.

## Interior conclusion and its dependencies

For 2<=i<=2k-1, both shift indices i-1 and 2k-i lie in [1,2k-2]. Apply the separately proved earlier C polygon identity and stationary-run shielding on those two full crops. The two normalized offers become F_Z(z) and F_Z(z-2A)+1. Their minimum is J_Z(z) under the earlier authentic midpoint/range theorem. Hence M_Q(y)=J_Z(z)+B(y).

This is a raw-M identity first. Identifying it with the current standard F_Q(y) additionally requires y in the licensed actual E(Q) and the current F_Q=M_Q polygon theorem. No such license follows solely from either C-source identity. Similarly, identification with a literal G3 occurrence requires the genuine restored ALT_Z scalar and the actual occurrence origin V_C+iZ and jet B, not just congruence modulo a period. Those actual chronology/frame premises were supplied by the parent assignment and are not independently reconstructed here.

## Endpoint obstruction is real but does not refute the minimum

At i=1 and i=2k, the two indices are 0 and 2k-1. The interior inclusion theorem does not cover them. In particular F_C(z)=F_Z(z) on the whole restored ALT crop is FALSE.

Independent literal replay uses original_port_recursion and review.Field, not the abstract source identities: saved word113, A=(5,2), R=(17,7), Z=(27,11), k=1 and2. Genuine C words are1133 and11332 respectively. There are1720 restored ALT_Z sites; their z' partners are checked to lie in the same crop.

For each k the discrepancy triples (first-F_Z(z),second-[F_Z(z-2A)+1],min-J_Z) at i=1 have exact counts:

 (0,0,0):1231; (0,-1,0):298; (1,0,0):191.

At i=2k they are:

 (0,0,0):1231; (-1,0,0):298; (0,1,0):191.

Thus individual endpoint equality fails in both signs, while this test has no endpoint minimum discrepancy. The counts are diagnostic only, not an unbounded proof. Script corrected_head_endpoint_audit.py preserves the literal construction; its `BAD` printed examples after the audit enhancement are individual-offer discrepancies, NOT minimum counterexamples.

## Precise remaining endpoint obligation

The parent's endpoint formula for the second normalized offer reduces its extra branch to F_Z(z)+c_A-P0(z), where c_A=(T_A+L_A)/2 and P0(z)=F_Z(z)-F_Z(z+V_A)+b_A.z. Relative to J_Z(z)=F_Z(z)-floor(D(z)/2), its nonnegativity is exactly

 P0(z)<=c_A+floor(D(z)/2), D(z)=F_Z(z)-F_Z(z-2A).

With authentic D in{0,1,2}, this is P0(z)<=c_A+1_{D(z)=2}. In addition the first normalized offer must be >=J, and at least one of the three offers must attain J. These are correlated inequalities. Separate bounds P0<=c_A+1 and 0<=D<=2 do NOT suffice. The lower-s fold formula suggested by the parent can localize the missing correlation, but needs actual folded C membership and an earlier Z two-difference identity. No universal endpoint closure is claimed here.
