from pathlib import Path
import sys,z3 as z,json,hashlib,time
p=Path(__file__).parent;src=(p/'uniform.py').read_text();sys.argv=['uniform.py','reciprocal','geometry'];ns={'__file__':str(p/'uniform.py')};exec(src[:src.index('vs,gs=')],ns)
h,x,y,e,root=[ns[t]for t in['h','x','y','e','root']];k=z.Int('k');idx=sys.argv[-1] if False else None
# args preserved separately by environment: all12 checks fast and explicit.
rows=[]
for label,ell in[('zero',0),('first',1),('last',2*k-1)]:
 X=x+ell*e;Y=y+ell;dc,nc=1+k*e,k;TC=dc*dc+2*dc*nc-nc*nc;tv=nc*X-dc*Y;sv=(dc+nc)*X+(dc-nc)*Y;odd=(x+y)%2==1
 lo=z.If(odd,nc-TC,1-TC);hi=z.If(odd,dc,dc+nc-1);sl=z.If(odd,2-dc+nc,0);sh=z.If(odd,2*TC+dc+nc-2,2*TC+2*nc)
 margins=[tv-lo,hi-tv,sv-sl+(2*TC if label=='zero'else 0),sh-sv]
 for face,margin in enumerate(margins):
  s=z.Solver();s.set(timeout=120000);s.add(h>=0,k>=1,root,margin<0);f=p/f'pure3_geometry_{label}_{face}.smt2';f.write_text(s.to_smt2());t0=time.time();r=s.check();rec=dict(label=label,face=face,result=str(r),seconds=time.time()-t0,sha256=hashlib.sha256(f.read_bytes()).hexdigest());
  if r==z.sat:rec['model']=str(s.model())
  print(rec,flush=True);rows.append(rec)
(p/'PURE3_GEOMETRY.json').write_text(json.dumps(rows,indent=2)+'\n')
