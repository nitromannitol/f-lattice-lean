from pathlib import Path
import sys,json,z3 as z
p=Path(__file__).parent;sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import alg,review,getFracs
src=(p/'uniform.py').read_text();rows=[]
for family in['reciprocal','nearone']:
 sys.argv=['uniform.py',family,'audit'];ns={'__file__':str(p/'uniform.py')};exec(src[:src.index('s=z.Solver()')],ns)
 for hv in[0,1,2]:
  w='3'*hv if family=='reciprocal' else'2'*(hv+1);m,al=alg.get_odometers(w);zf=getFracs(w)[1];F=review.Field(zf.numerator,zf.denominator,alg.export_tile(m[1])).g
  alt=alg.export_tile(al[1]);alt={(x-zf.denominator+1,y-1):val for(x,y),val in alt.items()}if family=='reciprocal'else alt
  exprs=[z.simplify(z.substitute(v,(ns['h'],z.IntVal(hv))))for v in ns['vs']];coords=[tuple(z.simplify(z.substitute(v,(ns['h'],z.IntVal(hv))))if not isinstance(v,int) else z.IntVal(v) for v in pt)for pt in ns['points']]
  for x,y in alt:
   sub=((ns['x'],z.IntVal(x)),(ns['y'],z.IntVal(y)))
   assert z.is_true(z.simplify(z.substitute(ns['root'],(ns['h'],z.IntVal(hv)),*sub)))
   for val,pt in zip(exprs,coords):
    xx,yy=[z.simplify(z.substitute(v,*sub)).as_long() for v in pt];got=z.simplify(z.substitute(val,*sub)).as_long();assert got==4*F((xx,yy)),(family,hv,x,y,xx,yy,got,F((xx,yy)))
  rows.append(dict(family=family,parameter=hv,roots=len(alt),evaluations=len(exprs)*len(alt)));print(rows[-1],flush=True)
(p/'EVALUATOR_AUDIT.json').write_text(json.dumps(rows,indent=2)+'\n')
