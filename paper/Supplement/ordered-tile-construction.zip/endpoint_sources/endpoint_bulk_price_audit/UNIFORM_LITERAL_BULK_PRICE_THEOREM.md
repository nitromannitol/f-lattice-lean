# Uniform literal endpoint bulk prices, including the saved1 substitution

## Genuine fields and scope

This exact-arithmetic certificate applies to the complete occupied literal even alternate support S, including its exceptional corners, in two families:

* reciprocal: Z=(e,1), e=2h+3, h≥0, genuine birth a=(1,0), consumed RAW staircase-alternate frame;
* near-one: Z=(2d+1,2d−1), d=h+2, h≥0, genuine birth a=(d,d−1), R=(1,1), consumed doubled-ladder-alternate frame raw−(0,1).

F is the genuine global standard at Z, authenticated by its literal initializer and canonical deck laws. Let v=V_a, U=2a, c_a=(T_a+L_a)/2, eta_a=(T_a−L_a)/2, and define physical prices

 P(z)=F(z)−F(z+v)+a_a·z,
 D(z)=F(z)−F(z−U),
 H(z)=F(z−v−U)+a_a·z+eta_a+2−F(z).

These are actual endpoint births, not limits where a missing proper-field hypothesis is assumed. No current child field is used in the certificates.

## 1. Whole occupied support statements

For both families, 0≤D(z)≤2 throughout S.

For near-one, H(z)≥0 and P(z)≤c_a+1_{D(z)=2} everywhere on S, including its two literal extra sites.

For reciprocal, H≥0 everywhere except R=(3,e+1), where H=−1. The cap P≤1+1_{D=2} holds everywhere except L=(1−e,−1) and L0=(1−e,0), where P=2 and D=0,1 respectively. In particular the cap failure at L0 is a genuine occupied R2/bulk exception, not one of the two R2-excess corners. It cannot be removed by quoting the already paid excess-corner theorem.

The exceptions are exactly the actual ordered helper contacts discussed in PURE3_COMPLETE_G3_STEP.md. No additional exceptional threshold or parameter value was found or left implicit.

## 2. W0 zero-index fold prices, all stationary lengths

For C=a+kZ,k≥1, suppose z∈S satisfies the actual lower longitudinal condition s_C(z)<lo_s(E_C,parity(z)). Put JminusF=min(0,1−D(z)). Uniformly in k and the family:

 F(z+U)−F(z) ≥ JminusF,
 P(z−v)−c_a ≥ JminusF,
 P(z)≥c_a.

These are precisely the two constituents of the licensed primary-folded zero query and its attainment condition. They are not derived from an assumed native inclusion of z or z−v. The certificates include the actual unbounded k in the guard. Current fold geometry must still separately license the chosen C representative.

## 3. Saved1/W1 price substitution, with no proper-birth threshold

Let A=Z−a be the genuine effective current odd parent. Define the effective backward price P_eff(x)=F(x)−F(x−V_A)−a_A·x, and eta_A=(T_A−L_A)/2. The exact previously audited deck identities give

 P_eff(z)−eta_A=P(z)−c_a,
 P_eff(z+2A)−eta_A=P(z−2a)−2−c_a.

The following literal-support statements hold in BOTH families without exclusions:

 (a) P(z−2a)≤c_a+1 for every z∈S.
 (b) If s_Z(z)>upper_s(E_Z,parity(z)), then P(z)≤c_a−1 and F(z+2a)−F(z)≥0.
 (c) Write z'=2a+V_Z+(1,−1)−z. If D(z)=2 and s_Z(z')>upper_s(E_Z), then P(z−2a)=c_a+1.

Consequently the actual saved1 fringe has h_eff−F=eta_A−P_eff(z+2A)−D≥1−D≥−floor(D/2), hence h_eff is above the genuine old midpoint. Both high-fold constituents are nonnegative by(b), since z−2A≡z+2a modulo the zero2Z period. Condition(c) gives exact midpoint attainment in the reflected D=2 high-fold case. These remove the old proof's N≥3 and D−N≥4 threshold assumptions for these two genuine literal families; they do not replace the corresponding source/mask/geometry licenses.

## 4. Exact evaluator and quantifiers

uniform.py encodes the literal standard native support and its EXACT height formula, including all marked+1 sites. It works with4F to avoid floor ambiguity; the near-one quadratic parity correction is retained. At each required physical argument it selects a native representative

 w=z+iZ+jV_Z, |i|≤3, |j|≤2,

then pulls its value back by the genuine law

 F(z)=F(w)−j(a_Z·z−c_Z)+j(j−1)T_Z/2.

All seven required argument maps have their own unbounded coverage proof for each family. Thus the fallback value of the encoded selector is never consumed. Coherence of different representatives is the already authenticated standard field/deck theorem. Fixed address bounds are proved by these coverage queries, not inferred from finite tests.

The complete literal ALT support is encoded directly from original_port_base.py, in the stated consumed frame, including caps and extra sites. The parameter h is an arbitrary nonnegative INTEGER. Root coordinates are arbitrary integers subject only to the actual support. For the fold queries k is an arbitrary positive integer. Every theorem is proved by an UNSAT query for its negation; all constants and strict fold comparisons are in the saved raw SMT.

## 5. Independent checks and limits

There are34 unbounded UNSAT evaluator/price obligations. Two deliberate unexcluded reciprocal H/cap queries return SAT, demonstrating that the known exceptions are not vacuous. Each query was independently replayed through the standalone Z3 executable. The additional28 pure3 geometry obligations are included in FINAL_INDEPENDENT_CLI_REPLAY.json, for64 total matching results.

A separately written evaluator audit compares all seven encoded field evaluations at every actual old ALT point in six literal initializers against the original-port genuine global Field evaluator:4088/4088 agree. This finite check tests implementation fidelity, not the universal quantifiers. The proof is an exact-arithmetic computer-assisted proof, not a proof-assistant formalization or an independent second SMT encoding.

The saved1 price theorem is a transferable analytic component. It does not by itself prove authentic helper upper-right alignment, full current standard recognition, even-helper source rotation, outer touching constants, or physical recurrence. The pure3 full G3 constructor-step application, with its precise earlier-stage assumptions and retained older owners, is recorded separately.
