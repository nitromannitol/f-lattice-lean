import sys,json
from pathlib import Path
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
rows=[]
for family in['reciprocal','nearone']:
 for k in[0,1,2,3]:
  w=('3'*k)if family=='reciprocal'else('2'*(k+1));m,al=alg.get_odometers(w);zf=getFracs(w)[1];Z=(zf.denominator,zf.numerator);F=review.Field(Z[1],Z[0],alg.export_tile(m[1])).g
  A=(1,0)if family=='reciprocal'else(k+2,k+1);v=(A[1]-A[0],sum(A));U=(2*A[0],2*A[1]);TA=A[0]**2+2*A[0]*A[1]-A[1]**2;c=(TA+sum(A))//2;eta=(TA-sum(A))//2
  alt=alg.export_tile(al[1]);alt={(x-Z[0]+1,y-1):h for(x,y),h in alt.items()}if family=='reciprocal'else alt
  bad={key:[]for key in['H','cap','D','midpoint']}
  for z,av in alt.items():
   f=F(z);D=f-F((z[0]-U[0],z[1]-U[1]));P=f-F((z[0]+v[0],z[1]+v[1]))+A[1]*z[0]-A[0]*z[1];H=F((z[0]-v[0]-U[0],z[1]-v[1]-U[1]))+A[1]*z[0]-A[0]*z[1]+eta+2-f
   for key,b in[('H',H<0),('cap',P>c+int(D==2)),('D',D not in[0,1,2]),('midpoint',av!=f-D//2)]:
    if b:bad[key].append(dict(z=z,F=f,D=D,P=P,H=H,A=av))
  rows.append(dict(family=family,Z=Z,A=A,count=len(alt),bad=bad));print(family,Z,bad,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')
