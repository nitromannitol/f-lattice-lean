; benchmark generated from python API
(set-info :status unknown)
(declare-fun h () Int)
(declare-fun k () Int)
(declare-fun y () Int)
(declare-fun x () Int)
(assert
 (>= h 0))
(assert
 (>= k 1))
(assert
 (let (($x38 (<= x 3)))
 (let (($x39 (and (= y (+ (+ (* 2 h) 3) 1)) (>= x (- 4 (+ (* 2 h) 3))) $x38)))
 (let (($x32 (<= x 0)))
 (let (($x28 (= y (- 1))))
 (let (($x19 (>= y 0)))
 (let (($x26 (and (>= (+ x y) (- 2 (+ (* 2 h) 3))) (<= (+ x y) (+ (+ (* 2 h) 3) 2)) $x19 (<= y (+ (* 2 h) 3)) (>= x (- 4 (* 2 (+ (* 2 h) 3)))) (<= x (+ (* 2 h) 3)))))
 (or $x26 (and $x28 (>= x (- 1 (+ (* 2 h) 3))) $x32) $x39 (and (= x (- 1 (+ (* 2 h) 3))) (= y 0)) (and (= x 3) (= y (+ (* 2 h) 3)))))))))))
(assert
 (let ((?x77 (* k k)))
(let ((?x72 (+ 1 (* k (+ (* 2 h) 3)))))
(let ((?x78 (- (+ (* ?x72 ?x72) (* (* 2 ?x72) k)) ?x77)))
(let (($x88 (= (mod (+ x y) 2) 1)))
(let ((?x91 (ite $x88 (- k ?x78) (- 1 ?x78))))
(let ((?x81 (- (* k (+ x (* 0 (+ (* 2 h) 3)))) (* ?x72 (+ y 0)))))
(let ((?x103 (- ?x81 ?x91)))
(< ?x103 0)))))))))
(check-sat)
