# Complete pure3 W0 G3 recognition, SHORT and LONG

## Conditional constructor-step statement
Let e>=3 be odd, A=(1,0), Z=(e,1), C=A+kZ, k>=1, and O=C+Z. Use the actual reciprocal alternate support S and actual original ordered helpers, not an enlarged abstract R2. Assume the genuinely available earlier canonical ordinary stages at C and O, including their global deck/reflection laws, zero strips and full-E stationary realizations. O is the SAME-WORD ordinary stage built before the corrected LONG alternate; it need not be an earlier word.

Then every G3 occurrence of the actual pure3 SHORT and LONG helpers agrees with the respective proposed outer target at newly owned sites. At the two first-G3 contacts of each helper the incoming alternate offer is one above the target, and the genuinely older standard owner has exactly the target value. There are no other exceptions. Thus the ordered helper, not the incoming alternate alone, has the required G3 values throughout its actual G3 union, including both literal R2-excess corners and both adjacent bulk contacts.

This is a conditional constructor-step recognition result. It is not an unconditional recurrence theorem for this family or for arbitrary words. G1/G2 recognition, global comparison and a well-founded supply of earlier canonical stages must be assembled separately.

## Fields, phase, and available stage inputs
Write F for the actual reciprocal standard, v=V_A=(-1,1), and use P,D,H of UNIFORM_LITERAL_BULK_PRICE_THEOREM.md. In particular H is a PRICE DIFFERENCE, not the second roof itself. The true old alternate is

 J(z)=F(z)+q(z), q(z)=min(0,1-D(z)).

On their licensed canonical domains the genuine ordinary fields satisfy

 F_C(w)=min(F(w), F(w)+H(w)+2k-2),
 F_O(w)=min(F(w), F(w)+H(w)+2k).

For k=1 the first formula is supplied directly on the whole E_C by endpoint_G1_G2/reciprocal_pure3_initial_roof (four exact raw obligations and standalone replay). For k>=2 it is the earlier canonical ordinary stage with proper parents C_(k-1),Z. The O formula is supplied by that earlier-in-phase ordinary stage. Neither is deduced from current corrected recognition or from a roof asserted only on the occupied native support.

The consumed reciprocal alternate is in its literal RAW frame. Its centering and pure3 restoration cancel. The old alternate reflection is rho(z)=2A+V_Z+(1,-1)-z=(4-e,e)-z; it preserves S and sends D to 2-D.

## Every physical query is licensed
The 12 obligations in PURE3_GEOMETRY.json prove for every occupied z in S:

 z+lZ belongs to E_C for 1<=l<=2k-1.

At l=0 both transverse facets and the upper longitudinal facet hold, while the lower longitudinal deficit is at most 2T_C. If the lower facet fails, z+2C is therefore a true E_C representative. No proper-birth R2 inclusion is substituted for the actual support.

The 16 obligations in PURE3_OUTER_GEOMETRY.json prove that every y=z+V_C+iZ lies in the true target E_Q for SHORT, 1<=i<=2k, Q=2C+Z. For LONG, 1<=i<=2k+1, every such y lies in the lower-sector creation R2 of O. Its lower-sector condition is d_O-3n_O=(e-3)(k+1)+1>0. These checks use the authenticated creation-R2 rows, not a newly inferred native-domain theorem.

Each margin is affine in the occurrence index, so its endpoint queries cover the whole index interval. All remaining parameters are unrestricted integers in their stated ranges.

## Bulk recognition, including zero-query folding
Put e_l(z)=F_C(z+lZ)-F(z+lZ). Away from the four contacts listed below, the whole-support price theorem gives H>=0 and P<=1+1_{D=2}. Consequently e_l=0 for 1<=l<=2k-2, and e_(2k-1)=min(0,H-1).

At index zero, if native, e_0=0. If folded, its exact error is

 e_0=min(F(z+2A)-F(z), P(z-v)-1).

Both terms are >=q(z) by the unbounded guarded fold certificates. The same guard gives P(z)>=1. The reflected fringe offer is exactly min(1-D(z),1-P(z)); the cap proves it >=q. Attainment follows: D=1 or2 attains through 1-D; D=0,P=1 attains through 1-P; D=0,P<1 cannot be folded and the first offer is zero.

After subtracting the common placed jet and F(z), the SHORT target at occurrence i is exactly

 min(e_(i-1)(z), 1-D(z)+e_(2k-i)(rho(z))).

This proves equality with q(z) on the reflection-invariant complement of the four contacts. For LONG the formula is

 min(E_i(z), 1-D(z)+E_(2k+2-i)(rho(z))),

where E denotes errors for O with stationary parameter k+1. Its endpoint nonfringe index is 1, so the same cap and attainment argument applies without a zero-index fold. This also proves every interior occurrence.

## Four contacts, exact ownership rather than false source equality
The complete exceptional table is

 point                  F                         J                      D P H
 L=(1-e,-1)             0                         0                      0 2 3
 L0=(1-e,0)             0                         0                      1 2 2
 R0=(3,e)               -e(e-1)/2+1               same                   1 0 0
 R=(3,e+1)              -e(e+1)/2+2               F-1                    2 0 -1.

rho exchanges L,R and L0,R0. At L,L0 all relevant e_l are zero. If the zero query is off E_C, the genuine physical zero strip pays it (t_C(L)=k+1 and t_C(L0)=k(1-e)>=1-d_C). At R and R0 respectively,

 e_l(R)=min(0,2k-3-l), e_l(R0)=min(0,2k-2-l).

Substituting these values in the preceding two exact target formulas shows a deficit of precisely one against the incoming J offer ONLY at RIGHT i=1, z=L,L0, and LEFT last index, z=R,R0. The last global index is 2k for SHORT and 2k+1 for LONG. At every other occurrence all four sites have exact incoming equality.

The historical literal ordered theorem PURE3_ENDPOINT_ORDERED_LONG_EXTENSION.md independently supplies exactly these older owners. In internal RIGHT coordinates the two retained points are (k-1)V_Z+(0,1) and (k-1)V_Z+(0,2); their preceding standard is one below the first incoming G3. The reflected LEFT points have the same one-unit difference. Later coherent G3 copies do not erase these lower owners. Thus the target deficit is the actual ordered helper value, not a defect to be discarded. The bulk L0 contact is essential: it is not one of the two R2-excess sites.

## Genuine placement, jet, and outer gauges
The literal internal RIGHT G3 origins are (k-1)V_Z+v+iZ, i=1..2k-1 SHORT or1..2k LONG. Its slope is a_A+(k-1)a_Z and scalar 1+(k-1)(e+1)+d_(k-1), where d_j=j eta_Z+T_Z j(j-1)/2. LEFT origins are iZ in descending order 2k-1..1 SHORT or2k-1..0 LONG, with zero inner slope and scalar.

PURE3_OUTER_SHIFTED_G2_AND_LONG_P_AUDIT.md binds the actual RIGHT outer origin V_Z, slope a_Z and scalar eta_Z; LEFT outer origins V_C+Z SHORT and V_C+2Z LONG, slope a_C and scalar eta_C+1. Substitution puts all occurrences in the common global jet

 a_C dot y + eta_C+1 + J(z).

The actual RIGHT clipped global points are kV_Z+(0,1),(0,2), exactly y=L/L0+V_C+Z. The source-only pure3 G2 correction does not move any G3 origin. With earlier G1/G2 recognition, the authentic chronological outer contacts select these scalar gauges. We do not derive their selection from finite touching alone.

## Verification and endpoint scope
The full receipt FINAL_INDEPENDENT_CLI_REPLAY.json binds 64 standalone matching results: 34 universal old-field coverage/price UNSAT queries, two intentional unexcluded SAT controls and 28 universal geometry UNSAT queries. The independently written finite original-port evaluator comparison is 4088/4088; it checks fidelity and does not supply universal quantifiers. The SMT proofs have not been independently reimplemented or proof-assistant checked.

The generic uncorrected ODD alternate dispatcher uses final1 or3. It retains the current even child of a pure prefix, so its pure endpoint rows are R1,N1,N0. A further3 on a pure3 prefix remains literal base dispatch. The clipped R0 analysis here is nevertheless required for actual moving ordinary and corrected LONG stages; it is not an additional UNC odd-star endpoint case.
