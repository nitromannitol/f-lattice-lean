from pathlib import Path
import sys,z3 as z,json,hashlib
p=Path(__file__).parent;src=(p/'uniform.py').read_text();sys.argv=['uniform.py','reciprocal','geometry'];ns={'__file__':str(p/'uniform.py')};exec(src[:src.index('vs,gs=')],ns)
h,x,y,e,root=[ns[t]for t in['h','x','y','e','root']];k=z.Int('k');dc,nc=1+k*e,k;TC=dc*dc+2*dc*nc-nc*nc;K=(dc+nc)*e+dc-nc;rows=[]
for long in[False,True]:
 dt,nt=(dc+e,nc+1)if long else(2*dc+e,2*nc+1);TT=dt*dt+2*dt*nt-nt*nt
 for label,i in[('first',1),('last',2*k+int(long))]:
  X=x+nc-dc+i*e;Y=y+dc+nc+i;tv=nt*X-dt*Y;sv=(dt+nt)*X+(dt-nt)*Y;odd=(x+y)%2==1
  if long:hi=dt+1;lo=dt+nt-TT-TC-K-hi;sl=z.If(odd,3*nt-dt,0);sh=z.If(odd,2*TT+dt-nt-2,2*TT+2*nt-2)
  else:lo=z.If(odd,nt-TT,2-TT);hi=z.If(odd,dt,dt+nt-2);sl=z.If(odd,2-dt+nt,0);sh=z.If(odd,TT+dt+nt-2,TT+2*nt)
  for face,margin in enumerate([tv-lo,hi-tv,sv-sl,sh-sv]):
   s=z.Solver();s.set(timeout=120000);s.add(h>=0,k>=1,root,margin<0);f=p/f'pure3_outer_{int(long)}_{label}_{face}.smt2';f.write_text(s.to_smt2());res=s.check();rec=dict(long=long,label=label,face=face,result=str(res),sha256=hashlib.sha256(f.read_bytes()).hexdigest());
   if res==z.sat:rec['model']=str(s.model())
   print(rec,flush=True);rows.append(rec)
(p/'PURE3_OUTER_GEOMETRY.json').write_text(json.dumps(rows,indent=2)+'\n')
