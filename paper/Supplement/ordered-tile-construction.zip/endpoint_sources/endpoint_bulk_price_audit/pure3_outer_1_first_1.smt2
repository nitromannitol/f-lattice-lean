; benchmark generated from python API
(set-info :status unknown)
(declare-fun h () Int)
(declare-fun k () Int)
(declare-fun y () Int)
(declare-fun x () Int)
(assert
 (>= h 0))
(assert
 (>= k 1))
(assert
 (let (($x38 (<= x 3)))
 (let (($x39 (and (= y (+ (+ (* 2 h) 3) 1)) (>= x (- 4 (+ (* 2 h) 3))) $x38)))
 (let (($x32 (<= x 0)))
 (let (($x28 (= y (- 1))))
 (let (($x19 (>= y 0)))
 (let (($x26 (and (>= (+ x y) (- 2 (+ (* 2 h) 3))) (<= (+ x y) (+ (+ (* 2 h) 3) 2)) $x19 (<= y (+ (* 2 h) 3)) (>= x (- 4 (* 2 (+ (* 2 h) 3)))) (<= x (+ (* 2 h) 3)))))
 (or $x26 (and $x28 (>= x (- 1 (+ (* 2 h) 3))) $x32) $x39 (and (= x (- 1 (+ (* 2 h) 3))) (= y 0)) (and (= x 3) (= y (+ (* 2 h) 3)))))))))))
(assert
 (let ((?x365 (+ (+ (+ y (+ 1 (* k (+ (* 2 h) 3)))) k) 1)))
(let ((?x9 (* 2 h)))
(let ((?x11 (+ ?x9 3)))
(let ((?x68 (+ 1 (* k ?x11))))
(let ((?x599 (+ ?x68 ?x11)))
(let ((?x465 (- (* (+ k 1) (+ (- (+ x k) ?x68) (* 1 ?x11))) (* ?x599 ?x365))))
(let ((?x321 (+ ?x599 1)))
(let ((?x408 (- ?x321 ?x465)))
(< ?x408 0))))))))))
(check-sat)
