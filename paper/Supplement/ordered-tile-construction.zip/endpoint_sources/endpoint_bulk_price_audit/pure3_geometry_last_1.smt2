; benchmark generated from python API
(set-info :status unknown)
(declare-fun h () Int)
(declare-fun k () Int)
(declare-fun y () Int)
(declare-fun x () Int)
(assert
 (>= h 0))
(assert
 (>= k 1))
(assert
 (let (($x38 (<= x 3)))
 (let (($x39 (and (= y (+ (+ (* 2 h) 3) 1)) (>= x (- 4 (+ (* 2 h) 3))) $x38)))
 (let (($x32 (<= x 0)))
 (let (($x28 (= y (- 1))))
 (let (($x19 (>= y 0)))
 (let (($x26 (and (>= (+ x y) (- 2 (+ (* 2 h) 3))) (<= (+ x y) (+ (+ (* 2 h) 3) 2)) $x19 (<= y (+ (* 2 h) 3)) (>= x (- 4 (* 2 (+ (* 2 h) 3)))) (<= x (+ (* 2 h) 3)))))
 (or $x26 (and $x28 (>= x (- 1 (+ (* 2 h) 3))) $x32) $x39 (and (= x (- 1 (+ (* 2 h) 3))) (= y 0)) (and (= x 3) (= y (+ (* 2 h) 3)))))))))))
(assert
 (let ((?x67 (* 2 k)))
(let ((?x68 (- ?x67 1)))
(let ((?x439 (+ y ?x68)))
(let ((?x72 (+ 1 (* k (+ (* 2 h) 3)))))
(let ((?x399 (- (* k (+ x (* ?x68 (+ (* 2 h) 3)))) (* ?x72 ?x439))))
(let (($x88 (= (mod (+ x y) 2) 1)))
(let ((?x93 (ite $x88 ?x72 (- (+ ?x72 k) 1))))
(let ((?x497 (- ?x93 ?x399)))
(< ?x497 0))))))))))
(check-sat)
