from pathlib import Path
import z3 as z,itertools,json,hashlib,sys,time
out=Path(__file__).parent
family=sys.argv[1];task=sys.argv[2];h,x,y=z.Ints('h x y');e=2*h+3;d=h+2
mn=lambda a,b:z.If(a<=b,a,b);mx=lambda a,b:z.If(a>=b,a,b)
if family=='reciprocal':
 D,N=e,1;ad,an=1,0;vx,vy=-1,1;cA=1;etaA=0
 def nat(X,Y):return z.Or(z.And(X>=2-e,X<=e,Y>=0,Y<=e+1,X+Y>=1,X+Y<=e+2),z.And(X==0,Y==0),z.And(X==2,Y==e+1))
 def val(X,Y):return -2*Y*(Y-1)+4*mn(X-1,0)+4*z.If(z.Or(z.And(X==0,Y==0),z.And(X==2,Y==e+1)),1,0)
 root=z.Or(z.And(x+y>=2-e,x+y<=e+2,y>=0,y<=e,x>=4-2*e,x<=e),z.And(y==-1,x>=1-e,x<=0),z.And(y==e+1,x>=4-e,x<=3),z.And(x==1-e,y==0),z.And(x==3,y==e))
else:
 D,N=2*d+1,2*d-1;ad,an=d,d-1;vx,vy=-1,2*d-1;cA=d*d+d-1;etaA=d*d-d
 def nat(X,Y):
  Y=Y+1
  return z.Or(z.And(X>=-1,X<=2*d+1,Y>=1,Y<=6*d-1,Y-X>=-1,Y-X<=4*d+1,z.Not(z.Or(z.And(X==-1,Y<=2*d+1),z.And(X==2*d+1,Y>=4*d-1)))),z.And(X==-1,Y==4*d+1),z.And(X==2*d+1,Y==2*d-1))
 def val(X,Y):
  Y=Y+1;p=(X+Y)%2
  corr=z.Or(z.And(X==-1,Y==4*d+1),z.And(X==2*d+1,Y==2*d-1),z.And(Y-X==2*d,X>0,X<2*d))
  return -(X-Y)*(X-Y)+p+4*(mn(0,2*d-Y)+mx(0,Y-X-2*d)+mn(0,4*d-Y))+4*z.If(corr,1,0)
 root=z.Or(z.And(y-x>=-2,y-x<=4*d,x>=-2,x<=2*d+1,y>=0,y<=6*d-3,z.Not(z.Or(z.And(x<=-1,y<=2*d-2),z.And(x>=2*d,y>=4*d-1)))),z.And(x==-2,y==4*d-1),z.And(x==2*d+1,y==2*d-2))
T=D*D+2*D*N-N*N;cZ=(T+D+N)/2;Vx,Vy=N-D,D+N
addresses=sorted(itertools.product(range(-3,4),range(-2,3)),key=lambda ij:(abs(ij[0])+abs(ij[1]),ij))
def ev(X,Y):
 ans=z.IntVal(0);guards=[]
 for i,j in reversed(addresses):
  xx,yy=X+i*D+j*Vx,Y+i*N+j*Vy;g=nat(xx,yy);guards.append(g)
  price=val(xx,yy)-4*j*(N*X-D*Y-cZ)+2*j*(j-1)*T
  ans=z.If(g,price,ans)
 return ans,z.Or(guards)
points=[(x,y),(x+vx,y+vy),(x-2*ad,y-2*an),(x-vx-2*ad,y-vy-2*an),(x-2*ad+vx,y-2*an+vy),(x+2*ad,y+2*an),(x-vx,y-vy)]
vs,gs=zip(*(ev(*p)for p in points));P=vs[0]-vs[1]+4*(an*x-ad*y);DD=vs[0]-vs[2];HH=vs[3]+4*(an*x-ad*y+etaA+2)-vs[0]
s=z.Solver();s.set(timeout=120000);s.add(h>=0,root)
if task.startswith('cover'):s.add(z.Not(gs[int(task[5:])]))
else:
 s.add(*gs)
 if task=='H':s.add(HH<0);s.add(z.Not(z.And(x==3,y==e+1)))if family=='reciprocal'else None
 if task=='cap':s.add(P>4*cA+z.If(DD==8,4,0));s.add(z.Not(z.And(x==1-e,z.Or(y==-1,y==0))))if family=='reciprocal'else None
 if task=='D':s.add(z.Or(DD<0,DD>8))
 if task=='saved1cap':s.add(vs[2]-vs[4]+4*(an*x-ad*y)>4*(cA+1))
 if task=='saved1high':
  sz=(D+N)*x+(D-N)*y;upper=z.If((x+y)%2==0,T+2*N,T+D+N-2)
  s.add(sz>upper,P>4*(cA-1))
 if task=='saved1attain':
  K=(ad+an)*D+(ad-an)*N;sz=(D+N)*x+(D-N)*y;upper=z.If((x+y)%2==0,T+2*N,T+D+N-2)
  s.add(DD==8,2*K+2*N-sz>upper,vs[2]-vs[4]+4*(an*x-ad*y)!=4*(cA+1))
 if task=='saved1foldD':
  sz=(D+N)*x+(D-N)*y;upper=z.If((x+y)%2==0,T+2*N,T+D+N-2)
  s.add(sz>upper,vs[5]-vs[0]<0)
 if task in ['saved3foldD','saved3foldP','saved3foldcap']:
  kk=z.Int('stationary_k');sc=(ad+an+kk*(D+N))*x+(ad-an+kk*(D-N))*y;lo=z.If((x+y)%2==0,0,2-ad+an-kk*(D-N));tar=z.If(DD<=4,0,4-DD)
  s.add(kk>=1,sc<lo)
  if task=='saved3foldD':s.add(vs[5]-vs[0]<tar)
  if task=='saved3foldP':s.add(vs[6]-vs[0]+4*(an*x-ad*y+(ad*ad+2*ad*an-an*an)-cA)<tar)
  if task=='saved3foldcap':s.add(P<4*cA)
 if task=='H_unexcluded':s.add(HH<0)
 if task=='cap_unexcluded':s.add(P>4*cA+z.If(DD==8,4,0))
fn=out/(family+'_'+task+'.smt2');fn.write_text(s.to_smt2());t0=time.time();res=s.check();rec={'family':family,'task':task,'result':str(res),'seconds':time.time()-t0,'query_sha256':hashlib.sha256(fn.read_bytes()).hexdigest()}
if res==z.sat:rec['model']=str(s.model())
(out/(family+'_'+task+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
