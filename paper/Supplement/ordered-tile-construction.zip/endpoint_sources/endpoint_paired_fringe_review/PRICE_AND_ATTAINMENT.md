# Independent price audit: N0, R1, N1, including the UNC m=1 star

## Verdict and hypotheses
The PRICE and attainment step passes on the complete literal source support for all three rows, without clipped contacts. It remains conditional on genuine stationary standard fields on the licensed E polygons, their physical deck/reflection laws, and actual target chart/placement licenses. The new remaining_G3_geometry certificates are the geometric supplier, not a consequence of this price argument. The final N1 transverse facet is now paid by the independently checked direct proof described below.

Rows: N0 is near-one birth a=(d,d-1), Z=(2d+1,2d-1), d>=2, effective A=a, current W0. N1 has the same birth and effective A=Z-a, current W1. R1 has reciprocal birth a=(1,0), Z=(e,1), e>=3 odd, effective A=Z-a, current W1. There is no R0 UNC odd-star case in the literal dispatcher.

The source is the COMPLETE literal ALT: near-one consumed coordinates are raw-(0,1), with no additional restoration; reciprocal consumed coordinates are raw, because centering and pure3 restoration cancel. This includes the two extra corners and all exceptional height corrections. No proper R2 containment is used. Both source reflections below reduce to rho(z)=2a+V_Z+(1,-1)-z, which preserves this true source and has D(rho(z))=2-D(z).

## Independent inputs actually consumed
Use endpoint_bulk_price_audit/UNIFORM_LITERAL_BULK_PRICE_THEOREM.md, its 34 unbounded old-field/coverage obligations and exact literal midpoint/reflection. These inputs are about the old field only. They include 0<=D<=2 everywhere. All references to P below mean the genuine birth-W0 forward price, not the effective saved1 price. c is the true birth c_a.

N0 uses H>=0 and P<=c+1_{D=2} everywhere, plus the three guarded W0 zero-fold bounds. Unlike reciprocal R0, near-one has NO exceptions to any of these whole-support claims.

R1/N1 use, everywhere, P(z-2a)<=c+1. On the old high-s region they use P(z)<=c-1 and F(z+2a)-F(z)>=0. Finally, if D(z)=2 and rho(z) is in that high-s region, they use P(z-2a)=c+1. All are separately certified for both literal families; the reciprocal R0 cap exceptions do not invalidate these DIFFERENT saved1 inequalities.

## N0 corrected SHORT and LONG
Set q(z)=min(0,1-D(z)), C=A+kZ, O=C+Z, k>=1. The W0 errors for stationary parameter m are at z+lZ. The genuine formula gives error min(0,H(z)+2m-2-l) when native. Thus indices 1 through 2m-2 are zero, and the upper fringe is min(0,H-1).

SHORT pairs indices (i-1,2k-i), i=1..2k, with second error weighted by 1-D. At a zero-index lower-s fold the exact first error is

 min(F(z+2a)-F(z), P(z-v_a)-c).

The saved guarded inequalities put each constituent above q. The reflected upper fringe transforms exactly to min(1-D,c-P). The intrinsic cap puts it above q. Attainment: D=1 or2 uses 1-D; D=0,P=c uses c-P; D=0,P<c cannot be folded (the fold implies P>=c), and the native first offer is zero. Reflecting gives the other endpoint. All interior pairs are immediate.

LONG uses m=k+1 and pairs (i,2k+2-i), i=1..2k+1. No zero-index fold occurs. The same upper-fringe cap and a zero-error interior give equality. This is strong equality throughout the actual source, not a first-ownership repair.

## R1 and N1 corrected SHORT and LONG
Let P_eff be the genuine backward effective price. Exact period algebra gives

 P_eff(z)-eta_A=P(z)-c,
 P_eff(z+2A)-eta_A=P(z-2a)-2-c.

Consequently the effective lower-fringe price h_eff-F=eta_A-P_eff(z+2A)-D is >=1-D. Its error e_0=min(0,h_eff-F) lies in [q,0]. Interior indices 1..2m-2 have zero error, since the stationary correction increases by l and h_eff-F>=-1.

At the last index 2m-1, if native, the error is zero (m>=1). If high-folded, the true representative is z-Z, obtained by subtracting the zero primary 2(A+mZ). The exact error is

 e_high=min(D_eff(z-2A), eta_A-1-P_eff(z)).

Here D_eff(z-2A)=F(z+2a)-F(z), by the true zero-Z period. The geometric high-implies-old-high result and the two literal high-s price certificates imply e_high>=0. It need NOT be zero; asserting zero here would lose the attainment issue.

SHORT pairs (i,2k-1-i), i=0..2k-1. At a low/high pair, D<=1 forces e_0=0, so the first offer attains q=0 and the high offer cannot undercut. When D=2 and the reflected high query is native it has error zero and the second offer attains -1. When that reflected query folds, the separate literal equality certificate P(z-2a)=c+1 gives h_eff-F=-1, hence e_0=-1. This supplies attainment even if the high error is positive. Reflection handles the reversed pair. This is the exact extra assertion a mere lower bound on the two offers would not supply.

LONG at m=k+1 has pairs (i+1,2k-1-i), i=-1..2k-1. Both indices are in 0..2m-2: there is no high fringe. For k>=1, an endpoint pairs a low fringe with a zero-error interior; if D<=1 the low error is zero, while D=2 is attained by the zero error on the opposite side. Interior pairs are immediate.

## UNC m=1: do not import an absent interior
At m=1 the N0 star uses TWO upper fringes (index1 on both sides). R1/N1 use TWO lower fringes (index0 on both sides). These are genuinely licensed by the m=1 specialization of the stationary geometry; W1 does NOT use the possibly high-folded index1 here.

For either phase the two individual errors obey q(D)<=e<=0 and q(2-D)<=e'<=0. For W1 this follows directly from the lower-fringe bound. For W0, the exact reflected upper-fringe formula min(1-D,c-P) and the whole-source cap, applied also at rho(z), give both bounds. They do not require H>=1.

Then min(e,1-D+e')=q(D): if D<=1, e=0; if D=2 then D'=0 forces e'=0. This exhausts D=0,1,2 and proves strong midpoint equality with no additional tiny-length exception.

## Literal shifts, jets, and limits
The actual global G3 coordinates and jets are:
 W0: y=z+V_C+iZ, jet a_C dot y+eta_C+1;
 W1: y=z+V_C+2A+iZ, jet a_C dot y+eta_C.
For LONG W1 the physical standard query is x=y+Z and the second arm uses c_Z-1. It is not the W0 c_Z+1 expression.

At UNC k=0 these specialize to the actual star origins V_A+Z (W0) and V_A+2A-Z (W1). The raw target is J(z)+a_A dot y+eta_A+1-W. If the restored primitive is J+gamma, its actual translated height differs by gamma-eta_A-1+W; authentic chronological touching, not this audit, fixes that scalar. Earlier proper packets are not flattened to primitive labels by this price calculation.

No additional price/attainment case remains in N0/R1/N1. Remaining assembly obligations are genuine earlier-stage supply, actual native/halo chart coverage wherever consumed, original helper upper-right alignment and chronological scalar selection. The geometry is supplied separately, not inferred from the price proof. This is neither a new all-word recurrence theorem nor an independent reimplementation of the old SMT evaluator.

## Final N1 geometry addendum
Read N1_LAST_TRANSVERSE_ROW_PROOF.md independently. With ell=y-x, the two margin coefficients are indeed x+(b+1)ell+b+2 and 2x+(2b+1)ell+2b+1 on odd roots, and x+(b+1)ell+2b+1 and 2x+(2b+1)ell+4b on even roots. For ell=-1 these reduce to x+1,2x; for ell=-2 to x-1,2x-2. At the sole ell=-3 corner x=2b+1 both odd coefficients are zero. For ell>=0, x>=-2 bounds t_A<=2,t_Z<=4 and both coefficients are nonnegative for b>=2. The literal y>=0 condition gives x>=1 or2 on the negative rows. The calculation proves the outstanding facet for every k>=1. Thus no missing stationary-query geometry remains in the stated three classes, given the other 37 recorded obligations. I did not rerun those 37 geometry encodings, which belong to the parent review.

Target distinction: these stationary-query licenses justify evaluating F_C/F_O inside the two-offer target formula. They do not alone authenticate the final original target native support or helper outer calibration. Those remain the named separate assembly premises above; no new gap in price or paired attainment is hidden there.
