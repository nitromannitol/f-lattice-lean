from pathlib import Path
import sympy as s,json,hashlib
D=Path(__file__).resolve().parent;R=D.parent.parent;pf=R/'recovery_20261101_0745/check_original_mixed_root_even_r1_uniform_gluing.py';ns={'__file__':str(pf)};exec(pf.read_text().split('def vertices')[0],ns);K,N=s.symbols('K N',integer=True);x,y=4*K+3,2*K+1;H=s.expand((x*x+2*x*y-y*y-2*y)/4);A,B=-y,x-1;do,no=6*K+7,2*K+3;T=do**2+2*do*no-no**2;c=-(T+do+no)/2;ans=[]
for j,h in [(0,0)]+[(j,h)for j in range(-2,3)for h in range(-1,2)if(j,h)!=(0,0)]:
 for r,e in enumerate(ns['cells']):
  X=A+j*do+h*(no-do)-e['p'][0];Y=B+j*no+h*(no+do)-e['p'][1];I=s.expand((2*X+Y)/14);J=s.expand((-X+3*Y)/14)
  if not all(a.is_Integer for a in s.Poly(I,K).all_coeffs()+s.Poly(J,K).all_coeffs()):continue
  sl=[s.Poly(s.expand((t*K+k-a*I-b*J).subs(K,N+1)),N).all_coeffs()for a,b,t,k in e['rows']]
  if not all(min(z)>=0 for z in sl):continue
  a,b,d,f=e['coef'];val=s.expand(a+b*K+d*I+f*J-7*J**2-h*(no*A-do*B+c)+(h*(h-1)//2)*T+H)
  if val==0:ans.append(dict(alias=[j,h],owner=r,copy=e['copy'],group=e['group'],local=e['u'],coarse=[str(I),str(J)],slacks=[list(map(str,m))for m in sl],value_residual=str(val)))
 if ans:break
assert ans
(D/'LOWER_ZERO.json').write_text(json.dumps(dict(scope='Every K>=1: true lower 3-tail corrected odd c(F0)=H(F0)+E_old(JF0)=0',source_sha=hashlib.sha256(pf.read_bytes()).hexdigest(),source_sites=len(ns['cells']),uniform_positive_witnesses=ans,first=ans[0]),indent=1));print(ans[0])
