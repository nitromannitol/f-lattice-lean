from pathlib import Path
import sys,json,hashlib
D=Path(__file__).resolve().parent;W=D.parent.parent;sys.path.insert(0,str(W/'recovery_20261101_0745/f_lattice_original_tests'));import original_port_recursion as O
P=O.export_tile(O.get_odometers('1')[0][0]);rows={str(z):P[z]for z in[(9,3),(10,3),(-2,7),(-1,7),(1,0),(2,0)]};assert all(P[z]==0 for z in[(9,3),(10,3),(1,0),(2,0)])
(D/'PRIMITIVE_ENDPOINTS.json').write_text(json.dumps(dict(b2_word='1',genuine_sites=len(P),heights=rows,literal_sha=hashlib.sha256(Path(O.__file__).read_bytes()).hexdigest(),b_ge4='P(2p−(r,1))=P(1+r,0) by zero primary and centered reflection. Genuine P upper Lp0 has Y=0 lower height0 then k=0 with value C_(b−1)(1+r)=0 as 0<=1+r<=2<=b−1. Global P<=0 closes both endpoint zeros.'),indent=1));print(rows)
