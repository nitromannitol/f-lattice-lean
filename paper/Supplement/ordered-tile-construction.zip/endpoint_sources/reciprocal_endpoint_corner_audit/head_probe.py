import sys,json
from pathlib import Path
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
rows=[]
for length in[1,2]:
 e=2*length+1;Z=(e,1);vz=(1-e,e+1);T=e*e+2*e-1;cZ=(T+e+1)//2
 old,_=alg.get_odometers('3'*(length-1));F=review.Field(1,e,alg.export_tile(old[1])).g
 for k in[1,2]:
  cw='3'*length+'2'*(k-1);cm,ca=alg.get_odometers(cw);om,oa=alg.get_odometers(cw+'2');C=(1+k*e,k);O=(1+(k+1)*e,k+1);vc=(C[1]-C[0],sum(C));tc=C[0]**2+2*C[0]*C[1]-C[1]**2;etaC=(tc-sum(C))//2;etaZ=(T-e-1)//2
  FC=review.Field(C[1],C[0],alg.export_tile(cm[0])).g;FO=review.Field(O[1],O[0],alg.export_tile(om[0])).g
  for long in[False,True]:
   end=2*k+int(long)
   for nm,z,alt in [('L',(1-e,-1),0),('R',(3,e+1),-e*(e+1)//2+1)]:
    for i in range(1,end+1):
     y=(z[0]+vc[0]+i*e,z[1]+vc[1]+i);jet=C[1]*y[0]-C[0]*y[1]+etaC+1
     if long:price=min(FO(y),FO((y[0]+vz[0],y[1]+vz[1]))-(y[0]-e*y[1])+cZ+1)
     else:price=min(FC((y[0]-e,y[1]-1)),FC((y[0]-vz[0],y[1]-vz[1]))+(y[0]-e*y[1])+etaZ)
     err=price-jet-alt;expected=-int((nm=='L'and i==1)or(nm=='R'and i==end));assert err==expected,(e,k,long,nm,i,err,expected)
     rows.append(dict(e=e,k=k,long=long,corner=nm,index=i,raw_source_excess=-err))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS',len(rows))
