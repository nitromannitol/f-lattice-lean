import sys,json
from pathlib import Path
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
rows=[]
for length in[0,1,2,3]:
 w='3'*length;ma,aa=alg.get_odometers(w);e=getFracs(w)[1].denominator;F=review.Field(1,e,alg.export_tile(ma[1])).g
 raw={(x-e+1,y-1):v for(x,y),v in alg.export_tile(aa[1]).items()}
 for name,z in [('L',(1-e,-1)),('R',(3,e+1))]:
  zz=(z[0]-2,z[1]);q=(z[0]-1,z[1]-1);H=F(q)-z[1]+2-F(z)
  rec=dict(e=e,name=name,z=z,F=F(z),Fminus=F(zz),D=F(z)-F(zz),A=raw[z],H=H,h=F(q)-z[1]+2)
  rows.append(rec);print(rec,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')
