import sympy as s,json
from pathlib import Path
h,j=s.symbols('h j',nonnegative=True);e=2*h+3;k=j+1;Z=s.Matrix([e,1]);C=s.Matrix([1,0])+k*Z;Q=2*C+Z
v=lambda X:s.Matrix([X[1]-X[0],sum(X)]);a=lambda X:s.Matrix([X[1],-X[0]]);T=lambda X:-a(X).dot(v(X));rows=[]
for name,z in[('L',s.Matrix([1-e,-1])),('R',s.Matrix([3,e+1]))]:
 for label,i in[('first',1),('last',2*k)]:
  y=z+v(C)+i*Z;t=a(Q).dot(y);ss=s.Matrix([sum(Q),Q[0]-Q[1]]).dot(y)
  for face,q in enumerate([t-Q[1]+T(Q),Q[0]-t,ss-(2-Q[0]+Q[1]),T(Q)+sum(Q)-2-ss]):
   pp=s.Poly(s.expand(q),h,j);ok=all(c>=0 for c in pp.coeffs());rows.append(dict(corner=name,index=label,face=face,pass_=bool(ok),polynomial=str(pp.as_expr())))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print(sum(x['pass_']for x in rows),len(rows),[x for x in rows if not x['pass_']])
