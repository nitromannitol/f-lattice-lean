# Reciprocal R2-excess corners: exact SHORT/LONG prices and the required older owners

## Scope and distinction of exceptional sets

Let e≥3 be odd, Z=(e,1), A=(1,0), v=V_A=(−1,1), C=A+kZ, k≥1. The genuine old reciprocal alternate A_e is consumed in RAW coordinates: export adds(e−1,1), and the actual all3 restoration including its extra e_y subtracts exactly that vector. Its two sites above the endpoint R2 are

 L=(1−e,−1),  R=(3,e+1).

These are NOT the two extra sites outside the initializer's polygon-plus-cap-band description in the earlier endpoint_birth_projection_audit note. L and R belong to the literal cap bands but violate the respective endpoint-R2 transverse facets by1. Both have odd physical parity. Confusing those two exceptional sets changes the problem.

This note pays the analytic corner comparisons using the actual pure3 standard/ALT formulas, true standard decks, and the explicitly stated current stationary polygon identity. It identifies a real failure of full incoming-source equality, not a failure of weak ordered assembly.

## 1. Genuine literal values, with exact native aliases

Write F=F_Z, U=2A=(2,0), eta_Z=(e²+e−2)/2 and

 H(z)=F(z−(1,1))−z_y+2−F(z),
 D(z)=F(z)−F(z−U).

The literal reciprocal formulas and genuine zero Z period give

 F(L)=0, F(L−U)=0, A_e(L)=0, H(L)=3;
 F(R)=−e(e+1)/2+2,
 F(R−U)=−e(e+1)/2,
 A_e(R)=−e(e+1)/2+1=−eta_Z, H(R)=−1.

Thus D(L)=0 and D(R)=2. In particular H(R)≥0 is FALSE: the proper full-E shielding statement cannot be extended to this excess corner.

All standard values above use explicitly genuine native sites. The aliases are

 L+Z=(1,0),  L−U+2Z=(e−1,1),
 L−(1,1)+2Z=(e,0),
 R−Z=(3−e,e), R−U=(1,e+1), R−(1,1)=(2,e).

Each satisfies the literal staircase standard domain, and substitution in its closed formula produces the displayed values. No raw native formula is evaluated at an unlicensed global point. The ALT values are the initializer's actual exceptional+1 values, not a height reset. probe.py/.json independently replays e=3,5,7,9.

The genuine old alternate reflection is

 z↦2A+V_Z+(1,−1)−z=(4−e,e)−z,

and interchanges L and R exactly.

## 2. Current query licenses, including the only missing zero query

At both corners the physical stationary queries are z+lZ. The exact coefficient audit guards.py proves

 R+lZ∈E_C for0≤l≤2k−1,
 L+lZ∈E_C for1≤l≤2k−1.

All margins at the index endpoints are affine in l, and their coefficients are nonnegative polynomials in (e−3)/2,k−1. L itself fails the lower longitudinal E_C facet; it is not silently admitted by a relaxed polygon. But t_C(L)=k+1 lies in the authentic global zero strip of the standard C, so F_C(L)=0=F(L) directly.

Assume the genuine current stationary identity, used ONLY at the licensed points,

 F_C(w)=min(F(w),h(w)+2k−2),  h−F=H.

The canonical Z primary and a_A·Z=−1 give H(z+lZ)=H(z)−l. Consequently the exact errors are

 e_l(L):=F_C(L+lZ)−F(L)=0 for0≤l≤2k−1,
 e_l(R):=F_C(R+lZ)−F(R)=min(0,2k−3−l).

At k=1 this gives e_0(R)=−1 and e_1(R)=−2. Both are real physical prices. The full proper-case assertion that the whole interior error vanishes is therefore not an endpoint theorem.

For O=A+(k+1)Z the identical argument with parameter k+1 gives E_l(L)=0 and E_l(R)=min(0,2k−1−l) through0≤l≤2k+1. All LONG queries below are covered.

## 3. Exact SHORT comparison: two one-unit incoming excesses

Use the genuine W0 raw SHORT comparator Q=2C+Z. At a head point y=z+V_C+iZ, subtract the head jet a_C·y+eta_C+1 and F(z). The exact two-offer algebra, including the old reflected corner z', gives

 min(e_(i−1)(z),1−D(z)+e_(2k−i)(z')).

The full nominal SHORT union has1≤i≤2k. Inserting the error table proves:

 * For L at i=1, the target is A_e(L)−1 plus the head jet.
 * For R at i=2k, the target is A_e(R)−1 plus the head jet.
 * At every other corner occurrence, the target is exactly A_e(z) plus the head jet.

Thus demanding equality of EVERY incoming G3 value to the target would be false at those two occurrences. The incoming actual raw alternate is one unit ABOVE the target there. It does not undercut an already retained lower owner.

The separate outer_guards.py proves all16 endpoint facet inequalities placing both full SHORT corner progressions inside the true standard E_Q. This is a genuine outer standard-domain license. It does not substitute E_O for an odd alternate's native domain.

## 4. Exact LONG comparison

For the phase-zero raw odd LONG comparator built from O=C+Z, the analogous normalized minimum is

 min(E_i(z),1−D(z)+E_(2k+2−i)(z')).

The nominal union is1≤i≤2k+1. Therefore only L at i=1 and R at i=2k+1 have target A_e(z)−1 plus the same head jet; every other corner occurrence agrees with A_e(z) plus that jet. The LONG terminal copy does not remove the initial older owner, and its reflected endpoint requires the corresponding older LEFT owner.

head_probe.py/.json independently evaluates the genuine chronological ordinary C/O fields for e=3,5 and k=1,2. Every observed raw-source excess is exactly the one predicted by these formulas. Those finite receipts are diagnostics, not the all-parameter proof.

## 5. Match to actual ordered helper ownership

The already proved PURE3_ENDPOINT_ORDERED_LONG_EXTENSION.md identifies the exact RIGHT first-G3 clipped contacts: raw old-source coordinates(1−e,−1) and(1−e,0). The former is L. Its LEFT reflected contacts are(3,e+1) and(3,e), the former being R. At each, the genuinely preceding standard prefix is one unit lower than the incoming G3. Both SHORT and LONG ordered helper constructions retain that previous value and retain an equality touch elsewhere, so their touching scalar is not changed.

Thus the corner discrepancy found here is exactly the required weak ownership pattern, not a residual unexplained sign. Once the actual helper-to-outer frame and scalar identify these owner contacts with y=L+V_C+Z and the corresponding last LEFT R occurrence, the earlier owner supplies the lower target, while every newly exposed exceptional-corner site has full equality. Source-only endpoint G2 shifts must remain as in that ordered theorem; moving the running G3 origin would break this match.

## 6. Exact remaining gates

1. The current genuine C/O stationary polygon identity is an explicit input. This note does not prove it for a pure-birth family from an invalid proper-birth induction.
2. Actual helper restoration, upper-right placement, outer affine scalar and chronological preceding-union contacts must be bound to the nominal head frames used above. The internal ordered theorem alone does not establish outer calibration.
3. The remainder of the endpoint R2/bulk must have its own licensed analytic comparison. The two extra-corner calculation does not globalize H≥0 or prove a false full-source equality at clipped contacts.
4. LONG requires its actual alternate native/support guard where a later physical recurrence proof uses one. Only the SHORT outer standard E_Q guards are proved here.
5. No physical recurrence conclusion or direct pure2 crop bijection is asserted. Pure2 has a different endpoint atom, different literal correction and different corner parities.
