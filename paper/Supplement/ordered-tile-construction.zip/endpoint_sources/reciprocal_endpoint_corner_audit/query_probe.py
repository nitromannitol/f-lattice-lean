import sys,json
from pathlib import Path
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
from original_parent_bad_ports import *
rows=[]
for length in[0,1,2]:
 w='3'*length;ma,aa=alg.get_odometers(w);e=getFracs(w)[1].denominator;F=review.Field(1,e,alg.export_tile(ma[1])).g
 for k in[1,2]:
  cw=w+'3'+'2'*(k-1);mx,ax=alg.get_odometers(cw);cf=getFracs(cw)[0];assert (cf.denominator,cf.numerator)==(k*e+1,k);FC=review.Field(cf.numerator,cf.denominator,alg.export_tile(mx[0])).g
  for name,z in [('L',(1-e,-1)),('R',(3,e+1))]:
   for ell in sorted(set([0,1,2*k-2,2*k-1,2*k])):
    x=(z[0]+ell*e,z[1]+ell);h=F((x[0]-1,x[1]-1))-x[1]+2;raw=min(F(x),h+2*k-2);row=dict(e=e,k=k,name=name,ell=ell,x=x,F=F(x),FC=FC(x),raw=raw,error=FC(x)-F(x),defect=FC(x)-raw);rows.append(row)
  print('done',e,k,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print([r for r in rows if r['defect']])
