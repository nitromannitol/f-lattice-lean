import sympy as s,json
from pathlib import Path
h,j,l=s.symbols('h j l',nonnegative=True);e=2*h+3;k=j+1;Z=s.Matrix([e,1]);A=s.Matrix([1,0]);C=A+k*Z;v=lambda X:s.Matrix([X[1]-X[0],sum(X)]);a=lambda X:s.Matrix([X[1],-X[0]]);T=lambda X:-a(X).dot(v(X));rows=[]
for nm,z in [('L',s.Matrix([1-e,-1])),('R',s.Matrix([3,e+1]))]:
 for label,ell in [('zero',0),('first',1),('lastminus1',2*k-2),('last',2*k-1)]:
  w=z+ell*Z;tc=a(C).dot(w);sc=s.Matrix([sum(C),C[0]-C[1]]).dot(w);lo,hi,sl,sh=C[1]-T(C),C[0],2-C[0]+C[1],2*T(C)+sum(C)-2
  for face,q in enumerate([tc-lo,hi-tc,sc-sl,sh-sc]):
   pp=s.Poly(s.expand(q),h,j);ok=all(c>=0 for c in pp.coeffs());rows.append(dict(corner=nm,index=label,face=face,pass_=bool(ok),polynomial=str(pp.as_expr())))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print('pass',sum(z['pass_']for z in rows),'/',len(rows));print([z for z in rows if not z['pass_']])
