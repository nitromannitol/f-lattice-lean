import sympy as s,json,hashlib
from pathlib import Path
h,j=s.symbols('h j',nonnegative=True);d=h+2;k=j+1;A=s.Matrix([d,d-1]);Z=s.Matrix([2*d+1,2*d-1]);C=A+k*Z;v=lambda X:s.Matrix([X[1]-X[0],sum(X)]);a=lambda X:s.Matrix([X[1],-X[0]]);T=lambda X:-a(X).dot(v(X));rows=[]
for zi,z in enumerate([s.Matrix([-2,4*d-1]),s.Matrix([2*d+1,2*d-2])]):
 for label,ell in [('zero',0),('first',1),('last',2*k-1)]:
  w=z+ell*Z;tc=a(C).dot(w);sc=s.Matrix([sum(C),C[0]-C[1]]).dot(w);lo,hi,sl,sh=C[1]-T(C),C[0],2-C[0]+C[1],2*T(C)+sum(C)-2
  for face,q in enumerate([tc-lo,hi-tc,sc-sl,sh-sc]):
   pp=s.Poly(s.expand(q),h,j);ok=all(x>=0 for x in pp.coeffs());rows.append(dict(corner=zi,index=label,face=face,passed=bool(ok),polynomial=str(pp.as_expr())))
p=Path(__file__);p.with_suffix('.json').write_text(json.dumps({'rows':rows,'producer_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n');print('PASS',sum(z['passed']for z in rows),'/',len(rows));print([z for z in rows if not z['passed']])
