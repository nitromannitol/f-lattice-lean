# Proper-selected endpoint births: bounded coordinate audit and a two-corner repair

This note does not extend a proper-birth theorem merely because its selected pair is proper. It checks explicit endpoint substitutions and literal initializer support. True field price hypotheses, actual helper alignment and chronological normalization remain distinct.

## 1. G1 geometry survives three endpoint-birth rows

The direct symbolic substitutions in g1_limits.py are:

 * reciprocal saved1/W1: old a=(1,0),R=(2h+1,1),Z=(2h+3,1),effective A=Z−a;
 * near-one saved3/W0: a=(h+2,h+1),R=(1,1),A=a;
 * near-one saved1/W1: the same old birth with effective A=Z−a.

For every h≥0 and every stationary length k≥1, all384 exact G1 projection/fold facets pass. They use actual integer parity rows, with multiplied slack q satisfying q+T_Z>0, so integer physical slacks are nonnegative. These include W0 direct second-arm support and first-arm four-alias coverage, and both W1 four-alias queries. Thus these endpoint births do not themselves create a G1 geometric obstruction. The proof does not include the excluded genuine 0/1 helper G2, or claim the reflected even-helper restoration without checking it.

For near-one saved3/W0, g2_nearone_limit.py additionally verifies all66 prior G2 coordinate/central-band/longitudinal-fold inequalities after the exact substitution R=(1,1),a=(h+2,h+1). W1 odd nesting is already stated for arbitrary proper selected pairs, not only proper births. These are geometric facts, not replacement proofs of the corresponding endpoint height inputs.

## 2. Exact literal G3 support and restoration

### Near-one even alternate

Write d≥2, A=(d,d−1), R=(1,1), Z=(2d+1,2d−1). This is the old even alternate selected by saved2^(d−1)3 and saved2^(d−1)1. The literal get_doubled_ladder_even_alt has internal parameter2d, raw coordinates (X,Y), and lower-left raw(0,1). Its exported/consumed coordinates are (x,y)=(X,Y−1). The restore candidate R−V_A=(2,2−2d) has negative second coordinate, so the actual translate_alts branch does not move it further. There is no all3 correction.

The literal bulk in these consumed coordinates is

 −2≤y−x≤4d, −2≤x≤2d+1, 0≤y≤6d−3,
 excluding (x≤−1,y≤2d−2) and (x≥2d,y≥4d−1).

Exactly two occupied sites lie outside this bulk:

 z_minus=(−2,4d−1), height −4d²−4d+1;
 z_plus=(2d+1,2d−2), height0.

They violate the respective diagonal rows by exactly1. Both have odd physical parity. Their heights follow directly by inserting the literal formula's exceptional+1; deleting that correction would give the wrong midpoint and cannot be repaired by a common scalar. The arbitrary-d support classification follows directly from the two explicit exceptional branches in original_port_base.py. literal_corners.py replays fourteen literal initializers as an independent diagnostic of the frame and exceptions.

### Reciprocal even alternate

For Z=(D,1), odd D≥3, the literal staircase alternate raw lower-left is(1−D,−1). Export adds(D−1,1); the actual pure-three restoration, including its extra e_y, subtracts exactly(D−1,1). Thus its consumed coordinates are raw coordinates, not exported ones.

Relative to the initializer's ordinary polygon plus its two horizontal cap bands, the only two additional occupied sites are(1−D,0),height0 and(3,D),height1−D(D−1)/2. Two further marked cap endpoints already belong to those cap bands but have their own+1 value corrections. This note identifies their support/value obligations; it does not assert a reciprocal all-G3 price theorem from the near-one calculation below.

## 3. Uniform near-one exceptional-site prices

Let F=F_Z, v=V_A and U=2A. Set

 H(z)=F(z−v−U)+a_A·z+eta_A+2−F(z).

Direct true standard aliases give, for all d≥2,

 F(z_minus)=−4d²−4d+2,  F(z_plus)=0,
 H(z_minus)=1, H(z_plus)=2.

Here is an explicit native audit, not a raw formula evaluated globally. In the genuine even standard exported frame, the points z_minus+Z, z_plus and b=(0,2d+1) are all literally native. Their values from get_doubled_ladder_even are respectively−4d²−4d+2,0,−(d+1)². The two h-arguments satisfy

 (z_minus−v−U)+Z=b,
 (z_plus−v−U)+V_Z=b.

The first uses the genuine zero Z period. The second uses its actual secondary jet. Substitution gives exactly the displayed H values. nearone_corner_values.py independently checks these native memberships and values in eight literal initializers, while the displayed formulas and guards are algebraic in d.

The previously authenticated literal midpoint identity, including the initializer's two extra corners, then gives D(z_minus)=2,D(z_plus)=0 for D(z)=F(z)−F(z−U). The genuine old alternate reflection z↦U+V_Z+(1,−1)−z interchanges the two corners exactly.

## 4. Uniform corner coverage in every needed stationary query

For C=A+kZ,k≥1, the new nearone_g3_corner_guards.py checks both corner points at z+lZ, l=0,1,2k−1, against every true odd E_C facet. All24 polynomial margins have nonnegative coefficients in d−2,k−1. Since the margins are affine in l, every0≤l≤2k−1 is covered. Both corners are therefore inside the actual current standard polygon throughout the required range. No prior old R2 containing the extra sites is fabricated.

Assume the genuine W0 stationary polygon identity F_C=min(F,h+2k−2) on E_C. Since H(z+lZ)=H(z)−l,

 F_C(z+lZ)−F(z)=min(0,H(z)+2k−2−l)=0

at BOTH exceptional corners and every0≤l≤2k−1. For odd LONG use the same theorem at parameter k+1, extending through2k+1. The exact previously verified SHORT/LONG two-offer head algebra now applies, with the true reflected corner and D in{2,0}. Both corners receive precisely their genuine earlier alternate values plus the authenticated head jet. In particular there is no new exceptional fringe value to extrapolate: all these stationary errors are exactly zero.

This closes the two literal near-one corner obligations uniformly, conditional on the current standard stationary representation and the existing primitive midpoint/head algebra. It is not a proof of the bulk G3 comparison at an endpoint birth, of helper UR restoration, or of chronological outer calibration. The bulk still needs its own endpoint-valid price hypotheses rather than an invocation of the proper-birth theorem outside its domain.

## 5. Bounded diagnostic and remaining endpoint work

Fresh original chronological examples saved2·3·2 and saved2²·3·2 checked both SHORT heads on all58 and112 genuine old ALT sites. Both raw and actual-current head differences were zero, including the extra corners. Those finite observations are diagnostic only; the corner proof above is all-parameter.

Remaining: reciprocal cap-band and extra-corner head prices in their actual raw frame; even-helper harmonic rotation with its own source/restoration map; endpoint-valid bulk price/range inputs for both orientations; actual helper prefix/outer scalar and finite-padding guarantees. None is supplied merely by the384 G1 facet successes.
