from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
import original_port_recursion as alg
rows=[]
for d in range(2,9):
 w='2'*(d-1);ma,aa=alg.get_odometers(w);pts=alg.export_tile(aa[1]);expected={(-2,4*d-1):-4*d*d-4*d+1,(2*d+1,2*d-2):0}
 def bulk(p):
  x,y=p;return -2<=y-x<=4*d and -2<=x<=2*d+1 and 0<=y<=6*d-3 and not((x<=-1 and y<=2*d-2)or(x>=2*d and y>=4*d-1))
 extras={p:z for p,z in pts.items()if not bulk(p)};assert extras==expected,(d,extras,expected)
 rows.append({'family':'nearone','d':d,'extras':[[list(p),z]for p,z in extras.items()]})
for D in range(3,16,2):
 w='3'*((D-3)//2); # fraction1/D occurs at pure length(D-3)/2, including root.
 # Direct literal factory needs the actual pure word whose current even has denominator D.
 ma,aa=alg.get_odometers(w);assert alg.getFracs(w)[1].denominator==D
 exported=alg.export_tile(aa[1]);pts={(x-(D-1),y-1):z for(x,y),z in exported.items()}
 def bulk(p):
  x,y=p;return ((-D+2<=x+y<=D+2 and 0<=y<=D and -(2*D-4)<=x<=D)or(y==-1 and -(D-1)<=x<=0)or(y==D+1 and 4-D<=x<=3))
 expected={(1-D,0):0,(3,D):-D*(D-1)//2+1};extras={p:z for p,z in pts.items()if not bulk(p)};assert extras==expected,(D,extras,expected)
 rows.append({'family':'reciprocal','D':D,'extras':[[list(p),z]for p,z in extras.items()]})
p=Path(__file__);p.with_suffix('.json').write_text(json.dumps({'literal_diagnostics':rows,'producer_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n');print('PASS',len(rows),'literal supports')
