import sympy as S,json,hashlib
from pathlib import Path
h,l=S.symbols('h l',nonnegative=True);k=l+1
families=[('reciprocal_saved1',1,(1,0),(2*h+1,1)),('nearone_saved3',0,(h+2,h+1),(1,1)),('nearone_saved1',1,(h+2,h+1),(1,1))];rows=[]
for name,W,a,R in families:
 D,N=2*a[0]+R[0],2*a[1]+R[1];ad,an=(D-a[0],N-a[1])if W else a
 TA=ad**2+2*ad*an-an**2;T=D**2+2*D*N-N**2;K=(ad+an)*D+(ad-an)*N;B=K+k*T;TC=TA+2*k*K+k*k*T;dc,nc=ad+k*D,an+k*N
 for par in[0,1]:
  ts,ss=([2-T,D+N-2],[0,T+2*N])if not par else([N-T,D],[2-D+N,T+D+N-2]);tl,th,sl,sh=(1-TC,dc+nc-1,0,2*TC+2*nc)if not par else(nc-TC,dc,2-dc+nc,2*TC+dc+nc-2)
  arms=['r2','r1']if not W else['q1','q2']
  for arm in arms:
   for J in[1,k]:
    for it,t in enumerate(ts):
     for iss,s in enumerate(ss):
      if arm=='r2':tc=B*t-s-(J-1)*B*T;sc=B*s-2*t+2*(J-1)*T;tslack=0;sslack=0
      elif arm=='r1':tc=B*t-s-J*B*T+T;sc=B*s-2*t+2*J*T-B*T;tslack=TC;sslack=2*TC
      elif arm=='q1':tc=B*t+s-J*B*T;sc=B*s+2*t-2*J*T;tslack=TC;sslack=2*TC
      else:tc=B*t+s-(J-1)*B*T-T;sc=B*s+2*t-2*(J-1)*T-B*T;tslack=TC;sslack=2*TC
      for face,q in enumerate([tc-T*(tl-tslack),T*th-tc,sc-T*(sl-sslack),T*sh-sc]):
       poly=S.Poly(S.expand(q+T),h,l);ok=poly.TC()>0 and all(c>=0 for c in poly.coeffs());rows.append(dict(family=name,arm=arm,parity=par,J=str(J),vertex=[it,iss],face=face,passed=bool(ok),polynomial=str(poly.as_expr())if not ok else None))
p=Path(__file__);p.with_suffix('.json').write_text(json.dumps({'count':len(rows),'passed':sum(r['passed']for r in rows),'failed':[r for r in rows if not r['passed']],'producer_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n');print(len(rows),sum(r['passed']for r in rows));print([r for r in rows if not r['passed']])
