from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests')
import original_port_recursion as alg
rows=[]
for d in range(2,10):
 ma,al=alg.get_odometers('2'*(d-1));F=alg.export_tile(ma[1]);AA=alg.export_tile(al[1]);Z=(2*d+1,2*d-1);vz=(-2,4*d);a=(d-1,-d);v=(-1,2*d-1);U=(2*d,2*d-2);eta=d*d-d;TZ=Z[0]**2+2*Z[0]*Z[1]-Z[1]**2;cZ=(TZ+sum(Z))//2
 zm=(-2,4*d-1);zp=(2*d+1,2*d-2);base=(0,2*d+1)
 assert F[(zm[0]+Z[0],zm[1]+Z[1])]==-4*d*d-4*d+2
 assert F[zp]==0 and F[base]==-(d+1)**2
 # qminus+Z=base; qplus+VZ=base, actual secondary pulled backwards.
 for z,expectedF,expectedH in[(zm,-4*d*d-4*d+2,1),(zp,0,2)]:
  q=(z[0]-v[0]-U[0],z[1]-v[1]-U[1]);fq=F[base]if z==zm else F[base]-(Z[1]*q[0]-Z[0]*q[1])+cZ
  H=fq+a[0]*z[0]+a[1]*z[1]+eta+2-expectedF;assert H==expectedH
  rows.append(dict(d=d,z=z,F=expectedF,alternate=AA[z],H=H,used_native_alias=base))
p=Path(__file__);p.with_suffix('.json').write_text(json.dumps({'rows':rows,'producer_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n');print('PASS',len(rows),'literal corner value receipts')
