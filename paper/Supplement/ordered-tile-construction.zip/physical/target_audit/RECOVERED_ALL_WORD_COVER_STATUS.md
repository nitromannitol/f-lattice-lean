# Recovered all-word native cover: status and exact usable scope

## Verdict

**The relevant geometric theorem is already present and finally adopted in the recovered local work.** It is not merely the arithmetic cover of a surrounding rectangle. The final result states cover for every actual restored standard and alternate domain of the consumed original source recursion, at every proper emitted fraction. It therefore pays the support-cover premise of native recognition for the intended unbounded finite-support recursion, subject to the recorded component proofs. A new all-word cover project is not needed just because current height recognition is unfinished.

This review read the assembly, its final corrections, lower-sector/upper-odd adoption, the inner-domain bridge, and the consumed-definedness dependency. It did not rerun all historical source/cap SMT suites. It is an independent dependency/scope audit, not a new full replay of that large theorem.

## Primary local records and resolved HOLD

All paths below are under recovery_20261101_0745/:

1. ALL_ORIGINAL_STANDARD_AND_ALTERNATE_DOMAINS_HAVE_INTRINSIC_QUOTIENT_COVER.md.
2. ROOT_ADOPTION_ALL_ORIGINAL_STANDARD_AND_ALTERNATE_DOMAIN_QUOTIENT_COVER.md, final19:39 adoption.
3. INDEPENDENT_ALL_ORIGINAL_DOMAIN_QUOTIENT_COVER_MUTUAL_ASSEMBLY_AUDIT.md, including the final19:42 repair addendum.

The body of (1) and earlier paragraph of (3) contain an explicit HOLD: the pure2 LEFT G2 initializer was wrongly treated as0/E instead ofE/2E. Do not cite those paragraphs in isolation as the final status. The final addenda and (2) discharge the HOLD with these actual-shift repairs:

* UPPER_EVEN_STANDARD_SAVED_ONE_PAIR_HAS_AN_EXHAUSTIVE_ACTUAL_SOURCE_DISPATCH.md;
* INDEPENDENT_STANDARD_W1_SAVED1_PURE_TWO_ACTUAL_SHIFTED_CAP_INITIALIZATION_AUDIT.md;
* INDEPENDENT_PHASE_ZERO_SAVED_ONE_PURE_TWO_LEFT_G2_TRANSVERSE_SHIFT_AUDIT.md;
* INDEPENDENT_PHASE_ONE_CORRECTED_CONSUMED_EVEN_SOURCE_ALL_CONE_CAP_AUDIT.md.

Fixed a2/a3 and regular endpoints are separately checked in the correct receiver sectors. No old unshifted LEFT claim is reinstated. All29 named Markdown references extracted from the three primary assembly records exist locally.

## The theorem's actual lattice and support

For each proper fraction n/d and each restored standard or alternate native domain D,

 D + Lambda = Z^2,
 Lambda=<U,V>, U=mu(d,n), V=(n-d,n+d),
 mu=1 if d+n is even, mu=2 if d+n is odd.

Thus both generators have even coordinate sum. This is exactly the paper's L'(n,d), not the possibly parity-reversing undoubled primary. It agrees with the current convention: even fraction type has primary(d,n), odd fraction type has primary2(d,n).

The conclusion is a site cover, not a disjoint cell tiling, not D=H, and not a value-cocycle theorem. Arbitrary translation of the restored support preserves full quotient cover; the current native-recognition proof must still bind the corresponding height/gauge/phase restoration. An analytic dual map must transport the lattice and physical graph correctly, not merely transport the denominator/numerator label.

## Why lower atoms and opposite copies do not hide a current-cover assumption

ROOT_INDEPENDENT_CHRONOLOGICAL_CONSUMED_DEFINEDNESS_AND_BASIC_DOMAIN_AUDIT.md adopts cover-free finite support unions, genuine frames, standard BASIC and mandatory qq domains, alternate ACTIVE BASIC domains, and actual SET reflection. The selected four current outputs use OLD parent outputs and OLD auxiliaries. Record refresh and construction of NEXT auxiliaries happen afterward. Auxiliary pieces are not assigned fictitious full quotient covers.

The inner-domain bridge INNER_PARITY_HULL_FOLLOWS_FROM_COVER_BASIC_TRACES_AND_MANDATORY_QQ_EXTRAS.md uses an EARLIER standard's cover, its H upper bound and actual four traces/mandatory reflected extras to obtain its I lower set. It does not infer current cover from a currently assumed I. Optional internal pqqq extras are expressly excluded; upper-sector D=H is not assumed. The fresh ordinary six-source I inclusion then pays ordinary steps, and corrected steps have independent actual source-window/cap proofs.

ROOT_INDEPENDENT_LOWER_FULL_AND_UPPER_ODD_MUTUAL_QUOTIENT_COVER_AUDIT.md distinguishes lower full-parity cover from upper physical-odd cover. Lower H equality is available because no optional pqqq omissions occur there. It is NOT transported to upper physical-even domains by a bare reflection/duality. The later balanced and upper-even standard/alternate steps fill precisely that remaining scope.

Opposite window uses are bound to actual current/source SET-reflection centers. They do not assume HEIGHT reflection, periodicity, source coherence, current admission or recurrence. Both current alternate branches have their own cover steps; standard coverage is not substituted for alternate coverage. This separation is exactly what native recognition needs.

## Relation to the original paper and its proof issue

The original paper, local farey_recursion.tex in f_lattice_original_algorithm/arxiv_submission2, separately states geometric cover/extension ingredients: almost-tilings at lines722 onward, common-extension-pseudo-square at1704-1736, base alternate cover at1905-1918, and global extension at4081 onward. Its recurrence argument starts only after global extension and superharmonicity.

One may cite an independently accepted geometric cover lemma from that paper as a known input, but it must apply to the SAME native supports. Published mathematical tile coverage is not automatically coverage of a clipped exported array or a modified code-port support. The recovered domain theorem is more directly tailored to the actual consumed source lists and explicitly avoids height/recurrence premises.

Nothing in this review identifies geometric cover as the unresolved defect in the original recurrence proof. The recovered work explicitly marks cover closed and height/admission/recurrence open. Consequently it would be incorrect to reopen cover solely because the paper's final burning/interface argument is being replaced. Conversely, reading the published recurrence theorem as proof of the current target would be circular for an independent repair campaign.

## Finite-padding caveat remains distinct

The recovered notes call their objects “actual finite arrays” and prove support equals the union of placed finite source supports. Their proofs reason with those mathematical translated supports. Neither the reviewed assembly nor the consumed-definedness proof supplies a uniform bound guaranteeing every translated entry remains inside Julia's allocated storage rectangle.

The genuine translate_v implementation in final_code/build_odometers_init.jl lines125-135 discards entries outside that rectangle. Hence the recovered theorem is safely usable for the actual-frame, unbounded finite-support source recursion. It must not be promoted solely from its wording to an all-word no-clipping/termination theorem for fixed-padding execution. A literal-array claim still needs a separate proof that allocated translations preserve these supports, or an independently checked actual output cover. This caveat does not invalidate the mathematical source-domain cover theorem.

## Distinctness is separate, but not a new recurrence obligation

The original theorem:odometers at farey_recursion.tex176-182 explicitly asks for two distinct standard/alternate recurrent plane functions. If the current task is only to prove recurrence of all four true outputs, recognition of each independently recurrent candidate settles that task whether or not distinctness is reproved here. If claiming the full original theorem, bind an existing distinctness result or exhibit an actual normalized value/profile distinction. Domain cover does not prove it.

Do not unnecessarily strengthen the printed “distinct” to “not differing by any affine function” unless that is the campaign's intended projective claim. Since native recognition is stated projectively, a projective-class distinction, when claimed, must itself be established; a pair of arbitrary scalar normalizations is not evidence for it. No new distinctness proof is asserted in this audit.

## Recognition assembly after this lookup

Use the recovered final domain theorem as the cover input. Bind actual native frame and common gauge to the independently recurrent canonical field, then bind its parity-correct deck cocycle. Equality on every translated native representative follows, and the all-plane physical recurrence follows with no extra seam-star test. The native theorem remains insufficient only if these value/frame/cocycle inputs are missing, or if the claim concerns an unverified clipped Julia output rather than the mathematical source recursion.
