# Independent target audit: native recognition versus full physical recurrence

## Verdict

**Yes, with the actual period/phase and full translated-site cover bound.** If a literal finite output is, in its authenticated physical frame, the restriction of one already coherent recurrent plane field (up to a single integer affine gauge), and the prescribed copies of that output cover every physical lattice site and carry exactly that field's deck cocycle, its global extension is that recurrent field. No extra local seam-color or finite-torus burning proof is then required.

**No, native projective equality alone is not the full conclusion.** On a crop that does not cover the physical quotient, equality only identifies retained samples. It does not determine missing sites, guarantee the particular intended extension, prove the finite Julia routine returns, or show that a clipped implementation produced the mathematical tile claimed in the paper.

## What the original theorem actually requests

Local source: recovery_20261101_0745/f_lattice_original_algorithm/arxiv_submission2/farey_recursion.tex.

* Lines28-52 define the physical oriented F-lattice, integer superharmonicity on ALL Z^2, and recurrence by comparison on every finite strongly connected set with its physical incoming boundary. This is not recurrence of an isolated tile or of a quotient graph.
* Lines150-173 define M(n,d) and the parity-correct lattice L': use (d,n) as the primary when d+n is even, double it otherwise. The text explicitly warns that an odd period need not preserve the F-lattice Laplacian.
* Lines176-182, theorem labelled theorem:odometers, ask for TWO DISTINCT recurrent plane functions for each reduced0<n/d<1, with quadratic growth M(n,d) and the stated affine periodicity for every v in L'.
* Lines1704-1736, lemma labelled lemma:common-extension-pseudo-square, assert a unique plane extension from a compatible pseudo-square and its actual surrounding/translation rule. The proof uses an almost-tiling and compatible translated boundary strings, not just a local value match.
* The base-case proposition, lines1905-1918, separately lists standard almost-tiling, alternate translated cover, and recurrent extensions. In particular alternates are not simply assumed disjoint tiles.
* Lines4081-4145 distinguish three logical steps: global extension/growth, global integer superharmonicity, and recurrence. The final recurrence proof is not a consequence of the extension lemma alone.

These passages show that identifying an already proved recurrent plane field is a valid replacement proof of the physical conclusion, but the identification must include the extension data.

## Exact recognition lemma sufficient for the present proof architecture

Let D be the actual finite retained support in an authenticated physical coordinate system, f:D->Z the output, and Lambda the intended rank-two parity-preserving lattice. Let G:Z^2->Z be an independently constructed recurrent integer-superharmonic field. Suppose:

1. f(z)=G(z)+ell(z) on EVERY z in D, for one common integer-valued affine ell;
2. union_(lambda in Lambda)(D+lambda)=Z^2;
3. the prescribed output translation law is exactly the law of G+ell, including its constant character and quadratic cocycle, not merely the same Hessian or same slope vectors;
4. native-to-physical translation/rotation and restored alternate frame have been verified. If the map flips parity, use the actual F-lattice graph isomorphism/correcting harmonic term, not an unqualified spatial translation.

For any physical x choose x=z+lambda with z in D. The prescribed extension gives G(x)+ell(x). The same answer is obtained from every other native representative by premise3. Thus all overlaps are coherent, the extension is globally defined, and it equals G+ell everywhere. An affine function has zero F-lattice Laplacian and preserves the recurrence comparison after translating the competing function by that affine function. Therefore the output's physical extension is recurrent and has the same quadratic growth as G.

This proof needs no single crop containing an entire input star: the root and its two inputs may use three different native representatives. Once global equality has been established, their true values and hence their physical quotas agree automatically. Conversely, before global equality/cover, checking only native directed interiors does not identify boundary quotas.

A common scalar per returned matrix is harmless. A known affine gauge is harmless only when the cocycle is adjusted accordingly. Unspecified per-chart/per-deck scalars are not harmless: they do not supply premise3. The field G cannot be called recurrent solely because the finite output is claimed recurrent; its admission/rank/fort proof must occur earlier to avoid circular recognition.

The original theorem's distinctness requirement remains separate. Matching the standard and alternate restrictions to two proved recurrent fields suffices only if those two fields have also been shown distinct in the intended normalization (and, if the research claim is distinct projective classes, not merely different by an affine gauge). Full rank-two deck laws with the stated M give the growth once the residual is periodic; matching a Hessian label without the laws does not.

## How the old tile-cover theorem can be used safely

The paper's common-extension/almost-tiling and alternate-cover results can discharge premise2 if the ACTUAL retained support in the present argument has been identified with the relevant paper tile, or has independently been shown to retain a full representative set. It is not enough that an ideal unbounded source union has that cover. Likewise standard E cover does not automatically establish cover for a restored/clipped alternate crop.

If the present construction already proves global G directly for every rational/word, that proves the existence/recurrence part of the original mathematical theorem independently of a numerical export. Recognition of the finite algorithm is then an additional algorithm-fidelity claim. One should state which of these two claims has been proved, rather than using them interchangeably.

## The finite Julia implementation needs a separate caveat

Actual source files under recovery_20261101_0745/f_lattice_original_algorithm/final_code:

* odometer_recursion.jl lines1-29 chooses genuine parents by the last digit and pads them before calls; lines411 onward define get_odometers and its iterative correction state. This is the operative recursion. iterate.jl labels its setup as superseded, so it should not alone be cited as the current implementation.
* build_odometers_init.jl lines50-65 pads to six times the current maximum dimensions. It is finite padding, not an unbounded lattice allocation.
* The same file lines125-135, translate_v, explicitly retains a translated array entry ONLY if both target indices remain within the existing array. Entries outside are silently dropped. translate_va at140 onward then adds a slope in zero-based array coordinates.
* laplacian at lines31-43 computes only within the supplied array and leaves other sites NaN. It does not itself supply a physical all-plane boundary condition.
* Chronological merges in odometer_recursion.jl and iterate.jl calibrate through overlap-dependent min_nan operations. Lost support may change available contacts, lower-left/upper-right alignment, and later normalization; agreement on surviving values alone does not rule out such changes.

Accordingly a proof for the unbounded intended source recursion does NOT by itself prove that the literal fixed-padding Julia call succeeds for every word or outputs the full intended support. A theorem about literal finite outputs needs separate bounds showing no consequential clipping, or a direct proof that the actual clipped support still covers every required class and that all subsequent gauges/frames agree. If a routine fails before returning, there is no output on which native projective equality can be asserted. This is a real code-level distinction visible directly in translate_v, not merely a performance warning.

A precise final claim may therefore be: “The intended unbounded four-state recursion has coherent recurrent physical extensions for every admissible word; every finite implementation output whose frame, cover and character premises are verified is its corresponding restriction.” Claiming more about the distributed Julia implementation requires its own uniform padding/termination proof. No new failure example or assumption about a particular previously tested word is needed for this logical caveat.

## Bottom line for the current campaign

The proposed all-word analytic recurrent fields plus full native recognition CAN settle the user's physical recurrence problem. The final assembly must explicitly bind: real phase/restoration, common native gauge, intended parity-preserving deck characters, actual support cover, and the independently proved global recurrence of each candidate. Once these are bound, do not add an unnecessary separate seam-star proof. If only native equality is currently established, report exactly which cover/implementation premise remains rather than calling the finite crop itself recurrent.
