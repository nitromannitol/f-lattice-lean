# Upper W0 / saved-last1 even-class cover: phase-one source-history module inventory

2026-11-02 11:42 UTC. This is a dependency inventory, not an all-record theorem. All statements are domain-only, under defined literal touching and the earlier actual support/cover/mandatory-trace hypotheses used by their cited modules.

## Outer geometry

The current corrected EVEN standard output has outer W0, savedlast1. Its combined consumed even ALT_Q chain has phase1. The proved correlated full-period window, actual shared-source enrollment, and reflected opposite row are in UPPER_FIRST_EVEN_TRANSVERSE_GW_CLOSES_WITH_A_CORRELATED_ENDPOINT_WINDOW.md and its actual matching sources. The three upper inner-hull cones and coefficient determinant conventions are in UPPER_CLEAN_LAST_ONE_EVEN_CLASS_COVER_EXTENDS_TO_ALL_THREE_INNER_HULL_CONES.md. Genuine receiving child-deck shifts and both ordinary I-owner branches are retained.

## Consumed source histories

* UNC last1: high-strip shared-source proof, exact H_B cap and reflected I_A two-carrier endpoint; all three cones alongcaps close by12 polynomial cases+2 identical B-source twins each.
* UNC last2: UPPER_PHASE_ONE_LAST_TWO_UNC_ALTERNATE_HAS_THE_SAME_TRANSVERSE_REPAIR.md gives the actual restored star exclusion and licenses the same endpoint carrier from positivity of2A-B. All three cones have12 polynomial cases+2 twins.
* Corrected last3 with savedlast1/2: UPPER_PHASE_ONE_CORRECTED_EVEN_ALTERNATE_HIGH_STRIP_REDUCES_TO_TWO_ACTUAL_STANDARD_DOMAINS.md keeps actual RIGHT standard towers inside B@2A and excludes both LONG G3 chains/LEFT standards. UPPER_CORRECTED_EVEN_ALTERNATE_TRANSVERSE_ENDPOINT_REDUCES_TO_FIXED_PARENT_CARRIERS.md handles the terminal tower through the FIXED earlier parent, without the false inequality2A-currentB>0. UPPER_PHASE_ONE_CORRECTED_ALTERNATE_ALONG_CAPS_HAVE_TWO_SUFFIX_CERTIFICATES.md now has36 polynomial cases+4 literal B twins in EACH cone; both INNER/OUTER suffixes remain independent.

## Boundary faces

D0 faces are replayed from ORIGINAL unscaled Farkas polynomials at B=C=1,D=0, not inherited from D>=2 certificates. The high-cone literal near-one older odd alternate requires formalR2 PLUS two actual EVEN corners. Those exceptions are separately closed in UPPER_HIGH_ENDPOINT_LITERAL_EVEN_CORNERS_HAVE_SEPARATE_CAP_AND_TRANSVERSE_CERTIFICATES.md (4UNC+8corrected along-cap contradictions; negative transverse corner projections), independently audited by INDEPENDENT_UPPER_HIGH_LITERAL_EVEN_CORNER_CAP_AND_STRIP_AUDIT.md. Thus no fullR2 claim about that literal base is needed.

Any direct consumed literal root/endpoint source not represented by these strict or older-endpoint history templates must still use the already established literal/two-run initializer theorem. This inventory does not silently enlarge the template record partition.

## Not covered here

Outer W1 / consumed phase0, other saved outer records, current ALT quotient cover, and all height/recurrence assertions remain outside this inventory. The separate phase0 clean high-strip and endpoint H_A reduction do not yet close its actual optional-hole carrier. Physical-odd upper modules are owned separately and do not replace the physical-even correlated argument above.
