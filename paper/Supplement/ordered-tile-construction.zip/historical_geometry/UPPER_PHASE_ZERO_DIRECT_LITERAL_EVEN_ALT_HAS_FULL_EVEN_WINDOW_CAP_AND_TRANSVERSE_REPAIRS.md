# Direct literal even ALT: full physical-EVEN phase-zero window/cap/transverse repair

2026-11-02 13:19 UTC. Own-creation literal initializer, including3/5. Outer W1/savedlast1 corrected-even standard geometry. This source must NOT be replaced by a synthetic seven-operand UNC initializer.

Let a>=2, D=2a, A=(a,a-1), B=(1,1), P=A+B=(a+1,a), Q=2A+B=(D+1,D-1), T=T_Q=2D^2+4D-2. The actual literal even ALT_Q support is the selector in `LITERAL_NEAR_ONE_EVEN_ALTERNATE_HAS_ITS_ENDPOINT_CREATION_R2.md`, also reproduced in the audited physical-odd initializer. Its ordinary restored support is

    -2<=x<=D+1, 0<=y<=3D-3, -2<=y-x<=2D,

with (x<=-1,y<=D-2) and(x>=D,y>=2D-1) removed. The added two corners(-2,2D-1),(D+1,D-2) are BOTH ODD. Hence all physical EVEN sites lie in exactly THREE ordinary x-band components; no extra even corner is omitted.

## Actual high strip and endpoint

If an EVEN actual source point w has s_Q(w)>=c_Q+2=4, then y>=0 and x-y<=2 force x-y=2. Writew=(j+2,j). The inequality becomes2D-2-2j>=4, so

    0<=j<=D-3.                                  (1)

All points(1) belong to the ACTUAL literal STANDARD Q domain: x in[2,D-1],y in[0,D-3],difference2, away from both ordinary deletions. No full-H lower identity is required.

For the outer chain let S=2P+V_P+J V_Q, O=Q+V_P+(J+1)V_Q,N=2J-1. For chain-row indexi=1,...,N+1, exact identityS+iQ+V_Q=O+2P+(i-1)Q enrolls(1) in an actual Q copy of the growing-standard run. Fori=0 the query at the fixed seed P isw+B=(j+3,j+1). The literal odd-staircase P=(a+1,a) ordinary selector contains this entire ramp (x<=D,y<=D-2,difference2). Thus this index is paid by the ACTUAL literal seed, not an assumed ordinary-source expansion of that seed.

The remaining high indexi=-1 is impossible. Actual sourceR2 along bounds are

    b=-2D-4 <=t_Q<=T+2D.

Its representative window lower bound makes the highi=-1 representative satisfy t_Q(w)>=b+T=2D^2+2D-6. But(1) gives

    t_Q(w)=2(D+1)j+4D <=2D^2-6.

These conflict forD>=4. Hence every high transverse representative is enrolled. Actual literal ALT_Q reflection center is(D-1,3D-3)=2A+V_Q+delta, exactly the phase-zero center; the adopted current domain pairing supplies the opposite low row.

## Width and own-creation window replay

The actual literal creation-R2 has even s interval[4-T,2D-2], and t interval[b,T+2D]. The full-transverse correlated quotient window is

    4-T<=s<=2,
    b<=t<=(N+1)T+2D.

Actual source along width isT+4D+4<2T, since2T-width=2D^2-6>0. Thus actual earlier ALT quotient cover reduces window membership to the just-paid transverse rows plus the two ordinary along caps, exactly as in the nonliteral window argument.

`check_upper_even_direct_literal_phase_zero_windows.py` freshly replays ALL6 standard GW keys (three windows ×two original I owners) in the OWN-creation parameter Q=(2H+5,2H+3),H>=0. It specializes the original sign polynomials at old high-cone coordinates A=H-1,B=C=1,D=0; it does NOT import the invalid strict shift A>=0. All360 sign polynomials/90 strict margins PASS,min4. In particularH0 isQ3/5 and is included. Receiver/target fractions all lie at or above3/5, so the high/middle I endpoint formula used by these rows remains correct even atH0; the precreation A=1/2 is not itself an I receiver.

## Literal three-component along caps

The physical-even literal source is split into x bands[-2,-1],[0,D-1],[D,D+1], with the displayed deletion thresholds. Each is intersected with the actual common box and EVEN difference interval[-2,2D]. These are upper real relaxations of the actual source, not invented native filling.

Producer `upper_even_direct_literal_phase_zero_caps.py`; independent checker `check_upper_even_direct_literal_phase_zero_caps.py`. BOTH along caps ×three literal pieces give exactly6 keys. All PASS:292 direct endpoint polynomial signs,73 strict margins,471 leaves,155 branches,min2. The checker imports no producer, reconstructs the combined G3 origin from literal A3/A5 rows, verifies actual sourceQ including3/5, current mandatory I receivers, all Farkas identities and every four-way complement branch. The report is `UPPER_EVEN_DIRECT_LITERAL_PHASE_ZERO_CAPS_INDEPENDENT_REPLAY.json`.

These windows, actual high/low strip enrollments, width and literal caps handle this named DIRECT consumed-source initializer. Earlier literal Q quotient cover, earlier standard I containment, finite support definedness and the fresh ordinary inner-closure theorem remain explicit induction inputs. No current full H equality, scalar identity, height or recurrence is inferred. Other outer dispatchers remain separate.
