# Original algorithm: exhaustive saved-record support induction

2026-11-01 19:49 UTC. Assembly of the audited support modules. This is an UPPER-DOMAIN theorem only, not a recurrence, scalar, period, or superharmonicity theorem. **FULL ASSEMBLY INDEPENDENTLY PASS:** `INDEPENDENT_ALL_WORD_SUPPORT_RECORD_INDUCTION_AUDIT.md` (19:53). The pure-standard base-H initialization is separately proved and independently audited. All-word upper-support subgoal is closed in the stated scope; ROOT ADOPTED 19:53 after the independent assembly audit.

## 1. Literal control flow

Use `final_code/rational_recursion.jl:getNextFrac` and `odometer_recursion.jl:get_next_mat,get_corrections,get_odometers`, not a canonical replacement.

Starting from `(p1,q1,p2,q2)=(1/2,1/3,0/1,1/1)`, letter1 selects both current children; letter2 selects the odd current child and retained even parent; letter3 selects the retained odd parent and even current child. All newly created children are strict fractions. Once both retained parents are strict, every subsequent retained pair remains strict.

`get_first_ancestor` initializes at the maximal initial pure2 or pure3 prefix (or empty prefix). The first nonpure letter is consequently exactly one of

* `3^a1`, `3^a2`,
* `2^a1`, `2^a3`,

with nonempty pure prefix in switch cases and shared root1 when a=0. These are all the first-mixed initializations, not merely examples.

The ODD correction record `anc_data2` refreshes after letters1 or3 and stays fixed only through a run of2s. The EVEN record `anc_data3` refreshes after1 or2 and stays fixed only through a run of3s. Updates occur AFTER the four new children have been constructed. Therefore the construction never uses an enclosure of a current child to prove that same child's enclosure.

## 2. Endpoint-record exhaustion

A saved record whose predecessor data still contains 0/1 or1/1 must be either the initialized pure prefix or its FIRST mixed refresh. Any later refresh has strict predecessor data. Intersecting the first-mixed list with the two refresh rules gives exactly:

| correction record | endpoint predecessor families | suffix during persistence |
|---|---|---|
| ODD | pure3^a, 3^a1, 2^a1, 2^a3 | 2^k |
| EVEN | pure2^a, 3^a1, 2^a1, 3^a2 | 3^k |

Root1 is shared and handled by the six literal balanced-root cases. Pure2/pure3 initialization constructs one unused correction; the original code explicitly notes this. No theorem is asserted for an unused initialization correction. The table concerns corrections ACTUALLY consumed by a subsequent constructor.

Each listed family has one SHORT standard and one LONG alternate output: sixteen nonroot endpoint-family cases. Their proofs use literal base alternate domains, not an invalid generic R2 estimate for a pure base alternate.

## 2a. The sector split is exhaustive

A strict parity-compatible predecessor pair has determinant of absolute value1. Its odd member has denominator at least2 and its even member at least3. If a reduced rational r/s lies strictly between two determinant-one neighbors, writing its primitive vector in their unimodular basis gives two positive integer coefficients; hence s is at least the sum of the two neighbor denominators, here at least5. Therefore neither1/3 nor1/2 can lie strictly between the predecessor fractions. The pair belongs to one common CLOSED sector: lower (at most1/3), balanced (between1/3 and1/2), or upper (at least1/2). Boundary fractions are already allowed in the matching parity positions in the packets. Thus no cross-sector predecessor case is omitted.

## 3. Audited modules

0. Literal pure standard bases: `ORIGINAL_ALL_PURE_STANDARD_BASE_DOMAINS_LIE_IN_FULL_H.md`, independently checked in `INDEPENDENT_ALL_PURE_STANDARD_BASE_FULL_H_AUDIT.md`. Pure alternate bases remain literal endpoint inputs.
1. Ordinary standard source unions: fresh L145, all576 cases, independently replayed (`INDEPENDENT_FRESH_ORDINARY_A3_ALL_SECTOR_HULL_ENCLOSURE_AUDIT.md`).
2. Strict predecessor corrected and alternate source unions in both outer sectors: fresh L151,48 types/4480 target rows (`FRESH_DIRECT_OUTER_AUXILIARY_ENCLOSURE_CERTIFICATES_AND_AUDIT.md`).
3. Balanced strict records and shared root:30 types/4816 inequalities, including SIX literal-root types (`FRESH_BALANCED_THIRTY_TYPE_ENCLOSURE_REPLAY_AUDIT.md`).
4. First-mixed actual initialization: all four families, both standard H and alternate creation-R2, with separate root and literal endpoint cases; see the `ORIGINAL_*FIRST_ONE*FULL*INITIALIZATION` and `ORIGINAL_*SWITCH*FULL*INITIALIZATION` sources and independent receipts.
5. ODD endpoint records: pure3 SHORT/LONG; reciprocal-first-one SHORT/LONG; near-one first-one SHORT/LONG; near-one switch SHORT/LONG. Receipts: `INDEPENDENT_PURE_THREE_SAVED_SHORT_FULL_H_AUDIT.md`, `INDEPENDENT_PURE_THREE_SAVED_LONG_CHAIN_FULL_R2_AUDIT.md`, `INDEPENDENT_RECIPROCAL_SAVED_SHORT_LONG_AND_UNCORRECTED_RUN_ENCLOSURE_AUDIT.md`, `INDEPENDENT_RECIPROCAL_FIRST_ONE_SAVED_SHORT_FULL_H_AUDIT.md`, `INDEPENDENT_NEAR_ONE_ODD_SAVED_REMAINING_ENCLOSURES_AUDIT.md`, `INDEPENDENT_PURE_TWO_SWITCH_SAVED_LONG_R2_AUDIT.md`.
6. EVEN endpoint records: pure2 SHORT/LONG, and the other six cases in `ORIGINAL_STRICT_BASE_EVEN_SAVED_RECORD_UNIFORM_ENCLOSURES.md`. Receipts: `INDEPENDENT_PURE_TWO_SAVED_SHORT_FULL_H_AUDIT.md`, `INDEPENDENT_PURE_TWO_SAVED_LONG_CHAIN_FULL_R2_AUDIT.md`, `INDEPENDENT_STRICT_BASE_EVEN_SAVED_ENCLOSURES_AUDIT.md`.

Uniform growing standard sources used within endpoint records are either directly proved by the actual fixed-parent domain recurrence/triangular-grid expansion, or follow fresh L145 from earlier actual standard H. No current-height or current-period premise is needed.

## 4. Simultaneous induction and exact conclusion

Induct on the actual constructor step, maintaining standard-H containment for all stored strict standard arrays, and creation-R2 containment for all stored NONBASE alternate arrays. Keep literal pure-base alternate arrays as separate objects; do not insert them into the R2 invariant.

At an ordinary standard output use L145. At an alternate/corrected output inspect the actual saved source record, not merely the current consumed fractions. A literal endpoint record belongs to Section2 and uses its audited family theorem; the shared root uses the literal balanced-root packet. A strict predecessor record uses the matching balanced or outer conditional packet. The generic alternate input is always a child of the record predecessor pair (an output at the record's immediate prefix and an INPUT to the record constructor, not a current record output): last1 uses children p=a+b and q=2a+b; last2 uses alternate p=a+b; last3 uses alternate q=2a+b. Hence that alternate is nonbase and its creation-R2 is already available strictly earlier. A retained pure-base q in last2 or p in last3 is used only as STANDARD. This explicitly prevents applying R2 to a literal pure-base alternate. Every source array is earlier in the constructor order, including the growing uncorrected standard source at the prior suffix stage. Thus the source assumptions are induction hypotheses or literal base facts.

The construction's finite support is contained in the union of its translated operand supports. Upper inclusion needs only this SUBSET assertion; it does not require nonempty touching, exact support equality, operand value agreement, or later-write coherence. Native frame centering/A4/A6 are exactly those checked in the module audits. Reflection used in the endpoint proofs is reflection of actual domains only.

With the preceding pure-standard initialization and the record-provenance audit, this establishes the full all-word upper-support induction: every stored standard output lies in its H and every NONBASE alternate output lies in its creation-R2. All consumed endpoint corrections are included. No finite-support lower coverage is asserted.

## 5. What remains for the user's recurrence problem

This closes only support inequalities. It does not imply original operand height compatibility, current-child deck identities, exterior-star superharmonicity, a complete first-owner leaf cover, or absence of finite forbidden configurations.

The paper's final recurrence proof (`farey_recursion.tex` lines4148–4180) needs a global column/interface induction: for every translated double-decomposition subtile T^i, an occupied forbidden-set column V^j cannot meet its incoming boundary. The text invokes repetition of base stacked-string arguments; the missing exhaustive transfer must account for EVERY actual interface, including central corrected L/L interactions. Support containment alone cannot supply it.

## Consumed finite-support premise discharged (2026-11-02 13:24)
The finite-touch/exact-union premise for every ACTUALLY CONSUMED operand is now proved by the chronological mutual DOMAIN induction in ORIGINAL_CONSUMED_FINITE_DEFINEDNESS_AND_BASIC_DOMAINS_CLOSE_BY_CHRONOLOGICAL_MUTUAL_INDUCTION.md, independently adopted in ROOT_INDEPENDENT_CHRONOLOGICAL_CONSUMED_DEFINEDNESS_AND_BASIC_DOMAIN_AUDIT.md. Literal ALT active initialization has its separate fresh root receipt. Thus the present domain-support/frame/reflection/trace statement may be applied to all original words without assuming consumed finite touching. Unused disjoint initial auxiliaries are outside the theorem, and no value compatibility, quotient coverage, height reflection or recurrence claim is added. The proof does not use current cover or heights.
