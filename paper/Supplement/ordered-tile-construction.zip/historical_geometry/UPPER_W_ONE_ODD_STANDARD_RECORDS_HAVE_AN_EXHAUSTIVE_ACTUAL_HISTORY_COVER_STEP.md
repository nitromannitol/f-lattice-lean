# W1 odd STANDARD outputs: exhaustive actual-history physical-even cover step

2026-11-02, 17:08 UTC. This assembles OUTER W1 / saved1 and saved2 only. It is a joint-domain-induction step, not a current-ALT cover theorem, a height theorem, or an unconditional all-word recurrence statement.

## 1. Literal dispatcher, including the selected-parent distinction

In `f_lattice_original_algorithm/final_code/odometer_recursion.jl:get_next_mat`, letter1 selects both previous children, letter2 selects the previous odd child and retained even parent, and letter3 selects the retained odd parent and previous even child. The updated quadruples are stored BEFORE ancestor records are refreshed. The even-L record `anc_data3` refreshes at1/2 and persists through3. `get_l_correction.jl:get_l_correct(getOdd=false)` takes G3 from `Gp2_`, the selected earlier odd alternate in that saved quadruple, not its newly created odd child.

Let the saved record be `nu s`, s=1 or2, and let nu be the prefix immediately before its last letter. The consumed odd alternate is the odd child at nu in BOTH selections. All subsequent threes preserve this record. Thus the cases below classify the actual consumed object; they do not classify merely the final digit of the outer word.

An upper-sector history starts with a maximal pure prefix2^m (m>=1), with the shared1/2 boundary handled by its literal base. Once the first non2 letter occurs, retained parent fractions are proper. Phase is the parity of the number of ones; pure2 has phase0, letter1 flips it, and2/3 preserve it.

## 2. Exhaustive source partition

**A. nu is pure2^m.** If s=2 the saved record is still pure2 and has W0, hence cannot occur here. If s=1 its phase is W1: this is precisely the direct literal near-one odd ALT consumed by saved2^m1. It is covered by
`UPPER_W_ONE_SAVED_ONE_DIRECT_LITERAL_ODD_ALTERNATES_HAVE_EXACT_WINDOWS_AND_CAPS.md`, now independently adopted in
`ROOT_INDEPENDENT_W_ONE_DIRECT_LITERAL_ODD_ALT_WINDOW_AND_CAP_AUDIT.md`.
Here a=m+2>=3, P=(a,a-1), Q=(2a-1,2a-3). The source has its actual three-piece even domain, including both exceptional even corners; its width is2T+1, NOT the strict-source width. The formal-window padding nevertheless bounds the omitted indices to the immediate two caps. Four certificate cap cases plus two actual strip twins cover each a>=4/a3 family; root a3 has a fresh six-case GW packet. FULL H is used only for the two literal standard P,Q bases whose full domains are proved; the growing standard and current target remain I. No seven-source representation of the literal ALT is introduced.

**B. nu is nonpure and ends1 or3.** Literal `get_next_mat` creates the odd alternate by UNC. Its seven actual creation operands are the UNC-source cap input. Its creation predecessor pair is either proper or the first-mixed endpoint pair from the pure2 prefix. The latter has the separately initialized literal even near-one alternate; the full restored EVEN-alternate R2 applies in both physical parities.

**C. nu is nonpure and ends2.** Write nu=rho 2^h, h>=1, with rho not ending2. Since a pure run is initialized directly, rho is nonempty, nonpure, and ends1 or3. The odd alternate is the corrected LONG construction with saved odd-L record rho, and h is independent of the outer suffix. Its proper predecessor and older-endpoint cases are exactly the corrected-inner source grammar and endpoint packets. In particular, a savedlast3 does not make its companion standard odd P corrected: CURRENT letter2 constructs that P by UNC. This licenses the actual whole-B companion carriers used in the corrected cap proof.

These cases are disjoint and exhaustive. No direct literal source is hidden in B/C. There is no additional pure2-saved corrected-odd-L family: remaining inside a pure run belongs to A, while the first nonpure last1/3 record is explicitly B/C.

## 3. Proper, endpoint, and root bindings

For B/C with proper creation data, use
`UPPER_W_ONE_ODD_OUTPUT_STRICT_SOURCE_DOMAIN_COVER_ASSEMBLY.md` and all named component certificates. The three closed upper cones and their coefficient faces are retained, not treated as generic strictly positive coordinates.

For the older-even endpoint and half-root creation states use
`UPPER_ODD_ADJACENT_SOURCE_CAPS_HAVE_FRESH_LITERAL_ENDPOINT_AND_HALF_ROOT_REPLAYS.md` and
`INDEPENDENT_W_ONE_ODD_ADJACENT_CAP_ENDPOINT_ROOT_AUDIT.md`.
The W1 regular high endpoint packets have22 UNC /34 corrected certificate cases; rootlast1 has12/18, rootlast3 has10/16. Their fresh direct coefficient reconstruction does not reuse a strict positivity certificate. Correct receiver I sectors are used at both roots. These are NONLITERAL current ALT sources with a literal older operand; their actual creation unions are valid. Their outer creation pairs are proper, so the proper-source R2 width theorem applies. The separately replayed original-GW coefficient faces supply the matching window cases.

The residual UNC savedlast3 / outer saved2 B cap is handled by actual present-trace descent, not H filling. Under W1 its saved prefix is proper; the pure2 singleton seed has W0 and cannot enter this W1 gate. In any event the unique singleton has its separate actual adjacent-A repair, not an unproved same-parent retention assertion.

## 4. Induction chronology and conclusion

Use only earlier standard quotient cover plus adopted actual BASIC/mandatory traces to obtain earlier I. Use earlier alternate quotient cover and actual R2 (or the literal domain in A) to select representatives. Current finite constructor unions and domain reflection are already defined domain theorems. The ordinary-I owner decomposition is the fresh all-sector theorem `ROOT_FRESH_ALL_SECTOR_ORDINARY_INNER_CLOSURE_ADOPTION.md`.

The original-window certificates pay ordinary receivers or reduce to the unique source window. Source support and width/padding restrict its representative to an included actual ALT copy or one of the two end caps. Every cap is paid by a verified I receiver/current child-deck receiver, an actual whole-source twin/companion carrier, actual protected present-trace descent, or the explicit literal strip twin. None of these uses the current output's cover as an input.

Therefore every physical-even current quotient class is represented in the actual STANDARD ODD domain for BOTH W1 saved1/2 records, for every actual upper history, under the earlier-domain joint IH. The physical-odd cover step is separately adopted. This closes these two STANDARD outer-record steps only. Current-ALT physical-even cover and its own history-specific caps remain separate; no full mutual/all-word cover is asserted here.

## 19:26 explicit proper coefficient-wall map

The existing `check_upper_w1_odd_adjacent_cap_d_zero_faces.py cone unc|corr` supplies all three original-window source-cap D=0 faces by fresh signs, not just HIGH literal endpoint/root specialization. LOW/HIGH states are (sourceW,last,outer)=(0,3,1),(1,1,2); MIDDLE reverses coefficient determinant orientation and uses (1,3,2),(0,1,1). The original-GW all36 both-phase boundary-face inventory was separately audited in `INDEPENDENT_UPPER_ODD_BOTH_PHASES_ORIGINAL_GW_AUDIT.md`.

Only MIDDLE has the remaining UNC creatorlast3/outerlast2 reflected-B trace gate. New `check_upper_w1_saved2_b_band_d_zero_face.py middle` freshly reconstructs that exact native-B lower-band inequality and directly specializes B=C=1,D=0, phase1; terminal PASS16 signs/4 strict. LOW/HIGH B exceptions are whole companion outer1 carriers and do not require an invalid phase1-on-phase0 band specialization. Positive cap still follows actual set reflection. External allface/keyset audit is requested as an explicit addendum to the earlier root adoption.
