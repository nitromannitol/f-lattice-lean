# Root adoption: actual balanced mutual quotient cover

2026-11-02 15:17 UTC. Root adopts the DOMAIN theorem and chronological assembly in ACTUAL_BALANCED_STANDARD_AND_ALTERNATE_DOMAINS_HAVE_FRESH_MUTUAL_QUOTIENT_COVER.md after completion of every named fresh packet and its separate audit.

For every output of the original algorithm with fraction in[1/3,1/2], both standard and alternate actual native domains cover their intrinsic period quotient. Every such standard domain is exactly its parity-safe hull H. No height, admission, recurrence or alternate hull equality is inferred.

Root independently replayed/read the96 standard windows,448 standard UNC-source caps,64 widths and896 ALT UNC-source caps. The independent receipts for640 standard corrected caps,1200 refined ALT windows,1280 ALT corrected caps and all four literal initial/root packets have been read and their exact scope checked against the assembly. The11 packet manifest records the fresh files; no unavailable historical certificate is adopted.

The only receiver-filling premise is EARLIER balanced standard D=H, obtained from earlier cover, safe enclosure and the independently proved mandatory-trace ambiguity theorem. Current cover is never used to fill its own receivers. Ordinary six-source closure was freshly reconstructed and independently audited. Current corrected standard targets reduce to actual mandatory rectangles or the proved chain window. ALT targets use genuine current-deck translates of actual mandatory rectangles or that window.

Root checked the finite-chain/two-cap lemma directly. For a source quotient representative, the strict transverse strip forces transverse index0; along width<2T restricts its index to-1,...,N+1. The two certified caps remove exterior indices for points outside mandatory receivers. The remaining representative lies in a real chain copy. Source enclosure need not be filled. The periodic version changes only which current-deck representative is used and does not assume current coverage.

Chronology is by strictly earlier source denominators with the already adopted actual helper-construction ordering. The balanced branch is ancestor-closed after its literal1/2,1/3 root; strict siblings cannot cross either rational wall except the catalogued root. The consumed source alternatives are literal root, initial word1, strict UNC, corrected with initial saved record, and strict corrected. Independent inner/outer lengths are preserved. Literal30-site catalogs and primitive chains replace, rather than extrapolate, nonbase R2 at endpoints. Together the audited cases exhaust both phases, source types, outer records, physical parities and both caps.

Combining this result with ROOT_INDEPENDENT_LOWER_FULL_AND_UPPER_ODD_MUTUAL_QUOTIENT_COVER_AUDIT.md gives full actual quotient cover for both outputs with fraction0<r<=1/2, and physical-ODD cover in the upper sector. Upper physical-EVEN completion remains separate. The all-word recurrence task remains OPEN.
