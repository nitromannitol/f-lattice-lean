#!/usr/bin/env python3
"""Construct finite polynomial certificates for balanced auxiliary support.

Five variables: four nonnegative Farey cone coordinates and suffix k.
Repeated A5 chains are reduced to their two endpoints. Every source
polygon is treated by a two-row nonnegative dual certificate.
Discovery pilots never certify a result.
"""
from collections import Counter
from functools import lru_cache
from itertools import combinations, product
from math import comb
from pathlib import Path
import argparse
import json
import time

ROOT = Path(__file__).resolve().parent
SECTOR = "lower"
ZERO = (0, 0, 0, 0, 0)


class Poly:
    def __init__(self, value=0):
        self.d = ({ZERO: value} if isinstance(value, int) and value else
                  {} if isinstance(value, int) else {e: c for e, c in value.items() if c})

    def __add__(self, other):
        other = other if isinstance(other, Poly) else Poly(other)
        out = Counter(self.d)
        out.update(other.d)
        return Poly(dict(out))

    __radd__ = __add__

    def __neg__(self):
        return Poly({e: -c for e, c in self.d.items()})

    def __sub__(self, other):
        return self+-(other if isinstance(other, Poly) else Poly(other))

    def __rsub__(self, other):
        return -self+other

    def __mul__(self, other):
        other = other if isinstance(other, Poly) else Poly(other)
        out = Counter()
        for e, c in self.d.items():
            for f, a in other.d.items():
                out[tuple(x+y for x, y in zip(e, f))] += c*a
        return Poly(dict(out))

    __rmul__ = __mul__

    def __eq__(self, other):
        return self.d == (other.d if isinstance(other, Poly) else Poly(other).d)

    def key(self):
        return tuple(sorted(self.d.items()))


VARS = [Poly({tuple(int(i == j) for i in range(5)): 1}) for j in range(5)]
A, B, C, D, KLEN = VARS
ZV = Poly(), Poly()


def power(p, n):
    out = Poly(1)
    for _ in range(n):
        out *= p
    return out


def encode(p):
    return [[list(e), c] for e, c in sorted(p.d.items())]


def normalize(p, phase):
    i, j, u, v = (0, 3, 1, 2) if phase else (1, 2, 0, 3)
    main, opposite = VARS[i]*VARS[j], VARS[u]*VARS[v]+1
    normal, quotient = Poly(), Poly()
    for e, c in p.d.items():
        k = min(e[i], e[j])
        f = list(e)
        f[i] -= k
        f[j] -= k
        factor = Poly({tuple(f): c})
        normal += factor*power(opposite, k)
        for h in range(k):
            quotient += factor*power(main, k-1-h)*power(opposite, h)
    return normal, quotient


def shift(p, lower):
    out = Counter()
    for e, c in p.d.items():
        for f in product(*(range(n+1) for n in e)):
            value = c
            for a, b, h in zip(e, f, lower):
                value *= comb(a, b)*h**(a-b)
            out[f] += value
    return Poly(dict(out))


@lru_cache(None)
def positive(key, phase, strict):
    p = Poly(dict(key))
    lower = ((1,1,1,2,0) if phase else (1,1,1,0,0)) if SECTOR == "lower" else ((1,1,1,2,0) if phase else (0,1,1,2,0))
    scales = [ZERO]
    if strict:
        scales += [tuple(k if i == j else 0 for i in range(5))
                   for k in (1, 2, 3) for j in range(4) if lower[j] > 0]
    for scale in scales:
        normal, quotient = normalize(p*Poly({scale: 1}), phase)
        coefficients = shift(normal, lower)
        if any(c < 0 for c in coefficients.d.values()):
            continue
        if strict and coefficients.d.get(ZERO, 0) <= 0:
            continue
        return {"scale": scale, "positive": encode(coefficients), "quotient": encode(quotient)}
    return None


def add(*vectors):
    return tuple(sum((v[j] for v in vectors), Poly()) for j in (0, 1))


def mul(k, v):
    return k*v[0], k*v[1]


def prime(v):
    return v[1]-v[0], v[1]+v[0]


def norm(v):
    d, n = v
    return d*d+2*d*n-n*n


def mixed(p, q):
    d, n = p
    e, a = q
    return d*e+d*a+n*e-n*a


def bounds(frac, odd, parity, creation=None):
    d,n=frac; T=norm(frac); lower=SECTOR=="lower"
    if creation is None:
        m=2 if odd else 1
        if parity:
            return n-T,d,(3*n-d if lower else d-n),m*T+(d-n if lower else 3*n-d)
        return ((2*n-T,d-n,Poly(),m*T+2*n) if lower else (d-n-T,2*n,Poly(),m*T+2*n))
    pp,q,W=creation; K=mixed(pp,q); eps=2*W-1
    if odd:
        b=W*(2-K-norm(q)); centre=n+d-T-norm(pp)-K-2*W
        hi=d-eps if parity or lower else 2*n
        return centre-hi,hi,b+((3*n-d if lower else d-n) if parity else 0),b+2*T+((d-n if lower else 3*n-d) if parity else 2*n)-2
    b=(1-W)*(-2-2*K-norm(q));centre=T+2*n+eps*(2*K+norm(q))
    hi=d if parity else (d-n if lower else 2*n)
    e=d-3*n+2*eps if lower and parity else 0
    return n+d-T+2-hi,hi,b-e,centre-b+e


def std_layout(p, q, W, odd):
    pp, qp = prime(p), prime(q)
    if odd:
        u = ((mul(2, p), pp, ZV, add(mul(2, q), qp)) if W else
             (ZV, add(mul(2, p), pp), mul(2, q), qp))
        return [(False, u[0]), (False, add(u[0], q)),
                (False, u[1]), (False, add(u[1], q)),
                (True, u[2]), (True, u[3])]
    u = ((mul(2, p), mul(2, pp), ZV, add(q, qp)) if W else
         (ZV, add(mul(2, p), mul(2, pp)), q, qp))
    return [(False, u[0]), (False, u[1]),
            (True, u[2]), (True, add(u[2], pp)),
            (True, u[3]), (True, add(u[3], pp))]


def alt_layout(p, q, W, odd, letter):
    pp, qp = prime(p), prime(q)
    if odd:
        if W:
            a, b, c, d, step = mul(2, p), add(mul(2, pp), mul(-1, q)), \
                ZV, add(q, qp), add(pp, mul(-1, q))
            extra = pp if letter == 2 else add(pp, mul(2, p), mul(-1, q))
        else:
            a, b, c, d, step = ZV, add(mul(2, p), mul(2, pp), q), q, qp, add(q, pp)
            extra = add(q, pp)
        return [(False, a), (False, b), (True, c), (True, add(c, step)),
                (True, d), (True, add(d, step))], extra
    if W:
        a, b, c, d, step = mul(2, p), pp, ZV, add(pp, qp, mul(2, q)), add(q, pp)
        extra = add(mul(2, q), qp) if letter == 2 else add(pp, q)
    else:
        a, b, c, d, step = ZV, add(mul(2, p), pp), q, \
            add(pp, mul(-1, q), qp), add(pp, mul(-1, q))
        extra = (qp if letter == 2 else
                 add(pp, mul(4 if letter == 3 else 2, p), mul(-1, q)))
    return [(False, a), (False, add(a, step)), (False, b), (False, add(b, step)),
            (True, c), (True, d)], extra


def raw_piece_ops(p, q, W, last, odd_piece, long, flip):
    k, pp, qp = KLEN, prime(p), prime(q)
    if odd_piece:
        current_p, current_q = add(p, mul(k, q)), q
        g1, g2, g3 = False, True, False
        if flip:
            k1, k2, k3, k4 = ((mul(-1, qp), mul(-1, pp),
                              add(mul(2, p), mul(-1, q)), q) if W else
                             (mul(-1, qp), add(mul(-1, pp), mul(-2, p), q), ZV, mul(-1, q)))
        else:
            k1, k2, k3, k4 = ((qp, add(qp, q, mul(-2, p)),
                              add(mul(-1, qp), pp, mul(2, p), mul(-1, q)), mul(-1, q)) if W else
                             (qp, qp, add(mul(-1, qp), pp), q))
        move = (mul(-1, q) if flip else add(mul(2, p), mul(2*k+1, q))) if W else ZV
    else:
        current_p, current_q = p, add(mul(2*k, p), q)
        g1, g2, g3 = True, False, True
        s2 = last == 2
        if flip:
            k1, k2, k3, k4 = ((mul(-2, p), add(mul(-1, q), pp, mul(-1, qp)),
                              add(qp, mul(-1, pp), q) if s2 else ZV, mul(-1, pp)) if W else
                             (mul(2, p), add(mul(2, p), pp, mul(-1, qp)),
                              add(qp, mul(-1, pp), mul(-2, p), q) if s2 else ZV, mul(-1, pp)))
        else:
            k1, k2, k3, k4 = ((mul(2, p), mul(2, p),
                              add(mul(2, q), mul(-2, p), qp, mul(-1, pp)) if s2
                              else add(q, mul(-2, p)), pp) if W else
                             (mul(-2, p), mul(-1, q), add(qp, mul(-1, pp)) if s2
                              else add(mul(2, p), mul(-1, q)), pp))
        move = ZV if W or flip else add(mul(2*k, p), q)
    start = std_layout(current_p, current_q, W, odd_piece)[3 if odd_piece else 5][1] if flip else ZV
    last_g1 = add(start, mul(k, k1))
    single = add(last_g1, k2)
    start_g3 = add(single, k3)
    # Each tuple is (alternate, odd-source, source-fraction, origin).
    return [(False, g1, p if g1 else q, add(start, move)),
            (False, g1, p if g1 else q, add(last_g1, move)),
            (False, g2, p if g2 else q, add(single, move)),
            (True, g3, p if g3 else q, add(start_g3, k4, move)),
            (True, g3, p if g3 else q, add(start_g3, mul(2*k+1+long, k4), move))]


def group(kind, W, last, root=False):
    corep, coreq = ((3*A+B,A),(3*C+D,C)) if SECTOR=="lower" else ((A+2*B,A+B),(C+2*D,C+D))
    phase = 1-W if last == 1 and not root else W
    if root:
        assert W == 1 and last == 1
        p, q = (Poly(2), Poly(1)), (Poly(3), Poly(1))
        creation = "literal"
    else:
        p, q = ((add(corep, coreq), add(mul(2, corep), coreq)) if last == 1 else
                (add(corep, coreq), coreq) if last == 2 else
                (corep, add(mul(2, corep), coreq)))
        creation = corep, coreq, phase
    odd = kind.endswith("p")
    alternate = "alt" in kind
    corrected = kind.startswith("corr")
    if not corrected:
        cp, cq, letter = p, q, last
        layout, extra = alt_layout(cp, cq, W, odd, letter)
        ops = [(False, is_p, p if is_p else q, v) for is_p, v in layout]
        ops.append((True, not odd, q if odd else p, extra))
    else:
        letter = 2 if ((not alternate and not odd) or (alternate and odd)) else 3
        odd_piece = letter == 2
        cp, cq = (add(p, mul(KLEN+1, q)), q) if odd_piece else \
            (p, add(mul(2*(KLEN+1), p), q))
        layout = (alt_layout(cp, cq, W, odd, letter)[0] if alternate else
                  std_layout(cp, cq, W, odd))
        left = raw_piece_ops(p, q, W, last, odd_piece, int(alternate), True)
        right = raw_piece_ops(p, q, W, last, odd_piece, int(alternate), False)
        if alternate:
            replacements = {3: left, 4: right} if odd else {0: right, 3: left}
        else:
            replacements = ({0: right, 3: left} if W else {1: right, 2: left}) if odd else \
                {3: left, 4: right}
        ops = []
        for i, (is_p, v) in enumerate(layout):
            if i in replacements:
                ops += [(a, o, r, add(v, u)) for a, o, r, u in replacements[i]]
            else:
                ops.append((False, is_p, cp if is_p else cq, v))
    target = add(cp if odd else mul(2, cp), cq)
    return target, odd, (cp, cq, W) if alternate else None, ops, creation, phase


def literal_base(odd):
    if not odd:
        return [(x, y) for x in range(-2, 4) for y in range(-1, 5)
                if (-1 <= x+y <= 5 and 0 <= y <= 3 and -2 <= x <= 3)
                or (y == -1 and -2 <= x <= 0) or (y == 4 and 1 <= x <= 3)
                or (x, y) in ((-2, 0), (3, 3), (-2, -1), (3, 4))]
    return [(x, y) for x in range(-1, 5) for y in range(6)
            if (0 <= x <= 3 and 1 <= y+1 <= 6 and -1 <= y+1-x <= 5)
            or (x == -1 and 4 <= y+1 <= 6) or (x == 4 and 1 <= y+1 <= 3)
            or (x, y+1) in ((0, 6), (3, 1), (-1, 6), (4, 1))]


def source_constraints(frac, odd, parity, creation):
    d, n = frac
    a, b, c, e = bounds(frac, odd, parity, creation)
    out = [(Poly(-1), Poly(), -a), (Poly(1), Poly(), b),
           (Poly(), Poly(-1), -c), (Poly(), Poly(1), e)]
    if creation is None:
        m = 2 if odd else 1
        out += [(-(d-n), -d, -norm(frac)*(1+n-d)),
                (d-n, d, norm(frac)*m*d),
                (d+n, -n, Poly()),
                (-(d+n), n, norm(frac)*(m*n+d+n-1))]
        # DIA rows in source (s,t), multiplied by positive T.
        T=norm(frac); N=d+n; c=d-n
        out += [(-2*d,-c,T*(-2+2*d+parity)),
                (2*d,c,T*(m*c+parity)),
                (2*n,-N,-T*parity),
                (-2*n,N,T*(m*N+2*n-parity))]
    return out


def target_normals(target, odd, creation, parent, offset, parity):
    dc, nc = target
    dr, nr = parent
    tr, cross, determinant = norm(parent), mixed(target, parent), nc*dr-dc*nr
    lo, hi, bot, top = bounds(target, odd, parity, creation)
    sshift = nc*offset[0]-dc*offset[1]
    tshift = (dc+nc)*offset[0]+(dc-nc)*offset[1]
    step = 1 if odd else 2
    return [(-cross, -determinant, tr*(-lo+step+sshift)),
            (cross, determinant, tr*(hi+step-sshift)),
            (-2*determinant, -cross, tr*(-bot+2+tshift)),
            (2*determinant, cross, tr*(top+2-tshift))]


def det(a, b):
    return a[0]*b[1]-a[1]*b[0]


def dual_certificate(rows, target, phase):
    for i, j in combinations(range(len(rows)), 2):
        x, y = rows[i], rows[j]
        for sign in (1, -1):
            denominator = sign*det(x, y)
            pc = positive(denominator.key(), phase, True)
            if pc is None:
                continue
            lambdas = [sign*det(target, y), sign*det(x, target)]
            lpc = [positive(l.key(), phase, False) for l in lambdas]
            if any(p is None for p in lpc):
                continue
            margin = denominator*target[2]-lambdas[0]*x[2]-lambdas[1]*y[2]
            mc = positive(margin.key(), phase, True)
            if mc is not None:
                return {"constraints": [i, j], "sign": sign, "denominator": pc,
                        "multipliers": lpc, "strict_margin": mc}
    return None


def groups():
    out = []
    for W in (0, 1):
        out += [("unc_alt_p", W, s, False) for s in (1, 3)]
        out += [("unc_alt_q", W, s, False) for s in (1, 2)]
        out += [(kind, W, s, False) for kind in ("corr_std_q", "corr_alt_p") for s in (1, 3)]
        out += [(kind, W, s, False) for kind in ("corr_std_p", "corr_alt_q") for s in (1, 2)]

    return out


def main():
    parser = argparse.ArgumentParser()
    global SECTOR
    parser.add_argument("--sector", choices=("lower","upper"), default="lower")
    parser.add_argument("--group", type=int)
    parser.add_argument("--out", default="reconstructed_direct_auxiliary_packet.json")
    args = parser.parse_args()
    SECTOR=args.sector
    memory = next(int(s.split()[1]) for s in Path("/proc/meminfo").read_text().splitlines()
                  if s.startswith("MemAvailable:"))
    # Certificate engine is exact; run one group at a time to bound memory.
    selected = list(enumerate(groups()))
    if args.group is not None:
        selected = [selected[args.group]]
    records, counts = [], Counter()
    started = time.monotonic()
    for number, case in selected:
        target, odd, target_creation, ops, source_creation, phase = group(*case)
        record = {"group": number, "case": case, "phase": phase, "rows": [], "unclosed": []}
        for source_no, (alternate, source_odd, parent, origin) in enumerate(ops):
            if alternate and source_creation == "literal":
                for z in literal_base(source_odd):
                    point = add(origin, tuple(Poly(a) for a in z))
                    dc, nc = target
                    s, t = nc*point[0]-dc*point[1], (dc+nc)*point[0]+(dc-nc)*point[1]
                    lo, hi, bot, top = bounds(target, odd, sum(z) % 2, target_creation)
                    step = 1 if odd else 2
                    margins = (s-lo+step, hi+step-s, t-bot+2, top+2-t)
                    for bound_no, margin in enumerate(margins):
                        key = [source_no, list(z), bound_no]
                        cert = positive(margin.key(), phase, True)
                        if cert is None:
                            record["unclosed"].append(key)
                        else:
                            record["rows"].append({"key": key, "literal": True, "certificate": cert})
                continue
            creation = source_creation if alternate else None
            for parity in (0, 1):
                rows = source_constraints(parent, source_odd, parity, creation)
                targets = target_normals(target, odd, target_creation, parent, origin, parity)
                for bound_no, target_row in enumerate(targets):
                    key = source_no, parity, bound_no
                    cert = dual_certificate(rows, target_row, phase)
                    if cert is None:
                        record["unclosed"].append(key)
                    else:
                        record["rows"].append({"key": key, "literal": False, "certificate": cert})
        records.append(record)
        counts["groups"] += 1
        counts["proved_rows"] += len(record["rows"])
        counts["unclosed_rows"] += len(record["unclosed"])
        report = {"status": "PASS" if not counts["unclosed_rows"] else "INCOMPLETE",
                  "counts": dict(counts), "records": records, "complete_groups": args.group is None
                  and len(records) == len(selected)}
        (ROOT/args.out).write_text(json.dumps(report, separators=(",", ":"))+"\n")
        print(json.dumps({"group": number, "case": case, "seconds": round(time.monotonic()-started, 2),
                          "proved": len(record["rows"]), "unclosed": len(record["unclosed"])}), flush=True)


if __name__ == "__main__":
    main()
