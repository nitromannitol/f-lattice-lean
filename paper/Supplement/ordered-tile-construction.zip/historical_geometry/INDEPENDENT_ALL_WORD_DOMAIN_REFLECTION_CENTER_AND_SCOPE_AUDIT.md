# Independent all-word DOMAIN reflection: center algebra and precise frame dependency

2026-11-02 09:55 UTC; recovery/audit update 09:58 UTC below. DOMAIN ONLY. No height-reflection, common-extension, or scalar-coherence claim.

## Result

The reflection induction in recovered L150, `f_lattice_original_algorithm/thm13-recurrence-agents/flattice-thm13-20261019/ALL-SECTOR-FRAMES-SUNA.md`, has the correct all-word, all-sector **set-erased** scope. Whenever the actual finite touching operations are defined, their supports are exactly the translated source unions, so the conclusion transfers to actual domains. Finite touching is a premise, not established here.

Fresh checker `check_l150_domain_reflection_center_algebra.py` passes **114 formal vector identities** with arbitrary coordinate polynomials and symbolic suffix length, not sampled fractions or words:

* 24 source-pair center identities for all four MAIN six-source constructors and both phases;
* 8 individually fixed UNC ALT star centers for every allowed final letter/phase;
* 80 paired A5 source endpoints for both piece types, both allowed saved last letters, both phases and SHORT/LONG (first/last G1, G2, first/last G3);
* 2 literal endpoint G2 center-discrepancy cancellations.

The source origins are the separately source-audited `std_layout`, `alt_layout`, and `raw_piece_ops` in `reconstruct_direct_auxiliary_enclosure.py`. Their literal binding was re-read against `final_code/tile_decomp/tile_offsets.jl`, `get_l_correction.jl`, and the A4/A6 branches in `odometer_recursion.jl`. The checker uses no support hull or determinant inequality.

## Original dependency status (resolved by 09:58 recovery below)

L150's **all-sector lower-left/A4 frame restoration theorem is an explicit retained dependency**. Its proof cites `ANCHOR-GEOMETRY-ANALYSIS.md`; that file and its referenced verification scripts were not found in the current recovered workspace. Therefore this receipt is not a new standalone audit of those minima inequalities. It independently verifies the domain-reflection algebra given the already adopted actual A4/A6 frame tables, and checks that L150 states the requisite domain-only conclusion. The missing dependency does not justify silently promoting height reflection.

The available `CONSTANT-PARITY-ANALYSIS.md` §§4,5,9,10,12 supplies all the center equations below. Its additional height statements are NOT used.

## Universal set argument

Put P=(d,n), Q=(e,r), V=P'=(n-d,n+d), Y=Q'=(r-e,r+e), delta=(1,-1). Standard centers are wP=2P+V+delta and wQ=Q+Y+delta. Every occurrence D+v of a source with D=w-D is paired with D+u when v+u+w equals the output center. Taking unions preserves this equality regardless of insertion order or overlaps.

The ordinary standard pairings are odd (0,3),(1,2),(4,5), even (0,1),(2,5),(3,4). ALT odd uses the even pairing and ALT even the odd pairing. The raw output ALT centers are

    odd:  2P+2(1-W)Q+2V+Y+delta,
    even: 2P+2WQ+2V+Y+delta.

These are raw/A4-restored creation frames. After centering by a lower-left a, the reflection center is w-2a; do not retain the raw center in a centered frame.

For UNC ALT the extra source is fixed individually. Its restored center is

    odd ALT's Q source: wQ+(1-2W)(2P-Q);
    even ALT's P source:
       last1,W0: -2P+2Q+Y+delta;
       last1,W1:  2P+Y+delta;
       last2,W0:  2P+2V-Y+delta;
       last2,W1:  2P-2Q+2V-Y+delta.

Adding twice the literal star displacement yields the corresponding output center in all eight cases. These restored-source identities follow from earlier creation-center identities under the exact inverse parent substitutions and the retained A4 frame restoration, not from current output reflection.

For A5, match like-indexed sources LEFT/RIGHT. K1 and K4 signs are opposite, so the index contribution cancels for EVERY index; endpoint checks are formal affine identities, not a truncation of the suffix. G1, G2 and G3 sums plus their source centers have one common cross-center. Both SHORT and LONG retain equal chain lengths on the two sides. The actual pure3 G2 shifts (0,-1),(1,-1) sum to (1,-2), cancelling the endpoint 0/1 center discrepancy (-1,2). The pure2 LEFT G2 shift (1,1) cancels endpoint 1/1 discrepancy (-1,-1). These changes affect G2 only, NOT the continuing G3 origin, as the literal code confirms.

If raw R=H-L and the lower-left anchors are aR,aL, individually centering the pieces gives common cross-center and common upper-right H0=H-aR-aL. A6 shifts exactly one piece by w_target-H0, hence the aligned pair has cross-center w_target. This fact itself needs no closed formula for aR or aL. The replaced slots are precisely one opposite MAIN pair: standard odd (1,2) W0 or (0,3) W1; standard even and ALT odd (3,4); ALT even (0,3). Thus replacement preserves output domain reflection.

## Noncircular induction and boundary of use

Induct on the full actual erased state, carrying both standard and ALT outputs, retained parents, saved records and active pieces. Literal base supports provide the initial centers; prior actual A4 restoration supplies each consumed ALT source frame; like-index A5 pairing gives newly stored pieces; A6 paired replacement gives the next output. Every source is earlier in constructor order. There is no current height, current recurrence, scalar agreement, or current-domain-reflection premise inside a step.

Under defined finite touching, min_nan insertion has precisely union support; affine finite shifts and normalization do not remove sites. Consequently set-erased and actual supports coincide. No clipped comparison window is substituted for the literal support. This conclusion is enough for reflecting a domain membership/cap inequality, but NOT for reflecting kernel values or source scalar gauges.

## Literal centering/A6 check (09:56 UTC)

Re-read `helper_functions.jl:29–49`: lower-left is min in lex order (y,x), upper-right is max in the same order. Reflection reverses this order exactly. `build_odometers_init.jl:70–87` **unpad is only a common rectangular coordinate crop**, not independent geometric lower-left centering; no finite site is removed. `center_mats(A...)` at lines104–116 pads, translates every input by the difference between its lower-left and that of A[1], then calls common unpad. Thus all inputs have the SAME geometric lower-left b, not necessarily matrix index(1,1). The two-argument overload also aligns both lower-lefts, to the second input's anchor.

Crucially `odometer_recursion.jl:get_next_mat` calls the multi-argument center_mats on all current/retained standard, ALT, SHORT and LONG matrices BEFORE choosing the consumed pair. Subsequent common pad preserves the common anchor. A6 reads actual upper-right vertices and shifts one piece by the actual difference to the represented standard parent's upper-right. In coordinates relative to the common b, the proof above applies verbatim; restoring b adds 2b to each reflection center. Independent earlier unpad crops of stored LEFT/RIGHT are therefore harmless: their displacement is canceled by the next actual center_mats.

**No current A5 minimum/extremum formula is needed.** The only retained frame premise for raw-source pairing is the earlier ALT creation-center/A4 restoration invariant (plus earlier standard centers). Current piece anchors and upper-rights cancel by exact set geometry and literal A6. In particular one need not re-prove L150's six-row piece-minimum table to invoke current domain reflection.

## Read-only recovery and closure of the anchor dependency (09:58 UTC)

The missing AG document was located and fetched through the authorized Dropbox read-only connector, at `/Past_Projects/f_lattice/thm13-recurrence-agents/flattice-thm13-20261019/ANCHOR-GEOMETRY-ANALYSIS.md`, file id `id:7FnwDTaoNtQAAAAAABpS0A`, revision `65e8326bdc56c0845d85f`, server modified2026-10-23T14:54:03Z. The local copy now sits beside L150,21151bytes, SHA256 `587a0594bd5ba9ef22ceff29f48f4b351419417e141d1b958c3fbbc5c07c6ccd`. Only connector-added trailing blank lines were normalized to the original reported byte length. No Dropbox state was changed.

**Full source read/audit PASS for the needed domain/anchor proof.** Checked AG §§1,2,4,5,6 against CP §§12.1–12.3 and literal A4/A5/A6:

1. All P,Q,P',Q' are lex-positive, including P=(1,0). Each arithmetic chain's lower-left is at its first/last index, so the complete A5 problem reduces exactly to the twelve displayed three-candidate rows, independent of suffix size. This is a uniform proof, not the bounded experiments in AG §§3,9.
2. AG §4.1 obtains t directly from the actual A4 shift of the lower-left-centered ALT input. All eight inverse-record rows use the correct phase flip at last1. The extra e2 belongs exactly to even ALT generated at pure3, including saved record3^j1; in these cases uncorrected O_y=0. It is not a shift of the running G3 origin.
3. The bounds −Q<t<=0 (odd pieces) and −P<t<=0 (even pieces) follow from Q−O=2A+A' and P−O=A+A'. For the exceptional A=0/1, subtracting e2 leaves (1,0)>lex0, not a falsely strictly positive y-coordinate.
4. Every candidate comparison in AG §4.3 is valid without sector assumptions. Odd W1's potentially dangerous G2 candidate is above G3, using O+t<=0 at last1 and Q>2P,Q'>2P' at last3. Even W0 LEFT uses (P'−P)_y=d_p>0 together with exact last1 identities (Q'−2P)_y=2d_a+d_b−n_b>0 and (P'−Q)_y=d_a+d_b−n_a>0; last2 uses P>Q,P'>Q'. Even W1 last2 uses Q+Q'+t=min(Q+Q',P'). These checks prove all six minimum rows including both lengths.
5. AG §5's SHORT alignment shifts are lex-positive, so the corrected standard minimum remains0 at an unreplaced ordinary zero-origin source. AG §6's LONG shifts are exact identities only; no positivity is falsely claimed.
6. CP §12.1's eight UNC ALT star minima do not lower the six-MAIN minimum. In odd W1 last1, the literal B3 case uses Q'−e2, still positive. CP §12.3 then checks all four corrected ALT minima using the LONG shifts. In even W0 last1 the potentially low candidate X1=2P+2P'−Q satisfies X1−(P'−Q_current)=(2k+4)P+P'>0; the other candidate P'+Q'>0. The odd exceptional cases retain their −e2 and still have positive y-coordinate. Thus the ALT lower-left table and A4 restoration close simultaneously, rather than being assumed for the current output.

This removes the earlier missing-AG obstacle to the **domain** induction. No height discussion in AG §7 or CP's value-reflection sections is used. Literal base reflection/anchor formulas remain the actual initializer inputs already audited in the prior base receipts; the endpoint G2 corrections are independently checked above.

Recovered `scripts/check_effective_piece_shifts.py` (Dropbox id `id:7FnwDTaoNtQAAAAAABpT3Q`,2790bytes) was source-read and replayed: PASS4 formal rows/**112 coefficient identities**, with output `data/effective_piece_shifts.independent_check.json`. It uses only integer polynomial vector arithmetic, pathlib and json. Together with the fresh114 identities this checks both effective-shift and reflection-center algebra.

Also recovered `scripts/verify_piece_reflection.py` (id `id:7FnwDTaoNtQAAAAAABpVNg`,9091bytes) for provenance, but did NOT execute it: it depends on absent `spec_recursion.py` and tests bounded height outputs, unnecessary for this universal domain proof. Dropbox title search for `check_all_sector_frames_suna.py` returned no matching file; no claim of replaying its old finite report is made.
