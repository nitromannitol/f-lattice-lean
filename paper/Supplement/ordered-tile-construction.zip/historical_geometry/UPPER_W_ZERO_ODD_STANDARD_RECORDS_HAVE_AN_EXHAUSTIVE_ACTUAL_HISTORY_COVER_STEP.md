# W0 odd STANDARD outputs: exhaustive actual-history physical-even cover step

2026-11-02 19:18 UTC. Domain-only conditional induction step; root adoption requested. This supplies the missing actual-history completion of `UPPER_W_ZERO_ODD_OUTPUT_PHYSICAL_EVEN_DOMAIN_COVER_ASSEMBLY.md`, especially its stale item7. It does not use current alternate cover or any height theorem.

## Actual selection and disjoint source histories

Use the same literal get_next_mat/get_l_correct selection binding independently established in `UPPER_W_ONE_ODD_STANDARD_RECORDS_HAVE_AN_EXHAUSTIVE_ACTUAL_HISTORY_COVER_STEP.md`: the even-L record refreshes on1/2 and persists through3; for saved record nu s, s1/2, its G3 is the selected odd alternate at nu, NOT the newly created child at nu s. Ones flip phase; pure2 has phase0.

For OUTER W0:
1. If nu is pure2^m and s=1, the saved phase is W1, so this case cannot occur.
2. If nu is pure2^m and s=2, the whole current history is the pure-two saved family2^(m+1)3^h. Its ORIGINAL standard odd domain has independently proved full quotient cover via `CORRECTED_UPPER_ODD_SHORT_CONSTRUCTOR_IS_A_CROPPED_HARMONIC_ROTATION.md`, root receipt `ROOT_INDEPENDENT_CORRECTED_UPPER_ODD_LITERAL_ROTATION_AUDIT.md`. Only that theorem's domain sandwich and two-point period repair are needed here. No arbitrary-word rotation is assumed.
3. If nu is nonpure and ends1/3, the consumed odd alternate is genuinely UNC. Use its actual seven-source grammar, not a literal initializer. Its older endpoint input is separately bound by the endpoint/root cap modules.
4. If nu is nonpure and ends2, it is a genuinely corrected LONG odd alternate. Its earlier saved1/3 record and independent inner suffix give the actual ten-component grammar. The same-step standard odd companion is UNC because CURRENT letter2 dispatches it that way; actual whole-B cap carriers are therefore licensed. A direct literal source is not hidden in this case.

Thus there is NO remaining direct literal consumed-source module for W0 apart from the already covered whole pure2 saved family. The direct firstmixed2^m1 initializer belongs to W1 only. This classification corrects the overly broad unresolved wording in old item7; it does not discard firstmixed histories generally.

## Proper source geometry and actual cap exceptions

Invoke the original W0 unique-window theorem, full external both-phase GW audit, actual source width, and strict adjacent-cap source/receipt listed in the old assembly. Each source packet has exact polynomial receivers plus whole-A twins and whole actual companion B carriers. The UNC creatorlast3/outer saved2 remaining B pair uses the audited reflected horizontal-band localization and actual PRESENT trace descent into the protected LEFT prefix, not H filling. Pure2 ancestry inside that strict current case is separately handled by the actual adjacent-A singleton repair and its three literal band specializations. Positive caps are actual set-reflection partners.

External full baseline receipt: `INDEPENDENT_FULL_UPPER_ODD_ADJACENT_CAP_BASELINE_AND_EXCEPTION_AUDIT.md`. Regular older-even endpoint and two half-root states: `INDEPENDENT_UPPER_ODD_ADJACENT_LITERAL_ENDPOINT_AND_HALF_ROOT_CAP_AUDIT.md`. These use actual older EVEN literal full R2, correct MIDDLE/LOW receiving-I formulas, and independent suffixes. The source creation remains genuinely nonliteral.

## Fresh proper coefficient-wall completion

Strict positivity does not automatically include D=0. `check_upper_w0_odd_adjacent_cap_d_zero_faces.py CONE unc|corr` now directly specializes B=C=1,D=0 with A and suffix variables free and freshly verifies every multiplier/margin. It reconstructs actual W0 receivers, using --outer-phase0 for the shared six-slot replayer. All six runs terminal PASS:

|cone|UNC polynomial / geometric keys / signs|CORR polynomial / geometric keys / signs|
|---|---|---|
|LOW|22 /6 /400|34 /6 /552|
|MIDDLE|22 /6 /352|34 /6 /504|
|HIGH|22 /6 /400|34 /6 /552|

Reports `UPPER_{CONE}_W0_ODD_ADJACENT_{UNC,CORR}_D0_FACE.json` assert complete28/40-key partitions. Geometric keys retain their actual A-twin/B-carrier proofs; no incomplete row is treated as a certificate. Original GW faces have the independently audited36-case both-phase face packet.

The actual reflected-band gate is source key(unc_alt_p,0,3,2,0,-1,1), coefficient phase0. Its valid proper D0 faces are LOW/HIGH only; fresh `check_upper_w0_saved2_b_band_d_zero_face.py low|high` each PASS16 signs/4 strict. MIDDLE has phase1 on D0 and excludes this key; its B exceptions are outer saved1 unchanged companion carriers. An attempted MIDDLE band replay correctly failed the phase assertion and is not promoted. The literal pure2 and half-root band initializations retain their separate adopted packets.

## Chronological conclusion

Earlier standard full cover plus unconditional traces/H gives actual I. Earlier consumed alternate full cover plus its actual support/width gives representatives. Fresh ordinary I closure and original-window certificates reduce each target class to actual unchanged/protected standard receivers or the source window. Included source copies and the exactly paid endcaps cover that window. All current periods used are genuine quotient translations; no native periodicity is inferred.

Therefore both W0 odd-standard saved1/2 records preserve physical-even quotient coverage under the earlier full-domain mutual IH, including every actual literal/saved history above. Together with separately adopted physical-odd coverage these are full standard-output steps. Root review of this final dispatcher/wall completion is requested before unconditional upper mutual-cover assembly. No current alternate coverage, value compatibility, admission or recurrence is concluded here.
