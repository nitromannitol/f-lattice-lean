# Independent W1 STANDARD odd-output proper cap walls

2026-11-02 19:26 UTC. Full wrapper read, fresh six cap suites and fresh MIDDLE B-band suite PASS.

`check_upper_w1_odd_adjacent_cap_d_zero_faces.py low|middle|high unc|corr`: UNC22 polynomial cases per cone,352 signs each; corrected34 cases,552/504/552 signs. Independent exact expected-set comparison checked all six duplicate-free inventories, not just counts. UNC stored inventory omits four A-twin keys per face and has24 keys (22+2 B); corrected has40 (34+4 twins+2 B).

LOW/HIGH source states(W,last,outer)=(0,3,1),(1,1,2); MIDDLE=(1,3,2),(0,1,1). Thus LOW/HIGH last3 B gates are whole outer-saved1 companion carriers. ONLY MIDDLE has the outer-saved2 reflected trace gate. Fresh `check_upper_w1_saved2_b_band_d_zero_face.py middle` PASS16 signs/4 strict for exact key(unc_alt_p,1,3,2,0,-1,1). Its added source lower-I s row is reconstructed from the actual B H-normal row. Positive cap uses separately proved actual domain reflection; actual PRESENT trace descent remains its audited geometric input, not H filling.

All wall signs are freshly evaluated at B=C=1,D=0, retaining A/suffix variables and combining coefficients. No D>=2 positivity or vanishing scale is reused. Actual current W1 source/receiver reconstructions are used (corrected shared checker defaults outer1). Original GW both-phase36 faces were separately independently audited; direct literal/half-root/source-support cases retain their existing literal receipts.

This completes the proper-wall clarification for the already adopted W1 STANDARD history step. It does not on its own prove whole mutual cover or any height/admission/recurrence assertion.
