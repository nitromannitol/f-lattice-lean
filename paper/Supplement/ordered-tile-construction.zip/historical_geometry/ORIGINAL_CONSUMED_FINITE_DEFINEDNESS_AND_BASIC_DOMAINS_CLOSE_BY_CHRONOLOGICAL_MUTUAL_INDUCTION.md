# Consumed finite definedness and BASIC-domain invariants close chronologically

2026-11-02 13:17 UTC. DOMAIN-ONLY joint induction. The anchor inventory is independently audited, including endpoint corrected-ALT40. ROOT independently adopted both the new four literal ALT initialization differences and the full dependency graph; receipts are given below. No quotient cover or height theorem is an induction premise.

## Statement

Every standard/alternate output actually requested by the ORIGINAL recursion has a finite nonempty integer-valued native array. Every consumed ordered touching insertion has a finite integer normalization scalar, and its support is exactly the union of the placed source supports. Every consumed SHORT/LONG piece has the same property. Unused auxiliary initializations that never supply a selected operand are explicitly not asserted finite.

Simultaneously:
1. Standard domains contain all four prescribed BASIC traces, all mandatory non-pqqq horizontal extras and their prescribed reflections, and the separately protected endpoint extras.
2. Alternate domains contain their prescribed ACTIVE BASIC trace (normal horizontal for even ALT, reversed vertical for odd ALT, in the actual creation frame).
3. Actual standard/ALT domain reflection and the adopted lower-left/A4/A6 frame formulas hold; like-indexed LEFT/RIGHT prefixes are reflected as sets.
4. The twelve standard ports used in the finite-overlap tables are retained.

The previously audited all-sector H/R2 upper-support induction can consequently use the exact actual support unions without a finite-touch proviso. This is NOT full-hull equality, quotient coverage, overlap value agreement, a canonical boundary VALUE theorem, admission, or recurrence.

## What is carried in the state

Carry the actual current and retained standard/ALT arrays, their raw/restored creation-frame records, and the selected SHORT/LONG corrections. Every source and every saved MAIN copy mentioned by an anchor is earlier in this chronological state. An erased finite union can be formed geometrically before any touching scalar is computed; the overlap proofs then identify it with the actual finite support. This distinction avoids assuming a current output finite merely to define its geometric candidate.

At a word transition, literal `final_code/odometer_recursion.jl:get_next_mat` first centers the OLD state, selects the two parent pairs and OLD corrections, and constructs four outputs (lines359–372 in the recovered source). It next stores the new quadruples, updates the ancestor record according to the letter (lines386–391), and only THEN builds the NEXT SHORT/LONG pieces (lines397–398). Thus an A5 head proof using the newly stored creation MAIN copies is later than their already completed output construction, not circular with it.

## Dependency DAG

| stage | uses only | establishes | excluded dependence |
|---|---|---|---|
|Literal initialization|exact base selectors and atom words|finite nonempty bases; BASIC standard/active ALT; reflection and native frames|no current or earlier cover, no generic synthetic base creator|
|OLD-piece input at a transition|previous-stage completed consumed A5 pieces|finite incoming corrections|does not build next pieces early|
|Current four outputs|earlier ports, standard BASIC, ALT active BASIC, earlier domain reflection, finite OLD pieces; explicit ordered anchors|finite scalars, exact current support unions|no current I/H equality, quotient cover, source height compatibility or current min formula|
|Current standard trace update|earlier standard BASIC/mandatory extras; exact union; protected full G1/G2 prefixes and endpoint joins|current BASIC4 and mandatory extras|no G3 value retention or unknown opposite gauge|
|Current ALT trace update|earlier standard BASIC; exact union; two actual standard/prefix carrier blocks|current active BASIC trace|no current ALT active values or full ALT boundary exhaustion|
|Current frames/reflection|earlier source centers/anchors; actual finite union; literal A4/A5/A6 center/extrema algebra|actual current frame/minima and set reflection|no current cover or height symmetry|
|NEXT internal pieces|now earlier selected parents/records, their ports/active traces/reflection; prefix/head/tail anchors|finite next consumed SHORT/LONG pieces and reflected paired prefixes|no next-child cover, next-child values or currently unavailable MAIN source|

The stages trace/frame update may be performed on the same erased union; neither needs the other's height information. A6 reads actual geometric extrema; its previously audited erased-domain formulas are valid before scalar choices because they use the minimum of finitely many known nonempty source supports. Once overlaps are proved finite, those extrema are exactly the actual ones.

## Ports do not secretly use quotient cover

The normal horizontal first q@0 BASIC atom contains0,e1,e2. The normal vertical first p@(U-(1,1)) contains U via native(1,1) and U-e2 via native(1,0). The prescribed reflected BASIC traces therefore contain w,w-e1,w-U and w-(U-e2)=V+e1. These give all eight standard ports0,e1,U,V+e1 and their prescribed reflections, WITHOUT assuming whole-domain reflection or H membership. The four odd ports e2,U-e2,U+e2,U+V-e2 also have their independent unchanged-MAIN induction in ORIGINAL_STANDARD_FOUR_ODD_PORTS_AND_TERMINAL_OVERLAP_ANCHORS.md and its independent receipt. Thus the complete twelve-port list used by the anchor scripts is available chronologically. The H/cover-forced body corner U-2e1+e2 is NOT used anywhere in this finite-definedness proof.

For the special corrected-ALT principal LEFT anchors, the earlier even ALT active trace supplies its terminal BASIC site B-e2, and earlier ACTUAL ALT domain reflection supplies the required reflected point with the correct parent-dependent center. W1 saved-last3 instead descends through an actual earlier RIGHT protected standard chain. Neither argument substitutes an ALT standard-H port. Literal endpoint corrected-ALT40 uses literal corner membership rather than a fictitious creator MAIN decomposition.

## Literal initialization and inheritance inputs

Standard literal BASIC/mandatory initialization is LITERAL_PURE_STANDARD_BASES_CONTAIN_ALL_BASIC_TRACES_AND_MANDATORY_QQ_EXTRAS.md, with its independently replayed20 unbounded differences. Alternate initialization is LITERAL_ALTERNATE_BASES_CONTAIN_THEIR_ACTIVE_BASIC_TRACE.md and the fresh checker check_literal_alternate_active_basic_initialization.py (four unbounded differences). Both include root1/2,1/3 and proper3/5 branches through their actual selectors. Endpoint atoms are their literal finite BASIC shapes.

Standard trace/extra inheritance is ALL_ORIGINAL_FINITE_STANDARD_DOMAINS_RETAIN_BASIC_TRACES_AND_MANDATORY_QQ_EXTRAS.md. Its finite-support premise is supplied at the CURRENT output stage, not assumed globally. Ordinary trace concatenation uses complete earlier words; corrected traces use complete protected G1/G2 prefixes; endpoint singleton joins and the one permitted pure2 pqqq omission are explicitly covered. No actual trace VALUE assertion from those sources is needed.

ALT active-domain inheritance is the domain-only portions of EVEN_ALTERNATE_ACTIVE_HORIZONTAL_WORD_HAS_TWO_EXACT_STANDARD_TRACE_CARRIERS.md and ODD_ALTERNATE_ACTIVE_REVERSED_VERTICAL_WORD_HAS_TWO_EXACT_STANDARD_TRACE_CARRIERS.md, including their corrected extensions. Independent receipt INDEPENDENT_CORRECTED_ALT_ACTIVE_BASIC_TRACE_CARRIER_DOMAIN_AUDIT.md verifies the exact protected-prefix rows. These two standard blocks are actual support carriers even if earlier touching clips their values.

## Reflection, anchor minima and support enclosures

INDEPENDENT_ALL_WORD_DOMAIN_REFLECTION_CENTER_AND_SCOPE_AUDIT.md independently reads the literal frame code and recovered AG anchor proof, and freshly checks114 source-center identities plus112 effective-shift identities. Its recovered09:58 appendix proves the A4 minima and all A5/A6 lexicographic comparisons without cover, recurrence, values or scalar agreement. The paired LEFT/RIGHT argument is same ordered index, not reversed order. The pure3 G2-only shifts and pure2 LEFT G2 shift are included; the G3 running origin is never shifted by those endpoint exceptions.

AG's minimum calculations require finite nonempty INPUT sources and the erased union only. After the explicit finite-overlap stage this is the actual support; therefore its conditional finite-union premise is discharged in this joint induction. No historical finite frame experiment is used as evidence.

All-word H/R2 support induction in ORIGINAL_ALL_WORD_SUPPORT_RECORD_EXHAUSTION_AND_INDUCTION.md and its separately audited strict/literal support modules uses earlier support enclosures, actual source frames, and current exact union. It does not feed a CURRENT cover hypothesis back into the overlap anchors. Its definedness condition is now supplied by the preceding stages. This application preserves every original endpoint/creation-record scope.

## Complete anchor inventory and endpoint exhaustion

ORIGINAL_CONSUMED_OPERANDS_HAVE_A_COMPLETE_FINITE_TOUCH_DEFINEDNESS_INVENTORY.md lists the ordinary standard/UNC ALT, A5 prefix/first-head/tail/LEFT-transfer, corrected standard and corrected ALT modules and receipts. Endpoint corrected-ALT40 now has INDEPENDENT_LITERAL_ENDPOINT_CORRECTED_ALT_FORTY_OUTER_ANCHORS_AUDIT.md; endpoint UNC48 has INDEPENDENT_LITERAL_ENDPOINT_UNC_ALT_ORDERED_TOUCH_AUDIT.md. Root separately adopted strict standard-prefix8/32.

Saved records are exhausted by strict older creation core; proper firstmixed saved-last1 lower/upper and lower-last2/upper-last3 (with separate root); and pure2/pure3 records. The proper firstmixed rows have strict consumed standard P,Q despite their endpoint predecessor. Pure-run singleton G2 shifts are NEVER obtained by specializing a strict H or synthetic ALT creator. Their actual finite outer constructions are the adopted corrected-negative/rotated-upper standard family proofs and direct pure3/pure2 LONG domain proofs cited in the inventory. Only their finite support/overlap portions are used, not recurrence.

An auxiliary requested by the implementation but never selected by any future admissible record is outside the consumed-state claim. The actual saved-record table and pure-word dispatch determine this exclusion; this theorem does not claim that arbitrary disjoint initial correction calls have finite maxima.

## Consequence and exact limit

Well-founded induction on actual constructor time now simultaneously proves the stated consumed definedness and domain invariants, with all initialization and dependency-graph inputs independently adopted. There is no cycle through quotient cover or heights. The theorem discharges the finite-union premise of the domain-support/trace/reflection packets; it does not supply the still separate upper physical-even corrected quotient-cover cases or any missing value/recurrence induction.

## Independent adoption (13:24 UTC)
Root full-read/fresh-replay receipts are ROOT_INDEPENDENT_LITERAL_ALT_ACTIVE_BASIC_INITIALIZATION_AUDIT.md (four EMPTY differences) and ROOT_INDEPENDENT_CHRONOLOGICAL_CONSUMED_DEFINEDNESS_AND_BASIC_DOMAIN_AUDIT.md. Root checked actual get_next order, active ALT carrier extensions, all ports as BASIC/reflected sites, erased-union frame DAG and record exhaustion. No quotient-cover or height cycle was found. The consumed finite-definedness, standard BASIC/mandatory, ALT active BASIC and set-frame/reflection conclusions above are therefore unconditional all-word DOMAIN invariants of the original recursion, with unused initial auxiliaries explicitly excluded. This adoption does not assert all-word quotient cover, value normalization or recurrence.
