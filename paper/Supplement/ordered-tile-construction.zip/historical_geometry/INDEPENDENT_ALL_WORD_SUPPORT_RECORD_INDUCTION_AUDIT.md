# Independent final audit: all-word original upper-support induction

2026-11-01 19:53 UTC. **PASS for the upper-support subgoal, not recurrence or constructor definedness.**

Read the current ORIGINAL_ALL_WORD_SUPPORT_RECORD_EXHAUSTION_AND_INDUCTION.md and directly inspected getNextFrac, get_first_ancestor, get_next_mat and get_odometers in the recovered original Julia source.

## Exhaustion and chronology

The first ancestor is exactly the maximal initial pure2/pure3 prefix, or empty. The four first-mixed families are exhaustive. A retained0/1 parent survives only pure3 moves, and retained1/1 only pure2 moves; once removed it cannot return because all children are strict. Hence a record with endpoint predecessor data is the pure prefix or its first mixed refresh. Intersecting this with the actual record updates (odd after1/3, even after1/2) yields exactly the source's eight persistence families, with suffix2^k or3^k. The unused initial correction is never imported into the theorem.

Both record updates occur after construction of all four children. Generic alternate inputs are the refreshed child of the predecessor pair at an earlier prefix: last1 may use p=a+b or q=2a+b; last2 uses alternate p=a+b; last3 uses alternate q=2a+b. A retained pure-base q in last2 or p in last3 is used only as STANDARD. Thus no generic creation-R2 estimate is applied to a pure-base alternate, including a record immediately after the first mixed word.

The sector exhaustion argument is correct. A strict odd/even determinant-one pair has denominator sum at least5. Every reduced rational strictly between it has positive integer unimodular coordinates and hence denominator at least that sum. Neither1/3 nor1/2 can lie strictly between the pair, so one closed sector contains it. The parity-compatible boundary cases are present in the exact cone packets.

## Complete proof inputs

The pure-standard H base gate is now proved in ORIGINAL_ALL_PURE_STANDARD_BASE_DOMAINS_LIE_IN_FULL_H.md and independently checked in INDEPENDENT_ALL_PURE_STANDARD_BASE_FULL_H_AUDIT.md. It includes the actual empty-root staircase1/2 and1/3 domains; endpoint atoms and pure alternates are handled separately.

The generic ordinary576, outer4480, and balanced4816 certificate sets have all been freshly generated and independently replayed. Balanced includes all six literal root cases. All first-mixed initial outputs and all sixteen nonroot endpoint persistence cases have source-level independent audits, including actual literal base bounds, raw K/A6 placements, parity rounding and domain reflection. Growing standard inputs are supplied either by an explicit uncorrected domain expansion or an earlier ordinary-H induction step.

Therefore ordinary induction on actual constructor steps maintains H containment of every stored strict standard and creation-R2 containment of every stored NONBASE alternate. Every actual source is earlier or a separately certified literal base; no current-child support or height claim is used circularly.

## Exact conclusion and limitations

The actual finite support is contained in the translated operand union, and the retained L150 frame theorem identifies its physical frame. This is enough for upper inclusion; exact support equality, touching-scalar compatibility and lower coverage are not needed. The theorem concerns outputs of the original constructor in those actual frames. It does NOT separately prove that every touching operation is defined/nonempty, nor prove its values agree, its periods hold, or its native stars are admitted.

With these boundaries, the all-word upper-support subgoal is established. In particular this is not completion of the user's recurrence task. The uniform original height/period/SH and global interface or kernel-calibration/contact obligations remain separate.
