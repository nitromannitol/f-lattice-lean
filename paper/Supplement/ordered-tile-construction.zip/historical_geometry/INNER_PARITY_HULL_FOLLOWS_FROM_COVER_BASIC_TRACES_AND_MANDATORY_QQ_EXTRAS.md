# Inner parity hull from cover, basic traces, and mandatory qq extras

2026-11-02. Constructive arithmetic bridge. This is not a proof of generic corrected trace retention.

Use the exact H, I, J, periods and arithmetic reflection from
`ALL_SECTOR_INNER_PARITY_RECTANGLE_HAS_A_DIRECT_INTRINSIC_QUOTIENT_COVER.md`
and `STANDARD_HULL_COVER_FORCES_AN_EXACT_UNIQUE_REPRESENTATIVE_INNER_CORE.md`.
Use the exact mechanical horizontal and vertical normal traces. Let B be their basic atom sites and their images under z->w-z. Let E be the horizontal lower qq extras r_j+(1,-1) EXCEPT those whose decorated q is the middle q of an internal pqqq, together with their reflected images. No other qq enlargement or current-domain reflection is assumed.

Then, for every strict reduced fraction,

                    I subset J union B union E.        (1)

## Proof

By the explicit formulas for J, a point of H\J lies in at least one of its two horizontal or two vertical ambiguity bands. `ROOT_HORIZONTAL_AMBIGUITY_BANDS_ARE_BASIC_ATOMS_OR_QQ_EXTRAS.md` proves that the horizontal bands are basic sites or precisely the designated lower qq extras, plus their reflections. `ALL_STANDARD_VERTICAL_AMBIGUITY_BANDS_ARE_BASIC_ATOM_SITES.md` proves that both vertical bands are basic sites, including all finite endpoint indices.

It remains to exclude the optional pqqq extra from I. Put A=d+n,N=2n,c=d-n, C_k=ceil(Nk/A), delta_k=A*C_k-Nk. A lower qq extra of atom j=k+1 in the upper horizontal band has s=A-delta_k and c<=delta_k<N. The kth letter is q, so delta_(k-1)=delta_k-c. It is preceded by p precisely when delta_(k-1)<c, or delta_k<2c. Its successor j+1 is q precisely when delta_(k+1)=delta_k+c<N. Hence an internal pqqq deletion satisfies

             c<=delta_k<min(2c,N-c).

If this interval is nonempty, N>2c, equivalently n>d/2. Its extra therefore satisfies

             s>A-2c=3n-d,
             s>A-(N-c)=2c.

The upper-sector I even bound is s<=max(3n-d,2c). Thus the extra is outside I. At n<=d/2 the deletion interval is empty. Reflection preserves I, so the reflected optional extra is outside I as well. This proves(1).

## Actual-domain consequence and precise remaining induction gate

Suppose an actual standard domain D obeys:

1. D subset H and D+Lambda=Z²;
2. D contains B, the four specified basic traces;
3. D contains E, all specified non-pqqq horizontal extras and their reflected copies.

The unique-representative argument gives J subset D. Equation(1) then gives I subset D. The claim uses earlier quotient cover, not full H equality, and permits genuine deletions such as the two missing word23 sites.

This bridge can recover the stronger lower-hull induction hypothesis from a weaker cover-plus-trace hypothesis. It does NOT itself prove either cover or actual constructor retention of B/E. Complete-word p|q concatenation preserves the mandatory-extra property, as proved in `COMPLETE_STRICT_BOUNDARY_CONCATENATIONS_PRESERVE_NON_PQQQ_QQ_EXTRAS.md`; exact offsets, corrected A5/A6 prefix binding, and endpoint exceptions remain separate source-level inputs. There is no circular inference of cover from the desired I containment.

## Stronger low-slope arithmetic consequence

The band proofs actually give H subset J union B union ALL designated horizontal qq extras/reflections. If n/d<=1/2, then N<=2c and the optional pqqq interval above is empty. In that sector, (1) strengthens to H subset J union B union E. Thus the three actual-domain premises would imply D=H in this sector. This is an arithmetic conditional statement only; it is not an assertion that generic corrected trace binding has already been proved.
