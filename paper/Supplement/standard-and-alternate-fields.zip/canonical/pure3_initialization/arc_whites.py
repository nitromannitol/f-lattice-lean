from pathlib import Path
import sys,json,hashlib,subprocess
sys.path.insert(0,'/tmp/f_lattice_z3');import z3 as z
import sympy as s
D=Path(__file__).resolve().parent;d,t=z.Ints('d t');dd,tt=s.symbols('d t')
def cv(e):
 p=s.Poly(s.expand(e),dd,tt)
 return sum(z.RealVal(str(c))*d**i*t**j for(i,j),c in p.terms())
def zero(e):
 e=s.factor(e)
 if e==0:return z.BoolVal(True)
 _,fs=s.factor_list(e)
 return z.Or(*[cv(f)==0 for f,k in fs])
def native(u,v):return z.Or(z.And(u>=2-d,u<=d,v>=0,v<=d+1,u+v>=1,u+v<=d+2),z.And(u==0,v==0),z.And(u==2,v==d+1))
rows=[]
for typ,X,Y,guard in [('H',tt,0,z.And(t>=1,t<=d)),('V0',0,0,z.BoolVal(True)),('Vi',1-tt,tt,z.And(t>=1,t<d)),('Vl',2-dd,dd,z.BoolVal(True))]:
 X,Y=s.sympify(X),s.sympify(Y)
 for par in[0,1]:
  rootpar=int((X+Y).subs({dd:3,tt:par}))%2
  for ex,ey in[(0,0)]+([(-1,0),(1,0)]if rootpar==0 else[(0,-1),(0,1)]):
   xx,yy=X+ex,Y+ey
   arg=yy+1-xx;rem=int(arg.subs({dd:3,tt:par}))%2
   target=s.Integer(0)if typ=='H'else xx*(xx-1)/2-(arg*arg-rem)/4
   offers=[]
   for i in[-1,0,1]:
    for j in[-1,0,1]:
     u=xx+i*dd+j*(1-dd);v=yy+i+j*(dd+1);zu,zv=cv(u),cv(v)
     base=-v*(v-1)/2-j*(xx-dd*yy-dd*(dd+3)/2)+j*(j-1)*(dd*dd+2*dd-1)/2-target
     # split min(u-1,0) and literal corner correction, exact positive offers.
     corner=z.Or(z.And(zu==0,zv==0),z.And(zu==2,zv==d+1))
     for low in[False,True]:
      for bump in[0,1]:
       offers.append(z.And(native(zu,zv),zu<1 if low else zu>=1,corner if bump else z.Not(corner),zero(base+(u-1 if low else 0)+bump)))
   name=f'arc_{typ}_{par}_{ex}_{ey}';q=z.Solver();q.set(timeout=120000);q.add(d>=3,d%2==1,t%2==par,guard,z.Not(z.Or(*offers)));raw=q.to_smt2();p=D/(name+'.smt2');p.write_text(raw);ans=str(q.check());print(name,ans,flush=True);assert ans=='unsat',q.model();fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(p)],capture_output=True,text=True).stdout.strip();assert fresh=='unsat';rows.append(dict(name=name,status=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
(D/'ARC_WHITE_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
