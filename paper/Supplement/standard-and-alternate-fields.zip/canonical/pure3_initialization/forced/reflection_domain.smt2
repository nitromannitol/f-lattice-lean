; benchmark generated from python API
(set-info :status unknown)
(declare-fun d () Int)
(declare-fun y () Int)
(declare-fun x () Int)
(assert
 (>= d 3))
(assert
 (= (mod d 2) 1))
(assert
 (let (($x22 (and (= (- 2 x) 2) (= (- (+ d 1) y) (+ d 1)))))
(let (($x19 (and (= (- 2 x) 0) (= (- (+ d 1) y) 0))))
(let (($x62 (and (>= (- 2 x) (- 2 d)) (<= (- 2 x) d) (>= (- (+ d 1) y) 0) (<= (- (+ d 1) y) (+ d 1)) (>= (+ (- 2 x) (- (+ d 1) y)) 1) (<= (+ (- 2 x) (- (+ d 1) y)) (+ d 2)))))
(let (($x33 (= x 2)))
(let (($x35 (and $x33 (= y (+ d 1)))))
(let (($x32 (and (= x 0) (= y 0))))
(let ((?x49 (+ x y)))
(let (($x50 (>= ?x49 1)))
(let (($x47 (>= y 0)))
(let (($x53 (and (>= x (- 2 d)) (<= x d) $x47 (<= y (+ d 1)) $x50 (<= ?x49 (+ d 2)))))
(and (distinct (or $x53 $x32 $x35) (or $x62 $x19 $x22)) true))))))))))))
(check-sat)
