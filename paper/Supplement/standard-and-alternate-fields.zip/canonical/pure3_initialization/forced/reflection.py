from source import *
if __name__=='__main__':
 X,Y=2-x,d+1-y
 # Quadratic parts cancel: reflected difference minus (-x+d*y+1-d(d+1)/2)
 diff=2*P.corr(X,Y)-2*P.corr(x,y)+2*x-2
 rows=[run('reflection_domain',P.native(x,y)!=P.native(X,Y)),run('reflection_height',z.And(P.native(x,y),diff!=0))]
 (D/'REFLECTION_RECEIPT.json').write_text(json.dumps(rows,indent=2))
