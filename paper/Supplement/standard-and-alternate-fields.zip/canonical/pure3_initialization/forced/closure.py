from source import *
if __name__=='__main__':
 fc=[];sat=[]
 for dx,dy in [(0,0),(1,0),(0,1),(1,1)]:
  X,Y=x+dx,y+dy;fc.append(z.If(isfree(X,Y),1,0))
  # bulk whites horizontal; outward west on left, east on right.
  for i,j in P.aliases:
   a,b=P.shift(X,Y,i,j)
   sat.append(z.And(bulk(a,b),z.If(a<=0,-1,1)==(-1 if dx==0 else 1)))
 row=run('closure',z.And(P.native(x,y),z.Not(z.Or(*sat)),sum(fc)<2))
 (D/'CLOSURE_RECEIPT.json').write_text(json.dumps([row],indent=2))
