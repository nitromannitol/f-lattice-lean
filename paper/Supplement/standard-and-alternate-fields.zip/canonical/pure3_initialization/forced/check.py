from pathlib import Path
import sys,json,hashlib,subprocess
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent));import prove_rank as P
z=P.z;d,x,y=P.d,P.x,P.y
# All queries use actual physical coordinates, not quotient edges.
def run(name,bad):
 s=z.Solver();s.set(timeout=120000);s.add(d>=3,d%2==1,bad);raw=s.to_smt2();p=D/(name+'.smt2');p.write_text(raw);a=str(s.check());print(name,a,flush=True)
 out=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(p)],capture_output=True,text=True,timeout=130).stdout.strip();assert a==out=='unsat',(name,a,out,str(s.model())if a=='sat'else'')
 return dict(name=name,status=a,fresh=out,sha256=hashlib.sha256(raw.encode()).hexdigest())
def isfree(X,Y):return z.Or(*[P.free(*P.shift(X,Y,i,j))for i,j in P.aliases])
def bulk(X,Y):return z.And(P.star(X,Y),(X+Y)%2==0,P.lap(X,Y)==0,z.Or(X<=0,X>=2),z.Not(isfree(X,Y)))
def black(X,Y):
 return z.Or(*[z.And(P.star(*P.shift(X,Y,i,j)),P.lap(*P.shift(X,Y,i,j))==-1)for i,j in P.aliases])
def earlier(X,Y,root):return z.And(bulk(X,Y),z.If(X<=0,1-X,X-1)<z.If(root<=0,1-root,root-1))
if __name__=='__main__':
 rows=[]
 for side in [-1,1]:
  # side=chosen horizontal direction; opposite square is the rejected side.
  good=[]
  for v in [-1,1]:
   a,b=x-side,y+v
   good.append(z.And(black(x-side,y),black(x,y+v),z.Or(black(a,b),z.And(earlier(a,b,x),z.If(a<=0,-1,1)==side))))
  rows.append(run('force_'+str(side),z.And(bulk(x,y),z.If(x<=0,-1,1)==side,z.Not(z.Or(*good)))))
 (D/'FORCING_RECEIPT.json').write_text(json.dumps(rows,indent=2))
