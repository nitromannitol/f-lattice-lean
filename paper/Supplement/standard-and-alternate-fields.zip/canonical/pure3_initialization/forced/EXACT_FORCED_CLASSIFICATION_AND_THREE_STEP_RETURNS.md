# Reciprocal pure3: exact physical forcing and three-edge returns

For every K>=0, d=2K+3, take the actual standard even field at word3^K. The empty word K=0 is included. All statements below are on the physical F-lattice, not on a torus burn.

## Authentic source, cover and deck

The source is precisely original_port_base.get_staircase_even(s,isFull=True), dispatched at empty word and every pure3 word by get_base_quadruple. Its exported native support is
[2-d,d] x [0,d+1] intersect {1<=x+y<=d+2}, plus (0,0),(2,d+1).
Its value is -y(y-1)/2+min(x-1,0)+the indicator of those two corners. The literal source and port are hash-bound below. No generic nonbase producer is used.

U=(d,1), V=(1-d,d+1), a=(1,-d), T=d^2+2d-1, cU=0, cV=-d(d+3)/2.
For an alias z+iU+jV, the doubled value pulled back to z, after subtracting -y(y-1), is
2 corr(z+iU+jV)-2dij+2dj-i^2-2ij-2iy+i-2j^2-2jx-2jy+2j.
This is affine in the quantified physical coordinates and d. It is not a numerical fit.

The earlier exact inverse bounds apply to any native point or its unit neighbor: all possible native aliases have |i|<=2, |j|<=1. Fifteen new gates prove agreement with the native value on EVERY overlap in this exhaustive window. The inverse deck cocycle extends this consistency to all overlaps. Four new gates prove every cardinal unit neighbor of every native point has a positive native alias. Consequently the periodic union of this nonempty native domain is closed under all four unit moves, hence equals Z^2. This proves full cover without assuming recurrence, binary admission, or a quotient cardinality. The ITE global field is therefore total and coherent. A new gate proves its doubled Laplacian is 0 or -2 everywhere. Every raw query has a matching standalone CLI replay.

## Exact forced/free classification

Write H={(j,0):1<=j<=d} and Vpath={(0,0)} union {(1-j,j):1<=j<d} union {(2-d,d)}. Their deck classes are disjoint with unique H/V representatives by the already sealed uniqueness gate. All these classes are white by the source-height gates in the earlier packet, independently included in the present global color classification.

Every other white has a genuine native full input star at an even root, with x<=0 or x>=2. More precisely, the new classification gate proves white iff some H/V alias OR some such genuine full-star white alias. This weaker existential formulation is sufficient and avoids an arbitrary representative convention.

The forced arrow is W for x<=0 and E for x>=2. Here is an actual finite unit-clause proof, not an inference from a chosen strict policy. For a bulk white z=(x,y), let s=-1 or +1 be that arrow. One of the two elementary squares on the REJECTED side has the following three other corners:
  z-s e1, z-s e1+v e2, z+v e2,  v in {-1,+1}.
The two odd corners are genuinely black. The opposite even corner is either genuinely black or a bulk white whose arrow s points into this square and whose native |x-1| is strictly smaller. The two universal forcing gates prove this exact assertion, including all boundary-adjacent native cases. Induct on the minimum |x-1| among a site's bulk offers. The predecessor's minimum is no larger than its displayed smaller value. Acyclicity of the already proved strict policy ensures overlapping offers cannot force contradictory arrows. Thus every nonfree white has a finite elementary-square unit proof of the stated arrow.

No H/V white is further unit-forced. The new closure gate checks EVERY elementary square (its SW corner taken in a native domain, then translated): either a previously forced bulk white already points OUT of that square, satisfying its clause, or the square has at least TWO H/V white corners. There are therefore no remaining zero- or one-literal unsatisfied clauses after all bulk assignments. This establishes exact exhaustion of the elementary-square forcing process, not merely a subset of its forced sites.

## Uniform three-edge physical returns

For b in {-1,+1}, use Q_b: H even W, H odd S except Hlast has vertical -b; V even has horizontal b except Vlast W, and V odd has vertical -b. In particular H0 is S and V0 has horizontal b. Nonfree whites use the arrows just proved; black roots retain both inputs.

For EVERY H/V root z and its selected direction e, the rejected neighbor z-e has a retained path of EXACTLY THREE unit steps to z. The proof checks the two possible squares:
  z-e -> z-e+v -> z+v -> z,
where v is one of the two perpendicular unit vectors. Eight universal gates (two signs, four possible selected physical directions) prove at least one path exists. Each intermediate retained edge is licensed by either a genuine native black star, a genuine bulk white offer, or the exact H/V free table. No projected edge, winding argument, or terminal-rank premise is used. The last H/V sites, both corners, and d=3 are inside the quantifiers.

## Actual reflection

Rc=(2,d+1)=U+V+(1,-1). Native support is exactly reflection-invariant, and
 F(Rc-z)=F(z)-x+d y+1-d(d+1)/2.
Two new universal gates prove this directly from the literal native source; deck coherence extends it globally. Rc has even parity, so reflection preserves the input axis and colors. Reflect Q_{-eta}. Since Rc-H_j=H_{d-1-j}+V and Rc-V_j=V_{d-j}+U (indices H0..Hlast and V0..Vlast), the reflected free table is exactly e_{(-1,eta)}: H0 vertical -eta, remaining H positive axial, V0 E, Vlast horizontal eta, internal V horizontal eta or vertical -eta. Bulk forced directions reflect as well. All forcing squares and every three-step return transport as PHYSICAL paths. This closes the previous named-canonical graph-inclusion qualification in the strict-rank packet.

This note makes no new claim that the previous affine strict rank has zero character on the clean-band pitch. That separate issue is handled by allj_audit's flat-level certificate. Ordinary physical recurrence already follows from the prior strict ranks, now for the fully identified canonical graphs.

## Reproducibility

check.py: two forcing gates. source.py: fifteen coherence, four cover, binary and classification gates. closure.py: exact unit-closure gate. returns.py: eight three-step gates. reflection.py: two native reflection gates. Total 34 universal integer-linear queries, each producer UNSAT and separately replayed UNSAT. The current manifest additionally binds the earlier rank, uniqueness and arc-height evidence, and the literal source files. Finite probes are not premises.
