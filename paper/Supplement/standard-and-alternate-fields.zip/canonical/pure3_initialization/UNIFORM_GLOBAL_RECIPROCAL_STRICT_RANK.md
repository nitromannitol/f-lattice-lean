# Explicit global strict ranks for the genuine reciprocal standard

## Theorem and policy
For every odd d>=3, including the actual empty-word root d3, let F be the original standard even reciprocal1/d. The two policies Q_b below have global strict integer ranks with deck characters

 cU=2d, cV=2b(d+1),  U=(d,1), V=(1−d,d+1).

Every retained physical input drops the rank by at least1. Both actual black inputs are retained; each white has at least one retained input. Thus F has no finite nonempty fort. Reflection gives the two oppositely oriented policies, and the authenticated harmonic quarter-turn transports recurrence to the genuine pure2 odd base.

Here H={(j,0):1<=j<=d}; Vpath={(0,0)} union{(1−j,j):1<=j<d} union{(2−d,d)}. On H choose W at even roots and S at odd roots, except Hlast chooses vertical−b. On Vpath choose horizontal b at even roots and vertical−b at odd roots, except Vlast chooses W. The H0 choice is S. All translates carry the same arrows.

For remaining sites use every positively certified native-full-star even WHITE offer: W if its native x<=0, E if x>=2. Exclude all H/V classes from this bulk rule. If no white offer exists, retain BOTH actual inputs. This conservative last rule is intentional: missing a white classification never discards a required black edge. Multiple positive offers, if any, are all retained and all are checked. One may choose any retained direction at a white. The graph is defined by all genuine deck aliases, not by a representation-dependent sample window.

The eight universal rank gates apply to THIS explicit graph. Identification with a named canonical graph additionally uses its genuine nonfree-arrow classification, or direct graph inclusion. On every genuinely unit-forced white, any satisfying completion of this acyclic graph must choose its forced direction. No unsupported complete unit-closure theorem is used for recurrence.

## Canonical representatives and the five-piece ranks
Choose the unique H/V representative of a free class first. For every other class choose the lexicographically largest native point (x first, then y). Put p=(x+y) mod2. On these representatives set:

Q_minus:
  H:                  2x+p
  Vpath:             −2y−p
  x+y=d+1 and x>=1:   2x
  other x<=0:         2x−4+p
  other x>=1:         4d−4−2x+p.

Q_plus:
  H:                  2x+p−4
  Vpath:              2y−p
  x+y=2 and x<=0:     2y
  other x<=0:         2x+4d−4+p
  other x>=1:         4d−2x+p.

Branches are ordered as printed. Extend R_b(z+iU+jV)=R_b(z)+2di+2b(d+1)j. These formulas are not asserted on all duplicate native points without their deck correction. That distinction is essential near the native corners.

## Why the finite alias window is globally complete
The actual native domain lies in [2−d,d]×[0,d+1], including both inserted corners. H/V representatives are native. For a native root or one of its actual inputs, comparison to any native representative gives |dx|<=2d−1 and |dy|<=d+2. With T=d²+2d−1, inverse deck coordinates obey

 |i| T <= (d+1)(2d−1)+(d−1)(d+2)=3d²+2d−3 <3T,
 |j| T <= 2d−1+d(d+2)=d²+4d−1 <2T.

Thus |i|<=2, |j|<=1. This same window contains every competing native representative, so the lexicographic test is exhaustive. A separate universal gate proves H/V uniqueness for every nonzero alias in this complete window. Genuine native quotient coverage ensures a representative exists. The four edge queries for each sign ALSO explicitly reject missing root or target representative coverage, so coverage is not merely tacitly assumed by an ITE default.

## Actual color and retained-edge checks
Bulk white offers require both inputs in the true native guard and exact native Laplacian0. In the reciprocal source F=−y(y−1)/2+min(x−1,0)+two-corner correction; the x-independent quadratic contributes0 on horizontal stars and−1 on vertical stars. The encoded correction formula retains both corners.

Twenty-four unbounded source gates prove F=0 on every H root and both actual inputs, and F=h0 on every Vpath root and both inputs, including endpoints. Each height equality has a positive genuine native/deck offer from the original staircase, with exact inverse character and quadratic cancellation. All24 producer and fresh CLI checks return UNSAT. Since h0 is F-lattice harmonic, every arc offer is truly white. No raw off-native formula is extrapolated.

On each native root and each of its four possible geometric displacements, the rank query requires the physical parity-selected axis, a retained edge, actual root/target selector coverage, and strict integer rank drop. All8 queries return UNSAT in producer and separate CLI replay, uniformly for all odd d>=3. Every arbitrary physical root is a deck translate of a native one; the policy is periodic and rank differences are invariant under simultaneous translation. Hence this is a global physical proof, not a torus burn.

## Reflection, sign names and pitch warning
Let Rc=(2,d+1)=U+V+(1,−1). Reflection sends H_j to reversed H+V and V_j to reversed Vpath+U. Reflect Q_b with b=−eta. Its free arrows are: H0 vertical−eta, all other H positive axial; V0 E, Vlast horizontal eta, internal V horizontal eta or vertical−eta. This is the exact free table of e_(−1,eta), including d3. The reflected strict rank is R_(−eta)(Rc−z), with characters(−2d,2eta(d+1)). The interior/nonfree name identification retains the graph-inclusion qualification above.

Along the exact chain pitch 2eta U+V this rank changes by2eta(1−d), NOT zero. It must not be used as a rank on a pitch quotient. Subtracting(d−1)P cancels that character algebraically but fails to remain strict even on flat Phi: at d3,eta−, (1,1)→(2,1) has raw rank drop1 and Pdrop1, so the corrected drop is−1. The eta+ edge(0,3)→(0,4) gives the same obstruction. This refutes that particular adjustment, not existence of a different flat-band rank. Ordinary physical recurrence follows without a pitch-zero requirement.

## Evidence and dependency boundary
GLOBAL_RANK_RECEIPT.json binds8 raw/fresh strict gates; SELECTOR_RECEIPT.json binds uniqueness; ARC_WHITE_RECEIPT.json binds24 source gates. The actual staircase/deck/native-cover facts are the authentic pure-base source inputs. No nonbase gluing, current all-word recurrence, fitting extrapolation, or alternate recurrence enters. The finite LP files are discovery only and are unnecessary to verify these uniform formulas.
