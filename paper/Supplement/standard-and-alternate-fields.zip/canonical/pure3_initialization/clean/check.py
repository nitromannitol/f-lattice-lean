from pathlib import Path
import sys,json,subprocess,hashlib
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'raw'));import raw3 as A
A.P=D
from raw3 import *
rows=[]
def run(name,bad):
 s=z.Solver();s.set(timeout=120000);s.add(base,bad);raw=s.to_smt2();p=D/(name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(p)],capture_output=True,text=True,timeout=130).stdout.strip();(D/(name+'.fresh')).write_text(fresh+'\n');assert ans==fresh=='unsat',(name,ans,fresh)
 rows.append(dict(name=name,status=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()));(D/'DIRECT_RECEIPT.json').write_text(json.dumps(rows,indent=2))
def selected(dx,dy,eta,lap):
 fs=z.Or(*[z.Or(H(*shift(x,y,i,j)),V(*shift(x,y,i,j)))for i,j in aliases])
 forced=z.And(z.Not(fs),(x+y)%2==0,z.Or(z.And(x<=0,dx==-1),z.And(x>=2,dx==1)))
 return z.Or(lap==-1,forced,z.Or(*[freeE(*shift(x,y,i,j),eta,dx,dy)for i,j in aliases]))
for parity in [0,1]:
 es=[(-1,0),(1,0)]if parity==0 else[(0,-1),(0,1)];gs=[grad(0,0,*e)for e in es];lap=sum(gs);flow=(x+y)%2==parity
 for eta in [-1,1]:
  inc=[g-grad(-1-2*eta,1,dx,dy)-dy for g,(dx,dy)in zip(gs,es)]
  run('unit_%d_%d'%(eta,parity),z.And(flow,z.Or(*[z.Or(h>1,h< -1)for h in inc])))
  # m_j=F+min(0,j-Phi); on Phi=j it equals F.
  # Delta m=Delta F-sum positive increments. All off-band inputs already burnt.
  need=1-lap+sum(z.If(h>0,h,0)for h in inc)-sum(z.If(h!=0,1,0)for h in inc)
  have=sum(z.If(z.And(h==0,selected(dx,dy,eta,lap)),1,0)for h,(dx,dy)in zip(inc,es))
  run('quota_%d_%d'%(eta,parity),z.And(flow,have<need))
 h=z.Int('threshold_minus_price')
 for nm,cx,cy,lin in [('P',-1,1,1),('Dplus',-2,0,0),('Dminus',2,0,0),('PhiPlus',-3,1,1),('PhiMinus',1,1,1)]:
  inc=[g-grad(cx,cy,dx,dy)-lin*dy for g,(dx,dy)in zip(gs,es)]
  mn=lambda q:z.If(q<0,q,0)
  delta=lap+sum(mn(h-v)-mn(h)for v in inc)
  run('binary_'+nm+'_'+str(parity),z.And(flow,z.Not(z.Or(delta==0,delta==-1))))
