# Reciprocal clean physical bands and all-threshold binary minima

All odd d>=3, including actual root d=3. Use the authentic global reciprocal F, exact canonical e(-1,eta), and raw prices
 P(z)=F(z)-F(z+(-1,1))-y,
 D_eta(z)=F(z)-F(z+(-2eta,0)),
 Phi_eta(z)=F(z)-F(z+(-1-2eta,1))-y.
The source/deck/cover and graph are independently closed by ../forced. This proof does not assume a literal alternate producer.

## All thresholds
For each Q in {P,D+,D-,Phi+,Phi-} and EVERY integer j,
 m_j=F+min(0,j-Q)
has Laplacian in {-1,0} on the entire physical plane. Ten new universal gates prove the statement, splitting only physical root parity. With h=j-Q(z), input increments a_e=F(z+e)-F(z), q_e=Q(z+e)-Q(z), they test exactly
 Delta m_j=sum_e a_e + sum_e[min(0,h-q_e)-min(0,h)].
The variable h is arbitrary integer, not a sampled list of levels. Genuine positive native joint-edge offers evaluate all gradients; their cover queries are included and freshly replayed. Deck covariance transports the native-root result: Q changes by a common integer deck character and h ranges over all integers. Thus no range restriction on j is hidden.

## Direct clean-band quota
Fix eta,j and B={Phi_eta=j}. At a band root let a=Delta F, q_e=Phi(z+e)-Phi(z). Four new queries prove |q_e|<=1 on all physical input edges, not just retained edges. At the root of B,
 Delta m_j=a-sum_e max(q_e,0).
If all off-band inputs are already burnt, the number of further burnt BAND inputs required is
 b_B=1-a+sum_e max(q_e,0)-#{e:q_e!=0}.
The four direct quota gates prove that the number of actually retained canonical inputs with q_e=0 is at least b_B. This is the BURN threshold, not the fort quota. If b_B<=0 the root needs no band input. All input multiplicities are physical and retained. Black retains both; nonfree white uses its independently proved forced arrow; H/V whites use the exact reflected free table.

The independent bounded correction r_eta in ../raw/flatrank3.py drops strictly on every retained Phi-flat physical edge. It is genuinely deck-periodic with 0<=r_eta<=2d+2. Consequently burn any finite subset of B, with its outside inputs already burnt, in increasing r_eta: each selected same-band input has smaller rank and the direct inequality supplies the required number. In particular there is no finite unburnt residual in this clamped band.

For the complete band modulo its pitch W=2eta U+V, Phi(U)=-1 and Phi(V)=2eta. Each of the T native deck classes has exactly one W-orbit on a specified integer level: solving -i+2eta k=j-Phi(z) has one solution modulo (2eta,1). Thus the band quotient is finite (T sites), and r_eta descends to it. The same increasing-r burn proves the complete clean cylindrical band, with physical input arcs and multiplicities. No assertion that the older nonzero-pitch strict rank descends is used. Equivalently the current full rank (2d+3)Phi+r_eta has zero W-character and is strict.

## Verification and scope
check.py produces 18 substantive universal gates: 4 unit-edge, 4 exact band quota, 10 arbitrary-threshold binary. Its gradient evaluator additionally produces positive source-edge coverage gates. Every gate has producer UNSAT and a saved standalone fresh UNSAT output, with hashes in COMPLETE_RECEIPT.json. MANIFEST.json binds the current raw evaluator, forcing/source packet, flat-rank script, and independently replayed rank raws. This closes the standard reciprocal clean-band and primitive all-threshold admission inputs only; it is not a new alternate-source identification.
