import sys,json
from pathlib import Path
sys.path.insert(0,'astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review');from straddle import O,field
rows=[]
for K in range(4):
 d=2*K+3;m,al=O.get_odometers('3'*K);F,*_=field(O.export_tile(m[1]),O.getFracs('3'*K)[1]);E=O.export_tile(al[1]);raw={(x-d+1,y-1):v for(x,y),v in E.items()}
 pred={}
 for x in range(4-2*d,d+1):
  for y in range(-1,d+2):
   G=(2-d<=x+y<=d+2 and 0<=y<=d)or(y==-1 and 1-d<=x<=0)or(y==d+1 and 4-d<=x<=3)or(x==1-d and y==0)or(x==3 and y==d)
   if G:
    c=int((x+y==2 and 0<y<d)or(x==1-d and y in[-1,0])or(x==3 and y in[d,d+1]))
    pred[x,y]=-y*(y+1)//2+min(2-x,0)+min(d-2+x,0)+max(x+y-2,0)+c
 assert pred==raw
 assert all(h==(F((x,y))+F((x-2,y))+1)//2 for(x,y),h in raw.items())
 rows.append(dict(K=K,d=d,native_sites=len(raw),exact_support_and_heights=True,raw_midpoint=True))
Path(__file__).with_name('LITERAL_REGRESSION.json').write_text(json.dumps(rows,indent=2)+'\n')
