# Genuine pure3 even alternate: raw/consumed midpoint, cover, and global binary extension

For every K>=0, d=2K+3, let F be the authentic standard 1/d staircase with canonical LL(0,0) and height0, and define

 J(z)=ceil((F(z)+F(z-2e1))/2).

On the ENTIRE genuine raw native support of get_staircase_even_alt,

 Hraw(z)=min(F(z),F(z-2e1)+1)=J(z),
 0<=F(z)-F(z-2e1)<=2.

This raw support covers the full physical quotient. Its coherent phase-zero global extension is J, with U=(d,1) primary character0 and V=(1-d,d+1) secondary jet (1,-d).z-d(d+3)/2-1. J is globally binary. No recurrence or canonical rank is assumed or concluded in this packet.

## 1. Actual source support, including array bounds and root

Original final_code/base_case.jl:get_staircase_even_alt enumerates raw x from4-2d throughd and y from-1 throughd+1. Inside those actual array bounds its support is the union

 * 2-d<=x+y<=d+2, 0<=y<=d;
 * y=-1, 1-d<=x<=0;
 * y=d+1, 4-d<=x<=3;
 * (1-d,0), (3,d).

The extra corners (1-d,-1),(3,d+1) are already in the bottom/top pieces and receive their genuine +1 height. Value is

 -y(y+1)/2 + min(0,2-x)+min(0,d-2+x)+max(0,x+y-2)+c(x,y),

with c=1 on x+y=2,0<y<d, and at all four listed corner points; otherwise0. The diagonal override remains in the stated support. These are the literal loops and assignments, not a convex-hull replacement. All statements include d=3; there is no omitted low-parameter case.

The raw lower-left is (1-d,-1) and its value is0. Therefore the actual LL-exported field satisfies

 Hexport(z)=Hraw(z-(d-1,1))=J(z+e1),

the last equality using J's primary period U. The shift (d-1,1) has odd coordinate sum. Thus exported H is phase-flipped relative to raw/consumed H; it must NOT be silently treated as phase-zero at the same coordinates.

The genuine translate_alts rule has O=U_oldq-V_endpoint=(d-1,0), followed by its explicit all3 +im correction. It restores by -(d-1,1), exactly to the raw phase-zero frame above, with no scalar adjustment. This applies also to the root creator.

## 2. Universal native midpoint and quotient cover

prove.py transcribes the true support and value. It offers actual guarded standard native aliases for each of z,z-2e1 and includes the exact standard deck correction. Every root is licensed with

 (F-Hraw,F(. -2e1)-Hraw) in {(0,0),(0,-1),(1,-1)}.

This proves the minimum, rounded mean and width statements together. Alias offers use i=-2,...,2 and j=-1,0,1, but no assertion of inverse-window completeness is made or required: each used representative has a true native guard, and absence of all valid offers is the negated universal gate.

A second positive-coverage gate proves every actual standard native site is a deck translate of some genuine alternate raw native site. The true standard native quotient cover then gives full physical coverage of the alternate source. Both unbounded integer queries are producer/fresh UNSAT in RECEIPT.json.

## 3. Coherence, deck characters, and binary admission

The standard has U-character0 and V-jet alpha.z+cV, alpha=(1,-d), cV=-d(d+3)/2. Since alpha.(-2e1)=-2, the two standard values' mean has V-increment alpha.z+cV-1, an integer. Ceiling commutes with this increment. Hence J is an explicit globally coherent alternate extension; every native offer agrees with it by the native theorem.

The min formula is restricted to the true native domain. A global min of the same two unrounded arms must not replace J outside the paid width range.

binary.py independently proves the exact raw native input Laplacian is -1 or0 for both physical parities. Each possibly off-native input has an actual positive alternate native alias with the just-established cV-1 character. Quadratic terms are expanded and canceled before solving. Both producer/fresh CLI queries are UNSAT in BINARY_RECEIPT.json. Native cover propagates the result to all physical roots. No blanket Jensen-preserves-binary claim is used.

## Verification and scope

check_literal.py compares the complete translated exported original constructor against the transcribed support and heights for K0,1,2,3 and checks the raw midpoint. Every support and height matches; LITERAL_REGRESSION.json is a source-wiring regression, not the all-parameter proof.

The four all-parameter raw queries and fresh results, with checked SHA256s, are pinned in MANIFEST.json. The only global source inputs are the authentic standard staircase deck law/coherence/native cover. Actual source support, LL gauge, phase restoration, alternate cover, midpoint, coherence, and global binary admission are now paid. Recurrence and rotated pure2-odd source identification remain separate.
