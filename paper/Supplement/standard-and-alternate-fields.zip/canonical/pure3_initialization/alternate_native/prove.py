from pathlib import Path
import sys,json,subprocess,hashlib
sys.path.insert(0,'/tmp/f_lattice_z3');import z3 as z
import sympy as sy
P=Path(__file__).resolve().parent;D,x,y=z.Ints('d x y');dt,xt,yt=sy.symbols('d x y',integer=True)
conv=lambda v:eval(str(sy.expand(v)),{'d':D,'x':x,'y':y})
mn=lambda v:z.If(v<0,v,0);mx=lambda v:z.If(v>0,v,0)
aliases=[(i,j)for i in range(-2,3)for j in [-1,0,1]]
T=dt*dt+2*dt-1;c=-dt*(dt+3)/2

def std(X,Y):return z.Or(z.And(X>=2-D,X<=D,Y>=0,Y<=D+1,X+Y>=1,X+Y<=D+2),z.And(X==0,Y==0),z.And(X==2,Y==D+1))
def sc(X,Y):return mn(X-1)+z.If(z.Or(z.And(X==0,Y==0),z.And(X==2,Y==D+1)),1,0)
def alt(X,Y):
 return z.And(X>=4-2*D,X<=D,Y>=-1,Y<=D+1,z.Or(z.And(X+Y>=2-D,X+Y<=D+2,Y>=0,Y<=D),z.And(Y==-1,X>=1-D,X<=0),z.And(Y==D+1,X>=4-D,X<=3),z.And(X==1-D,Y==0),z.And(X==3,Y==D)))
def ac(X,Y):return mn(2-X)+mn(D-2+X)+mx(X+Y-2)+z.If(z.Or(z.And(X+Y==2,Y>0,Y<D),z.And(X==1-D,z.Or(Y==0,Y==-1)),z.And(X==3,z.Or(Y==D,Y==D+1))),1,0)
def offers(q):
 tx=xt-2*q;ty=yt;rows=[]
 for i,j in aliases:
  rx=tx+i*dt+j*(1-dt);ry=ty+i+j*(dt+1)
  pol=-ry*(ry-1)+yt*(yt+1)-2*j*(tx-dt*ty+c)+T*j*(j-1)
  v=conv(pol)+2*sc(conv(rx),conv(ry))-2*ac(x,y)
  rows.append((std(conv(rx),conv(ry)),v))
 return rows
f,g=offers(0),offers(1)
good=z.Or(*[z.And(a,b,v>=0,v<=2,w>=-2,w<=0,v+w>=-2,v+w<=0)for a,v in f for b,w in g])
checks={'native_midpoint_width':z.And(D>=3,D%2==1,alt(x,y),z.Not(good)),
'positive_native_cover':z.And(D>=3,D%2==1,std(x,y),z.Not(z.Or(*[alt(x+i*D+j*(1-D),y+i+j*(D+1))for i,j in aliases])))}
rows=[]
for name,F in checks.items():
 sl=z.Solver();sl.set(timeout=120000);sl.add(F);raw=sl.to_smt2();p=P/(name+'.smt2');p.write_text(raw);ans=str(sl.check());print(name,ans,flush=True)
 if ans=='sat':print(sl.model(),flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:150',str(p)],capture_output=True,text=True,timeout=160).stdout.strip();rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
