from pathlib import Path
exec(Path(__file__).with_name('prove.py').read_text().split('f,g=offers(0)')[0])
def inputs(dx,dy):
 tx=xt+dx;ty=yt+dy;rows=[]
 for i,j in aliases:
  rx=tx+i*dt+j*(1-dt);ry=ty+i+j*(dt+1)
  pol=-ry*(ry+1)+yt*(yt+1)-2*j*(tx-dt*ty+c-1)+T*j*(j-1)
  v=conv(pol)+2*ac(conv(rx),conv(ry))-2*ac(x,y)
  rows.append((alt(conv(rx),conv(ry)),v))
 return rows
rows=[]
for ph,dx,dy in [(0,1,0),(1,0,1)]:
 f,g=inputs(dx,dy),inputs(-dx,-dy);good=z.Or(*[z.And(a,b,z.Or(v+w==0,v+w==-2))for a,v in f for b,w in g])
 sl=z.Solver();sl.set(timeout=120000);sl.add(D>=3,D%2==1,alt(x,y),(x+y)%2==ph,z.Not(good));raw=sl.to_smt2();name='binary_phase'+str(ph);p=P/(name+'.smt2');p.write_text(raw);ans=str(sl.check());print(name,ans,flush=True)
 if ans=='sat':print(sl.model(),flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:150',str(p)],capture_output=True,text=True,timeout=160).stdout.strip();rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'BINARY_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
