# Reciprocal pure3 even: full physical zero and harmonic strips

For all odd d>=3, including the root, the true standard 1/d field satisfies

 F(z)=0 when 1-d<=t(z)<=2d,
 F(z)=h0(z) when 1-2d<=s(z)<=2d+1,

where t=x-dy and s=(d+1)x+(d-1)y. These are full global strips, not merely arc traces.

## True primitive and deck

The genuine native support is

 {2-d<=x<=d,0<=y<=d+1,1<=x+y<=d+2} union {(0,0),(2,d+1)}.

F=-y(y-1)/2+min(x-1,0)+1 at the two exceptional corners (the last indicator is zero elsewhere). U=(d,1), V=(1-d,d+1), T=d²+2d-1; U character0 and V jet (1,-d).z+cV, cV=-d(d+3)/2.

By native cover write any site w+iU+jV with w native. For the zero strip suppress i. The exact strip and native bounds force j=0 or-1. In the first case y=0 or1; in the second y=d or d+1. Inserting these four bands into

 2F(w+jV)=-y(y-1)+2min(x-1,0)+2corner
          +2j(t(w)+cV)-Tj(j-1)

gives zero under the genuine native and strip constraints.

For the harmonic strip, h0 and F have identical V jet, so F-h0 and s are V-periodic; suppress j. The native and strip bounds force i=0 or-1. Put k=x+y. For i0, k is in {0,1,2,3}; for i=-1 it is in {d-1,d,d+1,d+2,d+3}. Retain both exceptional native corners. Substitute y=k-x and x'=x+id,y'=y+i into

 4(F(w)-h0(w+iU))=-2y(y-1)+4min(x-1,0)+4corner
                  -2x'(x'-1)+(y'+1-x')²-((y'+1-x') mod2).

This vanishes in all nine bands. In particular the floor parity remainder is not discarded.

full_strips.py independently proves the six integer alias/band reductions and thirteen scalar cases, with all parameters unbounded. FULL_STRIPS_RECEIPT.json records 19 producer and fresh CLI UNSAT results, bound to raw hashes. No current recurrence, raw D comparison, or provisional Carbon strip premise enters the calculation. The only global input is the authentic coherent standard deck extension and its native cover.
