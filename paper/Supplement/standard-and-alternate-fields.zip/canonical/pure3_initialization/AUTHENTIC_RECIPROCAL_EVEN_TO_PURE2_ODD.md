# Authentic reciprocal-even to pure2-odd rotation

For K>=0 set d=2K+3, D=(d+1)/2 and N=(d−1)/2. Let Q be the actual standard even reciprocal at word3^K and P the actual standard odd at word2^K, both in their exported lower-left coordinates. Then globally

 P(x,y)=Q(−y,x−1)+h0(x,y),
 h0(x,y)=x(x−1)/2−floor((y+1−x)^2/4).

## Native source proof, including K0

The literal odd staircase uses RAW y=y_export+1. Its genuine native guard and both exceptional inserted corners are retained in rotation.py. After subtracting h0, its value is min(d−y−1,0)+corner−x(x−1)/2; the identical floor cancels exactly, not approximately. For the transformed point Zx=(−y,x−1), nine genuine reciprocal native offers with (j,k) in{-1,0,1}² suffice. Each offer carries the literal reciprocal main guard OR its two inserted corners, its exact value and genuine deck jet. A tenth gate proves positive cover of the ENTIRE literal odd native domain. All ten unbounded gates, for every odd d>=3, pass producer and independent CLI. This includes the actual K0 root, not a generic replacement endpoint.

The inverse deck formula used is
 Q(z)=Q(z+jU+kV)−k(a.z+cV)+k(k−1)T/2,
 where U=(d,1),V=(1−d,d+1),a=(1,−d),T=d²+2d−1,cV=−d(d+3)/2.
Each twice-height residual is affine after the explicit quadratic cancellation, so these are integer linear arithmetic gates. Aliases are positive offers; no omitted negative-domain argument is used.

## Actual global characters and phase

The true odd periods are Up=(d+1,d−1),Vp=(−1,d). The linear part of Z sends Up to V and Vp to −U. Expanding h0 under these parity-preserving periods gives
 P(z+Up)−P(z)=0,
 P(z+Vp)−P(z)=N x−D y−D²−D+1.
These are the authentic odd standard characters: cU=0 and cV=−(Tp+Lp)/2=−D²−D+1, since Tp=2D²−1 and Lp=2D−1. Native quotient coverage and genuine deck coherence therefore extend the proved source equality to every physical site. Neither recurrence nor a guessed source normalization is used in that extension.

Z reverses physical parity and rotates the input axis: horizontal inputs at an even root map to vertical inputs at an odd root, and conversely. Direct parity calculation gives Delta h0=0. Thus colors and all burning/fort conditions are carried exactly by Z. A strict global rank R for any reciprocal policy pulls back as R(Zz); its odd deck characters are (cV_Q,−cU_Q). This transports the policy with its ACTUAL directions. Identifying a separately named odd canonical policy with that transported policy additionally requires its free-arrow table; it is not implied by standard names alone.

## Dynamical progress and limitation

The reciprocal family is the single staircase, not the doubled ladder. Its observed nonfree bulk has the held-boundary rank −2|x−1|+1_(x+y odd) on its ordinary unaliased pieces: forced even whites point E on the right and W on the left, while ordinary black odd roots retain the two vertical inputs. That local expression is NOT asserted globally across native overlaps/free arcs.

Actual reciprocal Q_b ranks were solved at K0,1,2,3 with genuine source-generated colors/forced arrows and the canonical free table. They have characters(2d,2b(d+1)). These finite LP data suggest a simple global affine-periodic rank but are not an all-K rank proof. The uniform result established here is the source/phase/character rotation and consequent conditional dynamical transfer.
