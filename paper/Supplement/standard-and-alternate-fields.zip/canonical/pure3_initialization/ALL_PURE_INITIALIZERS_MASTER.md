# Every genuine standard and alternate pure initializer is recurrent

For the empty word and every word 2^K or 3^K (K≥1), all four native children (odd/even, standard/alternate) extend coherently with their true characters to recurrent binary fields on the physical F-lattice. This is an unconditional theorem about the mathematical integer initializers prescribed by the original Julia code, not a claim about available machine memory or all nonpure constructors. At the empty word one uses the actual standard/alternate staircases at 1/3 and 1/2. There is no spurious doubled ladder with parameter two.

The proof needs just two even families and their true harmonic quarter-turn conjugacies. Correct normalization matters: the exported reciprocal-even ALTERNATE has flipped checkerboard phase; its actual restoration removes it. The near-one odd alternate needs an additional affine term. Binary admission alone would not imply recurrence.

## 1. Near-one even family

At word 2^K let a=2K+2, D=(a−1)/(a+1). See bundled earlier_report/PURE2_ACTUAL_STANDARD_AND_ALTERNATE_THEOREM.md and its separately persisted full source/certificate archive. Each genuine standard signed policy has strict rank (2a+3)Φη+rη, 0≤rη≤2a+2; drifts of Φη are (−1,2η). Every true alternate native value, with both actual added corners, is J=ceil((F+F(.+σ))/2), σ=(−a,2−a). True standard D+=F−F(.+σ) is unit on all physical edges, has no opposing ±1 pair at even D+, and is nonincreasing on every retained η+ input. Thus (D+ mod 2,R+) is a strict physical policy rank for the actual J. Its V character is the standard one minus one. The doubled-ladder pair therefore recurs, including genuinely clean standard chain bands.

## 2. Reciprocal even family, INCLUDING the root

Let d=2K+3, K≥0, F the genuine standard 1/d staircase at 3^K. On its actual native domain
 F(x,y)=−y(y−1)/2+min(x−1,0)+the two actual raised-corner indicators.
Use U=(d,1), V=(1−d,d+1), T=d²+2d−1, primary character zero and V jet (x−dy)−d(d+3)/2. forced/EXACT_FORCED_CLASSIFICATION_AND_THREE_STEP_RETURNS.md proves native overlap/coherence and cardinal closure, binary colors, canonical forced/free assignment, reflection, and physical rejected-edge three-step returns. A nonfree white has a genuine full native horizontal star, west at x≤0/east at x≥2. Increasing |x−1| gives the finite square-unit derivation. Residual free completions are checked rather than presumed.

With v=(−1,1), σ=(−2,0), b=(0,−1), put P=F−F(.+v)+b·z, Dη=F−F(.+ησ), Φη=F−F(.+v+ησ)+b·z. The true signed policies e_(−1,η) make P,Dη,Φη nonincreasing on every retained edge, including both black inputs. Across all physical inputs P,Dη,Φη change by at most one, P has no opposite ±1 input star, and even-Dη has none. All thresholds for the three types of minimum are admitted. source, boundary, reflection, unit returns, cutoff of all genuine aliases, primitive and chain price windows are explicitly audited in forced/, raw/, clean/ and ENTIRE_STANDARD_STRIPS.md. Two entire strip values are F=0 and F=h0, not merely boundary-H/V values.

The two bounded tables in raw/UNIFORM_FLAT_PHI_CORRECTION.md give actual periodic rη values between 0 and 2d+2. On all Φη-flat retained edges they drop by at least one, including d=3 with its special free V0 value. Thus Rη=(2d+3)Φη+rη is a strict physical rank with zero drift along 2ηU+V. A minimum Rη point of a finite fort gives an immediate contradiction with its true retained-input quota, so F is recurrent. At a band tie of m=min(F,F−Φη+j), the exact additional burn requirement is 1−Δm−#off-band inputs. The direct local quota check in clean/ proves at least this many retained flat inputs. rη descends to the finite pitch quotient with exactly T classes, so both bands burn cleanly. The auxiliary simple ranks with nonzero pitch are not used for this argument.

The genuine reciprocal-even alternate in RAW physical coordinates is J(z)=ceil((F(z)+F(z−2e1))/2). alternate_native/TRUE_RAW_MIDPOINT_AND_COVER.md pays every actual finite value, quotient cover, and true secondary jet (standard minus one). The raw lower-left is (1−d,−1); LL-export reads J(z+e1), which has opposite checkerboard phase in those coordinates. The actual all3 restoration by −(d−1,1), including the source's extra +i offset, restores phase-zero J. The same midpoint-star lemma as in §1 now applies, with ALL its local and strict-edge hypotheses supplied by the verified reciprocal standard. Hence the actual alternate extension has a strict lex rank (D+ mod 2,R+) and is globally recurrent. This is a physical argument, not merely native binary admission.

## 3. Odd families and actual source normalization

The standard whole-lattice identities are F_odd(x,y)=F_even(−y,x−1)+h0(x,y) for each paired family: near-one odd at 2^K maps to reciprocal even at 3^K (including K0); reciprocal odd at 3^K maps to near-one even at 2^K (K≥1). Each is proved on the entire correct native support, then extended by the proven deck transformations. See AUTHENTIC_RECIPROCAL_EVEN_TO_PURE2_ODD.md and odd_standard_symmetry/.

Write J3 for phase-zero reciprocal-even alternate, J2 for near-one even alternate. At a near-one odd initializer with d=2K+3, its ACTUAL exported odd alternate is

 A(u,v)=J3(v−2d+4,d−u)+h0(u,v)−du−v+d(d+3)/2−2.

At a reciprocal odd initializer with a=2K+2≥4 it is

 B(u,v)=J2(−v,u−1)+h0(u,v).

odd_alternate_symmetry/ verifies the genuine lower-left frames, both support bijections, all strips and corner indicators, the gauges and the correct primary character −1. All maps rotate by a quarter-turn and reverse lattice parity, so carry each actual input star to an actual input star. h0 and integer affine terms are harmonic. Forbidden sets correspond exactly. That transfers recurrence to every odd initializer without presuming that a similarly named alternate has the correct heights. This proves the opening theorem.

## Proof status and provenance

244 raw reciprocal price/flat-rank/window/coverage obligations were freshly replayed; 34 further native/policy/return and 42 direct clean/admission/coverage gates were producer/fresh UNSAT. The exact strip, alternate and four rotation producers have their separate unbounded queries and fresh receipts. Overlaps among cited checks are not treated as independent evidence. The proofs use symbolic integer regions and complete positive native covers plus elementary arithmetic, not numeric extrapolation. Multiple pieces were implemented and audited separately; a fresh replay of a saved query is not a second independent derivation of its encoding or proof-assistant verification.

**Not proved here:** arbitrary nonpure original constructors, corrected native height recognition, matching of all arbitrary saved restoration records, or unbounded literal floating-point evaluation/padding. Some later odd-policy sign identifications may require mapping the actual free choices, not just invoking a graph rotation. Initialization of the degenerate 0/1 and 1/1 *endpoint carrier templates* when consumed is distinct from recurrence of these four native children at every pure word.
