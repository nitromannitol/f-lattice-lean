# Primary seams: what the minimum does and does not pay

This is an algebraic continuation of SECONDARY_SEAMS.md, not an all-word X/tie exclusion.

## Common-chart arithmetic audit
In the parent's proposed exact closed parity-rectangle description, a chart index k is allowed when s-kT lies in [c_parity,T+h_parity], with its t parity band also supported. Assume the genuine free spectra give h_even-c_odd=h_odd-c_even=L-2; all s values and bounds are even. To have no common index for two adjacent sites, one must lie strictly above a chart's upper threshold and the other strictly below the next chart's lower threshold. Strictness costs two at each end, so |Delta s| >= L+2. But a physical unit edge has |Delta s| equal to L or d-n, both at most L. Contradiction. Thus the two points have a common CLOSED primary chart. This proof depends on the exact rectangle identification, not merely containment in a bounding rectangle.

The restriction to the two primary indices additionally uses 0<2C<T for the authentic shift and the original root/input membership in E. This is a separate ownership step; the minimum algebra below only requires the selected chart to hold at both endpoints. The secondary exits were separately paid in SECONDARY_SEAMS.md.

## Exact two-price edge lemma
Let F=f_A+r and g=f_A+min(a,b), where all values refer to one actual common chart. At z,u define delta=r(u)-r(z). Then D=F-g is nonincreasing iff BOTH

 a(u)>=min(a(z),b(z))+delta,
 b(u)>=min(a(z),b(z))+delta.

No component achieving the minimum at u may be omitted. This follows directly by subtracting the two equalities, with no policy or recurrence premise.

Three useful sufficient forms:
1. A-to-A: delta=0. Both prices nondecreasing suffice.
2. Dominant branch: if b>=a at both endpoints, monotonicity of a suffices.
3. A-to-C crease: delta=-1. Individual lower increment bounds Delta a,Delta b>=-1 suffice, regardless of which branch is active.
4. Shielded exceptional branch: if a may fall, but b(z)<=a(z) and BOTH a(u),b(u)>=b(z), the minimum still cannot fall.

The printed three-chart proof fits these four forms. In particular, its Wave1 paragraph must establish the two input inequalities in item4 on the actual common chart. A root contact alone is not enough.

## Shared-face matching alone does not suffice
Two prices can agree at the shared endpoint and still decrease into the adjacent chart: (a(z),b(z))=(0,0), (a(u),b(u))=(-1,0). All increments have absolute value at most1 and the root is a tie, but their minimum drops. This is an abstract obstruction to the proposed inference, not a counterexample from genuine source fields. Any repair needs an oriented lower bound or a second shielding inequality; continuity/coherence alone cannot supply it.

## Exact remaining inherited inputs
Zero sheet: a=0,b=Psi∓2. A-to-A uses genuine Psi monotonicity on the actual inherited edge; crease uses its exact decrement -1.
Positive sheet: a=psi_plus(x), b=a+Psi(y+v_o). One needs dominance at BOTH endpoints or a direct two-price lower bound. The printed all-plane dominance from span1 and a displacement needs its actual scalar period and character verified. A Euclidean displacement, or an unsigned positive scalar displacement, is not a substitute.
Negative sheet: a=psi_minus(x), b=C_w-D_eps(q_sw)(Zx). Need the correctly transported old directed edge, or the precise Wave1 shielding. Neither old strict rank nor range bounds alone imply these signed inequalities.
Crease: old 1-Lipschitz on both prices pays algebraically. To derive that Lipschitz bound from old binary stars and a three-value range, the range must cover each WHOLE old star in one coherent normalization, including secondary seams. A native-root-only range is insufficient.

## Valid scalar span lemma (available if its hypotheses are authenticated)
Suppose an integer scalar H has H(t+P)=H(t)-1 and on a complete fundamental interval its oscillation is at most1. For an integer shift a>=P, write a=qP+r,0<=r<P. For any t, comparing reduced representatives gives H(t+a)-H(t)<=-q+1<=0. If a has the opposite sign reverse the inequality. This works globally, with no monotonicity assumption inside the interval. For the printed psi dominance, one must bind its projected shift to a>=P and bind the true reduced span; the large displayed dot product alone does not identify P.

No new-child rank, raw child monotonicity, or all-word recurrence is assumed by these lemmas. The remaining task is authenticating the listed old-source geometry and signed hypotheses, rather than additional minimum algebra.
