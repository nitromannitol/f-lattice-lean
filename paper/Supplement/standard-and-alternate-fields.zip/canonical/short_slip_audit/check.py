from pathlib import Path
import sys
D=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair').resolve();sys.path.insert(0,str(D));from biased_terminal import *
rows=[]
for w in ['1','11','12','23','31','32']:
 mats=O.get_odometers(w)[0];frs=O.getFracs(w);fr,p,q=frs[1:];n,d=fr.numerator,fr.denominator;pn,pd=p.numerator,p.denominator;qn,qd=q.numerator,q.denominator;W=w.count('1')%2;e=2*W-1;U=(d,n);sig=(e*2*pd,e*2*pn);E,bd,H,V=polygon(n,d);F,*_=field(O.export_tile(mats[1]),fr);P,*_=field(O.export_tile(mats[2]),p);lv=((1-W)*qd,(1-W)*qn);bad=[]
 for z in E-bd:
  # all interior roots, including reflected C side
  ip=[plus(z,a)for a in ([(-1,0),(1,0)]if sum(z)%2==0 else[(0,-1),(0,1)])]
  for si in [-1,1]:
   for u in ip:
    zz=plus(z,times(si,sig));uu=plus(u,times(si,sig));owners=[i for i in [-1,0,1]if minus(zz,times(i,U))in E and minus(uu,times(i,U))in E]
    if not owners:bad.append((z,u,si,zz,uu,[n*v[0]-d*v[1]for v in[zz,uu]]))
 bad=[(b,[F(v) for v in b[:2]],[F(v) for v in b[3:5]],[F(b[j])-F(b[j+3]) for j in [0,1]]) for b in bad];rows.append(dict(word=w,missing_common_primary_edges=bad)); print(w,len(bad),flush=True);continue
 opt,free=policy(fr,1,F,1,1);bad=[dict(data=b,lap=2*F(b[0])-sum(F(plus(b[0],a))for a in([(-1,0),(1,0)]if sum(b[0])%2==0 else[(0,-1),(0,1)])),retained=b[1]in opt(b[0]),free=free(b[0]))for b in bad];print(w,'missing common primary edge',len(bad),bad[:2],flush=True)

import json
Path(__file__).with_name("REGRESSION.json").write_text(json.dumps(rows,indent=2))
