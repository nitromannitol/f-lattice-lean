# Short-slip sheet audit: secondary seams

## Printed scope
Audited carbon_review/PROOF_212715.txt, §3.10(b)(iii), lines 2454–2511. The j0=0 assertion at lines 2466–2467 concerns a strictly interior ROOT z. Subsequent bullets evaluate both shifted root and shifted input in the same primary chart. The text does not separately justify this for an input on the horizontal boundary. The universal halo-range claim at lines 2388–2392 does not provide equality with a primary-chart minimum there. Thus root-only ownership does not license the edge calculation. This is an omission in the proof, not a counterexample to its conclusion.

## Exact secondary-strip classification
Use genuine polygon E, U=(d,n), V=(n-d,n+d), t=nx-dy, L=d+n, T=d²+2dn-n², and authentic parity-preserving sigma with t(sigma)=-2. From the independently proved H spectra and quotient coverage in local_phi/H_SEMIGROUP_TWO_SLIP_BOUNDS.md, the primary saturation E+ZU is exactly

 even: 2-T <= t <= L-2; odd: n-T <= t <= d.

For completeness the same representative replacement argument as that note works for the finite band: a representative with t differing by T can be replaced by the bottom H point (or its top reflection), whose spectrum contains the required value. Same t then differs by an integer U.

An input of an interior root lies in E. A shifted input can leave this saturation only at the following four extremal input levels: negative slip at even t=L-2 or odd t=d; positive slip at even t=2-T or odd t=n-T. These are exact parity bounds, not bounding boxes. The odd bottom extreme is the terminal H point (d,n-1), up to U; its horizontal callers are boundary or exterior. Reflection excludes the odd top extreme in the same way. Consequently every genuine SECONDARY exit from an interior-root star is one of:

 bottom: u even, t(u)=L-2; z=u+ey, t(z)=n-2; shifted levels (n,L);
 top: the image under R=U+V+(1,-1), with positive slip, shifted levels (d-T,-T).

Uniqueness modulo U follows from gcd(n,d)=1 and the exact H residue spectrum. The actual polygon may choose representatives; no primary-window size is asserted here.

## Actual values, without an exterior M substitution
At the bottom, F(u)=0 by the authentic horizontal trace; F(z)=0 by the genuine zero strip at odd t=n-2. The shifted root/input pair is a COMMON primary translate of (1,0),(1,-1), respectively, so both shifted heights are zero by true primary period and the actual two endpoint values. Therefore Dminus(z)=Dminus(u)=0. Reflection gives Dplus(R-z)=Dplus(R-u)=2. This pays these secondary seams by equality, without raw monotonicity or a new-child rank premise.

The argument uses the already authenticated standard zero strip/endpoint values and coherent reflection; it is not a derivation of those inputs from the disputed bulk claim.

## Independent original-field regression
check.py reconstructs six genuine original fields (1,11,12,23,31,32), examines EVERY directed star with strictly interior root (not only Sigma_A), and searches for one primary translate i in {-1,0,1} covering both shifted endpoints. Exactly two failures occur in each field: the above bottom and reflected top. All raw values are recorded in REGRESSION.json. Word1 bottom is z=(5,2),u=(5,1), shifted=(1,0),(1,-1), all heights0. Top z=(-1,10),u=(-1,11), shifted=(3,12),(3,13), heights(-37,-44,-39,-46), giving raw levels(2,2).

## Remaining gap, not claimed solved
Excluding secondary exits only puts both shifted sites in E+ZU. It does NOT by itself give one COMMON native primary chart, nor prove i lies in the printed two-sheet menu. Proving common-edge ownership at internal primary seams (or explicitly comparing their different chart expressions) remains necessary. The exact residual inequality is: with r=F-f_A and shifted residual h_i=g-f_A in chart i, raw monotonicity across z→u requires h_j(u)-h_i(z) >= r(u)-r(z). A root-only selected formula cannot replace this inequality. Nor do the range/semigroup repairs imply the black/black X exclusion or white/black tie exclusion by themselves. No universal exclusion is claimed here.
