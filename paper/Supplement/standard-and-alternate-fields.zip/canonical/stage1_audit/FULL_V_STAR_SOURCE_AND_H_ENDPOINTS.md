# Full V-star source equality and old H endpoint audit

## 1. Uniform full-star A equality: closed
Use the exact source spectra in strong_bulk/CANONICAL_V_RAW_SLIP_MONOTONICITY.md Section 1. Put parent p=N/D, c=D-N odd positive, Lp=D+N, and ordinary parent harmonic interval [1-2D,2Lp-1]. The aligned actual A values reduce to Fp(w) in BOTH W phases by its true zero-character Up period, after the stated affine target normalization.

Odd V roots have sp in [-c,Lp-2] at W1, [2-c,Lp] at W0. Their actual vertical inputs add +/-c. Thus full-star ranges are contained in
 W1: [-2c,2D-2]; W0: [2-2c,2D].
Both are within the old harmonic strip since N>=1.

Internal even roots have sp in [0,2N-2] at W1 and [2,2N] at W0. Adding +/-Lp gives
 W1: [-Lp,D+3N-2]; W0: [2-Lp,D+3N].
These lie in the old strip because c>=1. Initial V0 has sp=0, and its two inputs +/-Lp also lie in the strip.

Final Vend has sp=2N-2 at W1 and 2N+2 at W0. At W1 its entire horizontal star is in [N-D-2,D+3N-2], inside the old strip since D+N>=3 and c>=1. At W0 the west input is 2-c, the root is 2N+2, and the east input is D+3N+2. The first two are inside. The east input is inside iff c>=3. Since c is positive odd, the only remaining case is c=1, N=D-1, and then its sp is exactly 4D-1.

Therefore the nominated W0 near-one final EAST input is the ONLY failure of the ordinary full-star harmonic guard. Its actual parent residual is -1 by the original reciprocal native calculation in V_TERMINAL_SOURCE_ADDENDUM.md. All other aligned A roots/inputs equal h0. This establishes the one-exception classification uniformly from the exact spectra, not from finite tests.

## 2. Terminal C values: closed conditional on exact source identity
With z=(1-W)U+w, w=V+y, the supplied exact source/deck expansion is
 C(z)-h0(w)=Fp(y-eps Uq)-h0(y).
The four points y=I,I-ey,I-ex,I+ex give zero-strip arguments D+N-1,2D+N-1,D-1,D+2N-1. Thus the differences are (0,1,0,0). This proves final root/whole input-star C equality, and penultimate C-h0=1. Combined with Section 1, the final minimum has exactly the stated one exceptional -1 input and no other source deficit.

## 3. Nominal old H formula and exceptional eta-minus sandwich
Write the old even child denominator d=2Dp+dq, with proper old odd parent Dp>=2 and proper old even dq>=3. Conditional on the actual old-H/source alias formula
  Phi_eta(H_j)=c0-ceil((j+2 eta eps Dp)/d),
at its licensed indices, this is nonincreasing in j.

For eta-minus, the nominal endpoint values at j=-2 and j=0 coincide. If eps=+1, -d<-2Dp-2<=-2Dp<0, so both ceilings are0. If eps=-1, 0<2Dp-2<=2Dp<d, so both ceilings are1. The genuine canonical chain H[-2]=(-1,-1) -> H[-1]=(0,-1) -> V0 -> H0 and all-edge Phi monotonicity therefore force both exceptional middle values equal to the nominal endpoints. This pays the H[-1]/V0 substitution with its real arrows.

For eta-plus, the neighboring nominal values j=-1,+1 also coincide: their ceiling is1 for eps=+1 and0 for eps=-1. Thus the exact value required at H0 is c0-1 or c0, respectively. The supplied identity
  Phi_plus(H0)=c0+Dplus(V_{-eps r})
reduces this endpoint to the precise signed cut-value assertion
  Dplus(V_{-r})=-1 if eps=+1;
  Dplus(V_r)=0 if eps=-1.
Knowing only the rounded cut Jplus=0 does NOT determine this value: it permits both -1 and0. The exact raw cut trace, not rounded membership, is needed. Once these values and the supplied Phi_plus(I)=Phi_plus(H0) hold, both core substitutions preserve the nominal old-H ordering.

## 4. Remaining gap statement
This packet closes the full aligned A-star heights and all terminal C arithmetic. It verifies the eta-minus exceptional nominal sandwich and reduces the eta-plus exceptional value to two explicit raw cut values. It does not independently derive the global old-H alias formula or the exact source conjugacy sending each nonfinal V class to its stated old H index. Those need the actual signed source/deck identities, not merely a class correspondence.

After those identities and the two raw cut values are supplied, monotonicity of the nonfinal V gap sequence follows, its minimum is anchored by the penultimate gap1, and the full V halo follows from unit gap increments and the directly paid final tied star. No current child recurrence enters this chain. Pure predecessor cases outside Dp>=2,dq>=3 require their literal base conventions separately; the near-one source exception itself is already evaluated for the smallest D=2.
