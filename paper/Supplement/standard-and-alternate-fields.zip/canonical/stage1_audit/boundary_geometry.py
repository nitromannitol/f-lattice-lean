import math,json
from pathlib import Path
def edges(a,b):return [0]+[x for j in range(1,a+b-1)for x in([1]if b*(j+1)//(a+b)-b*j//(a+b)else[0,0])]+[0]
add=lambda a,b:(a[0]+b[0],a[1]+b[1]);sub=lambda a,b:(a[0]-b[0],a[1]-b[1])
def inp(z):x,y=z;return[(x-1,y),(x+1,y)]if(x+y)%2==0 else[(x,y-1),(x,y+1)]
count=0
for d in range(3,44,2):
 for n in range(1,d,2):
  if math.gcd(n,d)>1:continue
  U=(d,n);V=(n-d,n+d);R=add(add(U,V),(1,-1));T=d*d+2*d*n-n*n;H=[(1,0)];Y=[(0,0)]
  for v in edges((d-n)//2,n):H.append(add(H[-1],(1,v)))
  for v in edges(n,d-n):Y.append(add(Y[-1],(-v,1)))
  poly=H+[add(z,U)for z in Y]+[add(z,V)for z in H[::-1]]+Y[::-1];bd=set(poly)
  def inside(z):
   x,y=z;c=0
   for a,b in zip(poly,poly[1:]+poly[:1]):
    if(a[1]>y)!=(b[1]>y):
     dy=b[1]-a[1];num=(a[0]-x)*dy+(y-a[1])*(b[0]-a[0])
     if num*dy>0:c^=1
   return bool(c)
  E={z for x in range(n-d,d+n+2)for y in range(-1,d+2*n+1)if(z:=(x,y))in bd or inside(z)}
  expected=set()
  for i,z in enumerate(H):
   if sum(z)%2:expected.add((z,add(z,(0,-1)),V))
   elif i+1<len(H)and H[i+1][1]==z[1]+1:expected.add((z,add(z,(1,0)),V))
  for i,z in enumerate(Y):
   if sum(z)%2==0:expected.add((z,add(z,(-1,0)),U))
   elif i>0 and Y[i-1][0]==z[0]+1:expected.add((z,add(z,(0,-1)),U))
  expected|={(sub(R,z),sub(R,u),(-v[0],-v[1]))for z,u,v in list(expected)}
  real={(z,u)for z in E for u in inp(z)if u not in E}
  assert real=={(z,u)for z,u,v in expected},(n,d,'list')
  for z,u,v in expected:assert add(u,v)in E,(n,d,z,u,v)
  cls={}
  for z in bd:cls.setdefault((n*z[0]-d*z[1])%T,[]).append(z)
  assert len(cls)==d+(d+n)and all(len(v)==2 for v in cls.values())
  count+=len(real)
print(json.dumps(dict(status='PASS',exit_edges=count,denominator_max=43,scope='diagnostic geometry, not source heights')))
