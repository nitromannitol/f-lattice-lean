# Explicit boundary identifications and directed-halo reduction

Proper even n/d: n,d odd, coprime, 0<n<d. Put L=d+n, U=(d,n), V=(n-d,L), I=(1,-1), R=U+V+I, a=(n,-d), T=d²+2dn-n², cV=-(T+L)/2, kappa=(L-T)/2. Use the actual staircase polygon with boundary H, U+Vleft, V+H, Vleft and four unit connectors. Assume the established polygon simplicity, class cover, and interior-class count; no recurrence is required.

## All duplicate boundary pairs: proved
The ONLY pairs of distinct boundary points in the same deck class are
  z,z+V for z in H;
  z,z+U for z in Vleft.
There are d+L classes, each represented exactly twice. For proof use transverse t=nx-dy modulo T. H has 0<t<L and has no repeated t: equal t would make the difference an integer multiple of U, impossible since its x span is d-1. Vleft has strictly decreasing t from 0 to -T+L, since each step changes t by -d or -L; hence all its classes are distinct, and modulo T they lie at 0 or in [L,T). Thus H and V classes are disjoint. The translated arcs give the displayed pairs. The four unit connectors contain no additional lattice sites. The established Pick/cover argument excludes any interior representative of these boundary classes and any repeated interior class.

## Complete exiting-star list
For z on the BOTTOM H arc, the only exterior directed inputs are:
(H1) z odd: u=z-ey;
(H2) z even and its NEXT staircase step is diagonal: u=z+ex.
For z on the LEFT V arc, they are:
(V1) z even: u=z-ex;
(V2) z odd and its PREVIOUS staircase step is diagonal: u=z-ey.
The other two arcs' exits are obtained by (z,u)->(R-z,R-u). There are no other exiting stars: strict-interior roots have their unit inputs in closed E; all boundary roots are on the four listed arcs, and the horizontal/vertical ordering of each staircase gives the tests above. Endpoints are INCLUDED: H0 and Hlast use H1; V0 and Vlast use V1. This avoids inventing extra connector roots or discarding their parity.

The natural candidate representatives are u+V for H1/H2, u+U for V1/V2, and the corresponding negative translations on the reflected arcs. The remaining geometric membership check is explicitly
  u+V in E (H1/H2), u+U in E (V1/V2).
It is enough to verify these four inequalities in the genuine parity-rectangle description of E. No unbounded deck search is needed. The accompanying independent polygon code verifies the complete exit list, these memberships and boundary-pair classification for every reduced odd n,d through d=43 (20,642 exit edges). This finite replay is diagnostic; it is not a replacement for the four universal membership inequalities.

## Exact height calculation: sufficient native guards
Assume the actual global abstract M obeys
  M(R-z)=M(z)-a.z+kappa,
and on the directed H halo M=0, on the directed Vleft halo M=h0, apart from the already specified V0 exception and its reflection. These are TRUE M height guards, not assumptions about a periodized child's recurrence.

The bottom half-turn U+I-z preserves H and its directed halo by staircase palindrome. Therefore for every H-halo u,
  M(u+V)=M(U+I-u)+a.(u+V)-kappa
         =a.u+cV.
This gives the exact prescribed V pullback, including boundary duplicates. The computation uses a.V=-T and -T-kappa=cV.

Likewise V+I-z preserves Vleft and its directed halo. The genuine harmonic profile has h0(I-z)=h0(z) and h0(z+V)=h0(z)+a.z+cV. Hence
  h0(V+I-u)=h0(u)-a.u+kappa,
  M(u+U)=M(V+I-u)+a.(u+U)-kappa=h0(u),
using a.U=0. This pays the U seam and every ordinary V exterior input. These identities use physical parity correctly; U,V,I have even coordinate sum and h0 includes its actual floor term.

At u=(-1,0), if M(u)=-1 rather than h0(u)=0, the partner V+I-u is not to be replaced by -1 automatically: its actual value is the regular harmonic value unless it is itself a listed exception. The periodized value is 0. The sole affected root in E is V0=(0,0), whose other input (1,0) and height are zero; its Laplacian changes from -1 to0. The reflected case has the identical affine-transformed calculation. The other caller (-2,0) is outside E.

Thus, once the four geometric membership guards and the actual two-arc halo heights hold, the complete E deck/halo propagation follows from these elementary identities. Interior stars already equal M; all exterior stars are in the list; the two exceptional stars are computed explicitly. No new-child recurrence or literal constructor equality is used.

## Scope
The duplicate-boundary classification and height algebra are uniform. The exit-list classification is local staircase geometry, with all endpoints included. The supplied finite replay confirms transcription. The outstanding geometric task has been reduced to four genuine parity-rectangle membership inequalities, and the outstanding analytic input remains the actual M H/V halo values (including base exceptions). This does not certify those halo values merely from boundary values: a boundary value alone does not determine its exterior input.
