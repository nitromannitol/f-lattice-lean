# Four exterior memberships: uniform closure

Adopt the genuine exact E parity rectangle, not just its convex hull:
  even: 2-T<=t<=L-2, 0<=s<=T+2n;
  odd: n-T<=t<=d, 2-c<=s<=T+L-2,
where c=d-n, L=d+n, t=nx-dy, s=Lx+cy, T=d²+2dn-n². Parameters are odd coprime 0<n<d. All four membership gates from BOUNDARY_DECK_HALO_REDUCTION are paid below. U changes (t,s) by (0,T); V changes it by (-T,0). Each input flips physical parity; both U,V preserve it.

## H1: odd bottom z, u=z-ey, representative u+V
On H, t(z) in [n,d]. Since H is coordinatewise nondecreasing from (1,0) to (d,n-1), s(z) in [L,T-c]. Hence
  t(u) in [L,2d], s(u) in [2n,T-2c].
Thus t(u+V) lies in [2-T,L-2] and s(u+V) in [0,T+2n]. The sole nontrivial upper bound is 2d<=T+L-2, true already at n=1,d=3 and increasing in both positive parameters. This includes H0 and Hlast.

## H2: even bottom z whose next step is diagonal, u=z+ex
Here 2<=x<=d-1 and 0<=y<=n-2. This case is empty if n=1. The H even spectrum gives t(z) in [2,L-2], so
  t(u) in [n+2,d+2n-2].
The coordinate bounds give 2L<=s(z)<=T-L-2c and hence
  3L<=s(u)<=T-2c.
After adding V these satisfy the ODD rectangle: n-T<=t(u)-T<=d and 2-c<=s(u)<=T+L-2. The upper t inequality uses T>=2n-2. No special endpoint is discarded.

## V1: even left z, u=z-ex, representative u+U
The exact even V spectrum is 0<=s(z)<=2n; all V points satisfy -T+L<=t(z)<=0. Therefore
  -T+d<=t(u)<=-n,
  T-L<=s(u+U)<=T-c.
These lie in the ODD rectangle. The only lower s check is T-L>=2-c, equivalent to T>=2n+2, true for all the proper parameters. Both V0 and Vlast are included.

## V2: odd left z whose previous step is diagonal, u=z-ey
The previous diagonal ensures x<=-1,y>=2, and thus t(z)<=-n-2d. The whole V range gives t(z)>=-T+L. Consequently
  -T+L+d<=t(u)<=-L.
The odd V spectrum is 2-c<=s(z)<=L-2, giving
  T+2-2c<=s(u+U)<=T+2n-2.
These lie in the EVEN rectangle. The lower s check is T>=2c-2. This case needs no parity exception. All remaining inequalities are weaker than L>=4,c>=2,T>=14.

Reflection z->R-z maps E to itself and swaps the respective exiting stars; the corresponding representatives use -V and -U. Hence these four checks close ALL directed exterior representative memberships, uniformly, without current recurrence.

The basic scalar inequalities above can also be seen directly from d=n+c, n>=1,c>=2: T=2n²+4nc+c². No rational relaxation or finite parameter test is used in this proof.

## Exact remaining height inputs, separated from the closed geometry
Nothing further about deck membership remains after adopting the exact parity rectangle. To recognize the abstract M on E and its halo, the analytic inputs are precisely:
1. M=0 at every bottom-H point and its actual directed inputs.
2. M=h0 at every left-V point and its actual directed inputs, except the actual listed port u=(-1,0), where its value may be -1 in the 2^m3^k family.
3. Exact global affine reflection M(R-z)=M(z)-a.z+kappa, a=(n,-d), kappa=(L-T)/2.

Then at each H exterior u, the representative has the EXACT height
  M(u+V)=a.u+cV, cV=-(T+L)/2,
so its periodized pullback is zero. At each V exterior u, the representative has height
  M(u+U)=h0(u),
so its periodized pullback is h0(u). These are consequences of (1)-(3), the authentic arc palindromes, and h0's exact V character, not additional height guesses. On boundary duplicates the same formulas give M(z+V)-M(z)=a.z+cV for z in H, and M(z+U)=M(z) for z in V.

For the exceptional u=(-1,0), the periodized pullback is 0 although M(u)=-1. Its reflected partner V+I-u must use its genuine REGULAR halo value; it is not the listed reflected exception R-u (they differ by U). The only affected root is V0; its two periodized inputs and root height are all zero, so it becomes white. The reflected star is the affine image of this calculation.

Thus the remaining Stage1 analytic burden is proving inputs (1) and (2) from the actual parent source formulas (including literal pure-run exceptions), and authenticating (3) independently from parent characters. Native boundary heights alone do not imply (1)/(2). Once those are established, no further global recurrence premise, halo extrapolation, or unbounded alias analysis is required.
