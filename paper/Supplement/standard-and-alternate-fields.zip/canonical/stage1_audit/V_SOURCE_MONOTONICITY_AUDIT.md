# Symmetric V-source route: analytic audit and exact remaining guards

This audits the proposed reduction, not a new certification of all ancestor H-price formulas.

Let p=(dp,np), q=(dq,nq), child (d,n)=(2dp+dq,2np+nq), eps=np*dq-dp*nq=2W-1. Write sp(x,y)=(dp+np)x+(dp-np)y and sc(x,y)=(d+n)x+(d-n)y. The exact identity is
  d*sp(w)=dp*sc(w)-eps*(w_y-w_x).
This follows by expanding both coefficients. For a directed input u=w+e, add d*sp(e) on the right: ±d(dp+np) on a horizontal star, ±d(dp-np) on a vertical star. This is the exact source-coordinate formula to use on the FULL V star, not just at its root.

In the aligned W1 case x=w. In the stated aligned W0 right case x=w+Up, true primary periodicity gives Fp(x)=Fp(w), including both inputs, so the same formula tests the actual parent values. It does NOT assert h0(w+Up)=h0(w); the latter is generally false. Any affine target cancellation must therefore be performed before replacing x by w.

## What the source strip really pays
If, for each actual u in {w} union inputs(w),
  -2dp+1 <= sp(u) <= 2dp+2np-1,
then the already admitted genuine parent harmonic strip proves Fp(u)=h0(u). This is a sufficient direct full-star guard. At an endpoint outside that interval one needs the actual parent parity-specific enlarged strip or a literal base value; the root-only V inclusion does not pay it.

For example at an even V root, sc(w) is in [0,2n], k=w_y-w_x is in [0,2d-2], and the two horizontal input coordinates are
  sp(w) ± (dp+np) = [dp*sc(w)-eps*k]/d ± (dp+np).
At odd V roots use sc(w) in [2-d+n,d+n-2] and the vertical increments ±(dp-np). These formulas isolate the penultimate and final tests without an unbounded alias calculation. Coarse independent intervals may overestimate the extremes; actual staircase correlation/parity must be retained.

In particular broad interval bounds leave possible endpoint excesses when dp-np=1. They are not a proof that an actual excess occurs, nor a license to declare the exception exactly one point. The proposed single -1 pure-parent exception requires evaluating the actual relevant base source at those correlated endpoints.

## Gap monotonicity and the halo conclusion
Suppose the actual aligned root gap is PsiA=C-A, and A agrees with the correctly normalized h0 on the entire star. If PsiA(w)>=1 and |delta PsiA|<=1, all input gaps are nonnegative, so min(A,C)=h0 on the complete star. Thus monotone ordering of all nonfinal root gaps can reduce the ordinary roots to one endpoint lower bound.

At a tied root PsiA(w)=0 this conclusion DOES NOT follow. Binary M and harmonic A still permit one input gap -1, turning the root black. The needed 'C/h0 correction' is the explicit pair of guards
  C(w-e)>=h0(w-e), C(w+e)>=h0(w+e),
with e the root's actual input axis; equivalently both input gaps >=0. One genuine equality branch plus these inequalities suffices. At the declared exceptional exterior input its true M value must instead be -1 and the periodized repair must be computed, as in FOUR_MEMBERSHIPS_CLOSED.

## Audit of the old H sandwich
For eta- the asserted physical chain
  (-1,-1) -> (0,-1) -> (0,0) -> (1,0)
is consistent with the canonical directions: H[-2] east, H[-1]=Hlast-U north, V0 east. Hence all-edge raw-Phi monotonicity puts the middle two values between the endpoints. If the independently established nominal endpoint formula gives equal endpoint values, both middle values equal that common value. This is a valid way to replace the exceptional H[-1]/V0 value without presuming the nominal formula there.

The analogous eta+ I/H0 replacement requires the separately established cut equality. It is not supplied by the eta- sandwich. The proposed conjugacy of each nonfinal V class into old H[-j-1] must include the actual parity sheet and affine/deck constant; a representative-class match alone would not establish monotonicity of the actual gap sequence. Given those exact conjugacies and endpoint corrections, reversing the old H index indeed reverses the order as claimed.

## Verdict and exact outstanding analytic work
The symmetric route is structurally sound if its authenticated old H scalar formulas and parity-sheet conjugacies hold. The root-to-halo argument is completely paid for positive root gaps, but tied roots still require the two explicit C-input inequalities. The full aligned A star is reduced to the displayed sp inequalities plus genuine base evaluations where they fail. Penultimate V+(1,-2) and final V+I must be tested directly in these formulas; their treatment cannot be inferred solely from monotonicity of nonfinal indices. No current-child recurrence is needed for any of these checks.

This audit has not proved the precise all-word list of failed sp guards, the claimed unique pure-parent -1 value, or the final tied C guards. Those are the remaining source-height obligations, as opposed to the now-closed exterior representative geometry.
