# Basic odd-parent donor shielding before current periodization

## Verdict and exact upstream premises
The proposed proof is sound with the following already-earlier inputs retained explicitly: the genuine conjugate identity Z(Ep)=Eprime−Uprime; the global source identity Psi(z)=K−Phi_epsilon(Z(z−lv)); genuine earlier deck characters Phi(Uprime)=−1 and Phi(Vprime)=2 epsilon; earlier recurrence of Fprime AND admission of its chain mate Fprime−Phi; the actual H/V boundary and signed trace/cut identities. Recurrence of Fprime alone, without admission of that mate, would not justify the maximum principle. No current child recurrence or current periodization is used.

The exact earlier nominal H trace and the two core substitutions are now paid by the ancestral cut. For epsilon_old plus, the shifted entries −r and −r−1 both have Dplus=1−2=−1; for epsilon_old minus, r and r−1 both have Dplus=0. These give the plus H0 nominal value and Phi_plus(I)=Phi_plus(H0). The minus E,N,E sandwich between H[-2] and H0 pays Phi_minus(V0)=Phi_minus(H0) at proper stages. Pure stages retain their literal endpoint tables instead of a fictitious proper creator.

## 1. Maximum on the old polygon
Write h=Phi(H0), eta=epsilon=2W−1. The maximum principle applies to Fprime minus the admitted chain mate, on the strict interior of Eprime. All incoming exits from that interior lie on its geometric boundary. Thus its maximum is bounded by the actual boundary maximum.

On H the trace is nonincreasing; its maximum is h. On H+Vprime its maximum is h+2 eta. On V the plus trace is increasing and its final value is Phi(I)+2=h+2; the minus trace is decreasing and its initial value is h. The other V arc is its Uprime translate, whose values are lower by one. Consequently

 max_Eprime Phi = h+2W,
 max_(Eprime−Uprime) Phi = h+2W+1.

Equality is attained on the boundary (plus: H0+Vprime; minus: H0). This reasoning includes the pure cases: reciprocal root plus has h=1 and V maximum3; later reciprocals have V maximum h+2. Pure near-one plus has V0=h+1 but its V maximum is only V0+1=h+2. In every pure minus case V0=h. These are exactly the exceptions in PURE_BOUNDARY_TABLES and PURE_CLOSURE_AND_SCOPE, not an assumed universal H0=V0 identity. Their already-certified H and V orders are still required.

## 2. W0 calibration
The actual current H point with index dq is z=Uq+I, since its x coordinate is dq+1 and its even transverse coordinate is t(z)=L−2. The actual H spectrum identifies this point uniquely. In the aligned odd-parent source coordinate x=z−Uq=I, so Zx=H0prime. The strict current H-source result, proved from earlier fields, gives Psi(z)>=1. Therefore K−h>=1. The maximum in section1 is h+1 when W0, proving Psi>=0 on Ep+lv.

This does not use current F on H: it uses the independently calibrated source difference C−A and its earlier-chain monotonicity.

## 3. W1 calibration
The tied current Hlast gives K=Phi(Vprime_(d−1)), with no core alias. Let Lprime=2D, where D is the current odd-parent denominator. Then d−1=Lprime+dq−1. The exact V character gives

 K=Phi(Vprime_(dq−1))+2.

It suffices to prove Phi(Vprime_(dq−1))−h>=1. If the trailing run count k>=1, the literal Farey relation gives dq−1>=Lprime. Increasing plus V order and its character then give Phi(Vprime_(dq−1))>=Phi(V0prime)+2>=h+2, stronger than needed.

At birth k=0 there are two genuine cases. Let rprime be the earlier signed-cut run length (equal here to the retained old q denominator).

* Last digit s=2: earlier creator sign is plus, dq=rprime. At j=rprime−1 the genuine dual V formula gives the difference Dprime_plus(V[-1])−Dprime_plus(V[-rprime])=0−(−1)=1.
* Last digit s=1: earlier creator sign is minus, dq=Lprime−rprime. At j=Lprime−rprime−1 that difference is Dprime_plus(V[Lprime−1])−Dprime_plus(V[rprime])=2−0=2.

The cut values are genuine physical lifts: the negative argument in the first line is reduced by the V character2, not silently replaced by a native value. Both formulas include the inherited literal pure endpoint values; if a creator endpoint is used, its pure table is the source, not the proper-parent cut proof. These two lines use the authenticated dual V reindexing identity, not only the cut word by itself.

Thus K>=h+3, the section1 bound for W1. Again Psi>=0 on Ep+lv.

## 4. Consequence and scope
On every physical point of the COMPLETE basic parent donor Ep+lv, A=Fp in its actual source gauge, C>=A, and hence M=min(A,C)=A. This is a height statement on that donor, not automatic equality on its incoming halo or on arbitrary translated copies. All source shifts and their affine jets must be transported together when applying it elsewhere.

No new raw solver claim is made. This is an independent proof audit of the maximum principle, signs, constants, pure maxima and calibration implication. The source/conjugacy and genuine dual V reindexing premises are cited as earlier authenticated inputs. Their mere drift agreement would not suffice. This shielding proof is independent of the current child recurrence and so is suitable for Stage1 strip propagation.
