# Stage 1B normalized standard: independent dependency audit

Reviewed Carbon PROOF_212715_EXACT.txt, Theorems 2.11 and 2.12(a), including their proofs (approximately lines 1326–1650). This is a logical/source-scope audit, not a fresh verification of every universal Sturmian inequality.

## Noncircular chronological order
1. At strictly earlier depths obtain globally coherent standard parents, their true deck characters/reflection, zero/harmonic strips, native agreement, and clean bands. Earlier clean bands, with their actual phase/source covariance, give recurrence and binary admission of the NEW ABSTRACT comparison M through 2.10(b). Recurrence of two offers alone is not enough.
2. Carry the incoming E/O cross-parent profiles as a state of the already completed parent pair. Use those profiles and earlier strips to prove the new abstract M's H and V incoming-halo values. The stationary-run restriction identity used here must be the earlier abstract comparison identity, not recognition of the new literal output.
3. Compare the unmodified old C0 chart against M on its own old closed polygon: two actual boundary arcs plus genuine difference-reflection give all boundary values. Both fields are already recurrent, so two correctly oriented comparisons on the strict interior imply equality. This uses old chart recurrence and abstract M recurrence, NOT recurrence of the new periodic F.
4. Verify seam values/cocycles and periodize a true representative crop of M; prove F=M on closed E and the directed halo statement, with the explicitly exceptional ports retained. This yields global binary F.
5. Prove new strip propagation using the now-paid C0 equality and actual positive source representatives. Construct the same-depth odd object by the stated genuine even/odd conjugacy of the swapped word; do not appeal to same-depth odd recurrence.
6. Update the E/O pair profiles for the next step, including the simultaneous terminal-1 reversal. Those updated profiles may use the newly recognized children; they cannot be fed backwards into step 2 of the same child.
7. Only later establish current F recurrence/ranks. Literal corrected L constructors and alternate recognition belong to later stages with their additional source assumptions.

This ordering resolves the apparent 2.11(c) <-> 2.12(a) citation cycle if the cited calculations really have the restricted premises claimed in the text. Treating each theorem as one atomic input would conceal this necessary ordering.

## Four-boundary comparison is legitimate, with exact domain
Let C be an old recurrent chart and M the independently recurrent abstract minimum. If C=M on the lattice boundary of a finite polygon and both are globally superharmonic, apply recurrence comparison on its STRICT interior. Every input outside that interior must lie on the given boundary. The comparison in each direction gives C=M in the interior. Merely matching four geometric arcs without verifying all lattice boundary points, connectors and actual input exits would be insufficient.

The manuscript's C0-reflection identity must concern the FULL difference C-M with its affine jets, not symmetry of domains alone. Ordinary six-piece recognition additionally requires actual origins/slopes, nonempty chronological overlaps, normalization, and absence of unintended clipping. Abstract F=M on E does not itself identify an arbitrary finite-canvas Julia array.

## Halo-to-periodization lemma: precise repair/checklist
A sufficient self-contained formulation is:
(a) E contains at least one representative of each child deck class, with a specified representative subset D_can;
(b) every pair of points of E in the same class has the prescribed affine-cocycle difference in M;
(c) for every root z in E, periodizing each of its two ACTUAL inputs gives M at that input, except for an explicitly listed finite exceptional pair of root stars;
(d) on each exception, directly compute the periodized star and its Laplacian.
Then the representative extension is well defined, equals M on E, and is globally binary. Checking (b) only on U/V seams is sufficient only after proving that these seams generate all duplicate identifications in E. Checking (c) only on H/V halos is sufficient only after the boundary/connector classification shows that they cover all stars leaving E; use true reflection and cocycles for the opposite arcs.

This lemma does not require the current F to be recurrent. It isolates exact obligations hidden by the sentence 'By reflection and seam matching, F is globally binary'.

## The exceptional star is not harmless by monotonicity alone
On the family 2^m3^k the stated defect is M(-1,0)=-1 but F(-1,0)=0, with root z=(0,0), M(z)=0 and the other input M(1,0)=0. Thus Delta M(z)=-1 and Delta F(z)=0. This is a valid black-to-white repair. One must verify that this exterior point is an input of no other E root except z; the other horizontal caller is (-2,0), outside the actual E. The reflected exceptional star has the same computation with its true affine jet. The inequality F>=M on the halo alone would not guarantee admission: raising an input of an already white root would yield a positive Laplacian.

## A concrete wording correction
T_HV(z)=V+(1+z2,-z1) reverses checkerboard parity: V has even coordinate sum, while the added (1,0) has odd sum. This is exactly what is needed for a quarter-turn F-lattice star bijection, since horizontal inputs must become vertical and vice versa. The sentence calling it 'parity-preserving' is false literally. Replace it by 'parity-reversing F-lattice star bijection'. The claimed graph-star conjugacy itself has the correct parity behavior.

## Remaining positive-coverage obligations
The strip proof's phrase 'E spans s-width T, hence every transverse line has a representative' does not follow from width alone for a lattice polygon. It must use the genuine unimodular/representative coverage theorem. Likewise the subsequent claim that the representative necessarily lies in one of the listed positive source charts needs an actual guard-cover proof, including endpoints and odd parity sheets. A safe repair is to state a finite list of source regions with true guards and prove every relevant representative belongs to their union, rather than invoke a hull width as a substitute. The exceptional parent base point in the H-halo calculation must retain its literal evaluation; a generic strip estimate does not cover it.

For terminal 1, write the E/O-profile induction as incoming-pair -> abstract children/halo/recognition -> outgoing-pair, so use of F_current=M_current in outgoing profiles cannot be confused with a premise for the incoming boundary calculation. The source text suggests this order but does not present it as an explicit dependency graph.

## Verdict
No inherent NEW-CHILD recurrence loop is required for Stage 1B. The legitimate recurrent target is M from EARLIER clean bands. The independent repair above makes halo recognition and chronology precise. This review does NOT certify all-word native source equality or all strip guard coverage: those depend on the actual Sturmian/source identities just identified, not on an abstract minimum construction. The parity label requires correction; the periodization and strip-cover obligations should be made explicit before calling the stage fully verified.
