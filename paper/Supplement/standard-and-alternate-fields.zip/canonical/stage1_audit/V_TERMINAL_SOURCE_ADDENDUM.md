# Terminal V source guards and literal exceptional value

The parent's clarified unified formula is
 C(z)-h0(w)=Fp(y-eps Uq)-h0(y),
 z=(1-W)U+w, w=V+y.
Conditional on that source/deck expansion with its actual affine normalization, the proposed terminal values follow exactly, with the following explicit sign check.

Write p=(dp,np), aq pairing ap.Uq=eps. Thus
 tp(y-eps Uq)=ap.y-1.
At y=I=(1,-1), I-ey=(1,-2), I-ex=(0,-1), I+ex=(2,-1), respectively, the transverse arguments are
 dp+np-1, 2dp+np-1, dp-1, dp+2np-1.
Every argument is in the genuine parent zero strip [-dp+1,np+2dp-1], including the upper equality for I-ey. Hence all four Fp values are exactly zero. The h0 values are respectively 0,-1,0,0. Therefore the C-h0 differences are 0,+1,0,0. In particular C equals h0 at the FINAL V root and both of its actual horizontal inputs, while C is h0+1 at the penultimate root. It would be incorrect to say C equals h0 at all four tested sites.

If the aligned A star equals h0 as separately claimed, the final gap is zero and the penultimate gap is one. Together with the nonfinal monotone-gap argument this pays the tied terminal C correction without a current recurrence premise.

## Pure near-one exceptional source: exact original evaluation
Let the odd parent be (D-1)/D, D>=2, with conjugate reciprocal even denominator d'=2D-1>=3. At the proposed exceptional halo point sp=4D-1,
  t'=d'-sp=-(d'+1).
The genuine reciprocal standard field is primary-periodic under U'=(d',1). Instead of relying on a global reflection extrapolation, use the actual original native point (d'-1,2). Its transverse coordinate is
  (d'-1)-2d'=-(d'+1).
In original final_code/base_case.jl:get_staircase_even, this point satisfies every main guard:
  2-d'<=d'-1<=d', 0<=2<=d'+1,
  1<=(d'-1)+2=d'+1<=d'+2.
It is not one of the two corner overrides. The literal value is
  -2*3/2 + 2 + min(d'-2,0) = -1
for EVERY d'>=3. Thus the claimed source residual -1 is proved at the genuine native site, including the smallest endpoint D=2. Reflection t'->d'+1-t' gives 2d'+2 consistently, but is unnecessary for this evaluation.

This proves the numerical height at the nominated exception. The statement that it is the ONLY failed full-star harmonic-source guard remains dependent on the parent's complete sp range classification; this addendum does not replace that classification by the single endpoint calculation. At the exception C=h0 whereas A=h0-1, so their minimum is h0-1, exactly the stated halo defect. Reflecting the aligned W0 right frame sends it to the original left V0-ex port; that frame identity must be kept with its affine jet.
