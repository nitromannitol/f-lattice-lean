import sys,json,hashlib,subprocess
sys.path.insert(0,'/tmp/f_lattice_z3')
import z3 as z
from pathlib import Path
P=Path(__file__).resolve().parent
A,x,y=z.Ints('a x y')
mn=lambda t:z.If(t<0,t,0)
mx=lambda t:z.If(t>0,t,0)
abs_=lambda t:z.If(t<0,-t,t)
def native(x,y):
 Y=y+1;h=Y-x
 return z.Or(z.And(x>=-1,x<=A+1,Y>=1,Y<=3*A-1,h>=-1,h<=2*A+1,z.Not(z.Or(z.And(x==-1,Y<=A+1),z.And(x==A+1,Y>=2*A-1)))),z.And(x==-1,Y==2*A+1),z.And(x==A+1,Y==A-1))
def corr(x,y):
 Y=y+1
 return mn(A-Y)+mx(Y-x-A)+mn(2*A-Y)+z.If(z.Or(z.And(Y-x==A,x>0,x<A),z.And(x==-1,Y==2*A+1),z.And(x==A+1,Y==A-1)),1,0)
def inp(x,y):return [(x-1,y),(x+1,y)] if False else None
def delta(x,y):
 return z.If((x+y)%2==0,-1+corr(x-1,y)+corr(x+1,y)-2*corr(x,y),corr(x,y-1)+corr(x,y+1)-2*corr(x,y))
def star(x,y):return z.And(native(x,y),z.If((x+y)%2==0,z.And(native(x-1,y),native(x+1,y)),z.And(native(x,y-1),native(x,y+1))))
def candidate(x,y):
 h=y-x
 low=z.And(h%2==1,h>=-1,h<=A-3,x>=1,x<=A,y!=A-1,z.Not(z.And(h==-1,x==1)))
 high=z.And(h%2==1,h>=A+1,h<=2*A-1,x>=0,x<=A-1,y!=2*A-1,z.Not(z.And(h==2*A-1,x==A-1)))
 E=z.And(h==A-2,x>=2,x<=A);W=z.And(h==A,x>=0,x<=A-2)
 guard=z.Or(low,high,E,W)
 dx=z.If(E,1,z.If(W,-1,0));dy=z.If(z.Or(low,high),z.If(y<z.If(low,A-1,2*A-1),-1,1),0)
 rank=z.If(E,x-1+z.If(x==A,1,0),z.If(W,A-1-x+z.If(x==0,1,0),abs_(y-z.If(low,A-1,2*A-1))+z.If(z.Or(z.And(x==0,h==A+1),z.And(x==A,h==A-3)),1,0)))
 return guard,dx,dy,rank
G,dx,dy,r=candidate(x,y)
def witness(aa,bb):
 sq=[(x+aa+i,y+bb+j)for i in [0,1]for j in [0,1]]
 inside=lambda X,Y:z.And(X>=x+aa,X<=x+aa+1,Y>=y+bb,Y<=y+bb+1)
 clauses=[z.Not(inside(x+dx,y+dy))]
 for X,Y in sq:
  g,dX,dY,R=candidate(X,Y)
  clauses.extend([star(X,Y),z.Or(delta(X,Y)==-1,delta(X,Y)==0),z.Implies(z.And(z.Or(X!=x,Y!=y),delta(X,Y)==0),z.And(g,R<r,inside(X+dX,Y+dY)))])
 return z.And(clauses)
base=z.And(A>=4,A%2==0,native(x,y),G)
checks={
 'candidate_white_with_native_star':z.And(base,star(x,y),delta(x,y)!=0),
 'only_two_forced_star_exceptions':z.And(base,z.Not(star(x,y)),z.Not(z.Or(z.And(x==0,y==A),z.And(x==A,y==2*A-2)))),
 'positive_rank':z.And(base,r<=0),
 'square_induction_except_two_endpoints':z.And(base,z.Not(z.Or(z.And(x==0,y==A),z.And(x==A,y==2*A-2))),z.Not(z.Or(*[witness(a,b)for a in [-1,0]for b in [-1,0]]))),
}
rows=[]
for name,f in checks.items():
 s=z.Solver();s.set(timeout=120000);s.add(f);raw=s.to_smt2();p=P/(name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
 if ans=='sat':print(s.model())
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(p)],capture_output=True,text=True,timeout=150).stdout.strip()
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'BULK_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
