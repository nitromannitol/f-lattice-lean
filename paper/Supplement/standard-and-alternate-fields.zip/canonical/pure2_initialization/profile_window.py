"""Scalar ranges on the genuine standard polygon and its incoming halo, not box surrogates."""
from rawall import *
import sympy as sp,subprocess
S=sp;X,Y,k=S.symbols('x y k');a=2*k+2
def rect(i,l,sx=0,sy=0):
 return X+sx-i*(a+1)+2*l,Y+sy-i*(a-1)-2*a*l
def raw(i,l,sx,sy):
 u,v=rect(i,l,sx,sy);t=(a-1)*u-(a+1)*v;cV=-a*a-3*a+1;T=2*a*a+4*a-2
 # times 4, parity correction canceled in differences
 return -(v+1-u)**2+4*l*(t+cV)-2*l*(l-1)*T
def lift(expr):
 poly=sp.Poly(expr.expand(),X,Y,k);assert poly.total_degree()<=1,(expr,poly)
 return int(poly.coeff_monomial(1))+int(poly.coeff_monomial(X))*x+int(poly.coeff_monomial(Y))*y+int(poly.coeff_monomial(k))*K
D=P/'windowchecks';D.mkdir(exist_ok=True)
def check(n,p):
 s=z.Solver();s.set(timeout=90000);s.add(K>=1,A==2*K+2,p);f=D/(n+'.smt2');f.write_text(s.to_smt2());ans=str(s.check());print(n,ans,s.model()if ans=='sat'else'',flush=True);assert ans=='unsat',n
def E(x,y):return z.Or(native(x,y),z.And(x==-1,y==A),z.And(x==A+1,y==2*A-2))
def polygon(x,y):
 H=[(1,0),(2,0),(A,A-2),(A+1,A-2)];V=[(0,0),(0,A-1),(-1,A),(-1,2*A-1)]
 arr=H+[(i+A+1,j+A-1)for i,j in V]+[(i-2,j+2*A)for i,j in H[::-1]]+V[::-1]
 border=[];cross=[];const=lambda s:z.simplify(s+z.IntVal(0))
 for (i,j),(p,q)in zip(arr,arr[1:]+arr[:1]):
  du=const(p-i);dv=const(q-j)
  if z.is_true(z.simplify(dv==0)):
   border.append(z.And(y==j,z.Or(z.And(x>=i,x<=p),z.And(x>=p,x<=i))));continue
  slope=next(m for m in [-1,0,1]if z.is_true(z.simplify(du==m*dv)))
  m=i+slope*(y-j)
  border.append(z.And(x==m,z.Or(z.And(y>=j,y<=q),z.And(y>=q,y<=j))))
  cross.append(z.And(x<m,z.Or(z.And(y>=j,y<q),z.And(y>=q,y<j))))
 return z.Or(*border,sum(z.If(b,1,0)for b in cross)%2==1)
def main():
 check('actual_polygon',polygon(x,y)!=E(x,y))
 win=z.Or(E(x,y),z.And((x+y)%2==1,z.Or(E(x-1,y),E(x+1,y))),z.And((x+y)%2==0,z.Or(E(x,y-1),E(x,y+1))))
 for nm,sx,sy,lin,dom,lo,hi in [('P',0-1,a-1,1,win,-1,0),('Dplus',1,1,0,E(x,y),0,2),('Dminus',-1,-1,0,E(x,y),-2,0)]:
  def charts(sx,sy):
   arr=[]
   for i,l in itertools.product(range(-2,3),repeat=2):
    u,v=[lift(h) for h in rect(i,l,sx,sy)];ng=native(u,v);s=z.Solver();s.add(K>=1,A==2*K+2,dom,ng)
    if s.check()==z.unsat:continue
    arr.append(((i,l),ng,u,v))
   return arr
  F=charts(0,0);G=charts(sx,sy)
  check(nm+'_cover_z',z.And(dom,z.Not(z.Or(*[q[1]for q in F]))))
  check(nm+'_cover_shift',z.And(dom,z.Not(z.Or(*[q[1]for q in G]))))
  guards=[]
  for ((i,l),p,u,v),((j,m),q,w,t)in itertools.product(F,G):
   pol=raw(i,l,0,0)-raw(j,m,sx,sy)+4*lin*(k*X-(k+1)*Y-(k*k+3*k+1))
   val=lift(pol)+4*(corr(u,v)-corr(w,t))
   guards.append(z.And(p,q,z.Or(val<4*lo,val>4*hi)))
  check(nm+'_window',z.And(dom,z.Or(*guards)))
if __name__=='__main__':main()
