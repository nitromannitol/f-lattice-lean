from pathlib import Path
exec(Path(__file__).with_name('complete_partition.py').read_text().split('\nbase=z.And')[0])
def edge(X,Y,dx,dy,b):
 offers=[]
 for i,j in aliases:
  xx,yy=shift(X,Y,i,j);g,gx,gy,r=candidate(xx,yy)
  offers.append(z.And(star(xx,yy),delta(xx,yy)==-1))
  offers.append(z.And(native(xx,yy),g,gx==dx,gy==dy))
  hx,hy=hdir(xx,yy,b);vx,vy=vdir(xx,yy,b)
  offers.extend([z.And(H(xx,yy),hx==dx,hy==dy),z.And(VV(xx,yy),vx==dx,vy==dy)])
 legal=z.If((X+Y)%2==0,z.And(dy==0,z.Or(dx==1,dx==-1)),z.And(dx==0,z.Or(dy==1,dy==-1)))
 return z.And(legal,z.Or(*offers))
checks={'full_native_binary':z.And(A>=4,A%2==0,star(x,y),z.Not(z.Or(delta(x,y)==-1,delta(x,y)==0)))}
# Rejected displacement is (-dx,-dy). Complete square using either perpendicular sign.
for b in [-1,1]:
 for typ,guard,di in [('H',H(x,y),hdir(x,y,b)),('V',VV(x,y),vdir(x,y,b))]:
  dx,dy=di;rx=-dx;ry=-dy;paths=[]
  for s in [-1,1]:
   px=-ry*s;py=rx*s
   paths.append(z.And(edge(x+rx,y+ry,px,py,b),edge(x+rx+px,y+ry+py,-rx,-ry,b),edge(x+px,y+py,-px,-py,b)))
  checks[f'return_{typ}_{b}']=z.And(A>=4,A%2==0,guard,z.Not(z.Or(*paths)))
rows=[]
for name,f in checks.items():
 s=z.Solver();s.set(timeout=120000);s.add(f);raw=s.to_smt2();p=P/(name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
 if ans=='sat':print(s.model(),flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:130',str(p)],capture_output=True,text=True,timeout=140).stdout.strip()
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'PRIVATE_RETURN_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
