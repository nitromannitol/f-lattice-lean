# Entire pure2 zero and h0 strips, including the two true corners

For every K>=1 put a=2K+2, n=a-1,d=a+1,T=2a²+4a-2. Let F be the true canonical standard pure2 global extension, with

 U=(a+1,a-1), V=(-2,2a), alpha=(a-1,-a-1), cV=-(T+2a)/2.

Then on the ENTIRE physical lattice,

    -a <= t(z) <= 3a       implies F(z)=0,
    -2a-1 <= s(z) <= 4a-1 implies F(z)=h0(z),

where t=(a-1)x-(a+1)y and s=2a*x+2y. These are exactly the desired universal strips [-d+1,n+2d-1] and [-(2d-1),2d+2n-1]. No restriction to H/V arcs or to native roots is imposed.

## 1. Genuine native bounds and the corner correction

Use the literal domain and formula from UNIFORM_DOUBLED_LADDER_BULK_DIRECTIONS.md. In exported coordinates every native root satisfies

 -1<=x<=a+1, 0<=y<=3a-2, -3<=h=y-x<=2a+1.

The sharper commonly quoted h interval [-2,2a] excludes two genuine added corners:

 (a+1,a-2), h=-3; and (-1,2a), h=2a+1.

They cannot be dropped: the first lies directly in the zero strip, and the second enters after -V. Their source +1 corrections are retained in every scalar check below.

## 2. Reduction of arbitrary deck indices

Write a physical site as w+iU+jV with w native, using the authentic native cover and coherent deck extension. Since t(U)=0 and F has zero primary character, i can be suppressed for the zero strip. Here t(w+jV)=t(w)-jT.

The displayed native box gives

 -(a+1)(2a+3) <= t(w) <= 3a+5.

For j>=1, t(w)-jT <=3a+5-T<-a; for j<=-2 it is at least 2a²+3a-7>3a. Thus only j=0,-1 can enter the zero strip.

For h0, both F and h0 have the SAME V-deck jet alpha.z+cV. Therefore the defect F-h0 is V-periodic; s(V)=0, so arbitrary j can be suppressed. Also s(U)=T. The native box gives

 -2a <= s(w) <= T+4a-2.

If i>=1 then s(w)+iT>=T-2a>4a-1; if i<=-2 it is <=-T+4a-2<-2a-1. Thus only i=0,-1 can enter the harmonic strip. All displayed strict inequalities hold already at a=4.

## 3. Only finite transverse bands remain

For the zero strip:

 j=0: h belongs to {-3,-2,-1,0,1};
 j=-1: h=2a+r with r in {-3,-2,-1,0,1}.

Indeed t>=-a and x>=-1 exclude h>=2. For j=-1, h<=2a-4 and x<=a+1 imply t+T>=4a>3a. The remaining bounds are the true native bounds, including both corners.

For the harmonic strip:

 i=0: x in {-1,0,1};
 i=-1: x=a+r with r in {-1,0,1}.

For i0, y>=0 and s<=4a-1 exclude x>=2. For i=-1, x<=a-2 and y<=3a-2 would give s<=2a²+2a-4, whereas the strip requires s>=T-2a-1=2a²+2a-3.

The six bound statements, including the arbitrary integral deck-index reductions, were independently checked as unbounded integer queries and freshly replayed.

## 4. Exact scalar calculation on the finite bands

Write the genuine native value as

 F(x,y)=-floor((h+1)²/4)+C(x,y),

 C=min(0,a-y-1)+max(0,h+1-a)+min(0,2a-y-1)+c(x,y),

where c is the exact diagonal/corner correction. In a zero-strip band substitute y=x+h. Its fourfold transported value is exactly

 -(h+1)² + ((h+1) mod 2) + 4C(x,x+h)
 +4j[t(x,x+h)+cV]-2T*j(j-1).

For each of the ten band choices in Section 3, the native guard and the exact strip inequalities imply this expression is zero. This keeps the parity remainder, genuine corner flags, and original finite domain, not an unrestricted piecewise continuation.

For a harmonic-strip band substitute the corresponding x. Since U has even sum, the two floor remainders cancel exactly. Set x'=x+i(a+1), y'=y+i(a-1). Four times F(x,y)-h0(x',y') is

 -(y-x+1)² + 4C(x,y) -2x'(x'-1)+(y'+1-x')².

Each of the six choices in Section 3 makes this expression zero under the true native and strip guards. Expanding before solving leaves only linear arithmetic. No quadratic-floor approximation or unchecked endpoint truncation is used.

full_strips.py generates these exact scalar identities and all geometry reductions. FULL_STRIPS_RECEIPT.json records all 22 obligations as producer UNSAT and independent fresh CLI UNSAT, with raw SHA256 bindings. These checks quantify every even a>=4 and all remaining spatial/alias variables. The finite number 22 counts symbolic cases, not sampled parameters.

## Scope

This proof requires only the literal primitive formula and its true coherent deck extension/native cover; it does not use provisional Carbon recurrence, the current all-word induction, or raw potential monotonicity. The empty K=0 root is the separate reciprocal 1/3 case and is not treated as a doubled ladder of parameter2.
