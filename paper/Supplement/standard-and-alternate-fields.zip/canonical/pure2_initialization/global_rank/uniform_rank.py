from pathlib import Path
import json,hashlib,subprocess,sys
D=Path(__file__).resolve().parent
src=(D.parent/'complete_partition.py').read_text().split('\nbase=z.And')[0];src=src.replace("Path(__file__).with_name('uniform_bulk.py')","D.parent/'uniform_bulk.py'")
exec(src)
# Absolute canonical representative: actual H/V first, otherwise lex-largest native.
def rep(X,Y):
 nofree=z.Not(z.Or(*[free(*shift(X,Y,i,j))for i,j in aliases]))
 maximal=[]
 for i,j in aliases:
  xx,yy=shift(X,Y,i,j);maximal.append(z.Not(z.And(native(xx,yy),z.Or(xx>X,z.And(xx==X,yy>Y)))))
 return z.Or(free(X,Y),z.And(native(X,Y),nofree,*maximal))
def val(X,Y,b):
 h=Y-X;p=(X+Y)%2
 if b==-1:
  core=z.If(h<A-1,z.If(Y<A-1,2*Y+4,z.If(Y==A-1,2*A+2,4*A-2*Y))-p,z.If(Y<2*A-1,2*Y-4*A,z.If(Y==2*A-1,2,4*A-2*Y))-p)
  return z.If(z.And(X==1,Y==0),3,z.If(z.And(X==A+1,Y==A-2),2*A+3,z.If(z.And(h==-2,X>=2,X<=A),2*X,z.If(VV(X,Y),-2*Y-p,z.If(h==A-1,4*A-2*Y+3,core)))))
 core=z.If(h<A-1,z.If(Y<A-1,2*Y,z.If(Y==A-1,6*A-2,8*A-2*Y-4))-p,z.If(Y<2*A-1,2*Y,z.If(Y==2*A-1,8*A-6,12*A-2*Y-8))-p)
 return z.If(z.And(X==1,Y==0),-1,z.If(z.And(X==A+1,Y==A-2),2*A-1,z.If(z.And(h==-2,X>=2,X<=A),2*X-4,z.If(VV(X,Y),2*Y-p,z.If(h==A-1,z.If(X==A-1,8*A-5,8*A-2*Y-1),core)))))
def rank(X,Y,b):
 offers=[(rep(*shift(X,Y,i,j)),val(*shift(X,Y,i,j),b)-i*(2*A+2)-j*4*A*b)for i,j in aliases]
 ans=z.IntVal(0)
 for g,v in offers:ans=z.If(g,v,ans)
 return z.Or(*[g for g,v in offers]),ans

def edge(X,Y,dx,dy,b):
 offers=[]
 for i,j in aliases:
  xx,yy=shift(X,Y,i,j);g,gx,gy,_=candidate(xx,yy);hx,hy=hdir(xx,yy,b);vx,vy=vdir(xx,yy,b)
  offers.extend([z.And(star(xx,yy),delta(xx,yy)==-1),z.And(native(xx,yy),g,gx==dx,gy==dy),z.And(H(xx,yy),hx==dx,hy==dy),z.And(VV(xx,yy),vx==dx,vy==dy)])
 return z.And(z.If((X+Y)%2==0,dy==0,dx==0),z.Or(*offers))
if __name__=='__main__':
 names=sys.argv[1:];rows=[]
 for b in[-1,1]:
  g,r=rank(x,y,b)
  for dx,dy in[(-1,0),(1,0),(0,-1),(0,1)]:
   name=f'rank_{b}_{dx}_{dy}'
   if names and name not in names:continue
   gu,ru=rank(x+dx,y+dy,b);s=z.Solver();s.set(timeout=120000);s.add(A>=4,A%2==0,native(x,y),edge(x,y,dx,dy,b),z.Or(z.Not(g),z.Not(gu),ru>=r));raw=s.to_smt2();p=D/(name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
   if ans=='sat':print(s.model(),flush=True)
   (D/(name+'.producer.json')).write_text(json.dumps(dict(status=ans,model=str(s.model())if ans=='sat'else'',sha256=hashlib.sha256(raw.encode()).hexdigest())))
