from simple_candidate import *
import sys,contextlib,io
sys.path.insert(0,str(D.parent));from physical_unit_probe import run
for K in[1,2,3]:
 with contextlib.redirect_stdout(io.StringIO()):tile,F,forced,_,key=run(K)
 a=2*K+2;T=2*a*a+4*a-2;U=(a+1,a-1);V=(-2,2*a)
 for b,fun in[(-1,R),(1,Rp)]:
  d=np.load(D/f'lp_K{K}_b{b}.npz');bad=[]
  for x,y in tile:
   z=d['reps'][key((x,y))];dx,dy=x-z[0],y-z[1];j=(2*a*dx+2*dy)//T;h=(-(a-1)*dx+(a+1)*dy)//T;dif=fun(x,y,a)-fun(*z,a)-j*(2*a+2)-h*4*a*b
   if dif:bad.append(((x,y),int(dif)))
  print(K,b,len(bad),bad[:6])
