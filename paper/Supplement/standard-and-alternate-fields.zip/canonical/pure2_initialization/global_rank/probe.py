import sys,contextlib,io,json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D.parent));from physical_unit_probe import run

def go(K,b):
 with contextlib.redirect_stdout(io.StringIO()):tile,F,forced,_,key=run(K)
 a=2*K+2;U=(a+1,a-1);V=(-2,2*a);T=2*a*a+4*a-2
 H=[(1,0)]+[(x,x-2)for x in range(2,a+1)]+[(a+1,a-2)]
 VV=[(0,y)for y in range(a)]+[(-1,y)for y in range(a,2*a)]
 dirs={}
 for z in H:
  v=(0,-1)if z==H[0] else(0,-b)if z==H[-1]else(-1,0)if sum(z)%2==0 else(0,-1)
  assert key(z)not in dirs;dirs[key(z)]=v
 for z in VV:
  v=(b,0)if z==VV[0]else(-1,0)if z==VV[-1]else(b,0)if sum(z)%2==0 else(0,-b)
  assert key(z)not in dirs;dirs[key(z)]=v
 reps={key(z):z for z in sorted(tile)};reps.update({key(z):z for z in H+VV});assert len(reps)==T
 dirs.update(forced);edges=[]
 for k,z in reps.items():
  x,y=z;ins=[(x-1,y),(x+1,y)]if sum(z)%2==0 else[(x,y-1),(x,y+1)]
  white=sum(F(u)for u in ins)-2*F(z)==0
  if white:
   assert k in dirs;(dx,dy)=dirs[k];ins=[(x+dx,y+dy)]
  else:assert k not in dirs
  for u in ins:
   l=key(u);r=reps[l];dx,dy=u[0]-r[0],u[1]-r[1];j=(V[1]*dx-V[0]*dy)//T;h=(-U[1]*dx+U[0]*dy)//T;assert(dx,dy)==(j*U[0]+h*V[0],j*U[1]+h*V[1]);edges.append((k,l,j,h))
 A=lil_matrix((len(edges)+4,T+4));rhs=np.full(len(edges)+4,-1.)
 for i,(k,l,j,h)in enumerate(edges):A[i,k]-=1;A[i,l]+=1;A[i,T]=j;A[i,T+1]=h
 for i,(var,sign)in enumerate([(T,1),(T,-1),(T+1,1),(T+1,-1)]):A[len(edges)+i,var]=sign;A[len(edges)+i,T+2+(var-T)]=-1;rhs[len(edges)+i]=0
 c=np.zeros(T+4);c[-2:]=1
 fit=linprog(c,A_ub=A.tocsr(),b_ub=rhs,bounds=[(None,None)]*(T+2)+[(0,None)]*2,method='highs')
 out=dict(K=K,b=b,status=fit.message)
 if fit.success:
  out['characters']=fit.x[T:T+2].tolist();out['min_drop']=float(np.min(-A[:len(edges)].tocsr()@fit.x));np.savez(D/f'lp_K{K}_b{b}.npz',rank=fit.x[:T],chars=fit.x[T:T+2],reps=np.array([reps[k]for k in range(T)]),edges=np.array(edges))
 print(out,flush=True);return out
if __name__=='__main__':
 rows=[go(K,b)for K in[1,2,3,4,6]for b in[-1,1]];(D/'LP_RESULTS.json').write_text(json.dumps(rows,indent=2))
