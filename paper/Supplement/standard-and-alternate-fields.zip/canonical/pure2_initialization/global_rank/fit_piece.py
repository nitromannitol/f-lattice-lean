from pathlib import Path
import numpy as np,json
from scipy.optimize import linprog
from scipy.sparse import lil_matrix,hstack,vstack,eye,csr_matrix
D=Path(__file__).resolve().parent

def zone(x,y,a):
 h=y-x;par=(x+y)%2
 if(x,y)==(1,0):return'H0'
 if(x,y)==(a+1,a-2):return'Hlast'
 if h==-2 and 2<=x<=a:return'H'
 if(x,y)==(0,0):return'V0'
 if(x,y)==(-1,2*a-1):return'Vlast'
 if(x==0 and 1<=y<a)or(x==-1 and a<=y<2*a-1):return'V'+str(par)
 if h==a-1:return'center'+str(int(x==0))+str(int(x==a-1))
 side=int(h>a-1);level=(2*a-1 if side else a-1);sgn=int(y>level)-int(y<level)
 return str((side,sgn,par,int(h< -2),int(x in (-1,0,a-1,a,a+1))))
for b in[-1,1]:
 data=[(2*K+2,np.load(D/f'lp_K{K}_b{b}.npz'))for K in[1,2,3,4,6]]
 keys=sorted({zone(int(x),int(y),a)for a,d in data for x,y in d['reps']});ki={k:i for i,k in enumerate(keys)};count=sum(len(d['edges'])for a,d in data);A=lil_matrix((count,4*len(keys)+4));rhs=[];i=0
 for a,d in data:
  for k,l,j,h in d['edges']:
   for v,sign in[(k,-1),(l,1)]:
    x,y=map(int,d['reps'][v]);base=4*ki[zone(x,y,a)];A[i,base:base+4]+=np.array([x,y,a,1])*sign
   A[i,-4:]=[j*a,j,h*a,h];rhs.append(-1);i+=1
 nv=A.shape[1];AA=vstack([hstack([A,csr_matrix(A.shape)]),hstack([eye(nv),-eye(nv)]),hstack([-eye(nv),-eye(nv)])]);fit=linprog(np.r_[np.zeros(nv),np.ones(nv)],A_ub=AA,b_ub=np.r_[rhs,np.zeros(2*nv)],bounds=[(None,None)]*(nv-4)+[(2,2),(2,2),(4*b,4*b),(0,0)]+[(0,None)]*nv,method='highs');
 if fit.success:fit.x=fit.x[:nv];print(b,fit.message,flush=True)
 if fit.success:
  out={k:fit.x[4*i:4*i+4].tolist()for k,i in ki.items()};out['CHARACTERS']=fit.x[-4:].tolist();print(out);(D/f'PIECE_CANDIDATE_b{b}.json').write_text(json.dumps(out,indent=2))
