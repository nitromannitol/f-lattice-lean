from pathlib import Path
import numpy as np,json
D=Path(__file__).resolve().parent
def R(x,y,a):
 h=y-x;p=(x+y)%2
 if(x,y)==(1,0):return 3
 if(x,y)==(a+1,a-2):return 2*a+3
 if h==-2 and 2<=x<=a:return 2*x
 if (x==0 and 0<=y<a)or(x==-1 and a<=y<2*a):return -2*y-p
 if h==a-1:return 4*a-2*y+3
 if h<a-1:
  return (2*y+4 if y<a-1 else 2*a+2 if y==a-1 else 4*a-2*y)-p
 return(2*y-4*a if y<2*a-1 else 2 if y==2*a-1 else 4*a-2*y)-p
def Rp(x,y,a):
 h=y-x;p=(x+y)%2
 if(x,y)==(1,0):return -1
 if(x,y)==(a+1,a-2):return 2*a-1
 if h==-2 and 2<=x<=a:return 2*x-4
 if (x==0 and 0<=y<a)or(x==-1 and a<=y<2*a):return 2*y-p
 if h==a-1:return 8*a-5 if x==a-1 else 8*a-2*y-1
 if h<a-1:return (2*y if y<a-1 else 6*a-2 if y==a-1 else 8*a-2*y-4)-p
 return(2*y if y<2*a-1 else 8*a-6 if y==2*a-1 else 12*a-2*y-8)-p
if __name__=='__main__':
 rows=[]
 for K in[1,2,3,4,6]:
  a=2*K+2;d=np.load(D/f'lp_K{K}_b1.npz');r=[Rp(*z,a)for z in d['reps']];bad=[]
  for k,l,j,h in d['edges']:
   drop=r[k]-r[l]-j*(2*a+2)-h*4*a
   if drop<1:bad.append([d['reps'][k].tolist(),d['reps'][l].tolist(),int(j),int(h),int(drop)])
  print(K,len(bad),bad[:8]);rows.append(dict(K=K,bad=bad))
 (D/'SIMPLE_CANDIDATE_CHECK.json').write_text(json.dumps(rows,indent=2))
