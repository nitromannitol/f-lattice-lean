from pathlib import Path
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/pure2_initialization');exec((P/'uniform_bulk.py').read_text().split('G,dx,dy,r=candidate(x,y)')[0]);G,*_=candidate(x,y);h=y-x;odd=(x+y)%2
b=z.If(h<=A-2,2*A-2-2*abs_(y-(A-1))-odd,2*A-2*abs_(y-(2*A-1))-odd);center=z.If(h<=A-2,A-1,2*A-1)
plus=z.If(h==-1,z.If(x==A,2*A-3,2*A+1-2*y),z.If(h==A-1,2*x+3,b))
minus=z.If(h==-1,z.If(x==2,2,2*A+6-2*y),z.If(h==A-1,z.If(x==1,2*A,2*x+4),z.If(y==center+1,1-odd,b+z.If(y<center+1,1,5))))
s=z.Solver();s.add(A>=4,A%2==0,native(x,y),z.Or(G,z.And(star(x,y),delta(x,y)==-1)),z.Or(plus<0,plus>2*A+2,minus<0,minus>2*A+2));print(s.check());print(s.model()if s.check()==z.sat else'');Path('/tmp/flat_rank_bound.smt2').write_text(s.to_smt2())
