# Pure2 initialization: exact rotation reduction, not a closed raw-policy proof

## Verdict

The existing pure boundary table pays the pure2 endpoint scalars and boundary slip ranges. It does not by itself pay the all-edge raw P, D+, D− and Phi± initialization. A direct appeal to the proved pure3 EVEN staircase package does not pay it either: the genuine quarter turn sends pure2 EVEN to pure3 ODD. Below is the exact reduction, including all affine corrections. It isolates a short, parameter-dependent odd-staircase gate rather than assuming the desired initialization.

Sources inspected: pinned PROOF_212715.txt Corollary 2.3, Lemma 3.10.0, §3.10(b); terminal_repair/PURE_BOUNDARY_TABLES.md and PURE_CLOSURE_AND_SCOPE.md; policy_square_geometry.py's true square-clause/free-edge construction. The latter is not used as a universal solver certificate.

## 1. Actual global rotation and graph

Let K>=1, E be the canonical even standard at (2K+1)/(2K+3) from word 2^K, and O the canonical odd standard at 1/(2K+2) from word 3^K. Write

    Y(x,y)=(y+1,-x),   H(x,y)=x(x-1)/2-floor((y+1-x)^2/4).

The genuine pure-run conjugacy is exactly

    E(z)=O(Yz)+H(z).

This follows by inversion of O(w)=E((-w_y,w_x-1))+H(w), using H(Yz)=-H(z). No constant may be silently introduced in the canonical LL/height-zero frame.

Y reverses physical parity and rotates each input displacement (a,b) to (b,-a); it is an automorphism of the directed input graph. H has zero F-lattice Laplacian at every site, checked separately at even horizontal and odd vertical stars by the floor identity. Thus colors, finite forts, elementary square clauses, and their forced-direction closure are transported exactly. Recurrence/admission of E therefore follow from those of O.

This does NOT identify the selected free policy. The rotated choice at each free site must equal the authentic O choice in the required sign convention. A forced-edge transport is automatic, but a canonical free-edge transport is an additional boundary check. Nor does recurrence of O give monotonicity of an arbitrary difference of its translates.

## 2. Exact transformed raw fields

Set p=(K+1,K), Vp=(-1,2K+1), sigma=-2p, ap=(K,-K-1), eps=-1. These are the actual pure2 initialization data, not a fictitious proper opposite parent. Define

    P(z)=E(z)-E(z+Vp)+ap.z,
    D+(z)=E(z)-E(z+sigma),
    D−(z)=E(z)-E(z-sigma),
    Phi_eta(z)=E(z)-E(z+Vp+eta*sigma)+ap.z.

For w=Yz the exact identities are

    P = O(w)-O(w+(2K+1,1)) + K²+3K+1;
    D+ = O(w)-O(w+(-2K,2K+2))
         +(2K+1)x+y-2K²-5K-1;
    D− = O(w)-O(w+(2K,-2K-2))
         -(2K+1)x-y-2K²-3K-1;
    Phi+ = O(w)-O(w+(1,2K+3))
           +(2K+1)x+y-K²-2K;
    Phi− = O(w)-O(w+(4K+1,-2K-1))
           -(2K+1)x-y-K².

Proof: for an even-sum displacement v=(a,b), the floor remainders agree and

    H(z)-H(z+v)=-(a+b)x/2+(b-a)y/2
                +b/2-a²/2+(b-a)²/4.

Insert Vp, +/-sigma and Vp+/-sigma. This identity is global, not restricted to a native guard. All shifts here preserve phase. Constants and coefficients were independently expanded symbolically (check_rotation.py).

A useful warning: O has V_O=(-2K-1,2K+3), so the D+ shift is V_O+(1,-1), NOT a pure O deck vector. The remaining one-pixel comparison is precisely substantive. Dropping it would produce a false deck-only initialization argument.

## 3. Precise remaining finite-geometry gate

On every actual E selected edge z->u, transport it to w->w'=Yu in the O graph. Put l(z)=(2K+1)x+y. For v_D=(-2K,2K+2), v_+=(1,2K+3), v_-=(4K+1,-2K-1), the unpaid raw inequalities are exactly:

* O(w')-O(w'+(2K+1,1)) <= O(w)-O(w+(2K+1,1));
* [O(w')-O(w'+v_D)]-[O(w)-O(w+v_D)] <= -[l(u)-l(z)] for D+;
* the same formula with -v_D and right side +[l(u)-l(z)] for D−;
* the same formula with v_+ and right side -[l(u)-l(z)] for Phi+;
* the same formula with v_- and right side +[l(u)-l(z)] for Phi−.

P is needed for both eta choices, D+/Phi+ for eta+, D−/Phi− for eta−. At black roots every input is tested; at a forced white only its genuine forced input; at a free white the true prescribed direction, not an arbitrarily convenient direction. These local tests are periodic after deck cancellation, but their all-K proof is not furnished by a finite census.

For raw pair admission one additionally needs the shifted-star unit bounds and exclusion of the black/black opposing increments. A harmonic rotation transports those tests exactly once they are proved for the displayed shifted O pairs. Rounded-rank monotonicity alone does not exclude the raw 1->2 middle-step patterns documented in BALANCED_RANK_AND_RAW_SLIP_GATE.md.

## 4. What is already paid and what is not

PURE_BOUNDARY_TABLES.md proves the pure2 Phi+(H0)-Phi+(V0)=-1 and Phi− difference0, retaining the essential doubled-ladder diagonal +1. Its pure3 calculations are for the even reciprocal staircase, not the odd O appearing above. PURE_CLOSURE_AND_SCOPE.md explicitly keeps all-edge physical-policy monotonicity upstream. Consequently it would be circular to use that file's final no-wrap deduction as proof of these raw inequalities.

The empty root K=0 is the genuine reciprocal 1/3 field and belongs to the separately evaluated pure3 root package; it is not the nonexistent doubled-ladder parameter2. No extension of the doubled formula to K0 is made here.

Conclusion: exact pure2 rotation algebra and graph/forced-clause transport are established. Complete all-K raw canonical initialization remains the five explicitly displayed odd-staircase comparison gates plus authentic free-policy matching; no counterexample is asserted and no all-edge completion is claimed.
