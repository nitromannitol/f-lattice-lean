from rawall import *
import rawall as RA
out=P/'rankchecks';out.mkdir(exist_ok=True);RA.out=out
alias=[(i,l)for i in [0,-1,1]for l in [0,-1,1]]
def HV(x,y):
 return z.Or(z.And(x==1,y==0),z.And(x>=2,x<=A,y==x-2),z.And(x==A+1,y==A-2)),z.Or(z.And(x==0,y>=0,y<A),z.And(x==-1,y>=A,y<2*A))
def freer(x,y,eta):
 j=z.If(x==1,0,x-1);r=y-A
 H=z.If(j==0,2*A+1,z.If(j==A,1,2*(A+1-x))) if eta==1 else z.If(j==0,4,z.If(j==1,1,z.If(j==A,6,2*A+7-2*x)))
 if eta==1:V=z.If(y<A,2*y-y%2,2*r+1+r%2)
 else:V=z.If(y==0,5,z.If(y<A,2*A+3-2*y-y%2,z.If(y==A,2,z.If(y==A+1,1,2*A+4-2*r+r%2))))
 return H,V
def bulkr(x,y,eta):
 h=y-x;o=(x+y)%2;cen=z.If(h<=A-2,A-1,2*A-1);off=z.If(h<=A-2,2*A-2,2*A)
 r=off-2*abs_(y-cen)-o
 if eta==-1:r=z.If(y==cen+1,1-o,r+z.If(y<cen+1,1,5))
 first=z.If(x==A,2*A-3,2*A+1-2*y)if eta==1 else z.If(x==2,2,2*A+6-2*y)
 mid=2*x+3 if eta==1 else z.If(x==1,2*A,2*x+4)
 return z.If(h==-1,first,z.If(h==A-1,mid,r))
def addresses(X,Y):
 return [(X-i*(A+1)+2*l,Y-i*(A-1)-2*A*l)for i,l in alias]
def deckrank(X,Y,eta):
 freeoffers=[];bulkoffers=[]
 for u,v in addresses(X,Y):
  H,V=HV(u,v);hr,vr=freer(u,v,eta)
  freeoffers.extend([(H,hr),(V,vr)])
  bulkoffers.append((native(u,v),bulkr(u,v,eta)))
 ans=-1000
 for guard,value in reversed(freeoffers+bulkoffers):ans=z.If(guard,value,ans)
 return simp(ans)
def mainrank():
 native0=native(x,y);addresses0=addresses(x,y);fs=z.Or(*[z.Or(*HV(u,v))for u,v in addresses0])
 # Every nonfree has at most ONE native representative: this proves periodic evaluation unambiguous.
 verify('bulk_alias_uniq',z.And(native0,z.Not(fs),z.Or(*[native(u,v) for u,v in addresses0[1:]])))
 for eta in (-1,1):
  for dx,dy in [(-1,0),(1,0),(0,-1),(0,1)]:
   flow=(x+y)%2==(0 if dx else 1);gx=grad(0,0,dx,dy)
   gopp=grad(0,0,-dx,-dy);cd,cx,cy,r=candidate(x,y)
   freeHere=z.Or(*[free(u,v,eta,dx,dy) for u,v in addresses0])
   select=z.Or(gx+gopp== -2,z.And(cd,cx==dx,cy==dy),freeHere)
   sx,sy=(0,A)if eta==1 else(-2,A-2)
   phi=simp(gx-grad(sx,sy,dx,dy)+2*(K*dx-(K+1)*dy))
   Rank=deckrank(x,y,eta);rank2=deckrank(x+dx,y+dy,eta)
   # Full actual native cover for current/successor; free arc alias is paid by <=1 native neighbor shifts.
   verify('fold_cover'+str((dx,dy)),z.And(native0,flow,z.Not(z.Or(*[native(u,v)for u,v in addresses(x+dx,y+dy)]))))
   verify('flat_rank_'+str((eta,dx,dy)),z.And(native0,flow,select,phi==0,rank2>=Rank),timeout=180000)
if __name__=='__main__':mainrank()
