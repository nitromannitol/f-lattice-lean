from pathlib import Path
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/pure2_initialization')
exec((P/'uniform_bulk.py').read_text().split('G,dx,dy,r=candidate(x,y)')[0])
G,*_=candidate(x,y)
clauses=[]
for i in [-1,0,1]:
 for j in[-1,0,1]:
  if i or j:clauses.append(native(x+i*(A+1)-2*j,y+i*(A-1)+2*A*j))
s=z.Solver();s.add(A>=4,A%2==0,native(x,y),z.Or(G,z.And(star(x,y),delta(x,y)==-1)),z.Or(*clauses));print(s.check());print(s.model()if s.check()==z.sat else'');Path('/tmp/nonfree_native_unique.smt2').write_text(s.to_smt2())
