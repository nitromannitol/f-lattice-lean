from pathlib import Path
exec(Path(__file__).with_name('uniform_bulk.py').read_text().split('base=z.And')[0])
U=(A+1,A-1);V=(-2,2*A)
aliases=[(i,j)for i in [-1,0,1]for j in [-1,0,1]]
def shift(X,Y,i,j):return X+i*U[0]+j*V[0],Y+i*U[1]+j*V[1]
def H(X,Y):return z.Or(z.And(X==1,Y==0),z.And(X>=2,X<=A,Y==X-2),z.And(X==A+1,Y==A-2))
def VV(X,Y):return z.Or(z.And(X==0,Y>=0,Y<=A-1),z.And(X==-1,Y>=A,Y<=2*A-1))
def free(X,Y):return z.Or(H(X,Y),VV(X,Y))
def fg(X,Y):return z.Or(*[free(*shift(X,Y,i,j))for i,j in aliases])
def hdir(X,Y,ay):
 return z.If(z.And(X==1,Y==0),0,z.If(z.And(X==A+1,Y==A-2),0,z.If((X+Y)%2==0,-1,0))),z.If(z.And(X==1,Y==0),-1,z.If(z.And(X==A+1,Y==A-2),-ay,z.If((X+Y)%2==0,0,-1)))
def vdir(X,Y,ay):
 return z.If(z.And(X==0,Y==0),ay,z.If(z.And(X==-1,Y==2*A-1),-1,z.If((X+Y)%2==0,ay,0))),z.If(z.Or(z.And(X==0,Y==0),z.And(X==-1,Y==2*A-1)),0,z.If((X+Y)%2==0,0,-ay))
def out(X,Y,lx,ly,ay):
 inside=lambda dx,dy:z.And(X+dx>=lx,X+dx<=lx+1,Y+dy>=ly,Y+dy<=ly+1)
 offers=[]
 for i,j in aliases:
  xx,yy=shift(X,Y,i,j);g,dx,dy,r=candidate(xx,yy)
  offers.append(z.And(native(xx,yy),g,z.Not(inside(dx,dy))))
  dx,dy=hdir(xx,yy,ay);offers.append(z.And(H(xx,yy),z.Not(inside(dx,dy))))
  dx,dy=vdir(xx,yy,ay);offers.append(z.And(VV(xx,yy),z.Not(inside(dx,dy))))
 return z.Or(*offers)
base=z.And(A>=4,A%2==0,native(x,y))
g,*_=candidate(x,y)
checks={
 'full_native_partition':z.And(base,star(x,y),delta(x,y)==0,z.Not(g),z.Not(fg(x,y))),
 'off_native_star_partition':z.And(base,z.Not(star(x,y)),z.Not(g),z.Not(fg(x,y))),
 'forced_free_disjoint':z.And(base,g,fg(x,y)),
 'arc_stars_if_native_are_white':z.And(base,free(x,y),star(x,y),delta(x,y)!=0),
}
for ay in [-1,1]:checks['all_squares_policy_'+str(ay)]=z.And(base,z.Not(z.Or(*[out(x+i,y+j,x,y,ay)for i in [0,1]for j in [0,1]])))
rows=[]
for name,f in checks.items():
 s=z.Solver();s.set(timeout=120000);s.add(f);raw=s.to_smt2();p=P/(name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
 if ans=='sat':print(s.model(),flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:150',str(p)],capture_output=True,text=True,timeout=160).stdout.strip()
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'PARTITION_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
