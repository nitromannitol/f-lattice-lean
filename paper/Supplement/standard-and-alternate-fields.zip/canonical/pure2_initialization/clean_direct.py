from globalrank import *
import rawall as RA
out=P/'cleanchecks';out.mkdir(exist_ok=True);RA.out=out
def main():
 for eta in [-1,1]:
  sx,sy=(0,A)if eta==1 else(-2,A-2)
  for axis in ['h','v']:
   es=[(-1,0),(1,0)]if axis=='h'else[(0,-1),(0,1)]
   par=(x+y)%2==(0 if axis=='h'else 1);gs=[grad(0,0,*e)for e in es];black=sum(gs)==-2
   cd,cx,cy,_=candidate(x,y)
   esel=[z.Or(black,z.And(cd,cx==dx,cy==dy),*[free(u,v,eta,dx,dy)for u,v in addresses(x,y)])for dx,dy in es]
   gs_phi=[simp(g-grad(sx,sy,dx,dy)+2*(K*dx-(K+1)*dy))for (dx,dy),g in zip(es,gs)]
   need2=2-sum(gs)-sum(z.If(gg>0,-gg,0)for gg in gs_phi)-2*sum(z.If(gg!=0,1,0)for gg in gs_phi)
   have2=2*sum(z.If(z.And(gg==0,r),1,0)for r,gg in zip(esel,gs_phi))
   verify('chainunit_'+axis+str(eta),z.And(native(x,y),par,z.Or(*[abs_(gg)>2 for gg in gs_phi])))
   verify('bandquota_'+axis+str(eta),z.And(native(x,y),par,have2<need2))
if __name__=='__main__':main()
