exec(open('/tmp/pureprobe.py').read().split("if __name__")[0])
import contextlib,io
for K in range(1,8):
 with contextlib.redirect_stdout(io.StringIO()):tile,F,fo,ra,key=run(K)
 a=2*K+2;bad=[]
 for (x,y) in tile:
  if key((x,y))not in fo:continue
  h=y-x
  if h%2:rank=abs(y-(a-1 if h<a-1 else 2*a-1))+int((x==0 and h==a+1)or(x==a and h==a-3))
  else:rank=x-1+int(x==a) if h==a-2 else a-1-x+int(x==0)
  if rank!=ra[key((x,y))]:bad.append(((x,y),rank,ra[key((x,y))]))
 print(K,bad[:10],len(bad))
