from pathlib import Path
myfile=__file__; __file__=str(Path(__file__).resolve().parent.parent/'complete_partition.py')
exec(Path(__file__).read_text().split('\nbase=z.And')[0]); __file__=myfile
P=Path(__file__).resolve().parent
import sympy as sy
at,xt,yt=sy.symbols('a x y',integer=True)
conv=lambda v:eval(str(sy.expand(v)),{'a':A,'x':x,'y':y})
Ts=2*at*at+4*at-2;cs=-(Ts+2*at)/2
aliases=[(i,j) for i in [-2,-1,0,1,2] for j in [-1,0,1]]

def altguard(X,Y):
 R=Y+1
 return z.Or(z.And(X>=-2,X<=A+1,R>=1,R<=3*A-2,R-X>=-1,R-X<=2*A+1,z.Not(z.Or(z.And(X<=-1,R<=A-1),z.And(X>=A,R>=2*A)))),z.And(X==-2,R==2*A),z.And(X==A+1,R==A-1))
def altcorr(X,Y):
 R=Y+1
 return mn(A-R)+mx(R-X-A)+mn(2*A-1-R)+z.If(z.Or(z.And(R-X==A,X>0,X<A-1),z.And(X==-2,R==2*A),z.And(X==A+1,R==A-1)),1,0)
def offers(q):
 tx=xt-q*at;ty=yt+q*(2-at);out=[]
 for i,j in aliases:
  rx=tx+i*(at+1)-2*j;ry=ty+i*(at-1)+2*at*j
  pol=-(ry-rx+1)**2+(yt-xt+1)**2-4*j*((at-1)*tx-(at+1)*ty+cs)+2*Ts*j*(j-1)
  D=conv(pol)+4*corr(conv(rx),conv(ry))-4*altcorr(x,y)
  out.append((native(conv(rx),conv(ry)),D))
 return out
f=offers(0);g=offers(1)
licensed=z.Or(*[z.And(a,b,d>=0,d<=4,e>=-4,e<=0,d+e>=-4,d+e<=0)for a,d in f for b,e in g])
checks={'native_midpoint_and_width':z.And(A>=4,A%2==0,altguard(x,y),z.Not(licensed)),
# Positive native alternate cover of every standard native root.
'positive_standard_to_alternate_cover':z.And(A>=4,A%2==0,native(x,y),z.Not(z.Or(*[altguard(*shift(x,y,i,j))for i,j in aliases])))}
rows=[]
for name,F in checks.items():
 s=z.Solver();s.set(timeout=120000);s.add(F);raw=s.to_smt2();p=P/(name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
 if ans=='sat':print(s.model(),flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:150',str(p)],capture_output=True,text=True,timeout=160).stdout.strip()
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
