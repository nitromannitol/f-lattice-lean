from pathlib import Path
exec(Path(__file__).with_name('prove.py').read_text().split('f=offers(0)')[0])
P=Path(__file__).resolve().parent
def inputoffers(dx,dy):
 tx=xt+dx;ty=yt+dy;out=[]
 for i,j in aliases:
  rx=tx+i*(at+1)-2*j;ry=ty+i*(at-1)+2*at*j
  pol=-(ry-rx+1)**2+(yt-xt+1)**2-4*j*((at-1)*tx-(at+1)*ty+cs-1)+2*Ts*j*(j-1)
  val=conv(pol)+(y-x+dx+dy+1)%2-(y-x+1)%2+4*altcorr(conv(rx),conv(ry))-4*altcorr(x,y)
  out.append((altguard(conv(rx),conv(ry)),val))
 return out
rows=[]
for ph,off in [(0,(1,0)),(1,(0,1))]:
 f=inputoffers(*off);g=inputoffers(*[-v for v in off]);good=z.Or(*[z.And(a,b,z.Or(d+e==0,d+e==-4))for a,d in f for b,e in g])
 s=z.Solver();s.set(timeout=120000);s.add(A>=4,A%2==0,altguard(x,y),(x+y)%2==ph,z.Not(good));raw=s.to_smt2();name='global_binary_phase'+str(ph);p=P/(name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
 if ans=='sat':print(s.model(),flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:150',str(p)],capture_output=True,text=True,timeout=160).stdout.strip();rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'BINARY_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
