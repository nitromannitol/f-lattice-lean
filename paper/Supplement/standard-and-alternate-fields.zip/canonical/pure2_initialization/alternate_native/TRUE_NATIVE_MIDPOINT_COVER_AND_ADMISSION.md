# Genuine pure2 even alternate: exact native midpoint, global cover and binary extension

For every K>=1 put a=2K+2. Let F be the authentic standard doubled ladder at (a-1)/(a+1), U=(a+1,a-1), V=(-2,2a), T=2a²+4a-2, alpha=(a-1,-a-1), cV=-(T+2a)/2, and sigma=(-a,2-a)=-2(K+1,K).

Let H be the literal even alternate produced by get_doubled_ladder_even_alt, in its actual exported LL frame. Then on its ENTIRE true native domain,

 H(z)=min(F(z),F(z+sigma)+1)=ceil((F(z)+F(z+sigma))/2),
 0<=F(z)-F(z+sigma)<=2.

Its native domain covers every global deck class. Consequently its genuine coherent global extension is exactly

 J(z)=ceil((F(z)+F(z+sigma))/2),

with primary character0 and secondary jet alpha.z+cV-1. This J is binary on the entire physical lattice. Global recurrence is a distinct remaining conclusion, not inferred from the midpoint identity or binary admission alone.

## Authentic source and frame

Original final_code/base_case.jl, get_doubled_ladder_even_alt, uses raw X=x,Y=y+1. Native support is

 -2<=x<=a+1, 1<=Y<=3a-2, -1<=Y-x<=2a+1,

excluding x<=-1,Y<=a-1 and x>=a,Y>=2a, with actual extra corners (-2,2a),(a+1,a-1) in raw coordinates. Value is

 -floor((x-Y)^2/4)+min(0,a-Y)+max(0,Y-x-a)+min(0,2a-1-Y)+c,

where c=1 on Y-x=a,0<x<a-1 and on the two extra corners, else0. The lower-left is raw(0,1), with value0. Thus the displayed global formula has NO further translation or additive gauge. In the actual translate_alts test for this creator, O=(1,1)-Vp=(2,-2K) has negative imaginary coordinate; restoration is inactive for K>=1. No alternate of a different creator or consumed frame is substituted.

## Native identification and positive coverage

prove.py directly transcribes that domain and height. At each genuine H root it licenses native standard representatives of BOTH z and z+sigma, with true standard deck terms. It proves the stronger exact price constraints

 0<=F-H<=1,  -1<=F(.+sigma)-H<=0,
 -1<=(F-H)+(F(.+sigma)-H)<=0.

Since the heights are integers, these are precisely the three allowed price pairs (0,0),(0,-1),(1,-1), proving the minimum, rounded mean and width statements together.

The positive alias window is i=-2,...,2, j=-1,0,1. This is not an assumed complete inverse window: every successful offer carries its actual native guard. The narrower i=-1,...,1 window is insufficient (for example a12,z=(-2,11)); expanding the witness search removes the coverage failure. No mathematical counterexample was hidden by this expansion.

A separate universal gate proves every true STANDARD native root has a genuine H-domain deck translate in this positive window. Combined with actual standard native quotient coverage, this proves physical global H cover without any unsupported alternate domain assumption.

Both universal gates are producer/fresh UNSAT in RECEIPT.json.

## Global coherence and characters

F has zero U character, so J does too. alpha.sigma=-2. Hence F(z+V) and F(z+sigma+V) have secondary constant terms differing by exactly -2. Their mean increments by the integer alpha.z+cV-1; rounding therefore commutes exactly with this deck increment. J has the advertised alternate characters.

The native equality and global standard F make every overlapping native H deck offer agree automatically. Thus coherence is established by an explicit global function, not by assuming alternate admission. The min formula is asserted ONLY natively. Its global unrounded extension need not have the alternate deck character once the raw difference leaves [0,2]. The global statement is the rounded mean.

## Independent global binary admission

binary.py checks both physical root parities over the ENTIRE true H native domain, including its incoming halo. Each input value is obtained from a positively guarded true native H alias with the just-proved alternate character cV-1. The original quadratic floors cancel exactly, keeping the odd-input parity remainder. Each root's exact input Laplacian is proved to be -1 or0, with fresh CLI replay in BINARY_RECEIPT.json.

Global native cover and the affine deck jet propagate these local star statements to all physical roots. This does not invoke a generic assertion that rounding a mean preserves binary admission, which would need an additional parity-saddle argument.

## Remaining recurrence issue

This packet authenticates support, normalization, characters, coherence, midpoint and binary admission. To conclude recurrence, use a separate genuine no-fort argument or a previously proved band/strict-rank theorem with all its raw comparison and policy hypotheses discharged. Neither recurrence of F and its translate nor the newly proved binary midpoint alone is used as a recurrence theorem here. The root K=0 is separate.
