from globalrank import *
import subprocess,hashlib,json
checks={}
f=z.Or(*HV(x,y))
checks['free_arc_alias_unique']=z.And(f,z.Or(*[z.Or(*HV(u,v))for u,v in addresses(x,y)[1:]]))
checks['free_arcs_native_fold']=z.And(f,z.Not(z.Or(*[native(u,v) for u,v in addresses(x,y)])))
# Check correction bounds directly for both classes, independently of native selection order.
for eta in (-1,1):
 H,V=HV(x,y);hr,vr=freer(x,y,eta)
 checks['free_rank_bound'+str(eta)]=z.Or(z.And(H,z.Or(hr<0,hr>2*A+2)),z.And(V,z.Or(vr<0,vr>2*A+2)))
rows=[]
for name,bad in checks.items():
 s=solver(bad);raw=s.to_smt2();fn=P/(name+'.smt2');fn.write_text(raw)
 ans=str(s.check());fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(fn)],capture_output=True,text=True,timeout=60).stdout.strip()
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()));assert ans==fresh=='unsat',rows[-1]
 print(rows[-1])
(P/'GLOBAL_RANK_ALIAS_AUDIT.json').write_text(json.dumps(rows,indent=2)+'\n')
