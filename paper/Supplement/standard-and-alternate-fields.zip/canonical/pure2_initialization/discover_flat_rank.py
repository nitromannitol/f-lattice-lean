import io,contextlib
from physical_unit_probe import run
from collections import deque
for K in [1,2,3]:
 with contextlib.redirect_stdout(io.StringIO()):tile,F,forced,_,key=run(K)
 a=2*K+2;reps={key(z):z for z in tile}
 H=[(1,0)]+[(i,i-2)for i in range(2,a+1)]+[(a+1,a-2)];V=[(0,i)for i in range(a)]+[(-1,i)for i in range(a,2*a)]
 for eta in[-1,1]:
  dirs=dict(forced)
  for j,v in enumerate(H):dirs[key(v)]=(0,-eta)if j==0 else ((1,0)if sum(v)%2==0 else(0,1))
  for j,v in enumerate(V):dirs[key(v)]=(1,0)if j==0 else ((eta,0)if sum(v)%2==0 else(0,-eta))
  shift=(0,a)if eta==1 else(-2,a-2)
  def phi(z):x,y=z;return F(z)-F((x+shift[0],y+shift[1]))+K*x-(K+1)*y
  edges={k:[]for k in reps};rev={k:[]for k in reps};raw=[]
  for k,v in reps.items():
   if sum(F(u)for u in ([(v[0]-1,v[1]),(v[0]+1,v[1])]if sum(v)%2==0 else [(v[0],v[1]-1),(v[0],v[1]+1)]))-2*F(v)==0:
    e=dirs[k];ins=[(v[0]+e[0],v[1]+e[1])]
   else:ins=[(v[0]-1,v[1]),(v[0]+1,v[1])]if sum(v)%2==0 else[(v[0],v[1]-1),(v[0],v[1]+1)]
   for u in ins:
    if phi(u)==phi(v):edges[k].append(key(u));rev[key(u)].append(k);raw.append((v,u))
  deg={k:len(v)for k,v in edges.items()};q=deque(k for k in reps if deg[k]==0);rank={k:0 for k in q}
  while q:
   k=q.popleft()
   for j in rev[k]:
    rank[j]=max(rank.get(j,0),rank[k]+1);deg[j]-=1
    if deg[j]==0:q.append(j)
  print('K eta',K,eta,'acyclic',len(rank)==len(reps),'max',max(rank.values()),'H',[(v,rank.get(key(v)))for v in H],'V',[(v,rank.get(key(v)))for v in V])
