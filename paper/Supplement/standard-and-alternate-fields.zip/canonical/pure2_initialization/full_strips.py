from pathlib import Path
exec(Path(__file__).with_name('uniform_bulk.py').read_text().split('base=z.And')[0])
import sympy as sy
at,xt,yt=sy.symbols('a x y',integer=True)
conv=lambda v:eval(str(sy.expand(v)),{'a':A,'x':x,'y':y})
T=2*A*A+4*A-2;Ts=2*at*at+4*at-2;cs=-(Ts+2*at)/2
j=z.Int('j');i=z.Int('i')
t=(A-1)*x-(A+1)*y;s=2*A*x+2*y
base=z.And(A>=4,A%2==0,native(x,y))
checks={
 'zero_alias_j_bound':z.And(base,t-T*j>=-A,t-T*j<=3*A,z.Not(z.Or(j==0,j==-1))),
 'harmonic_alias_i_bound':z.And(base,s+T*i>=-2*A-1,s+T*i<=4*A-1,z.Not(z.Or(i==0,i==-1))),
 'zero_band_j0':z.And(base,t>=-A,t<=3*A,z.Or(y-x<-3,y-x>1)),
 'zero_band_jminus1':z.And(base,t+T>=-A,t+T<=3*A,z.Or(y-x<2*A-3,y-x>2*A+1)),
 'harmonic_x_i0':z.And(base,s>=-2*A-1,s<=4*A-1,z.Or(x<-1,x>1)),
 'harmonic_x_iminus1':z.And(base,s-T>=-2*A-1,s-T<=4*A-1,z.Or(x<A-1,x>A+1)),
}
for jj in [0,-1]:
 for r in range(-3,2):
  hh=sy.Integer(r) if jj==0 else 2*at+r
  YY=xt+hh
  poly=-(hh+1)**2+4*jj*((at-1)*xt-(at+1)*YY+cs)-2*Ts*jj*(jj-1)
  value=conv(poly)+conv(hh+1)%2+4*corr(x,conv(YY))
  tt=(A-1)*x-(A+1)*conv(YY)-T*jj
  checks[f'zero_j{jj}_r{r}']=z.And(A>=4,A%2==0,native(x,conv(YY)),tt>=-A,tt<=3*A,value!=0)
for ii in [0,-1]:
 for r in [-1,0,1]:
  XX=sy.Integer(r) if ii==0 else at+r
  xp=XX+ii*(at+1);yp=yt+ii*(at-1)
  # 4(F(native)-h0(native+iU)); parity remainders cancel because U has even sum.
  poly=-(yt-XX+1)**2-2*xp*(xp-1)+(yp+1-xp)**2
  value=conv(poly)+4*corr(conv(XX),y)
  ss=2*A*conv(XX)+2*y+T*ii
  checks[f'harmonic_i{ii}_r{r}']=z.And(A>=4,A%2==0,native(conv(XX),y),ss>=-2*A-1,ss<=4*A-1,value!=0)
rows=[]
for name,f in checks.items():
 sl=z.Solver();sl.set(timeout=120000);sl.add(f);raw=sl.to_smt2();p=P/('strip_'+name+'.smt2');p.write_text(raw);ans=str(sl.check());print(name,ans,flush=True)
 if ans=='sat':print(sl.model(),flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:130',str(p)],capture_output=True,text=True,timeout=140).stdout.strip()
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'FULL_STRIPS_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
