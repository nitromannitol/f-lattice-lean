"""All-parameter raw pure2 edge proof. Native finite lift cover certified by unbounded QF_LIA."""
import sys,itertools,json,hashlib,time,functools
from pathlib import Path
sys.path.insert(0,'/tmp/f_lattice_z3');import z3 as z
P=Path(__file__).resolve().parent;out=P/'rawchecks';out.mkdir(exist_ok=True)
exec((P/'uniform_bulk.py').read_text().split('G,dx,dy,r=')[0].split('P=Path(__file__).resolve().parent')[1])
# code above defines A,x,y,native,corr,candidate. A is even; use K variable to avoid half coeffs.
K=z.Int('K');n=A-1;d=A+1;base=z.And(K>=1,A==2*K+2,x>=-1,x<=A+1,y>=0,y<=3*A-2)
def simp(p):return z.simplify(p,arith_lhs=True)
def solver(p,ms=30000):
 s=z.Solver();s.set(timeout=ms);s.add(base,p);return s
gcache={};receipts=[]
def verify(name,bad,timeout=60000,save=True):
 s=solver(bad,timeout);raw=s.to_smt2();ans=str(s.check());print(name,ans,flush=True)
 if save:
  (out/(name+'.smt2')).write_text(raw)
  receipts.append({'name':name,'status':ans,'sha':hashlib.sha256(raw.encode()).hexdigest()});(out/'RECEIPTS.json').write_text(json.dumps(receipts,indent=2))
 if ans!='unsat':
  if ans=='sat':print(s.model(),flush=True)
  raise ValueError(name,ans)
def grad(cx,cy,dx,dy):
 # Returns TWO times G_e(z+c), where e in two real directed slots; caller enforces parity.
 key=(str(cx),str(cy),dx,dy)
 if key in gcache:return gcache[key]
 X=x+cx;Y=y+cy;C=[];par=((x+y)%2==0) if dx else ((x+y)%2==1)
 # c may have odd coordinate sum for intermediate diagonal step:
 par=(X+Y)%2==(0 if dx else 1)
 for i,l in sorted(itertools.product(range(-3,4),repeat=2),key=lambda t:abs(t[0])+abs(t[1])):
  u=X-i*d+2*l;v=Y-i*n-2*A*l
  guard=simp(z.And(native(u,v),native(u+dx,v+dy)));rg=simp(z.Or(guard,z.And(u==0,v==A,dx==-1),z.And(u==A,v==2*A-2,dx==1)))
  if str(solver(z.And(par,rg),5000).check())=='unsat':continue
  h=v+1-u;delta=dy-dx
  g=-h*delta-(h%2)+2*(corr(u+dx,v+dy)-corr(u,v))
  g=z.If(guard,g,(-A if dx==-1 else A-2))+2*l*(n*dx-d*dy)
  C.append((rg,simp(g)))
 assert C;cover=z.Or(*[b for b,g in C]);nm='cover_'+str(len(gcache));verify(nm,z.And(par,z.Not(cover)),save=True)
 val=0
 for b,g in reversed(C):val=z.If(b,g,val)
 val=simp(val);gcache[key]=val;return val
def free(x,y,eta,dx,dy):
 H0=z.And(x==1,y==0);H=z.Or(z.And(x>=2,x<=A,y==x-2),z.And(x==A+1,y==A-2))
 V0=z.And(x==0,y==0);V=z.Or(z.And(x==0,y>=1,y<A),z.And(x==-1,y>=A,y<2*A))
 return z.Or(z.And(H0,dx==0,dy==-eta),z.And(H,dx+dy==1),z.And(V0,dx==1),z.And(V,(dx,dy)==(eta,0)or(dx,dy)==(0,-eta)))
def main(mode):
 for ee in ['h','v']:
  # Displacements for a price are chosen in the congruent short-primary frame. sigma=-U+(1,1).
  axes=[(-1,0),(1,0)] if ee=='h' else [(0,-1),(0,1)]
  parity=(x+y)%2==(0 if ee=='h' else 1)
  weights={};normal=[grad(0,0,*e)for e in axes];black=(sum(normal)==-2)
  bnd=native(x,y);cd,cx,cy,rr=candidate(x,y)
  for nm,sx,sy,lin,eta in [('P',-1,A-1,1,0),('D+',1,1,0,1),('D-',-1,-1,0,-1),('Phi+',0,A,1,1),('Phi-',-2,A-2,1,-1)]:
   val=[simp(gg-grad(sx,sy,*e)+2*lin*(K*e[0]-(K+1)*e[1])) for gg,e in zip(normal,axes)];weights[nm]=val
   if mode in ('mon','all'):
    if nm in ['P','D+','D-']:
     verify('unit_'+ee+nm,z.And(parity,bnd,z.Or(*[z.Or(v>2,v< -2)for v in val])))
    if nm=='P':verify('noX_'+ee,z.And(parity,bnd,z.Or(z.And(val[0]<0,val[1]>0),z.And(val[1]<0,val[0]>0))))
    for h,e in enumerate(axes):
     g=val[h];bad=lambda allow:z.And(parity,allow,g>0)
     verify('black_'+ee+str(h)+nm,bad(z.And(bnd,black)))
     verify('forced_'+ee+str(h)+nm,bad(z.And(bnd,cd,cx==e[0],cy==e[1])))
     for sign in ([1,-1] if not eta else [eta]):verify('free_'+ee+str(h)+nm+str(sign),bad(free(x,y,sign,*e)))
  if mode in ('band','all'):
   for nm in ('Phi+','Phi-'):
    for h in range(-2,3):
     # shifted minimum of F and F-Phi+constant ; h=threshold−Phi(z)
     delta=sum(normal)+sum(z.If(2*h-v<0,2*h-v,0)for v in weights[nm])-2*min(2*h,0)
     verify('band_'+ee+nm+str(h),z.And(parity,bnd,delta!=0,delta!=-2))
   # D+ value F(z)-F(z+sigma) = difference to (1,1) exactly, U character zero.
   ix,iy=axes[1];u,v=(1-ix,1-iy);dplus=-(normal[1]+grad(ix,iy,u,v))/2
   for eta in (1,-1):
    nm='D+' if eta==1 else 'D-';dd=dplus if eta==1 else -(normal[0]+grad(-ix,-iy,-u,-v))/2
    e0,e1=weights[nm];verify('even_noX_'+ee+nm,z.And(parity,bnd,dd%2==0,z.Or(z.And(e0<0,e1>0),z.And(e1<0,e0>0))))
if __name__=='__main__':main(sys.argv[1]if len(sys.argv)>1 else'all')
