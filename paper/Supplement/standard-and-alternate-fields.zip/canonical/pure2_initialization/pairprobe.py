import sys,itertools;sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests');from original_parent_bad_ports import *
for k in range(1,9):
 s='2'*k;r=getFracs(s)[1];F=review.Field(r.numerator,r.denominator,alg.export_tile(alg.get_base_quadruple(s)[0][1]));D=set(F.tile);covered=set()
 for x in D:
  for u in incoming(x,F.phase):
   if u in D:covered.add((F.cls(x),u[0]-x[0],u[1]-x[1]))
 un=[(z,(v[0]-z[0],v[1]-z[1]))for k1,z in F.reps.items()for v in incoming(z,F.phase) if (k1,v[0]-z[0],v[1]-z[1])not in covered]
 print(k,len(un),un[:10])
