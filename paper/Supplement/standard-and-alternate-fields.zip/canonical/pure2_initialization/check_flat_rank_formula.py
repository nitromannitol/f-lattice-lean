import io,contextlib
from physical_unit_probe import run
from collections import deque
for K in range(1,11):
 with contextlib.redirect_stdout(io.StringIO()):tile,F,forced,_,key=run(K)
 a=2*K+2;reps={key(z):z for z in tile}
 H=[(1,0)]+[(i,i-2)for i in range(2,a+1)]+[(a+1,a-2)];V=[(0,i)for i in range(a)]+[(-1,i)for i in range(a,2*a)]
 for eta in[-1,1]:
  dirs=dict(forced)
  for j,v in enumerate(H):dirs[key(v)]=(0,-eta)if j==0 else ((1,0)if sum(v)%2==0 else(0,1))
  for j,v in enumerate(V):dirs[key(v)]=(1,0)if j==0 else ((eta,0)if sum(v)%2==0 else(0,-eta))
  shift=(0,a)if eta==1 else(-2,a-2)
  def phi(z):x,y=z;return F(z)-F((x+shift[0],y+shift[1]))+K*x-(K+1)*y
  edges={k:[]for k in reps};rev={k:[]for k in reps};raw=[]
  for k,v in reps.items():
   if sum(F(u)for u in ([(v[0]-1,v[1]),(v[0]+1,v[1])]if sum(v)%2==0 else [(v[0],v[1]-1),(v[0],v[1]+1)]))-2*F(v)==0:
    e=dirs[k];ins=[(v[0]+e[0],v[1]+e[1])]
   else:ins=[(v[0]-1,v[1]),(v[0]+1,v[1])]if sum(v)%2==0 else[(v[0],v[1]-1),(v[0],v[1]+1)]
   for u in ins:
    if phi(u)==phi(v):edges[k].append(key(u));rev[key(u)].append(k);raw.append((v,u))
  deg={k:len(v)for k,v in edges.items()};q=deque(k for k in reps if deg[k]==0);rank={k:0 for k in q}
  while q:
   k=q.popleft()
   for j in rev[k]:
    rank[j]=max(rank.get(j,0),rank[k]+1);deg[j]-=1
    if deg[j]==0:q.append(j)
  fr={}
  for j,v in enumerate(H):
   X=v[0]
   rr=(2*a+1 if j==0 else 1 if j==a else 2*(a+1-X))if eta==1 else(4 if j==0 else 1 if j==1 else 6 if j==a else 2*a+7-2*X)
   fr[key(v)]=rr
  for j,v in enumerate(V):
   q0=j-a
   rr=(2*j-j%2 if j<a else 2*q0+1+q0%2)if eta==1 else(5 if j==0 else 2*a+3-2*j-j%2 if j<a else 2 if j==a else 1 if j==a+1 else 2*a+4-2*q0+q0%2)
   fr[key(v)]=rr
  def cand(v):
   if key(v)in fr:return fr[key(v)]
   x,y=v;h=y-x;odd=(x+y)%2
   if h==-1:
    return (2*a-3 if x==a else 2*a+1-2*y)if eta==1 else(2 if x==2 else 2*a+6-2*y)
   if h==a-1:return (2*x+3)if eta==1 else(2*a if x==1 else 2*x+4)
   center=a-1 if h<=a-2 else 2*a-1
   off=2*a-2 if h<=a-2 else 2*a
   rr=off-2*abs(y-center)-odd
   if eta==-1:rr=(1-odd)if y==center+1 else rr+(1 if y<center+1 else 5)
   return rr
  bad=[(reps[k],reps[j],cand(reps[k]),cand(reps[j]))for k in edges for j in edges[k]if cand(reps[j])>=cand(reps[k])]
  mismatch=[(v,cand(v),rank[key(v)])for v in reps.values()if cand(v)!=rank[key(v)]]
  assert not bad and not mismatch
  print(K,eta,'bad',bad[:3],'mismatch',mismatch[:3],flush=True)
