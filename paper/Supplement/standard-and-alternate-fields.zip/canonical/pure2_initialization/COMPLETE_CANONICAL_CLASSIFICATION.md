# Complete pure2 canonical unit-clause classification

## Result

For every K>=1, a=2K+2, the four forced classes and directions in UNIFORM_DOUBLED_LADDER_BULK_DIRECTIONS.md are the entire genuine unit-propagation forced set, modulo the actual deck. Every other white class has exactly one representative in H union V below. Black vertices retain both inputs. All four prescribed free phase completions satisfy every physical unit-square clause. Thus none of these free slots is forced by the clauses.

This closes classification and local canonical consistency, not a separate proof of canonical strict rank, private-square return paths, or all-edge P/D/Phi monotonicity.

## 1. Exact free representatives and their genuine colors

    H = {(1,0)} union {(x,x-2):2<=x<=a} union {(a+1,a-2)},
    V = {(0,y):0<=y<=a-1} union {(-1,y):a<=y<=2a-1}.

These are the literal mechanical H/V arcs: edges(1,a-1) is 0, then a-2 ones, then 0; edges(a-1,2) has its single 1 in position a and zeros elsewhere. No fitted arc is used.

arc_star_heights.py independently pays full physical incoming stars, not just arc roots. At every H root and its actual two inputs, F=0. At every V root and its actual two inputs, F=h0. It uses the authentic native primitive formula, actual zero-primary U=(a+1,a-1), Vdeck=(-2,2a), true cV=-(T+2a)/2, T=2a²+4a-2. Every height assertion has an explicit positive native alias from {-1,0,1}². No negative assertion depends on completeness of this alias window. All 25 generated gates (including inactive phase cases) have producer and fresh CLI UNSAT, bound in ARC_STAR_RECEIPT.json.

The polynomial algebra cancels the common quadratic floor before solving; parity remainders are retained exactly. Each active input is selected by the physical root parity. Consequently all H/V sites are genuinely white, including endpoints with off-native inputs. No conjectural strip or current canonical recurrence is used to prove this.

## 2. Exhaustive partition

complete_partition.py proves for every true native root:

 * if its full star is native and white, it is either in a forced class or an actual H/V deck translate;
 * if its star is not native, it is either in a forced class or an actual H/V deck translate;
 * forced classes and H/V translates are disjoint.

The authentic pure-base global binary admission supplies the only other color: a remaining root with its full star native is black. The two forced off-native stars were already paid analytically. Thus no native boundary case is omitted. Authentic native quotient coverage extends the classification to the entire lattice.

The free representatives are pairwise distinct modulo deck. free_uniqueness.py first proves any two such representatives with arbitrary integral deck indices must have |i|,|j|<=2; then a finite exact LIA disjunction excludes all nonzero indices in that window. Both gates pass fresh. This also licenses a single-valued periodic free assignment.

## 3. Actual phase completions

Define Q_b for b in {-1,+1} by the genuine forced directions and this free table:

 H0=(1,0): S;
 Hlast=(a+1,a-2): vertical direction -b;
 other H: W at even roots, S at odd roots.

 V0=(0,0): horizontal direction b;
 Vlast=(-1,2a-1): W;
 other V: horizontal b at even roots, vertical -b at odd roots.

These are exactly the explicit free directions used by the canonical policy construction, stated as physical displacements rather than inferred sign names. The other two completions are their central reflections about R=(a,3a-2): at z take minus the Q_b direction at R-z. Forced directions are unchanged by this reflection because genuine unit propagation and its clauses are reflection covariant.

For each Q_b, the universal all_squares_policy_b query checks every physical unit square with a native representative of its bottom-left corner. At least one corner has a positively certified forced or free white offer whose selected direction leaves the square. Each offer carries its true native/arc guard. The genuine deck cover then transports this to EVERY physical square. Reflection gives the other two policies. No square is reduced vertexwise to a fictitious quotient square; the four corners are retained together in physical coordinates throughout the check.

All supplied direction offers agree: forced offers are genuine forced literals, free offers have unique representatives, and the classes are disjoint. Thus existential positive offers are a valid verification of the single global policy, not a choice that changes from square to square.

## 4. Why there are no further forced slots

Every free slot receives both of its possible directions among the four verified policies. For an interior V slot this follows already by changing b; likewise V0 and Hlast. Interior H slots reverse under reflection, since R-H is the reversed H arc plus Vdeck. For H0 the reflected representative is Hlast+Vdeck and both vertical choices occur. Vlast reflects to V0+U, so both horizontal choices occur.

Any literal inferred by elementary-square unit propagation is valid in every satisfying completion. Since each free slot has satisfying completions with opposite values, no such slot can ever be inferred. Together with the explicit finite grade induction that forces every displayed bulk slot, this proves exact closure, with no assumption of completeness of an experimental propagation run.

## Evidence and limitations

PARTITION_RECEIPT.json: six universal gates, all producer/fresh UNSAT.
ARC_STAR_RECEIPT.json: 25 authentic star-height gates, all producer/fresh UNSAT.
FREE_UNIQUENESS_RECEIPT.json: two universal uniqueness gates, all producer/fresh UNSAT.
BULK_RECEIPT.json: preceding four forcing gates, all producer/fresh UNSAT.

Input dependencies are the literal pure2 native formula, its accepted coherent global deck extension/binary admission/native cover, and true standard reflection. No nonbase gluing or alternate recurrence is used. K=0 remains the separate reciprocal root. This is a complete *unit-clause classification*; global dynamical and raw-price obligations remain distinct.
