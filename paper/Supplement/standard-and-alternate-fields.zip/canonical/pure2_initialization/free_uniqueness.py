from pathlib import Path
exec(Path(__file__).with_name('complete_partition.py').read_text().split('\nbase=z.And')[0])
i,j=z.Ints('i j')
# Arbitrary deck integers: NIA inverse-bounds first, then finite LIA disjunction.
xx,yy=shift(x,y,i,j)
checks={'inverse_free_alias_bound':z.And(A>=4,A%2==0,free(x,y),free(xx,yy),z.Or(i<-2,i>2,j<-2,j>2))}
checks['no_nontrivial_free_alias']=z.And(A>=4,A%2==0,free(x,y),z.Or(*[free(*shift(x,y,i,j))for i in range(-2,3)for j in range(-2,3)if(i,j)!=(0,0)]))
rows=[]
for name,f in checks.items():
 s=z.Solver();s.set(timeout=60000);s.add(f);raw=s.to_smt2();p=P/(name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
 fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:65',str(p)],capture_output=True,text=True,timeout=70).stdout.strip()
 rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
 (P/'FREE_UNIQUENESS_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
