# Pure2 dynamic seed: scope audit and exact rotation reduction

This audit concerns physical ranks, W1/private squares and clean bands, not the separate raw-price calculation.

## 1. Why the proper nonbase constructor theorem is not already the seed

For word2^K the even field has n=2K+1,d=2K+3, with consumed p=K/(K+1), q=1/1. Thus q is not proper, dq-nq=0, and current d-n=2. Several nonbase source/geometry proofs explicitly require proper q and d-n>=4. In particular the whole-V-star h0-strip proof uses d-n>=3; the donor cover uses dq-nq>=2. The W1_CONSTRUCTOR header assumes a proper even parent. Substituting q=1/1 without rechecking those proofs is not legitimate.

The all-slope physical escape theorem can still be reused as a CONDITIONAL mechanism after its true incoming M recurrence, strips, profiles, forced local atoms and core exceptions are independently supplied for this base. It does not itself supply those base inputs. Likewise canonical rank existence alone does not prove the claimed finite W1 unit witnesses or private three-step squares.

PURE_CLOSURE_AND_SCOPE.md explicitly assumes the pure2 raw profiles and policy monotonicity; it proves a two-scalar interface deduction, not the missing full dynamic seed. The historical pure2 ALT2/3 and ALT3/5 rotated-base notes explicitly concern one root. They must not be promoted to all K.

## 2. Exact dynamics transfer under an authentic whole-field rotation

Suppose two genuine global fields obey F(z)=G(Jz+b)+h0(z)+ell(z)+c, with J a quarter turn and the actual b making the map parity reversing, and ell integer affine. The F-lattice Laplacian of h0 is ZERO at both parities: its quadratic second difference is cancelled by its checkerboard correction. Affine terms also have zero Laplacian. The parity-reversing quarter turn sends each actual incoming star bijectively onto the other field's incoming star. Hence colors and fort quotas are preserved EXACTLY.

Consequences:
 * any physical strict rank R_G transports to R_F(z)=R_G(Jz+b), with the policy pulled back edge by edge;
 * every finite unit-square clause and every finite unit derivation transports, including its actual rejected-input square and step count;
 * every private return square transports as a physical square, not as a quotient walk;
 * any genuine recurrent field transports by the finite-fort criterion;
 * clean-band burning transports if the actual band chart, threshold, lattice and boundary condition are transported too.

These statements do not require native-domain identification once the WHOLE global identity is established. Conversely, a finite domain bijection alone does not prove a global identity without compatible true deck jets. Matching canonical sign LABELS must be checked through actual arrows: under Z(x,y)=(-y,x-1), east becomes north, north becomes west, west becomes south, south becomes east. A sign label is not invariant under this transformation.

## 3. Smallest reciprocal dynamic input needed

The authentic explicit base pairings are:

 pure2 odd staircase <-> pure3 even staircase;
 pure2 even doubled ladder <-> pure3 odd doubled ladder.

Thus a full uniform pure2 dynamic initialization can be transferred from the corresponding TWO reciprocal standard families, provided their actual global rotations and canonical policy matches are authenticated. The second line is important: recurrence/ranks for the even reciprocal staircase alone do NOT initialize the near-one even doubled ladder. Its partner is the odd reciprocal doubled ladder. Alternate pairings similarly require their own full global identities and gates; the one-root historical alternate certificates do not replace them.

The literal formulas in original_port_base.py are available and parameter-uniform, including the +1 corrections on the doubled ladder's internal line and its two exceptional corners. Those corrections cannot be dropped when constructing a policy or transporting a private square. The explicit base-domain/deck conjugacy in the pinned source is an algebraic input to audit, not a substitute for the reciprocal dynamic proof.

## 4. Precise current status

No independent all-K canonical rank/W1/private-square construction for the pure2 even doubled ladder has been established in this pass. I found conditional nonbase machinery, explicit base formulas/rotations and some one-root recurrence certificates, but did not locate a complete independently audited uniform dynamic package that pays the second reciprocal family and its canonical arrows. This is a search/audit conclusion, not a claim that no such proof exists elsewhere.

The transferable reduction in section2 is rigorous. The shortest remaining dynamic task is therefore one of:
 (a) give uniform explicit canonical ranks plus finite unit/private-square witnesses for the reciprocal odd doubled ladder, then transport them with the true global base rotation;
 (b) supply the missing pure2 base inputs to the already-proved physical escape theorem, and separately prove its W1/private squares.

A finite parameter census, an abstract recurrence certificate without canonical signs, or the raw price computation alone does not close this task. No all-word completion claim follows from this audit.
