import sys,io,contextlib,json
from pathlib import Path
D=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/pure2_initialization');sys.path.insert(0,str(D));from physical_unit_probe import run
out=[]
for K in range(1,9):
 with contextlib.redirect_stdout(io.StringIO()):tile,F,forced,_,key=run(K)
 a=2*K+2
 def R(z):
  x,y=z;h=y-x
  return 2 if h==a-1 else -2*abs(y- (a-1 if h<=a-2 else 2*a-1))+int((x+y)%2==0)
 def inp(z):x,y=z;return[(x-1,y),(x+1,y)]if(x+y)%2==0 else[(x,y-1),(x,y+1)]
 reps={key(z):z for z in tile};free={k for k,z in reps.items()if sum(F(u)for u in inp(z))-2*F(z)==0 and k not in forced};bad=[];cnt=0;fold=[]
 for k,z in reps.items():
  if k in free:continue
  ins=[(z[0]+forced[k][0],z[1]+forced[k][1])]if k in forced else inp(z)
  for u in ins:
   if key(u)in free:continue
   v=u if u in tile else reps[key(u)]
   if v!=u:fold.append((z,u,v))
   cnt+=1
   if R(v)>=R(z):bad.append((z,u,v,R(z),R(v)))
 out.append(dict(K=K,edges=cnt,bad=bad,fold=fold));print(K,cnt,bad[:3],fold[:3])
(D/'HELD_FREE_BULK_RANK_REGRESSION.json').write_text(json.dumps(out,indent=2))
