import ctypes as c,ctypes.util as u
lib=c.CDLL(u.find_library('isl'))
P=c.c_void_p;S=c.c_char_p;I=c.c_int
def f(name,args,ret=P):
 F=getattr(lib,'isl_'+name);F.argtypes=args;F.restype=ret;return F
ctx=f('ctx_alloc',[])()
read=f('set_read_from_str',[P,S]);fr=f('set_free',[P]);cp=f('set_copy',[P]);meet=f('set_intersect',[P,P]);minus=f('set_subtract',[P,P]);either=f('set_union',[P,P]);empty=f('set_is_empty',[P],I)
class Set:
 def __init__(self,val):
  self.ptr=read(ctx,val.encode()) if isinstance(val,str) else val
  if not self.ptr:raise Exception(val)
 def __del__(self):fr(self.ptr)
 def copy(self):return cp(self.ptr)
 def __and__(self,x):return Set(meet(self.copy(),x.copy()))
 def __or__(self,x):return Set(either(self.copy(),x.copy()))
 def __sub__(self,x):return Set(minus(self.copy(),x.copy()))
 def __bool__(self):
  z=empty(self.ptr);assert z in(0,1);return z==0
 def __str__(self):return f('set_to_str',[P],S)(self.ptr).decode()
def st(t):return Set('{[k,j]: '+t+'}')
def q(s):return st(s)
