from physical_unit_probe import run
import contextlib,io,json
from pathlib import Path
rows=[]
for a,b,root in [(6,-1,(1,0)),(4,-1,(0,3)),(6,1,(7,4)),(12,1,(-1,16))]:
 with contextlib.redirect_stdout(io.StringIO()):tile,F,forced,rank,key=run((a-2)//2)
 free={};H=[(1,0)]+[(x,x-2)for x in range(2,a+1)]+[(a+1,a-2)];V=[(0,y)for y in range(a)]+[(-1,y)for y in range(a,2*a)]
 for i,z in enumerate(H):free[key(z)]=(0,-1)if i==0 else(0,-b)if i==len(H)-1 else(-1,0)if sum(z)%2==0 else(0,-1)
 for i,z in enumerate(V):free[key(z)]=(b,0)if i==0 else(-1,0)if i==len(V)-1 else(b,0)if sum(z)%2==0 else(0,-b)
 ip=lambda z:[(z[0]-1,z[1]),(z[0]+1,z[1])]if sum(z)%2==0 else[(z[0],z[1]-1),(z[0],z[1]+1)]
 def classify(z):return 'black'if sum(F(v)for v in ip(z))-2*F(z)==-1 else 'forced'if key(z)in forced else'free'
 def opts(z):
  if classify(z)=='black':return ip(z)
  dx,dy=forced.get(key(z),free.get(key(z)));return[(z[0]+dx,z[1]+dy)]
 chosen=opts(root)[0];rx=root[0]-chosen[0];ry=root[1]-chosen[1];traces=[]
 for sign in [-1,1]:
  px=-ry*sign;py=rx*sign
  path=[(root[0]+rx,root[1]+ry),(root[0]+rx+px,root[1]+ry+py),(root[0]+px,root[1]+py),root]
  allowed=all(v in opts(u)for u,v in zip(path,path[1:]));types=[classify(v)for v in path[:-1]]
  traces.append(dict(path=path,allowed=allowed,tail_types=types))
 assert any(r['allowed']for r in traces)
 assert not any(r['allowed']and 'free'not in r['tail_types']for r in traces)
 rows.append(dict(a=a,b=b,root=root,traces=traces))
Path(__file__).with_name('PRIVATE_NONFREE_COUNTEREXAMPLES.json').write_text(json.dumps(rows,indent=2)+'\n')
