from pathlib import Path
exec(Path(__file__).with_name('complete_partition.py').read_text().split('\nbase=z.And')[0])
import sympy as sy
at,tt=sy.symbols('a t',integer=True);t=z.Int('t')
conv=lambda v:eval(str(sy.expand(v)),{'a':A,'t':t})
T=2*at*at+4*at-2;cv=-(T+2*at)/2
rows=[]
for kind,X,Y,guard in [('H0',sy.Integer(1),sy.Integer(0),t==0),('Hm',tt,tt-2,z.And(t>=2,t<=A)),('Hl',at+1,at-2,t==0),('V0',sy.Integer(0),tt,z.And(t>=0,t<=A-1)),('V1',sy.Integer(-1),tt,z.And(t>=A,t<=2*A-1))]:
 for off in [(0,0),(-1,0),(1,0),(0,-1),(0,1)]:
  dx,dy=off;XX=X+dx;YY=Y+dy
  ph=(conv(X)+conv(Y))%2
  active=z.BoolVal(True) if off==(0,0) else ph==(0 if dx else 1)
  offers=[]
  for i,j in aliases:
   nx=XX+i*(at+1)-2*j;ny=YY+i*(at-1)+2*at*j
   pol=-(ny-nx+1)**2-4*j*((at-1)*XX-(at+1)*YY+cv)+2*T*j*(j-1)
   if kind.startswith('V'):pol-=2*XX*(XX-1)-(YY+1-XX)**2;rem=0
   else:rem=(conv(YY+1-XX))%2
   eq=conv(pol)+rem+4*corr(conv(nx),conv(ny))==0
   offers.append(z.And(native(conv(nx),conv(ny)),eq))
  s=z.Solver();s.set(timeout=60000);s.add(A>=4,A%2==0,guard,active,z.Not(z.Or(*offers)))
  name=kind+'_'+str(dx)+'_'+str(dy);raw=s.to_smt2();p=P/('height_'+name+'.smt2');p.write_text(raw);ans=str(s.check());print(name,ans,flush=True)
  if ans=='sat':print(s.model(),flush=True)
  fresh=subprocess.run(['/tmp/f_lattice_z3/bin/z3','-T:65',str(p)],capture_output=True,text=True,timeout=70).stdout.strip()
  rows.append(dict(name=name,result=ans,fresh=fresh,sha256=hashlib.sha256(raw.encode()).hexdigest()))
  (P/'ARC_STAR_RECEIPT.json').write_text(json.dumps(rows,indent=2)+'\n')
