# Complete explicit flat-Phi rank candidate, both pure2 signs

STATUS: exact closed formula discovered and checked against every actual flat canonical quotient edge for K=1,...,10, BOTH signs. It equals the longest-path rank in every tested case. Universal symbolic edge verification is still required; this note does not label the finite regression a proof.

Let a=2K+2, h=y-x, chi=(x+y) mod2. Define a FULL-LATTICE PERIODIC correction r_eta by assigning the following values to each genuine native quotient class. Free classes have priority over the bulk formulas. The exact free aliases must use the independently certified native quotient chart, not raw coordinates outside it.

## Free tables (native physical H and V indices)

H0=(1,0); H_j=(j+1,j-1) for1<=j<=a-1; H_a=(a+1,a-2).
V_j=(0,j) for0<=j<a and(-1,j) for a<=j<=2a-1.

eta+:
 H0:2a+1; H_j:2(a-j) for1<=j<=a-1; H_a:1.
 V_j:2j-(j mod2) for0<=j<a;
 V_(a+q):2q+1+(q mod2) for0<=q<a.

eta-:
 H0:4; H1:1; H_j:2a+5-2j for2<=j<=a-1; H_a:6.
 V0:5; V_j:2a+3-2j-(j mod2) for1<=j<a;
 V_a:2; V_(a+1):1;
 V_(a+q):2a+4-2q+(q mod2) for2<=q<a.

## Bulk formulas

On h=-1 (nonfree roots only):
 eta+: r=2a+1-2y, except x=a has r=2a-3;
 eta-: r=2a+6-2y, except x=2 has r=2.

On h=a-1 (nonfree roots1<=x<=a-1):
 eta+: r=2x+3;
 eta-: r=2x+4, except x=1 has r=2a.

On all remaining nonfree native roots set
 center=a-1, offset=2a-2 if h<=a-2;
 center=2a-1, offset=2a if h>=a;
 b=offset-2|y-center|-chi.
Then r_plus=b. For eta- set r_minus=b+1 when y<center+1; r_minus=1-chi when y=center+1; r_minus=b+5 when y>center+1.

## Exact verification target and consequence

For every genuine canonical edge z->u at which Phi_eta(u)=Phi_eta(z), prove r_eta(u)<r_eta(z), using actual global native lifts for u. The raw price theorem supplies Phi_eta nonincrease on all other edges. The displayed correction takes values in[0,2a+2] in the authenticated representative partition (this bound should be verified with that same partition).

Once the universal edge check and boundedness pass,

 R_eta(z)=(2a+3) Phi_eta(z)+r_eta(z)

is a strict physical rank on EVERY canonical edge. At a flat edge its correction strictly drops. At a price-dropping edge the first term drops by at least2a+3 and the bounded correction can rise by at most2a+2. The rank has exact deck increments (2a+3)(-1,2eta), hence is periodic along the actual pitch W_eta=2eta U+V. Thus it supplies both physical standard recurrence and the pitch-zero strict rank needed for clean bands, not just held-free acyclicity.

This conditional implication is proved; the outstanding part is the unbounded verification of the concrete formula on all actual flat edges and its chart aliases. Matching finite longest paths is only discovery. check_flat_rank_formula.py reconstructs the real global base field, actual square-unit assignments, free canonical slots and physical price differences before checking the formula; it does not define flatness by a quotient-representative price.

## Native alias audit: bulk representative is unique

This part is now proved uniformly, not dependent on dictionary insertion order. Two native sites differ by iU+lV with |Delta x|<=a+2, |Delta y|<=3a-2. Inverting the period matrix gives
 i=(a Delta x+Delta y)/(a²+2a-1),
 l=((a+1)Delta y-(a-1)Delta x)/(2(a²+2a-1)).
For a>=4 these imply |i|<2 and |l|<2. Thus only the eight nonzero shifts in{-1,0,1}² can be aliases. The exact native guard plus (one of L/U/E/W OR a full-native black root) excludes every such native translate, by the unbounded query nonfree_native_unique.smt2 (producer and independent CLI UNSAT). Under the separately authenticated bulk exhaustion, EVERY nonfree quotient class therefore has exactly one native representative. Free classes use the explicit quotient-port tables with priority and their separately verified H/V alias convention. No arbitrary bulk representative order is needed.

## Uniform boundedness audit

The exact included-bulk guard proves 0<=r_plus,r_minus<=2a+2 by unbounded LIA, producer and independent CLI UNSAT for flat_rank_bound.smt2. Every displayed free-table entry lies in the same interval directly. Together with the alias result, boundedness of the actual periodic correction is paid; only the universal flat-edge decrease check remains before asserting the complete strict rank.
