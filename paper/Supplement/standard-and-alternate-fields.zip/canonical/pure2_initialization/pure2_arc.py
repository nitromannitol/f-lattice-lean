"""Unbounded integer-polyhedral proof: all five pure2 prices on both real free arcs."""
from islkit import *
import sympy as sy,itertools,json,hashlib
from pathlib import Path
from functools import lru_cache
k,j=sy.symbols('k j');a=2*k+2;n=a-1;d=a+1;T=sy.expand(d*d+2*d*n-n*n);cV=sy.expand(-(T+2*a)/2);c0=k*k+3*k+1
@lru_cache(None)
def linear(e):
 e=sy.expand(e);assert sy.Poly(e,k,j).total_degree()<=1
 return str(e).replace('**','^')
def con(a,op,b=0):return '('+linear(a-b)+op+'0)'
@lru_cache(None)
def dom(s):return q(s)
def native(u,v):
 # v is RAW y. Conditions from genuine doubled-ladder-even initializer.
 e1=con(u,'=',-1)+' and '+con(v,'=',2*a+1);e2=con(u,'=',a+1)+' and '+con(v,'=',a-1)
 e3=con(v-u,'=',a)+' and '+con(u,'>')+' and '+con(u,'<',a)
 bd=' and '.join([con(u,'>=',-1),con(u,'<=',a+1),con(v,'>=',1),con(v,'<=',3*a-1),con(v-u,'>=',-1),con(v-u,'<=',2*a+1)])
 bd+=' and not ('+con(u,'=',-1)+' and '+con(v,'<=',a+1)+') and not ('+con(u,'=',a+1)+' and '+con(v,'>=',2*a-1)+')'
 return '('+bd+') or ('+e1+') or ('+e2+') or ('+e3+')','('+e1+') or ('+e2+') or ('+e3+')'
def chunks(D,ds,ft,ff=0):
 S=dom(ds);A=D&S;B=D-S
 if A:yield A,ft
 if B:yield B,ff
lifts=sorted(itertools.product(range(-5,6),repeat=2),key=lambda w:abs(w[0])+abs(w[1]))
stats={'lift':set(),'cells':0,'factor_checks':0}
def fh(D,x,y,K,J):
 cover=D
 for i,l in lifts:
  if not cover:break
  u=sy.expand(x-i*d+2*l);v=sy.expand(y-i*n-2*a*l+1)
  guard,bump=native(u,v);zone=cover&dom(guard)
  if not zone:continue
  cover=cover-zone;stats['lift'].add((i,l));t=sy.expand(u-v)
  parity=int(t.subs({k:K,j:J}))%2
  # four times true deck extension on this native lift.
  base=sy.expand(-(t*t-parity)+4*(l*(n*u-d*(v-1)+cV)-l*(l-1)*T/2))
  terms=[(con(a-v,'<'),4*(a-v)),(con(v-u-a,'>'),4*(v-u-a)),(con(2*a-v,'<'),4*(2*a-v)),(bump,4)]
  branches=[(zone,base)]
  for test,val in terms:
   branches=[(B,z+extra)for A,z in branches for B,extra in chunks(A,test,val)]
  for B,z in branches:yield B,sy.expand(z)
 assert not cover,('no native lift',x,y,str(cover))
def same_on(D,r):
 if not r:return
 stats['factor_checks']+=1
 ff=sy.factor_list(r)[1]
 # Prove integer-cell subset of literal zero set using exact affine factors.
 gates=[dom(con(F,'=')) for F,_ in ff if sy.Poly(F,k,j).total_degree()<=1]
 for b in gates:D=D-b
 if D:raise AssertionError((str(D),str(sy.factor(r))))
def target(D,arc,nm):
 if arc=='H':
  dic={'P':[(con(j,'=',0),c0)],'D+':[],'D-':[],'Phi+':[],'Phi-':[(con(j,'<=',1),c0-1)]}
  fallback={'P':c0-1,'D+':0,'D-':0,'Phi+':c0,'Phi-':c0-2}
 else:
  dic={'P':[],'D+':[(con(j,'<',a),0),(con(j,'=',2*a-1),2)],'D-':[(con(j,'=',0),0),(con(j,'<',a),-1)],'Phi+':[(con(j,'<',a),c0+1)],'Phi-':[(con(j,'=',0),c0-1),(con(j,'<=',a+1),c0-2)]}
  fallback={'P':c0,'D+':1,'D-':-2,'Phi+':c0+2,'Phi-':c0-3}
 V=D
 for test,label in dic[nm]:
  Z=V&dom(test)
  if Z:yield Z,label
  V=V-dom(test)
 if V:yield V,fallback[nm]
def check():
 stat={}
 for name,x,y,guard in [('H',1,0,con(j,'=')),('H',j+1,j-1,con(j,'>=',1)+' and '+con(j,'<',a)),('H',a+1,a-2,con(j,'=',a)),('V',0,j,con(j,'>=')+' and '+con(j,'<',a)),('V',-1,j,con(j,'>=',a)+' and '+con(j,'<',2*a))]:
  for nm,dx,dy,lin in [('P',-1,a-1,1),('D+',-a,2-a,0),('D-',a,a-2,0),('Phi+',-a-1,1,1),('Phi-',a-1,2*a-3,1)]:
   for K,J in itertools.product(range(2),repeat=2):
    D=dom('k>=1 and (k mod 2)='+str(K)+' and (j mod 2)='+str(J)+' and '+guard)
    if not D:continue
    for S,h in fh(D,x,y,K,J):
     for B,h2 in fh(S,x+dx,y+dy,K,J):
      for C,p in target(B,name,nm):
       same_on(C,sy.expand(h-h2+4*lin*(k*x-(k+1)*y)-4*p));stats['cells']+=1;stat[name,nm]=stat.get((name,nm),0)+1
 print(json.dumps({'status':'PASS all integers k>=1 and every arc index','nonempty_cells':stats['cells'],'factor_checks':stats['factor_checks'],'lift_pairs':sorted(stats['lift']),'per_price_and_arc':{str(key):v for key,v in stat.items()}},indent=2))
if __name__=='__main__':check()
