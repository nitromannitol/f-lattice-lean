"""Pure2 E ownership, native closure, scalar alias consistency and reflection proofs."""
import sys,json,hashlib,itertools,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;sys.path.insert(0,'/tmp/f_lattice_z3')
import z3 as z
exec((P/'uniform_bulk.py').read_text().split('G,dx,dy,r=')[0].split('P=Path(__file__).resolve().parent')[1])
D=P/'nativechecks';D.mkdir(exist_ok=True);receipts=[]
def prove(n,bad):
 s=z.Solver();s.add(A>=4,A%2==0,bad);raw=s.to_smt2();f=D/(n+'.smt2');f.write_text(raw);ans=str(s.check());s2=subprocess.check_output(['/tmp/f_lattice_z3/bin/z3',str(f)],text=True).strip();print(n,ans,s2,flush=True);assert ans==s2=='unsat',s.model();receipts.append([n,hashlib.sha256(raw.encode()).hexdigest()]);(D/'RECEIPTS.json').write_text(json.dumps(receipts,indent=2))
aliases=list(itertools.product(range(-1,2),repeat=2))
native0=native(x,y)
for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
 prove('cover_'+str((dx,dy)),z.And(native0,z.Not(z.Or(*[native(x+dx-i*(A+1)+2*l,y+dy-i*(A-1)-2*l*A)for i,l in aliases]))))
for i,l in aliases:
 if (i,l)==(0,0):continue
 X=x+i*(A+1)-2*l;Y=y+i*(A-1)+2*A*l;h=y+1-x
 residual=i*h+2*l*x-l-2*l*l+2*i*(A+1)*l-i*i+corr(X,Y)-corr(x,y)
 prove('alias_'+str((i,l)),z.And(native0,native(X,Y),residual!=0))
R=(A,3*A-2)
prove('reflection',z.And(native0,z.Or(z.Not(native(A-x,3*A-2-y)),2*A-(y+1-x)-2*x+corr(A-x,3*A-2-y)-corr(x,y)!=0)))
