from profile_window import *
# t(x,y)=-(a+1)(y-x)-2x. Native x in [-1,a+1].
def le_t(poly):
 d=a+1;q,r=sp.div(sp.expand(poly),d,k);assert all(cc.q==1 for cc in sp.Poly(q,k).all_coeffs()),(q,r)
 # division by linear k gives constant remainder. If half integral use div in symbol a instead
 qq=lift(q);rr=lift(r);h=y-x;return z.Or(h+qq>=5,*[z.And(h+qq==m,(A+1)*m>=-2*x-rr)for m in range(-4,5)])
def le(poly):
 # divide in symbol a (T etc are polynomials in a), monic a+1. r constant independent of K.
 aa=sp.symbols('aa');expr=sp.expand(poly.subs(k,(aa-2)/2));q,r=sp.div(expr,aa+1,aa);assert r.is_Integer
 rr=int(r);q=q.subs(aa,a);qo=lift(q);h=y-x;M=abs(rr)+4
 # -2x-r in [ -2(a+1)-|r|,2+|r|]. M(a+1)>2(a+1)+|r| as a>=4.
 return z.Or(h+qo>M,*[z.And(h+qo==m,m*(A+1)>=-2*x-rr)for m in range(-M,M+1)])
def inc(s,t):return z.And(z.Not(le(s-1)),le(t))
def calculate():
 n=a-1;d=a+1;T=2*a*a+4*a-2;V=(a-1)*(a+2);Pmin=-d+3-T;Pmax=n+2*d-1;Bmin=-d+3-V;Bmax=n+2*d-1+V
 # certify deck range using actual native coarse t bounds **outside** the symbolic price test
 lo0=-(a+1)*(2*a+3);hi0=3*a+5
 for nm,expr in [('l_le_minus2',lo0+2*T-Bmax),('l_ge_2',Pmin-(hi0-2*T))]:
  p=sp.Poly(sp.expand(expr.subs(k,k+1)),k);assert p.coeff_monomial(1)>0 and all(c>=0 for c in p.all_coeffs());print(nm,p,flush=True)
 rawdiag=[]
 for i,l in itertools.product(range(-1,2),repeat=2):
  u,v=[lift(h)for h in rect(i,l,1,1)];guard=native(u,v)
  val=lift(raw(0,0,0,0)-raw(i,l,1,1))+4*(corr(x,y)-corr(u,v));rawdiag.append((guard,val))
 check('Dplus_native_diag_cover',z.And(native(x,y),z.Not(z.Or(*[q for q,v in rawdiag]))))
 for l in [-1,0,1]:
  for nm,t1,t2,lo,hi in [('closed_halo',Pmin,Pmax,0,2),('center',Bmin,Bmax,-1,1),('first_2',Bmin-1,Bmin-1,2,2)]:
   win=inc(t1+l*T,t2+l*T)
   check('global_'+nm+'_'+str(l),z.And(native(x,y),win,z.Or(*[z.And(g,z.Or(v+8*l<4*lo,v+8*l>4*hi))for g,v in rawdiag])))
if __name__=='__main__':calculate()
