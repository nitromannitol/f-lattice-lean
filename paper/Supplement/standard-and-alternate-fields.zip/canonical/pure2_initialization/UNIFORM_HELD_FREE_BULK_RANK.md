# Uniform explicit strict rank for the pure2 bulk with free boundary held

Let a=2K+2>=4, use the authentic exported LL coordinates and h=y-x of UNIFORM_DOUBLED_LADDER_BULK_DIRECTIONS.md. Define

 R(x,y)=2                                      if h=a-1;
 R(x,y)=-2|y-(a-1)|+1_{x+y even}               if h<=a-2;
 R(x,y)=-2|y-(2a-1)|+1_{x+y even}              if h>=a.

This gives a simple parameter-uniform physical decrease on EVERY edge between nonfree bulk roots once the actual free classes are held. It is NOT yet a full canonical rank across the free boundary or a recurrence proof.

## Exact local statement and proof

A root is included if it is in one of the four genuine forced classes L,U,E,W, or if its actual full-native star is black. At a forced root retain its already-proved unique direction; at a black root retain BOTH physical inputs. Whenever the target is another included native root, R(target)<R(root).

Within the lower phase an even black root's horizontal edge keeps y and drops the parity bonus1; an odd forced root moves vertically away from a-1, changing -2|y-(a-1)| by-2 and gaining the even bonus1. Thus each decrease is1. Odd black roots at y=a-1 have both vertical inputs strictly farther from the center, again decreasing. The upper phase is identical with center2a-1. The E/W forced classes take their outward horizontal direction into the respective lower/upper phase and drop the parity bonus. Central h=a-1 black roots have rank2 and both neighbors have rank at most1. The remaining apparent cross-phase edges are excluded by the exact native guards/colors or end at a free root rather than an included bulk root.

The last clause is verified without parameter enumeration by the raw linear-integer query held_free_rank_native_stars.smt2. It uses the literal native domain, the exact correction-term color formula on full-native stars, all four forced guards, BOTH black inputs and the piecewise rank above. It permits either of the two non-full-native forced E/W endpoint roots as source or target, using their separately proved forced directions rather than an off-native raw color. The query asks for ANY counterexample with even a>=4 and integer x,y; producer and independent CLI both return UNSAT.

The two off-native forced outgoing inputs are separately understood: (0,a) west maps by +U to (a,2a-1), a free class; its reflected east endpoint maps to (0,a-1), also free. They do not introduce a hidden bulk edge by folding. Exhaustion of all other actual black/nonfree roots and exact free labels is the separate coverage/assignment certificate currently being checked; no unknown star is silently evaluated by raw formula continuation.

## Consequence under exact quotient coverage

If the separately verified coverage says every actual nonfree white belongs to L/U/E/W, every other bulk root is full-native black, and every bulk class has its genuine unambiguous representative (all remaining off-native inputs are free as above), the quotient bulk graph with free roots removed is a DAG by R. No numerical torus acyclicity is used in this implication. Native 0<=y<=3a-2 gives R>=-4a+2 and R<=2, so every bulk-only path has length at most4a. In particular every physical canonical path reaches a free root within that bound unless it already leaves the held region.

This pays the bulk-terminal part of the dynamic base. It does NOT itself price exits, exclude a cycle through free roots, give a desired deck slope, or prove physical recurrence. Those require the canonical H/V boundary transitions and an actual global terminal/rank argument.

## Verification

The raw unbounded query is included, with source prove_held_free_rank.py. Fresh independent /tmp/f_lattice_z3/bin/z3 returns UNSAT. Regression on genuine quotient fields K=1,...,8 checks36,90,168,270,396,546,720,918 retained bulk edges respectively, with no failures and no bulk-to-bulk folding. That census is a consistency check only; the uniform local claim comes from the exact query and displayed rank.
