# The doubled-ladder initialization: the actual standard AND alternate recur

For every K≥1, the literal even standard and even alternate initializers at word 2^K, fraction n/d=(2K+1)/(2K+3), coincide on their respective actual native domains with the fields constructed below. Both coherent global extensions have no nonempty finite physical forbidden set. The two standard chain signs additionally have genuine zero-pitch strict ranks, all-threshold binary admission, and clean burning on their finite-period bands. No general corrected child, reciprocal staircase, or empty word is being inferred from this family.

“Literal initializer” here means the untruncated integer function specified by its Julia source, not a guarantee of successful finite-memory or floating-point execution at arbitrary K.

This is a computer-assisted parameter-uniform proof. The raw queries quantify all K and all remaining unbounded lattice coordinates, not examples up to a bound. All decisive pure2 base steps use the two original scalar formulas, not an upstream assertion that those bases are recurrent.

## 1. Normalize the actual fields

Set a=2K+2, n=a−1,d=a+1,T=2a²+4a−2, t(x,y)=nx−dy, U=(d,n), V=(−2,2a), and cV=−a²−3a+1. The regular pure2 even constructor uses the doubled ladder, not the staircase. In exported lower-left, value-zero coordinates its standard F on its native set is

    F(x,y)=−floor((y+1−x)²/4)+C(x,y),
    C=min(0,a−y−1)+max(0,y+1−x−a)+min(0,2a−y−1)+c.

Here c is 1 on y+1−x=a with 0<x<a and on the two authentic exceptional corners, and zero elsewhere. The complete cropped native set, its deleted strips and two added corners are stated in UNIFORM_DOUBLED_LADDER_BULK_DIRECTIONS.md and encoded in uniform_bulk.py; do not replace it by the full bounding box. Cover the plane by its translates and give F the jets

    F(z+U)=F(z),    F(z+V)=F(z)+t(z)+cV.

Native union is nonempty and closed under all four unit moves by positive native-lift coverage. Any two native aliases differ by iU+lV with |i|,|l|≤1, by inverting the period matrix on the true native rectangle. On such an alias the difference between the two raw formulas after cancellation of the quadratic and jet is

    i(y+1−x)+2lx−l−2l²+2i(a+1)l−i²+C(z+iU+lV)−C(z).

The eight nontrivial cases vanish. Reflection about R=(a,3a−2) satisfies F(R−z)=F(z)−t(z)−a²−a+1. All claims were checked as unbounded linear integer problems, nativechecks/. The actual alternate gets its own source/crop/character proof in §5.

## 2. Real physical colors and edges

Even physical sites receive the two horizontal neighbors, odd sites the two vertical. A field is binary if ΔF∈{−1,0}. Its black roots have ΔF=−1; either input in a forbidden set suffices there. At a white root a forbidden set must contain BOTH inputs. Thus a burning policy retains both black inputs, one actual white input.

Genuine full-native Laplacians are elementary linear guards after cancelling the quadratic floor. Non-full native stars are actual H/V classes or one of the two paid endpoint stars (0,a),(a,2a−2). The four explicit forced white classes and a positive induction grade with a physical unit-square derivation for every forced decision are in UNIFORM_DOUBLED_LADDER_BULK_DIRECTIONS.md. COMPLETE_CANONICAL_CLASSIFICATION.md checks exhaustion, native/free alias uniqueness, and free completions (not merely a guessed output of unit propagation). GLOBAL_BINARY_AND_FREE_RETURN_SQUARES.md verifies the global binary property and the physical three-step return from each rejected free input under BOTH canonical policies. The return may pass another free vertex; the proof does not require the false stronger exclusion. Forced whitenings have their unit-witness squares as well: the other whites point inward, and blacks retain both.

On H, e_{(−1,η)} selects the positive axial input except at H0=(1,0), where it selects vertical −η. At V0=(0,0) it selects E. All other V roots select horizontal η or vertical −η according to their genuine parity. The reflected policies give the other two standard signs. Free classes use their actual deck representatives; a listed free seat need not itself be native, but a genuine native fold is proved.

## 3. Raw prices, profiles and scalar windows

Let v=(−1,a−1), σ=(−a,2−a)=(1,1)−U, and b=(K,−K−1). Put

    P(z)=F(z)−F(z+v)+b·z,
    Dη(z)=F(z)−F(z+ησ),
    Φη(z)=F(z)−F(z+v+ησ)+b·z.

Each price is nonincreasing on every retained physical edge of the corresponding e_{(−1,η)} policy (P for either sign). Both inputs are retained at every F-black. P,D±,Φ± change by at most one on EVERY physical input, selected or not. P has no mixed (−1,+1) input star, nor does Dη at a root of even gap. Every translated chain minimum min(F,F−Φη+j), j any integer, is binary. In rawall.py all distinct root threshold offsets −2,…,2 are tested before the stronger Φ-unit gate; outside them one sheet wins the whole star. Shifts used to obtain gradients are unique physical values, not quotient representatives with unstated jets.

In detail, twice an input gradient in a native chart w=(x',y') of secondary index l is, for e=(dx,dy), h=y'+1−x', δ=dy−dx,

    −hδ−(h mod 2)+2(C(w+e)−C(w))+2l(n dx−d dy).

Use the actual exceptional outgoing chart values at (0,a) west and its reflection (doubled increments −a and a−2). Every chosen offer has both genuine native sites or one paid exceptional star; coverage of all needed shifted stars is checked. Arc scalar tables are derived separately by polyhedral splitting of the authentic formula. With c0=K²+3K+1, the H seats are H0, H_j=(j+1,j−1) (1≤j<a), H_a=(a+1,a−2). Along H, P−c0=0 at 0 and −1 otherwise; D±=0; Φ+−c0=0; Φ−−c0=−1 through j=1 then −2. On V, V_j=(0,j) for j<a and (−1,j) for a≤j<2a. There P−c0=0, and

    D+ = 0 (j<a), 1 (a≤j<2a−1), 2 (last);
    D− = 0 (j=0), −1 (1≤j<a), −2 (j≥a);
    Φ+−c0 = 1 (j<a), 2 (j≥a);
    Φ−−c0 = −1 (j=0), −2 (1≤j≤a+1), −3 thereafter.

pure2_arc.py pays all 124 nonempty integer cells; the number counts symbolic parameter cells, not values of K. Entire two strip orbits, not merely these arcs, are covered in ENTIRE_ZERO_AND_HARMONIC_STRIPS.md. In particular F=0 when −a≤t≤3a, and F=h0 when −2a−1≤2ax+2y≤4a−1.

The closed canonical polygon E is precisely native plus (−1,a) and (a+1,2a−2): profile_window.py computes boundary and winding of its actual H,V,H+Vdeck,V+U sides, including the four single-edge corners. On E with its genuine incoming halo P−c0∈{−1,0}; on E, D+∈[0,2], D−∈[−2,0]. For D+ as a function of t (U periods and gcd(n,d)=1), the complete halo interval [3−d−T,n+2d−1] has range in [0,2]. For L=|t(v)|=(a−1)(a+2), the central interval [3−d−L,n+2d−1+L] has |D+|≤1 and D+(2−d−L)=2. The code transverse_windows.py reduces any physical site to native plus lV: l∈{−1,0,1} for the stated windows by explicit extrema of native t, D+(w+lV)=D+(w)+2l. To avoid treating genuine products as linear, an endpoint polynomial in a is divided by the monic a+1; using t=−2x−(a+1)(y−x) and native |x|≤a+1 leaves a bounded number of exact integer comparisons around the quotient. The discarded tails have fixed sign. “Window” means the actual geometric set or actual integer t-interval specified, not samples.

## 4. Physical standard recurrence and clean bands

The explicit bounded periodic corrections rη are listed in EXPLICIT_FLAT_PHI_RANK_CANDIDATE.md. The “candidate” filename is historical: globalrank.py now proves every remaining flat-edge implication for the displayed correction. Free classes take their explicit arc values first; a nonfree class has a unique native representative. For native roots and their unit neighbors, all possible native/free addresses lie in {−1,0,1}² by the inverse bounds in GLOBAL_RANK_CODE_AND_ALIAS_AUDIT.md. Uniformly 0≤rη≤2a+2. At each retained physical edge z→u for which Φη(u)=Φη(z), each of the four axial edge directions for each sign has the proved inequality rη(u)<rη(z). Therefore

    Rη=(2a+3)Φη+rη

strictly falls on EVERY retained physical edge: on a strict integer price decrease even the largest possible correction increase is insufficient. At a minimum Rη vertex of a finite nonempty forbidden set, either both retained black choices fall and at least one belongs to the set, or its retained white choice falls and belongs to the set. Contradiction. This proves actual standard recurrence, not a finite-window or torus substitute.

The price drifts on U,V are −1,2η, hence Rη has exactly zero drift on Wη=2ηU+V. At a tie band Φη=j of m=min(F,F−Φη+j) let o count off-band inputs. After paying them, the on-band burn quota is 1−Δm−o. clean_direct.py substitutes BOTH physical increments with the genuine black/forced/free assignments at all native aliases; it proves every such root has at least this many retained tied inputs. This is an independent direct quota check, with no assumption that a band-black tie was already standard-black. There is one Wη-quotient point per standard deck class on a level because Φη has primitive U-drift −1 and kernel in the deck generated by Wη. Thus Rη restricts to the finite band quotient, and increasing rank burns all sites with the off-band inputs paid. This proves both clean standard chain bands.

## 5. The literal alternate, not just an abstract midpoint

For the original pure2 even alternate in its genuine exported frame, alternate_native/TRUE_NATIVE_MIDPOINT_COVER_AND_ADMISSION.md proves from get_doubled_ladder_even_alt, including both raised corners and the actual side cutoffs, that its value is

    J(z)=ceil((F(z)+F(z+σ))/2)=F(z)−floor(D+(z)/2).

There is no extra gauge or spatial shift. Natively it also equals min(F(z),F(z+σ)+1). The native price pairs relative to its true value are (0,0),(0,−1),(1,−1); both offers have genuine native standard lifts. A positive cover proves each standard class is met. The midpoint's U character is zero and its V jet is t(z)+cV−1, so this is the coherent global extension of the authentic native alternate. Binary admission of this extension was also checked directly on the two true native star parities.

For recurrence use the genuine strict F policy η=+ and Section 3, not merely binary admission nor an unjustified maximum principle for an average. Put r=D+(z) mod 2 and e_i=D+(u_i)−D+(z). Then ΔJ=ΔF−Σ floor((r+e_i)/2). Both original sheets are binary, |e_i|≤1, and even-gap roots exclude {−1,1}. D+ does not increase on any retained F input. As shown exhaustively in MIDPOINT_LEMMA.md, at even gap every J-black has two F-black ties, and every J-white has an available retained F tie. At odd gap the J-black inputs either go to even gap or are retained F ties; a J-white has two ties and is F-white. Consequently J has strict physical lex rank (r,R+). Its minimum on a finite forbidden set gives the same contradiction as for F. Thus the actual even alternate too is recurrent on the whole plane.

## Verification and scope

The archive includes the source formulas, readable subsidiary proofs, exact encoders and raw z3-LIA queries, plus the polyhedral arc verifier. FRESH_GEOMETRY_RAW_RANK.json replays 124 raw +25 rank/coverage+13 native geometry/alias queries in a fresh CLI (162). FRESH_WINDOWS_CLEAN_ALT.json separately replays 20 window +20 clean/coverage+4 true alternate queries (44). Other files supply separate signed square, strip, asset and classification receipts. Existing *_CANDIDATE, *_RESIDUAL and older initialization scope notes are historical; only the exact paid conclusions here supersede them. SAT files concerning inadmissibly stronger assertions (all return tails nonfree; every free seat literally native) are deliberate counterexamples, not proof obligations.

Independent audit includes distinct semantic review of the weighted rank and alias cutoff, different native admission/height and midpoint-star calculations, plus fresh solver replays on stored obligations. Re-running an SMT input is not a second independent reimplementation or a proof assistant certificate. Older numerical longest-path regressions discovered the formula but are not the uniform proof. The reciprocal staircase role, endpoint root and arbitrary corrected-child source-height recognition are distinct obligations. No complete all-word theorem or repair of the entire Carbon proof is claimed here.
