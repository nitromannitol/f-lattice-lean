# Global pure-2 rank: independent code and alias audit

## Verdict
PASS for `globalrank.py` as an all-parameter strict-rank certificate, conditional on the separately authenticated actual raw field, deck law, and exhaustive canonical forced/free assignment. This audit does not re-prove those producer obligations. There is no remaining free-neighbor alias cutoff. The correction is not dependent on dictionary insertion order.

I independently read `globalrank.py`, its imported `rawall.py`, and the actual `native`, `corr`, `candidate` definitions in `uniform_bulk.py`. I independently replayed all eight saved flat-edge queries, four native-neighbor fold queries, and the native nonfree uniqueness query with a fresh Z3 CLI. All thirteen are UNSAT. This is independent semantic review and solver replay, not an independently implemented field reconstruction or a formal proof-assistant certification.

## Uniform cutoff, including neighbors
Write a=2K+2>=4, Q=a^2+2a-1, U=(a+1,a-1), V=(-2,2a). Every native point is in [-1,a+1] x [0,3a-2]. A unit neighbor is in [-2,a+2] x [-1,3a-1]. Every H/V free representative lies in [-1,a+1] x [0,2a-1]. Every native or free representative therefore differs from a native point or its unit neighbor by a displacement (X,Y) satisfying |X|<=a+3, |Y|<=3a-1.

If (X,Y)=iU+lV, inversion gives

    i=(aX+Y)/Q,
    l=((a+1)Y-(a-1)X)/(2Q).

Consequently

    |i| <= (a^2+6a-1)/Q < 2,
    |l| <= (4a^2+4a-4)/(2Q) < 2.

The strict inequalities follow respectively from a^2-2a-1>0 and 4a>0. Thus integer i,l belong to {-1,0,1}. This proves completeness of the nine addresses for BOTH native and free representatives of the current root and its successor. It also proves that every possible alias between two native/free representatives is among the eight tested nonzero addresses.

## Alias choice and correction bounds
The new `audit_rank_alias.py` independently asks whether two distinct H/V free representatives are deck-congruent. UNSAT, with independent CLI replay. H and V themselves are disjoint. Thus free-offer priority is canonical, not order-dependent. Some free representatives are not literally in the native set (notably the first upper V seat); this is harmless. The correct statement, also independently checked, is that every free representative has a native fold. Do not replace this by a claim that every free arc point is native.

The saved native nonfree uniqueness query is UNSAT for ALL nonfree native points, stronger than uniqueness only on the explicitly forced/black subset. Combined with free priority and the cutoff, `deckrank` evaluates one genuine quotient function. Its default -1000 is unreachable by the saved fold-cover proofs. The separately proved bulk bounds and the new free bounds give 0<=r_eta<=2a+2 globally. New free bounds for both signs are independently UNSAT/CLI-UNSAT.

## Edge-query semantics
`grad` returns twice the actual physical field increment, including the secondary-deck affine correction. Hence `phi` is twice the physical Phi increment; `phi==0` is exactly flatness, with no division or parity ambiguity. The flow guard chooses horizontal inputs at even roots and vertical inputs at odd roots. `gx+gopp==-2` is exactly the actual black condition. `select` includes both black inputs, the authenticated forced direction, and the chosen free direction at EVERY possible free alias. Extra overlaps of these predicates can only strengthen the checked assertion.

The formulas in `freer` and `bulkr` agree term-by-term with `EXPLICIT_FLAT_PHI_RANK_CANDIDATE.md`, including eta-minus H1, V0, V_a, V_(a+1), the h=-1 exceptions, and the h=a-1 exception. Free priority is explicit in the nested conditionals. Each of the eight UNSAT queries asserts strict decrease at every selected flat-Phi edge, for every integer K>=1, not a bounded range.

## Physical strict rank
Using the independently supplied all-edge nonincrease of integer Phi, set

    R_eta=(2a+3) Phi_eta+r_eta.

A negative Phi increment is at most -1 and the correction increase is at most 2a+2, so R drops at least 1. At zero Phi increment the flat-edge queries give the same conclusion. Its deck increments are (2a+3)(-1,2eta), so it is exactly periodic along 2eta U+V. Strict descent is on actual physical edges, not merely on a finite torus. Together with the actual canonical retained-edge interpretation, a finite fort has a minimum-rank vertex with a retained input in the fort, a contradiction.

## Receipts
- `GLOBAL_RANK_INDEPENDENT_REPLAY.json`: thirteen fresh CLI replays with query hashes.
- `GLOBAL_RANK_ALIAS_AUDIT.json`: four independent alias/fold/bound queries, each with producer and fresh CLI verdict.
- `audit_rank_alias.py`: reproducible added checks.

An exploratory query named `free_arcs_native.smt2` is SAT and is NOT a failed necessary premise: it records the false stronger claim that every free seat is literally native. The correct native-FOLD query above is UNSAT.
