# Uniform genuine doubled-ladder forced directions

## Result and normalization

Let K>=1, a=2K+2, and F be the authentic even standard pure2 field (a-1)/(a+1), in exported LL coordinates. Put h=y-x. On the following native classes the actual elementary-square unit propagation forces exactly the direction stated, independently of any free signs. This is a parameter-uniform result, not extrapolation from the numerical closure.

L: h odd, -1<=h<=a-3, 1<=x<=a, y!=a-1, excluding (x,h)=(1,-1).
  Direction S if y<a-1; N if y>a-1.

U: h odd, a+1<=h<=2a-1, 0<=x<=a-1, y!=2a-1, excluding (x,h)=(a-1,2a-1).
  Direction S if y<2a-1; N if y>2a-1.

E: h=a-2, 2<=x<=a. Direction E.

W: h=a, 0<=x<=a-2. Direction W.

Intersect every class with the genuine native domain. These roots are white, not black. No direction is assigned here to a root outside these four classes. In particular the statement does not guess free signs. Any canonical policy satisfying the authentic square clauses must have these directions.

## 1. True source and exact colors

The literal Julia get_doubled_ladder_even uses raw Y=y+1. Its domain is

 -1<=x<=a+1, 1<=Y<=3a-1, -1<=Y-x<=2a+1,

with strips x=-1,Y<=a+1 and x=a+1,Y>=2a-1 removed, and the actual two corners (-1,2a+1),(a+1,a-1) inserted. Its value is

 -floor((h+1)^2/4)+min(0,a-y-1)+max(0,h+1-a)+min(0,2a-y-1)+c(x,y),

where c=1 on the actual diagonal h=a-1,0<x<a and on the two inserted corners, and zero otherwise. No unpad/gauge scalar is changed.

The quadratic-floor term has input Laplacian -1 at even h and 0 at odd h. Thus every full-native star's exact color is computed by the four piecewise-linear correction terms only. This is linear integer arithmetic, including the two parity residues. The verifier does not replace real boundary stars by a continuation of the raw formula.

## 2. Explicit finite induction grade

Assign the following positive integer to a displayed root:

 L: |y-(a-1)| + 1_{x=a,h=a-3};
 U: |y-(2a-1)| + 1_{x=0,h=a+1};
 E: x-1+1_{x=a};
 W: a-1-x+1_{x=0}.

For every such root except the two endpoint stars (0,a),(a,2a-2), there is an incident physical unit square Q with all four incoming stars genuinely native, such that:

 * the indicated root direction points out of Q;
 * every other white corner is one of the four displayed classes;
 * its indicated direction points into Q and its grade is strictly smaller.

Each elementary square requires at least one white corner to point out. Once the earlier directions have been forced, all their literals are false, leaving exactly the target literal. Induction on the positive grade therefore forces the claimed direction. This is the real unit-propagation inference, not a directed-rank substitute or a freely selected policy.

Four unbounded LIA checks verify: candidate white on every full-native star; only the two listed stars can leave the native domain; positivity of grade; existence of the above unit-square witness. Each query quantifies all even a>=4 and all integer x,y. The last query takes the disjunction of all four actual incident squares; it requires exact native guards at every vertex and both of its inputs, exact binary color, and strict grade/direction inequalities. Producer and fresh independent CLI both return UNSAT for all four. Raw queries and SHA256 bindings are in BULK_RECEIPT.json.

## 3. The two genuine off-native endpoint stars

At z=(0,a), the west input (-1,a) is represented by (+U) at (a,2a-1), since U=(a+1,a-1) has true zero primary character. The exact three values are

 F(0,a)=-a(a+2)/4,
 F(1,a)=-a²/4,
 F(-1,a)=F(a,2a-1)=-a²/4-a.

The east value includes the actual diagonal +1. Their Laplacian is zero, so z is white. Use the square with bottom-left z. Its other corners are:

 (1,a), black;
 (0,a+1), class U, direction S, grade a-1;
 (1,a+1), class W, direction W, grade a-2.

Both white directions point inward. Hence west at z is forced at grade a. The genuine standard reflection center is R=U+V+(1,-1)=(a,3a-2); it preserves the physical input graph and colors. Reflecting this square proves the east endpoint z=(a,2a-2), again at grade a. This uses the authentic global zero-primary deck and standard finite/global reflection, not raw off-native evaluation.

## 4. Regression and scope

physical_unit_probe.py reconstructs the true native quotient, computes its colors from the accepted deck extension, and runs literal square-unit propagation without choosing any free signs. For K=1,...,7 its forced directions and exact synchronous first-forcing grades agree with the four displayed formulas. This is discovery/regression only; the uniform argument is Sections 1-3 and the unbounded raw queries.

The proved implication is that every listed direction is genuinely forced for every K. The statement does not yet independently prove that these classes exhaust the full forced set, or identify every remaining native white with the canonical H/V free set. Such exhaustion is unnecessary when applying the displayed directions to roots already located in these classes, but must not be silently asserted for an arbitrary remaining root. The root K=0 is the separate reciprocal 1/3 initialization.
