import sympy as s,json
from pathlib import Path
K=s.symbols('K',integer=True)
def hdiff(a,b):return [s.expand(-(a+b)/2),s.expand((b-a)/2),s.expand(b/s.Integer(2)-a*a/s.Integer(2)+(b-a)**2/s.Integer(4))]
rows={}
for name,a,b,ap,expect in [
 ('P',-1,2*K+1,True,[0,0,K*K+3*K+1]),
 ('D+',-2*K-2,-2*K,False,[2*K+1,1,-2*K*K-5*K-1]),
 ('D-',2*K+2,2*K,False,[-2*K-1,-1,-2*K*K-3*K-1]),
 ('Phi+',-2*K-3,1,True,[2*K+1,1,-K*K-2*K]),
 ('Phi-',2*K+1,4*K+1,True,[-2*K-1,-1,-K*K])]:
 got=hdiff(s.sympify(a),s.sympify(b))
 if ap:got[0]+=K;got[1]-=K+1
 assert all(s.expand(x-y)==0 for x,y in zip(got,expect))
 rows[name]={'shift':[str(b),str(-a)],'affine':[str(s.expand(v))for v in got]}
h=lambda x,y:x*(x-1)//2-(y+1-x)**2//4
for x in range(-6,7):
 for y in range(-6,7):
  assert h(y+1,-x)==-h(x,y)
  q=[(x-1,y),(x+1,y)] if (x+y)%2==0 else [(x,y-1),(x,y+1)]
  assert sum(h(*v) for v in q)==2*h(x,y)
Path(__file__).with_name('ALGEBRA.json').write_text(json.dumps({'symbolic_five_identities':rows,'harmonic_inverse_local_regression':True},indent=2)+'\n')
print('PASS exact five symbolic affine identities; harmonic/inverse local regression')
