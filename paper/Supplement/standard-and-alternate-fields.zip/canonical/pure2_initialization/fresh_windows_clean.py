from pathlib import Path
import concurrent.futures,subprocess,hashlib,json
P=Path(__file__).resolve().parent
def run(p):
 s=subprocess.run(['/tmp/f_lattice_z3/bin/z3',str(p)],capture_output=True,text=True,timeout=210)
 return {'f':str(p.relative_to(P)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'verdict':s.stdout.strip(),'returncode':s.returncode}
if __name__=='__main__':
 files=sorted(p for d in ['windowchecks','cleanchecks','alternate_native']for p in(P/d).glob('*.smt2')); rows=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
  for row in pool.map(run,files):
   assert row['verdict']=='unsat'and row['returncode']==0,row
   rows.append(row)
 (P/'FRESH_WINDOWS_CLEAN_ALT.json').write_text(json.dumps(rows,indent=2));print('fresh',len(rows))
