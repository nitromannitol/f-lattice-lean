# Pure2 global binary admission and every free 3-step return

## Conclusions

For all K>=1 (a=2K+2), the authentic even doubled-ladder standard global field is binary: every physical input Laplacian is exactly -1 or 0. For either prescribed canonical signed policy e_{(-1,eta)}, every free white root z, and its rejected input u, one of the two actual incident unit squares gives three allowed edges u->v->w->z. The square is physical throughout; no vertexwise quotient folding is used.

The stronger statement that all three return tails are nonfree is FALSE. Therefore “private” must not be taken to mean “no other free white corner.” This distinction is relevant if a later argument only pays bulk monotonicity on return tails.

## 1. Binary admission independently of provisional Carbon

The new full_native_binary query proves directly from the literal doubled-ladder formula that delta F is in {-1,0} on every root with its complete incoming star native. This is exact LIA after cancellation of the common quadratic floor. The old partition query separately proves that any native root whose star is not native is either an H/V deck class or one of the two displayed forced endpoint stars.

For H/V classes, arc_star_heights.py already proves the actual entire incoming star has F=0 on H or F=h0 on V, with positive true native aliases and the genuine zero-primary/secondary deck constants. Both 0 and h0 are F-lattice harmonic, so these roots have delta0. The only other off-native stars are (0,a),(a,2a-2); their delta0 was established by the explicit alias calculation and its genuine reflection in UNIFORM_DOUBLED_LADDER_BULK_DIRECTIONS.md. Consequently every native root has delta -1 or0. Authentic native quotient cover and the affine deck character extend the statement to every physical root.

This argument uses the actual source formula and coherent global deck extension/cover, not a prior binary-admission assertion from Carbon, nor recurrence, nor the guessed sign of a black vertex. In particular, all remaining roots in the complete classification really have delta=-1, not merely “delta is nonzero.”

## 2. Full physical return verification

private_returns.py proves four universal gates, one for each arc H/V and each policy Q_b, b=+/-1 from COMPLETE_CANONICAL_CLASSIFICATION.md.

Let (dx,dy) be the actual selected free direction; the rejected displacement is r=(-dx,-dy). For each sign s=+/-1 let p=s*(-r_y,r_x). The two and only two square-return paths are

 z+r -> z+r+p -> z+p -> z.

Each edge is required to be a legal physical input edge at its actual tail parity. Its permission is certified by a positive real native alias offer:

 * a true full-native star with delta=-1, allowing both inputs;
 * one of the proved forced classes with exactly its forced direction;
 * an actual H/V representative with its prescribed Q_b free direction.

All guards and alias constants are retained. At least one entire three-edge path is certified for every parameter and every actual free representative. By deck covariance this covers all physical translates. All four producer and separate fresh CLI runs return UNSAT, alongside the full-native binary gate, in PRIVATE_RETURN_RECEIPT.json.

## 3. Canonical signed-policy mapping

The actual signed e_{(-1,eta)} is the central reflection of Q_b with b=-eta, about R=(a,3a-2). This agrees directly with strong_bulk/replay_strong.py:

 * on H, the selected direction is the positive input except H0, which takes S for eta=+1 and N for eta=-1;
 * on V0 it is E;
 * on internal V, it is horizontal eta at even roots and vertical -eta at odd roots.

To verify the first line, reflection sends H0 to Hlast+Vdeck, so it negates Q_b's final vertical -b and gives b=-eta. Interior H directions W/S become E/N. Reflection sends Vlast to V0+U; interior V reverses and negates Q_b, giving horizontal -b=eta and vertical b=-eta. Endpoint aliases are genuine.

Reflection preserves the physical graph, colors and authentic forced directions. Thus reflecting the four verified Q_b return gates proves exactly the requested e_{(-1,eta)} return gates, with no assumption that a nearby or differently signed policy is equivalent.

## 4. Exact obstruction to nonfree-only return

For a=6 (word22), Q_- at H0=(1,0) selects S and rejects u=(1,1). The valid square return is

 (1,1) [black] -> (2,1) [forced white] -> (2,0) [free white] -> (1,0).

The other possible square traverses (0,1),(0,0) and is not directed under Q_-. Thus there is no allowed three-edge square return with all three tails nonfree. Independent reconstruction from the actual exported original source, true deck field, and full square-unit closure verifies both possibilities in PRIVATE_NONFREE_COUNTEREXAMPLES.json. Three further examples are included. The stronger universal queries are SAT, deliberately retained in NONFREE_PRIVATE_RECEIPT.json; they are not failed proofs of the weaker completed theorem.

Under reflection, the first example gives the requested e_{(-1,+1)} root R-(1,0)=(5,16), with valid return

 (5,15) [black] -> (4,15) [forced white] -> (4,16) [free white] -> (5,16).

This is a concrete warning against applying a bulk-only potential inequality to all three tails. Once all-edge raw monotonicity is supplied independently, this distinction causes no problem for the return comparison.

## Scope

K=0 remains the separate reciprocal root. No canonical strict rank, absence of physical cycles, or alternate recurrence is inferred merely from binary admission and local square returns. Those are separate logical steps.
