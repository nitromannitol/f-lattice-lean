import sys
from pathlib import Path
sys.path.insert(0,'astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review')
from straddle import O,field

def run(K):
 tile=O.export_tile(O.get_odometers('2'*K)[0][1]);F,*_=field(tile,O.getFracs('2'*K)[1]);n=2*K+1;d=n+2;T=d*d+2*d*n-n*n
 key=lambda z:(n*z[0]-d*z[1])%T
 reps={key(z):z for z in tile};ip=lambda z:[(z[0]-1,z[1]),(z[0]+1,z[1])]if sum(z)%2==0 else[(z[0],z[1]-1),(z[0],z[1]+1)]
 white={k for k,z in reps.items() if sum(F(v) for v in ip(z))-2*F(z)==0};clauses=[]
 for z in reps.values():
  x,y=z;S={(x,y),(x+1,y),(x,y+1),(x+1,y+1)};cc=[]
  for v in S:
   if key(v) in white:
    q=next(u for u in ip(v)if u not in S);cc.append((key(v),(q[0]-v[0],q[1]-v[1])))
  assert cc;clauses.append(cc)
 forced={};rank={};round=0
 while True:
  new={}
  for cc in clauses:
   if any(forced.get(k)==v for k,v in cc):continue
   left=[(k,v)for k,v in cc if k not in forced];assert left
   if len(left)==1:
    k,v=left[0];assert k not in new or new[k]==v;new[k]=v
  if not new:break
  round+=1;forced.update(new);rank.update({k:round for k in new})
 dirs={(-1,0):'W',(1,0):'E',(0,-1):'S',(0,1):'N'}
 print('K',K,'round',round)
 for h in sorted({y-x for x,y in tile}):
  row=[]
  for x,y in sorted(tile):
   if y-x==h:row.append(f'{x}:{"B"if key((x,y))not in white else dirs[forced[key((x,y))]]if key((x,y))in forced else "."}')
  print(h,' '.join(row))
 return tile,F,forced,rank,key
if __name__=='__main__':run(int(sys.argv[1]))
