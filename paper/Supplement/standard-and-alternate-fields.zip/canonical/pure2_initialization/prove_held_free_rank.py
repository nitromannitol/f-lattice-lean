from pathlib import Path
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/pure2_initialization')
src=(P/'uniform_bulk.py').read_text().split('G,dx,dy,r=candidate(x,y)')[0];exec(src)
def R(x,y):return z.If(y-x==A-1,2,-2*abs_(y-z.If(y-x<=A-2,A-1,2*A-1))+z.If((x+y)%2==0,1,0))
G,dx,dy,_=candidate(x,y);bad=[]
for ex,ey in [(-1,0),(1,0),(0,-1),(0,1)]:
 X,Y=x+ex,y+ey;g,_,_,_=candidate(X,Y)
 edge=z.Or(z.And(G,dx==ex,dy==ey),z.And(star(x,y),delta(x,y)==-1,z.If((x+y)%2==0,ey==0,ex==0)))
 bad.append(z.And(edge,native(X,Y),z.Or(g,z.And(star(X,Y),delta(X,Y)==-1)),R(X,Y)>=R(x,y)))
s=z.Solver();s.add(A>=4,A%2==0,native(x,y),z.Or(G,z.And(star(x,y),delta(x,y)==-1)),z.Or(*bad));raw=s.to_smt2();(P/'held_free_rank_native_stars.smt2').write_text(raw);print(s.check());print(s.model()if s.check()==z.sat else'')
