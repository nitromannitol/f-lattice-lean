# Endpoint correction to the earlier audit

The prior audit incorrectly endorsed the last CHILD V endpoint measured in PARENT sp. Its true value is sp_p(Vchild+I)=2N-2epsilon, hence2N-2 at W1 and2N+2 at W0. After W0's reflected-frame correction -2, the final value is2N (not2N-2). The aligned boundary protection conclusion is unchanged: these final values are parent-free; only the stated W0 initial endpoint remains exceptional. The earlier endpoint sentence below is superseded.

# Independent final audit of W1_CONSTRUCTOR §§1,3,4

Verdict: no counterexample or arithmetic/sign error found in the requested sections. This checks the parameter calculations and placement reductions; it does not independently reprove the incoming field/strip, price, canonical-private-square, tie-rank or global producer premises.

Audited file SHA256: 1d0eb0ad324b2e2eabd3d80bf8cb9776745641cfc5a1b5b05a1820e688daa9f1

## Section1

The transform coefficients C=D(d+n)+N(d-n), tp=(Ct+epsilon s)/T and sp=(Cs+2epsilon t)/T have the correct signs for epsilon=Nd-Dn. The listed identities Cn=NT-epsilon L, Cd=DT+epsilon(d-n), CL=Lp T-2epsilon n follow directly. C>2d holds even for the smallest proper odd parent1/2.

The odd parent requires its physical parity label for tp mod Tp; retaining it is essential and the text does so. Since Lp,D-N are odd and coprime, sp mod2Tp identifies its full doubled-primary deck quotient and preserves physical parity. All H/V intervals match the true central-word residue spectra.

The exact open interior rectangle uses the cited Pick-count plus full geometric coverage, not coverage alone: those imply distinct interior nonboundary classes. With that fact, each coordinate lies in the complementary free-spectrum interval; the widths less than T give the converse uniqueness. Preserve that count/coverage premise if this paragraph is extracted.

The two lower adjacent-collar sites are exactly(1,1) and(d-1,n); their upper counterparts are genuine central reflections. All are black. Bottom/top collars cannot meet because their y separation exceeds2; left/right cannot meet because their x separation is at least n+1>=4. Thus no strict WHITE belongs to two collars. Unit corner connectors are included rather than replaced by a rectangular tile.

## Section3

The A-frame shift is tp(lv)=(1-W)epsilon, so t*=tp-(1-W)epsilon is correct. In the bottom collar the transformed intervals are precisely even[1-Lp,0] and odd[1-D,N]. For the lower odd endpoint, W1 gives -D+(s-(d-n))/T>-D, while W0 gives -D+1+((d-n)-s)/T>-D using s<T+2-d+n. Integrality yields1-D. The upper bounds use strict inequalities below1 (even) or belowN+1 (odd), not an unjustified real-valued bound0/N.

The inequalities Tp>2Lp-2 and Tp>2D-1 exclude neighboring H sheets; both hold also at1/2. On V, the first following odd site is already tp=-D, below the allowed odd range, and the second is at most-Lp, below the allowed even range. The previous V arc has minimum closest value Lp. Hence only the claimed H0 or V0 primary translates remain.

For W0 right reflection, I-(z-lv)=r-V-Up is correct. Its sp is sp(r)-2 modulo2Tp, and the physical parity is unchanged. The aligned bounds meet only Vlast even sp=2N and H0 odd sp=Lp. H1 has sp=2Lp and the next odd H has sp>=3Lp; the next V sheet begins at2Tp+2-D+N>3D+N. Reflecting back sends Vlast to V0 and H0 to Hlast with genuine deck shifts.

The prescribed inward core returns have the guards proved in CORE_LOCALIZATION_AND_INWARD_RETURNS.md. Bottom x=1 can contribute only the black(1,1); the left terminal collar row only the black V+(2,-1); reflected right exception is(d-1,n). No geometric endpoint is silently classed as a white interior root.

## Section4

Bottom endpoints: n Lp=N L-epsilon gives the floor perturbation -2epsilon l/L, strictly between-1 and1. Residue0 gives tp=Lp only at epsilon+, and tp=0 at epsilon-. These are actual free V endpoint classes of the indicated parity. For an odd doubled-zero midpoint, the no-jump condition gives tp=N+r with0<=r<=D-N; epsilon+ residue0 giving Lp cannot start a zero letter. At Hlast, tp=D+epsilon in the reflected/unshifted frame, so the stated W1 exception is correct.

Vertical endpoints: D(d-n)=(D-N)d+epsilon gives the floor perturbation epsilon l/d. The residual f is the ordinary residue except residue0 at epsilon-, when f=D. The relevant sp=2f-(D-N)-2(1-W) has exactly the ordinary odd V range plus the endpoint value-(D-N), which is Hlast-Up. Zero-letter midpoints have f<=N-1 at W1 and1<=f<=N at W0; their even sp falls in[0,2N]. The initial/final values0,2N (W1) and-2,2N-2 (W0) are correct.

The exceptional W0 initial V0 here is in the REFLECTED r-frame. In physical child coordinates it is R (the pinned p*), and its only neighboring strict candidate is R-(1,1), black. The prose's reference to black(1,1) is valid in that reflected frame; spelling out the physical point would make the endpoint bookkeeping easier to follow. This is a clarification, not a contradiction.

A forced parent's witness has no free corner. Once the active aligned boundary protection is supplied, any boundary contact of its unit square is impossible, except the protected extreme; the latter has no white strict neighbor. The no-double-WHITE-collar result is needed here and has been retained.
