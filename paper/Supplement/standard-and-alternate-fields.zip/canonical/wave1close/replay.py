from pathlib import Path
import collections,itertools,json
P=Path(__file__).resolve().parent;out=[]
def add(z,v):return(z[0]+v[0],z[1]+v[1])
def sub(z,v):return(z[0]-v[0],z[1]-v[1])
def ins(z):return [add(z,v) for v in ([(-1,0),(1,0)]if sum(z)%2==0 else[(0,-1),(0,1)])]
def arc(z,dirs,A,B):
 a=[z];e=[0]+[v for k in range(1,A+B-1)for v in([1]if(k+1)*B//(A+B)!=k*B//(A+B)else[0,0])]+[0]
 for v in e:a.append(add(a[-1],dirs[v]))
 return a
for r in json.loads((P/'native_collar_inputs.json').read_text()):
 n,d,N,D,e=(r[k]for k in ['n','d','N','D','eps']);W=int(e==1);L=n+d;T=d*d+2*n*d-n*n;U=(d,n);V=(n-d,L);R=add(add(U,V),(1,-1))
 data={(x,y):(f,a,c,slot,was)for x,y,f,a,c,slot,was in r['points']}; H=arc((1,0),[(1,0),(1,1)],(d-n)//2,n);vs=arc((0,0),[(0,1),(-1,1)],n,d-n)
 arcs=[H,[add(p,U)for p in vs],[add(p,V)for p in H],vs];bd=set(sum(arcs,[]))
 def geom(z):
  x,y=z;t=n*x-d*y;s=L*x+(d-n)*y
  return (2, L-2,0,2*n)if(x+y)%2==0 else(n,d,2-d+n,L-2)
 def inside(z):
  a,b,c,h=geom(z);x,y=z;t=n*x-d*y;s=L*x+(d-n)*y
  return b-T<t<a and h<s<T+c
 inter={z for z in data if inside(z)};assert len(inter)==T-d-L
 assert not bd&inter; E=inter|bd
 Dct={name:{add(z,v)for z in ac for v in itertools.product([-1,0,1],repeat=2)}&inter for name,ac in zip(['bottom','right','top','left'],arcs)}
 for z in E:assert data[z][0]==min(data[z][1:3])
 def ps(z):return data[z][2]-data[z][1]
 def opts(z,chart):
  w=z if chart else sub(R,z);q=ins(z);slot=data[w][3]
  return q if slot<0 else [q[slot if chart else 1-slot]]
 def white(z):return 2*data[z][0]==sum(data[u][0]for u in ins(z))
 def ffree(z,chart):w=z if chart else sub(R,z);return data[w][3]>=0 and data[w][4]==0
 def sqs(z,u):
  dx,dy=sub(u,z);return [[u,add(u,h),add(z,h),z]for h in [(-dy,dx),(dy,-dx)]]
 chosen={};works={};ncoll=ncf=nties=0
 for z in inter:
  near=[k for k,g in Dct.items()if z in g]
  for face in near:
   sch=face=='bottom'or face==('left'if W else'right')
   assert (ps(z)>=0 if sch else ps(z)<=0)
  if not white(z):continue
  assert len(near)<=1
  if not ps(z):assert opts(z,True)==opts(z,False);nties+=1
  ch=(near[0]=='bottom'or near[0]==('left'if W else'right'))if near else ps(z)>=0
  x=opts(z,ch);assert len(x)==1;chosen[z]=x[0];u=next(v for v in ins(z)if v!=x[0])
  paths=[q for q in sqs(z,u)if set(q)<=inter and all((ps(p)>=0 if ch else ps(p)<=0)for p in q) and all(v in opts(s,ch)for s,v in zip(q,q[1:]))]
  if not ffree(z,ch):paths=[q for q in paths if all(not ffree(p,ch)for p in q)]
  assert paths,(r['word'],z,ch);works[z]=paths
  if near:ncoll+=1;ncf+=int(ffree(z,ch))
 # Native actual W1 unseeded clause replay over all T quotient classes; physical proof order within tile first.
 left=set(chosen);known={};waves=0
 while left:
  pay=[]
  for z in left:
   if any(all(not white(p)or known.get(p)==v for p,v in zip(q,q[1:]))for q in works[z]):pay.append(z)
  assert pay;waves+=1
  for z in pay:known[z]=chosen[z];left.remove(z)
 orient=[(-1,0),(1,0),(0,-1),(0,1)]
 def key(z):return(n*z[0]-d*z[1])%T
 whitekey={key(p)for p in E if white(p)};pk={key(p):sub(v,p)for p,v in known.items()};protected={key(z)for z in bd}
 assert len(protected)==d+L and not protected&pk.keys()
 for z in E:
  sq={z,add(z,(0,1)),add(z,(1,0)),add(z,(1,1))}
  if any(key(p)in pk and add(p,pk[key(p)])not in sq for p in sq):continue
  assert sum(key(p)in protected for p in sq)>=2
 out.append(dict(word=r['word'],classes=T,interior=len(inter),white=len(chosen),tie_white=nties,collar_white=ncoll,collar_parent_free=ncf,contained_unit_waves=waves))
print(json.dumps(dict(PASS=True,rows=out,totals={k:sum(r[k]for r in out)for k in out[0]if k not in('word','contained_unit_waves')}),indent=2))
