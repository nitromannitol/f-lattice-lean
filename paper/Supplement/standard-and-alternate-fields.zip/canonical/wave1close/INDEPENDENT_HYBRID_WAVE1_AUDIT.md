# Independent audit: hybrid tie-first Wave 1

Verdict: the proposed algebraic and finite-induction mechanism is sound under the explicit hypotheses below. It removes the old requirement of using the same parent rank across the tie interface. It does not by itself prove the geometric inward-square or boundary classification hypotheses.

Use Psi=C-A, M=min(A,C), so A is active where Psi>=0. Reverse signs if naming conventions differ. Both parents and M are genuine globally binary fields; M is recurrent. Each parent has a canonical acyclic policy with physical three-edge rejected-input return squares at every white. A-policy Psi is nondecreasing, C-policy Psi nonincreasing. All assertions concern true physical inputs.

## 1. Tie algebra
If M is white at z with A(z)=C(z), then
  0=Delta M(z)<=Delta A(z)<=0,
and similarly for C. Thus both parents are white and M=A=C at BOTH inputs. Start the A-return path at the rejected input. Both endpoints have Psi=0, and Psi is monotone on its three retained edges. Hence the entire square lies in B={Psi=0}. The same holds for C. At its other corners M-white implies parent-white; parent-black implies M-black. Therefore every prerequisite white on that square is another M-white tie.

An M-black tie which is A-white has exactly one unit of loss from the two A input heights to M. If the used square input ties, the other input has Psi<0. A's Psi-nondecreasing policy cannot use that other input, hence retains the equal input. This argument is also valid at a strictly A-active M-black root if the square's input is A-active and the other input is C-active. If both inputs are A-active, A cannot be white while M is black. These facts pay the apparently new black corners without requiring their parent whiteness or a forced child literal.

## 2. Finite physical tie forcing
It suffices that the A rank restricted to B has finitely many values modulo a period which preserves B, and is actually invariant under that period. In particular the rank is bounded ABOVE on all B. On a return path the three other ranks are strictly HIGHER than the target. Induct from the largest rank down, forcing every M-white tie using its actual square and previously forced whites. Black corners need no premise. Every proof is a finite physical tree. No corner is folded separately into a quotient.

The same construction using C forces its direction. The two directions agree because M recurrence supplies square consistency: a recurrent field admits a policy with no finite directed cycle, hence satisfies every elementary-square clause; sound finite unit deductions cannot force opposite literals. This is a consistency use of M recurrence, not an assumption that its policy equals either parent's beforehand.

A nonzero drift along the B period would NOT suffice: a strict rank on an infinite strip can have infinitely ascending prerequisite chains. Thus 'periodic along B' must mean genuine zero drift for the period used to make B finite. The ancestor clean-band argument must establish this exact boundedness, including physical deck shifts.

## 3. Mixed interior forcing after ties
For each remaining child-white strict-interior root choose a genuine parent return square wholly in the strict interior and in that parent's closed active region. Tie whites have already been forced globally in M. For strict-active whites, their parent policy choice is forced by reverse parent-rank induction on the FINITE set of interior strict-active roots; all strict-active prerequisites have larger rank, while tie prerequisites were prepaid. A and C strict regions are disjoint, so this can be two separate inductions, not a comparison of unrelated numerical ranks. In lexicographic language: tie layer first, then reverse own-piece rank.

This uses child=M on the whole CLOSED E. For every strictly interior corner its actual two inputs lie in E, giving actual child/M color equality. An 'inward' square that still contains a boundary corner does not automatically qualify: the exterior input at that corner is not paid by native height equality alone. Likewise global M tie proofs do not automatically become strictly-interior child proofs. For a tie corner used in the native induction, one needs either its proof to lie in the child-valid region, or an independent true child-color transport for every clause in that proof. This is an important separate locality condition.

## 4. Exact boundary stopping, conditional geometry
Suppose ALL interior white literals have finite proofs using only strictly-interior physical squares, and the following actual boundary geometry/color classification is established:
(a) every square meeting boundary in >=2 sites has at least two proposed free white corners;
(b) a square with unique boundary port z either has another unresolved free corner, or its inward input is a strict-interior white w with an actual free input outside that square.
Then no boundary literal can be unit-forced. Indeed a white w adjacent to a free vertex f cannot be forced to reject f by a strictly-interior proof: its last unit witness would contain its rejected edge w->f and hence contain a boundary vertex. Thus w chooses f, which is outward from the square under consideration; that square is already satisfied, not a force on z. If z's inward input itself is free, there are two unresolved literals instead. This proves a fixed point of unseeded unit closure, rather than deriving a contradiction from assumed boundary freeness.

These are local facts about an already produced interior proof, not an appeal to a new terminal rank. However one must check actual colors: merely being a geometric staircase vertex is not enough. In particular 'other free' means an unresolved WHITE whose literal is present in the clause. The stated A/B endpoint and midpoint classification must include last ports, all four connectors and translated copies. This audit does not replace that geometric classification with sampled masks.

## Exact remaining dependency / potential gap
The tie-first GLOBAL M construction is valid. The mixed native induction is valid if every tie prerequisite has a true CHILD finite proof, with strict-interior proof locality if exact boundary stopping is to use Section 4. A global M proof on B may leave E; equality child=M only on E does not transport its colors or clauses there. Even if a separate global child=M theorem transports colors, it does not make that proof strictly interior. Thus global tie agreement alone is not yet the claimed strict-interior W1 producer. A sufficient repair is to prove that tie return squares for interior tie roots are strictly interior, and restrict the same bounded-rank induction to these roots. More generally a source-valid inward prerequisite closure would suffice. This is distinct from the now-paid zero-pitch tie well-foundedness.
