# Complementary collar prices: independent algebra and strip audit

**PASS given the stated actual collar/strict-interior coordinate bounds.** The prices and parent-strip containment follow uniformly from them. The stronger proposed lower parent s bounds are unnecessary: weaker bounds proved below already suffice. This note does not duplicate the Sturmian derivation of the input collar bounds.

Write child n/d=2P+Q, P=N/D, epsilon=N*dq-D*nq=2W-1, L=d+n, c=d-n, T=d²+2dn-n², Lp=D+N. Let

 C=D*L+N*c,
 C*n=N*T-epsilon*L,
 C*d=D*T+epsilon*c,
 C*L=Lp*T-2epsilon*n.

The coordinate changes are tp=(C*t+epsilon*s)/T and sp=(2epsilon*t+C*s)/T. For genuine proper parents, C>max(n,c) and T>2C: the latter follows from T=2C+B(Q,child) with positive bilinear term. These inequalities will make all the remainders below strict.

## Inputs on actual collars

For top z in strict E, put y=z-Vchild. Its bounds are:

 even parity: L-2<t(y)<=2L-2, 2n<s(y)<T;
 odd parity: d<t(y)<=n+2d-2, L-2<s(y)<T+2-c.

For a strict left V-collar point r:

 even: L-2-T<t(r)<2, 2n<s(r)<=2L-2;
 odd: d-T<t(r)<n, L-2<s(r)<=3d+n-2.

These are the supplied true polygon/collar bounds, not guessed height domains. In particular the excluded next top odd level n+2d and excluded next left even level 2L require the genuine strict-interior endpoint exclusions.

## 1. Top price

The authentic cross-branch identity gives

 fC(y+Vchild)=Fp(y-epsilon*Uchild-lv)+deck_child(y),
 F(y+Vchild)=F(y)+deck_child(y), lv=(1-W)Uq.

Since tp(Uchild)=epsilon and tp(lv)=(1-W)epsilon, the parent argument has

    tp'=tp(y)-W,

and the SAME physical parity as y. No unrecorded affine constant remains.

At even y, tp'>-1 in both phases, hence tp'>=0. For epsilon=+1,

 tp'<C(2L-2)/T=2Lp-(4n+2C)/T<2Lp.

For epsilon=-1,

 tp'<C(2L-2)/T-2n/T=2Lp+(2n-2C)/T<2Lp.

Thus 0<=tp'<=2Lp-1, inside the parent's genuine even-parity zero interval [1-Lp,2Lp-1].

At odd y, the upper remainders after subtracting N+2D are respectively

 epsilon=+1: (2-2n-2C)/T<0;
 epsilon=-1: (2-2c-2C)/T<0.

Thus tp'<=N+2D-1, the old full zero-strip upper endpoint. The lower bounds are >D-1 in the plus phase and >D-1-2/T in the minus phase, hence at least D-1 in either case, certainly >=1-D. Therefore the parent value is zero at odd y as well.

The child value F(y) is zero: even t lies in the expanded even-parity interval through 2L-2, and odd t lies in the old zero strip through n+2d-1. Hence fC(z)=F(z) on the ENTIRE stated top collar, not just at white roots.

## 2. Opposite V price, including W1 scalar

Put y=z-W*Uchild. Primary periodicity gives F(z)=F(y). The literal fC expression reduces, modulo the parent's zero-primary Up, to

    fC(z)=Fp(y-Vq)+aq.y+etaq.

For W0 this is direct. For W1 the apparent extra constant is aq.Uchild+2=-2+2=0. The exact harmonic identity h0(y-Vq)=h0(y)-aq.y-etaq then proves fC(z)=h0(y), provided the parent query is in its appropriate h0 region. This checks the full scalar, not merely agreement up to a constant.

For W0, r=z is in the left collar and sp(y-Vq)=sp(r)-2. For W1 let r=Rchild-z in the left collar, I=(1,-1). Then

    I-(y-Vq)=r-2Vp.

Thus sp(I-(y-Vq))=sp(r), with the same parity. The genuine parent identity (Fp-h0)(I-u)=(Fp-h0)(u), followed by its Vp-periodicity, licenses this reflected query; no symmetry of raw finite domains is asserted.

## 3. Parent h0 bounds on the opposite V collar

Define sp'=sp(r)-2 in W0 and sp'=sp(r) in W1. The transformed inequalities yield the following sufficient bounds.

At EVEN r:

 epsilon=+1: sp'>2N-2-4/T, sp'<2Lp;
 epsilon=-1: sp'>2N-2+(2L-4)/T, sp'<2Lp.

Because sp' is even and T>4, this gives sp'>=2N-2 in W1 and sp'>=2N in W0, and sp'<=2Lp-2. Both lie in the OLD even-parity h0 strip [1-2D,2Lp-1]. The stronger W1 lower bound 2N is not needed.

At ODD r, the lower bounds are

 epsilon=+1: sp'>Lp-2+2(c-C)/T>Lp-3;
 epsilon=-1: sp'>Lp-2+(2n-2C)/T>Lp-3.

Since sp' is odd and Lp is odd, sp'>=Lp-2. The upper remainders after subtracting 3D+N are respectively

 epsilon=+1: 2(c-C)/T<0;
 epsilon=-1: (-4c-2C)/T<0.

Thus sp'<=3D+N-2. This lies inside the parent's genuine enlarged ODD-parity h0 interval [2-3D+N,3D+N-2]. Again no strict improvement of the lower endpoint is required.

The child value is h0(y), using the child's genuine old/even or enlarged/odd h0 bounds on the left collar and, in W1, I-reflection plus V-periodicity of F-h0. Therefore fC(z)=F(z) on the opposite V collar.

## 4. Pre-W1 dependency audit

The calculation uses actual admitted parent global fields and their exact deck, reflection and conjugacy; genuine parent parity-strip extensions (derived at the preceding word); the current child's already established coherent deck/reflection and parity-strip extensions; the authentic native F=min(fA,fC) representation/cross-branch identity; and the supplied current polygon collar inequalities.

It does NOT use current unit-square closure, current canonical free choices, current strict rank, current recurrence, or current directional return-path inheritance. The current strip extensions must themselves be derived from the pre-W1 comparison bounds/ancestor chart and the two mutual zero seeds, as in NO_ODD_SLIP_AUDIT.md; if any current strip producer instead invokes current W1, that would be a circular upstream substitution. The argument only licenses the complementary chart's PRICE. It does not itself prove the remaining inward-return geometry or forcing order.

## Diagnostic only

An independent literal constructor calculation found fC=F on all strict radius-one top/opposite-V collar points for words 1,12,13,23,32,11,123,3232. This finite check was not used in the universal inequalities above and is not presented as an all-word geometry proof.
