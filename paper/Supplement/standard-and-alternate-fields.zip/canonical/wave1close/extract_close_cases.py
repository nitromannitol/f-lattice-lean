from pathlib import Path
import json
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review')
exec((P/'policy_square_geometry.py').read_text().split('rows=[]\nfor w in')[0])
D=Path(__file__).resolve().parent
def inp(z):return [add(z,d)for d in ([(-1,0),(1,0)]if sum(z)%2==0 else[(0,-1),(0,1)])]
def slot(z,q):return inp(z).index(q[0])if len(q)==1 else -1
from itertools import product
keepers=['1','12','13','21','23','31','32','11','123','212','3232']
out=[]
for w in keepers:
 mats,_=O.get_odometers(w);p,q=O.getFracs(w)[2:];fr=O.getFracs(w)[1];d,n=fr.denominator,fr.numerator;D1,N=p.denominator,p.numerator;qd,qn=q.denominator,q.numerator;W=w.count('1')%2;eps=2*W-1
 F=ext(O.export_tile(mats[1]),fr,1);Pp=ext(O.export_tile(mats[2]),p,0);lv=((1-W)*qd,(1-W)*qn);t=(qn-qd+eps*qd,qn+qd+eps*qn);c=(qd*qd+2*qd*qn-qn*qn-qd-qn)//2+2*W
 def psi(z):
  x=sub(z,lv);return Pp(sub(x,t))+qn*x[0]-qd*x[1]+c-Pp(x)
 E,bd,H,Vs=polygon(n,d);U=(d,n);V=(n-d,n+d);R=add(add(U,V),(1,-1));A,ass=policy(p,0,Pp,eps)
 def ea(z):return [add(y,lv)for y in A(sub(z,lv))]
 def fc(z):return Pp(sub(sub(z,lv),t))+qn*(z[0]-lv[0])-qd*(z[1]-lv[1])+c
 cap={add(y,(dx,dy))for y in E for dx,dy in product([-1,0,1],repeat=2)}
 # Sufficient data to check Ψ, true physical graphs, exact chart prices, stars.
 pts=[[x,y,F((x,y)),Pp(sub((x,y),lv)),fc((x,y)),slot((x,y),ea((x,y))),int(ass(sub((x,y),lv)))] for x,y in sorted(cap)]
 out.append(dict(word=w,n=n,d=d,N=N,D=D1,eps=eps,points=pts))
 print(w,len(pts),flush=True)
(D/'native_collar_inputs.json').write_text(json.dumps(out,separators=(',',':')))
