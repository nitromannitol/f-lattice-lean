# Exact q-donor arc inclusions: two endpoint repairs, and directed inner boundary

2026-11-19. The pinned full-arc inclusions are false at one endpoint in each phase. The correct statement below is proved by floor residues and is sufficient when the independently proved full incoming H/V halos are used.

Let p=(D,N) odd type and q=(e,r) even type be reduced proper parents with Ne−Dr=epsilon=2W−1. Thus e,r are odd, D+N odd. The even child is (d,n)=(2D+e,2N+r), U=(d,n), Up=2(D,N). Use actual canonical H and V paths, and I=(1,-1).

The exact conclusions are

 W0: H(q) subset H(child),
     V(q)\{Vq+I} subset V(child), but Vq+I is NOT in V(child).
 W1: (H(q)+Up)\{Up+(1,0)} subset H(child), but Up+(1,0) is NOT in H(child),
     V(q) subset V(child).

The exceptional points are nevertheless in the correct directed input halos:

 W0: Vq+I is the NORTH input of Vq+(1,-2), an odd physical child-V vertex;
 W1: Up+(1,0) is the WEST input of Up+(2,0), an even physical child-H vertex.

Both witnesses exist for every proper even q (e>=3). There is no attempt to use the wrong-parity neighbor across a diagonal.

## 1. Exact H floor coding

For an even-type a/b, put L=a+b. The complete doubled-letter vertices of H have x+y=h even, 2<=h<=L−2, and

 y=floor(ah/L), x=h-y.

An odd h strictly between these occurs precisely when the neighboring complete-vertex floors at h−1,h+1 coincide. The initial point is (1,0); the final point is (b,a−1). This is the literal 0 E(c((b−a)/2,a)) 0 path, not an enlarged linear strip.

For q versus child, with Lq=e+r and Lc=d+n,

 n/Lc − r/Lq = 2epsilon/(Lc Lq).

At every even h between2 andLq−2, the q numerator rh mod Lq is a NONZERO EVEN residue. Its distances from0 andLq are therefore at least2. The perturbation |2h/(Lc Lq)| is strictly less than2/Lq, so the complete-vertex floors are identical for both signs. Every internal odd midpoint of the q path is consequently a child midpoint too. The initial point is always common.

At the q final point, h=Lq−1, the preceding complete level Lq−2 has floor r−1. At the next level Lq the child floor is

 floor(r+2epsilon/Lc)=r−1 for W0, r for W1.

Thus W0 includes the q final point as an actual midpoint, while W1 omits it. There are no other missing q-H vertices. The literal H path is invariant as a set under U+I−z (its step word is palindromic). Reflecting the W1 q-prefix assertion in the child H reflection and using U−Uq=Up gives exactly the W1 translated-suffix assertion above. The omitted final q endpoint reflects to Up+(1,0). The next donor point Up+(2,0) is retained, proving the directed-halo repair.

## 2. Exact V floor coding

Put cq=e−r, cc=d−n. Complete V vertices have h=y−x+1=2j, 1<=j<=e−1, with

 -x=floor(cq*j/e), y=2j−1+x.

Again internal odd-h midpoints occur precisely when the two neighboring complete floors coincide. The initial point is0 and final point Vq+I=(1-cq,e+r−1).

The child floor argument at the same j differs by

 cc*j/d − cq*j/e = −2epsilon*j/(de).

Let a=(cq*j mod e), so 1<=a<=e−1 because gcd(cq,e)=1. The determinant gives cq D ≡ epsilon (mod e).

If epsilon=+1, j is the positive residue of Da modulo e, hence j<=Da. Consequently 2j<da, and the negative perturbation cannot cross the lower integer: a/e−2j/(de)>0.

If epsilon=−1, j is the positive residue of D(e−a) modulo e, hence j<=D(e−a). Consequently 2j<d(e−a), and the positive perturbation cannot cross the upper integer: a/e+2j/(de)<1.

Thus all internal complete floors agree, and so do all q internal odd-h midpoints. Initial0 is common. At h=2e the child complete floor is

 floor(cq−2epsilon/d)=cq−1 for W1, cq for W0,

whereas the preceding complete floor at h=2e−2 is cq−1. Therefore the last q midpoint is included exactly for W1. In W0 the preceding point Vq+(1,-2) remains included and its north input is the missing endpoint. Its coordinate sum is2r−1, odd, so this is a genuine directed input.

## 3. Explicit literal witnesses against the pinned inclusions

At word1, p=1/2,q=1/3,W1, child3/7. The translated Hq begins at(5,2), which is not on childH (nearby vertices are(5,1),(6,2),(7,2)). It is the west input of(6,2).

At word32, p=1/4,q=1/3,W0, child3/11. The q-V final point(-1,3) is not on childV; it is the north input of the common preceding point(-1,2).

These are exact word/path witnesses, not counterexamples to boundary VALUE equality. The full source H/V halos repair precisely the omitted points. The W0 V endpoint is never the special external point(-1,0), since its y=e+r−1>=3.

## 4. The closed donor polygon's directed inner boundary

Let E(q) be the genuine closed polygon bounded by Hq, Vq+Uq, reversed Hq+Vq, and reversed Vq, with the four usual connecting edges. Every path edge has displacement(1,0),(1,1),(0,1), or(-1,1); every connector is a unit horizontal/vertical edge. In particular each edge is primitive and has no extra lattice point in its relative interior.

A horizontal/vertical unit edge between lattice points cannot cross the relative interior of any of these boundary edges: its intersection with a slope+/-1 boundary edge is at integer ordinate/abscissa, hence at a lattice endpoint. Nor can it cross a unit axis-aligned boundary edge transversally except at its lattice endpoint. Thus a strictly interior lattice point cannot have a nearest-neighbor input outside the CLOSED polygon: such a step would have to cross the boundary away from its endpoint. It follows that every directed INNER-boundary center lies among the four closed arc vertex sets. The connector endpoints are already included, and connectors contain no additional lattice sites.

This proves the containment needed for recurrent comparison, not the stronger and unnecessary assertion that every arc vertex is a directed inner-boundary point. It uses the usual established simple closed-polygon interpretation of E, not a filled arithmetic bounding rectangle.

## 5. Repair to C0 boundary comparison

For W0, the child V-left full-source halo pays h0 also at the one omitted donor V endpoint. For W1, the child H full-source halo pays0 at the one omitted translated H endpoint. All remaining donor arc points use literal arc inclusions proved above. The W1 donor-right arc uses Vq subset Vchild and the exact reflection/harmonic computation in C0_REFLECTION_AND_BOUNDARY.md. Difference reflection then pays the other two donor arcs; the inner-boundary lemma in section4 permits two-sided recurrent comparison on all E(q)+WUp.

Therefore the C0 value proof can be repaired without proving polygon nesting and without current strip propagation, PROVIDED the genuine preperiodization H-zero and V-h0 full incoming halo statements have already been established. Root-only arc values would not suffice at these exact endpoints. No V full-star arithmetic or all-word recurrence claim is added here.
