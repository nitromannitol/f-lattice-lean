# Basic q donor: exact reflection and boundary reduction before strip propagation

Independent audit, 2026-11-19. The value argument closes once the preperiodization CHILD H-zero and V-left-h0 boundary statements, the genuine Christoffel arc inclusions, and global recurrent/admitted M are supplied. No current global F strip is needed. The stronger geometric inclusion E(q)+WUp subset E(child) is NOT proved just by this argument and is not necessary for the two-sided value comparison.

Use p=(Dp,Np), q=(dq,nq), Up=2p, Uq=q, Vq=(nq-dq,nq+dq), epsilon=2W-1, I=(1,-1), eta_q=(Tq-dq-nq)/2. Set lv=(1-W)Uq, e=Vq+epsilon Uq, ce=eta_q+2W,

 A(z)=Fp(z-lv), C(z)=Fp(z-lv-e)+aq·(z-lv)+ce,
 M=min(A,C), C0(z)=Fq(z-WUp).

## 1. Exact difference involution

Let R0=Uq+Vq+I+2WUp and z=u+WUp. Then, with x=z-lv,

 (R0-z-lv)+x=e+I+2WUp.

Genuine Fp(I-y)=Fp(y) and Up-periodicity imply A(R0-z)=Fp(x-e). As aq·Up=-2epsilon and aq·Uq=0,

 A(R0-z)=C(z)-aq·u-eta_q.

Applying the same involution gives C(R0-z)=A(z)-aq·u-eta_q (the consistency constant is aq·Rq=-2eta_q). Thus

 M(R0-z)=M(z)-aq·u-eta_q.

The genuine Fq reflection gives exactly this increment for C0. Therefore C0-M is R0-invariant on ALL physical points, not merely boundary points. The +2W in ce and doubled Up are essential. No current-child periodicity or native identification is used.

## 2. Two authentic boundary arcs are enough, including endpoints

On Hq+WUp, genuine old Fq=0. If the actual Christoffel inclusion Hq+WUp subset Hchild and the independently proved preperiodization M=0 on Hchild hold, this gives C0=M on the WHOLE lower donor arc, endpoints included.

For W0, the other arc is Vq subset Vchild. Genuine old Fq(v)=h0(v) and preperiodization M(v)=h0(v) on Vchild give equality, including V0=0 and Vend=Vq+I.

For W1, use the RIGHT donor arc, not its left arc:

 z=v+Uchild=v+Uq+Up, v in Vq.

Then C0(z)=Fq(v+Uq)=Fq(v)=h0(v). To evaluate M at z, do NOT assume that M is globally Uchild-periodic. Instead child reflection Rchild=Uchild+Vchild+I maps z to x=Vchild+I-v, which is the reversed CHILD left V arc when v lies in the genuine initial Vq subarc. Therefore M(x)=h0(x). The exact harmonic identities give

 h0(Vchild+I-v)=h0(v-Vchild)=h0(v)-achild·v-eta_child.

Child reflection, with achild·Uchild=0, now yields M(z)=h0(v). This includes v=0 and v=Vq+I. Hence the right donor arc is paid without current-periodization or global zero/h0-strip propagation.

Finally R0 reflects the donor lower H to its upper H and swaps donor left/right V. The difference invariance pays both remaining arcs. Every donor boundary endpoint is in this argument; no strict-arc exemption is needed. One must retain the genuine fact that the full directed INNER boundary of E(q) is contained in these four closed arcs. A geometrical polygon boundary alone is not a substitute for that established directed-boundary characterization.

## 3. Recurrent comparison and use of actual native source

Assume old Fq and M are BOTH recurrent global admitted fields, as required by the intended Stage2-before-Stage4 order. Affine even translation preserves this for C0. Two-sided comparison on E0=E(q)+WUp then proves C0=M throughout E0. The comparison requires only that E0 is finite and its incoming INNER boundary is paid. It does NOT require E0 subset E(child), since both compared fields are globally admitted.

For actual uncorrected q-source identification additionally use the genuine old native containment Dq subset E(q), with the authentic zero-jet and calibrated scalar at WUp. Then the entire actual donor is covered by the proved E0 equality. This is different from replacing Dq by a full arithmetic hull.

## 4. Exact remaining geometric/inductive inputs

This audit has not independently proved the Christoffel assertions

 Hq+WUp subset Hchild,   Vq subset Vchild,

or the full polygon nesting E(q)+WUp subset E(child). The first two suffice for the boundary-value proof above and must come from the true parity-sensitive word concatenation, not a raw parent t/s-width comparison. The latter is strictly stronger and is not a consequence merely of the two visible arcs or difference reflection; R0 need not preserve E(child). For applications specifically needing polygon nesting, verify all four donor arcs lie in the child polygon (then Jordan/no-hole geometry yields nesting), or give a parity-row containment proof. Neither current value equality nor Tchild>Tq licenses that inference.

Likewise, the V-left SOURCE h0 statement used in section2 must already be proved before current strip propagation. If only global current F=h0 is available, using it here would be circular. The recent independent source-boundary route can supply it, but its source/halo premises must remain in the dependency graph. This note does not duplicate V full-star arithmetic.

Conclusion: no algebraic or endpoint defect found in the C0 difference involution and the two-arc recurrent comparison. The pinned W1 printed notation conflates the donor right point with its unshifted v; the explicit z=v+Uchild computation above fixes it without changing the conclusion. Full donor-polygon nesting remains a distinct geometric obligation if not separately authenticated; it is unnecessary for native value identification once actual Dq subset E(q) is known.
