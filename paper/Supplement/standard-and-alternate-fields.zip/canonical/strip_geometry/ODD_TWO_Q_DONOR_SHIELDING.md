# Two genuine q donors in an odd child: exact shielding

Let w=u s 2^k, with s the last1 or3, k>=0. The fixed even q=2r+qold was created at u; r=(D,N), q=(d,n), eps0=det(r,q) in the convention N d−D n. Put eps=2W−1. If s3, p=r+kq and eps=eps0; if s1, p=(k+1)q−r and eps=−eps0. All vectors here are denominator/numerator, U_r=2r, U_q=q, V_r=(N−D,D+N), and similarly Vq. Write T_r=D²+2DN−N², L_r=D+N, c0=(T_r−eps0 L_r)/2. The old intrinsic chain is

 Phi_eta(x)=Fq(x)−Fq(x+eta eps0 U_r−eps0 V_r)−eps0 a_r.x.

The current first q donor is at W Up. In its actual source coordinate x=z−W Up its relative price is exactly the supplied source formula

 Psi(x)=Fq(x−Vp+eps Up)−Fq(x)+a_p.x+(Tp−Lp)/2+2(1−W).

This note checks its reduction and inequalities; it does not derive that original constructor formula or infer its scalar from matching characters.

## 1. Four exact birth identities
At k0, with Rq=Uq+Vq+(1,−1), the identities are

 W1,s3: Psi=c0−Phi_plus(x);
 W1,s1: Psi=c0+2−Phi_plus(x);
 W0,s1: Psi=c0+1−Phi_minus(Rq−x);
 W0,s3: Psi=c0−1−Phi_minus(Rq−x).

These hold on the entire physical plane, not merely on native sites. They follow from the genuine primary0, secondary cV=−(Tq+Lq)/2 and finite reflection
 Fq(Rq−y)=Fq(y)−a_q.y+(Lq−Tq)/2.
In particular the BACKWARD V constant is (Lq−Tq)/2, not its negative. The script audit_odd_q_constants.py expands all four constants independently. Its residual polynomials are multiples of N d−D n−eps0, and vanish exactly with the correct old sign. No source support is needed for these global old-field identities.

Increasing k by1 changes the argument by eps2Uq−Vq. The secondary law cancels the added a_q.x and the quadratic constant increment, leaving exactly2 because det(p,q)=eps. Thus Psi_k=Psi_0+2k at fixed physical x. Moreover Psi_k(x+Uq)=Psi_k(x)+eps. These are the two actual donor copies, with the same old Fq value by its primary0. No scalar is recalibrated separately for the second copy.

## 2. The required negative-V sign lemma
Use strictly earlier true native cover, native 0<=Dplus<=2, old ordinary zero strip, and true deck characters Dplus(Uq)=0,Dplus(Vq)=2. Then

 t_q(z)>=n+1 implies Dplus(z)<=0.

Indeed choose a genuine native representative y=z+aUq+lVq. Its t is t(z)−lTq. The actual parity upper bounds t(y)<=d (odd), t(y)<=Lq−2 (even), with Tq larger than those bounds, exclude l<0. If l>=1, Dplus(z)=Dplus(y)−2l<=0. If l0, then t(y)>=n+1 and t(y) is at most those native upper bounds. Since t_q(sigma)=−2, BOTH y and y+sigma lie in the genuine ordinary zero strip [1−d,n+2d−1]; hence Dplus(y)=0. All deck shifts preserve physical parity. This is a sign extension by the negative-V semigroup, NOT an assertion that Fq itself remains zero on an infinite half-plane. Native quotient coverage and the native D range are indispensable earlier inputs. Pure base domains use their authenticated cover and ordinary zero strip; the same upper bounds and T inequality hold for their actual polygons.

## 3. Entire native donors in the s1 cases
The earlier genuine boundary/max principle gives max_Eq Phi_plus<=c0+2 and max_Eq Phi_minus<=c0. The mate's admission, needed for that earlier maximum principle, remains part of the earlier stage, not an inference from recurrence alone. Reflection Rq−Eq=Eq is the actual closed-polygon reflection, including its exceptional corners.

Thus W1,s1 first price>=0 and second>=1. W0,s1 first>=1 and second>=0. All k extensions only improve these bounds by2k. No near-bottom restriction is needed here. Literal pure corner offsets are included in the prior maxima: reciprocal root plus has H0=1,Vmax3,c0=1; near-one plus has V0 one above H0 but Vmax only H0+2. One must not replace those facts by a false universal H0=V0 equality.

## 4. Near-bottom donors in the s3 cases
Restrict the actual first-copy query x to Eq and t_q(x)>=1−d. The mixed positive bilinear size C_r=−t_q(Vr)=(d+n)D+(d−n)N satisfies C_r>=Lq (also for endpoint r=(1,0), with equality). Since eps0=eps in s3, the required shifted point in BOTH phases is y=x−Vr: in W1 y=x−vprime, and in W0 y=x+vprime. Therefore t_q(y)>=1−d+Lq=n+1, so section2 applies.

For W1 use the exact decomposition
 Phi_plus(x)=P(x)+Dplus(x−vprime).
Native P(x)<=c0 and the sign lemma give Phi_plus(x)<=c0, hence first Psi>=0 and second Psi>=1.

For W0 put z=Rq−x. The exact physical reflection identity is
 Dminus(Rq−y)=Dplus(y)−2.
Apply it to y=x+vprime, so Rq−y=z−vprime. The actual dual decomposition yields
 Phi_minus(Rq−x)=P(Rq−x)+Dplus(x+vprime)−2<=c0−2.
Consequently first Psi>=1 and second Psi>=0. This uses P only at Rq−x IN Eq. It does NOT assume a price bound at the shifted point x−Vr, which need not be native. This distinction removes a spurious extra guard.

Again k adds2k. The second copy is treated at x+Uq, but its price was transported exactly from x; there is no requirement that x+Uq itself belong to Eq.

## Conclusion and limits
On both corresponding real q-donor subsets, the competing source is no smaller than the q source. Hence the actual coherent minimum equals that q source there. For s1 this holds on both full Eq copies; for s3 this proof claims only the specified near-bottom portions. It does not claim all-source retention, current global recurrence, or equality on incoming halos outside those portions.

All induction inputs are strictly earlier: actual native cover/geometry, old binary field and strips, native P/D ranges, chain mate admission, signed trace maxima and genuine reflection/decks. In particular using the current odd strip to establish one of these old inputs would be circular. The proof here is symbolic algebra plus exact geometry; no finite test is substituted for a uniform assertion.
