# Uniform near-bottom two-donor cover

## 1. A genuine restricted-collar lemma

For any reduced proper fraction a/b, put mu=1 if a,b are both odd and mu=2 otherwise. Every EVEN physical point (x,y) satisfying

 1<=x<=mu b,       1-b<=a x-b y<=a+b-1

belongs to the genuine closed standard polygon E(a,b).

Proof. Integrality gives 0<=y<=mu a: the minimum of (a x-(a+b-1))/b at x=1 is greater than -1, and the maximum of (a x-(1-b))/b at x=mu b is less than mu a+1. Within this rectangle, left V is at x<=0, right V starts at height mu a, and top H starts at height a+b>mu a. Thus only the bottom H can obstruct membership. At an even antidiagonal m=x+y, its actual paired-path vertex has y_H=floor(a m/(a+b)). The inequality a m-(a+b)y<=a+b-1 implies y>=floor(a m/(a+b)). The point is therefore on or above the true bottom boundary. At m=mu(a+b), the rectangle contains only the upper right corner (mu b,mu a), which belongs to right V; m=0 is impossible. All other even m in the rectangle lie in the actual H antidiagonal range. This proves closed membership, including the junction and endpoint rows, without a guessed whole-tile rectangle.

## 2. Child representatives and actual donor assignments

Let odd p=N/D, even q=nq/dq be proper Farey parents, epsilon=N*d-D*n=+/-1, (n,d)=2(N,D)+(nq,dq), W=(1+epsilon)/2. Let L=d+n, Lp=D+N, Lq=dq+nq. Thus Lp>=3, Lq>=4; Lp is odd and Lq even.

For every EVEN integer t in [1-d,L/2], choose the unique x in[1,d] with nx=t mod d and put y=(nx-t)/d. The point is even since n,d are odd and t is even. Assign it to a donor by its physical x coordinate:

 W1: if x<=2D, use E(p); otherwise use E(q)+Up.
 W0: if x<=dq, use E(q); otherwise use E(p)+Uq.

These are exactly the two donors E(p)+lv and E(q)+W Up, lv=(1-W)Uq. Their horizontal ranges meet consecutively without a missing integer column.

## 3. All four inherited transverse bounds

The following arguments show that the selected donor-coordinate point has its own transverse coordinate in [1-b,a+b-1], so section1 applies. Its donor x coordinate is automatically in[1,mu b]. All shifts preserve parity.

For p, use D L=Lp d-epsilon.

 W1, x<=2D: tp=(D t+x)/d. At the lower endpoint tp>-D, hence tp>=1-D. At the upper endpoint tp<Lp/2+1, hence tp<=(Lp+1)/2<=Lp-1.

 W0, x>=dq+1: after subtracting Uq, tp=(D t-x)/d+1. Its lower bound is -D+(D-x)/d+1>-D since x<=d. Its upper bound is Lp/2+1+(1/2-x)/d<Lp/2+1, giving the same integer upper bound.

For q, use dq L=Lq d+2epsilon.

 W0, x<=dq: tq=(dq t+2x)/d. Its lower bound is >-dq. Its upper bound is Lq/2+(2x-1)/d<Lq/2+2. Since Lq is even this gives tq<=Lq/2+1<=Lq-1.

 W1, x>=2D+1: after subtracting Up, tq=(dq t-2x)/d+2. Its lower bound is -dq+(dq-2x)/d+2>-dq since x<=d. Its upper bound is Lq/2+2+(1-2x)/d<Lq/2+2, giving the same integer upper bound.

All bounds are non-strict at the required final integer endpoints; the intermediate strict inequalities are what license the rounding. Hence EVERY representative belongs to its designated actual donor. No exceptional junction pixels remain.

## 4. Height consequence and limits

On each chosen donor-coordinate point the inherited ordinary zero strip gives donor height0. Therefore, if the previous recurrent C0 equality on E(q)+WUp and the actual p-donor shielding/equality on E(p)+lv have independently been proved, this cover yields current F=0 for every EVEN transverse t in [1-d,L/2]. Current primary periodicity then removes the representative choice. Any subsequent reflection or parity-extension step must use its separately established genuine identity.

This is a geometry theorem with an explicitly conditional height consequence. It does not assert the donor equalities from geometry, nor cover all points of the full child tile.

## Diagnostic independence

The attached finite diagnostic checks the proposed representative and the true polygon membership for twelve varied actual words; no misses occurred. The proof above is parameter-uniform and does not rely on this sample. A separate scratch check of section1 for all reduced fractions with denominator<=21 found no failures. The saved finite diagnostic is supplementary, not the theorem's justification.

## 5. All-parity strengthening (supersedes the even-only restriction)

For either standard type, the genuine bottom path has exactly one vertex H(x) at each integer x=1,...,mu b, since every horizontal or diagonal step increases x by one. Its transverse value is STRICTLY positive. For odd-type parents its even/odd spectra are [1,a+b-1] and [a,b]; for even-type they are [2,a+b-2] and [a,b]. In particular no t_H=0 endpoint is present: H0 has t=a>0 and Hlast has t=b>0.

Every physical point of EITHER parity satisfying

 1<=x<=mu b,       1-b<=t=a x-b y<=b

belongs to genuine E. Indeed integrality again gives 0<=y<=mu a. If it were strictly below H(x), integer y would be at most y_H-1, forcing t>=t_H+b>b, contradiction. The side/top argument in section1 is unchanged. Thus the stronger parity-free lemma does not require an even antidiagonal vertex.

The four donor bounds in section3 actually prove the sharper upper bounds needed here:

 tp<=(Lp+1)/2<=D, since D-N>=1;
 tq<=Lq/2+1<=dq, since dq-nq>=2.

These inequalities apply to ALL integer child t in [1-d,L/2], without assuming its parity. Their representative still has integral coordinates but now has whichever physical parity t dictates. Consequently the entire interval, both parities, is covered by the designated donor in section2. The same parity-free lemma for the CHILD, using t<=L/2<d and x in[1,d], also proves that the actual chosen representative lies in genuine Echild. Therefore F=M or donor agreements are being used at actual child sites, not unsupported exterior representatives.

With the same separately paid donor height premises, the zero-height consequence holds for BOTH physical parities throughout [1-d,L/2]. This does not use an unproved enlargement of the zero strip: each donor t lies in the already-existing ordinary interval[1-b,b], itself contained in its ordinary zero strip.
