# Odd standard near-bottom donor cover: both parities, all proper parameters

This proves the geometry left open in ODD_ZERO_AND_VERTICAL_STRIP_REDUCTION.md. The near-one parent exception is handled arithmetically, not by finite cases.

Let p=N/D be proper odd type and q=a/b proper even type, with epsilon=N b-D a=+/-1, W=(1+epsilon)/2. Put n0=N+a, d0=D+b, L0=n0+d0, Lp=N+D, Lq=a+b, Up=2(D,N), Uq=(b,a). The odd child has doubled primary Up+2Uq.

For every integer t in [1-d0,L0/2], there are TWO representatives (x,y) with 1<=x<=2d0 and n0*x-d0*y=t. They differ by (d0,n0), which flips physical parity because n0+d0 is odd. Both are required and both are covered below.

## 1. Actual donor assignment

W1: columns1,...,2D go to E(p); the next b columns go to E(q)+Up; the final b columns go to E(q)+Up+Uq.

W0: columns1,...,b go to E(q); the next b to E(q)+Uq; the final2D to E(p)+2Uq.

Every donor-coordinate x therefore lies in[1,mu*denominator], with mu=2 for p and1 for q. The primary shifts preserve parity. These are the actual three donor polygons, not an enlarged rectangular substitute.

## 2. Uniform inherited transverse coordinates

At the assigned p point,

 tp=(D t+epsilon x)/d0+2(1-W).

At either assigned q point (the second Uq translation does not change tq),

 tq=(b t-epsilon x)/d0+2epsilon W.

Use D L0=Lp d0-epsilon and b L0=Lq d0+epsilon.

Lower bounds: for W1 p, tp>=-D+(D+x)/d0>-D. For W0 p, tp>=-D+(D-x)/d0+2>-D since x<=2d0. For W0 q, tq>=-b+(b+x)/d0>-b. For W1 q, tq>=-b+(b-x)/d0+2>-b. Integrality gives tp>=1-D and tq>=1-b in every case.

Upper q bounds: W0 has x<=2b, hence
 tq<=Lq/2+(x-1/2)/d0<Lq/2+2.
W1 has x>=2D+1, hence
 tq<=Lq/2+2+(1/2-x)/d0<Lq/2+2.
Since Lq is even and b-a>=2, integrality gives tq<=Lq/2+1<=b.

Upper p bounds: W1 has x<=2D, giving
 tp<=Lp/2+(x-1/2)/d0<Lp/2+2.
W0 has x>=2b+1, giving
 tp<=Lp/2+2+(1/2-x)/d0<Lp/2+2.
Since Lp is odd, these imply tp<=(Lp+3)/2<=D whenever D-N>=3.

The only remaining possibility is D-N=1. Then the determinant reads b=D(b-a)-epsilon, so b>=2D-epsilon (proper even q has b-a even and>=2).
 * W1: d0>=3D-1 and (2D-1/2)/d0<1, hence tp<Lp/2+1=D+1/2, so tp<=D.
 * W0: b>=2D+1, and 2+(1/2-x)/d0<=2-(2b+1/2)/d0<1, hence again tp<Lp/2+1=D+1/2 and tp<=D.
Thus in all cases tp in[1-D,D] and tq in[1-b,b]. The smallest proper odd parent1/2 satisfies these same strict inequalities; no tip exception is omitted.

## 3. Genuine polygon membership and zero-height consequence

The parity-free restricted-collar lemma in section5 of NEAR_BOTTOM_TWO_DONOR_COVER.md says that 1<=x'<=mu B and 1-B<=A x'-B y'<=B imply actual membership in E(A/B). It rests on the strictly positive native H transverse values, not on a parity guess. Section2 therefore proves membership in the assigned genuine donor for BOTH representatives.

Applying the same lemma to the child, using x<=2d0 and t<=L0/2<d0, also proves actual membership in E(p0). Thus the height comparisons are invoked only at genuine child sites.

If the earlier recurrent p-donor equality on E(p)+2(1-W)Uq and the actual A-branch shielding on both q donors are independently paid, each donor height is zero by its ordinary strip. Hence the current odd field vanishes for both parities at every t in[1-d0,L0/2]. True primary periodicity then removes the representative restriction.

True central reflection t->L0-t extends this to the complete ordinary zero strip[1-d0,n0+2d0-1]. This reflection is an explicit height premise of the consequence; geometry alone cannot supply it. The two intervals meet, since the integer half-interval and its reflection exhaust the whole integer range.

## 4. Even h0 by the genuine quarter turn

For the complementary even child n/d, set A=(d-n)/2, B=(d+n)/2 and K(x,y)=(y+1,-x). Then

 t_odd(Kz)=(s_even(z)+d-n)/2,
 F_even(z)-h0(z)=F_odd(Kz).

The ordinary odd zero strip[1-B,A+2B-1] corresponds EXACTLY to all physical sites in the even h0 strip[1-2d,2(d+n)-1], since s_even is even. Thus the completed odd strip pays the even h0 strip, PROVIDED the actual constructor/extension quarter-turn identity is independently established. This is a simultaneous-height consequence with explicit premises, not an assumption of literal native recognition.

## Status

The three-donor geometry, all parities and near-one arithmetic are proved uniformly. No finite census or unproved whole-tile donor cover is used. The remaining height inputs are exactly the older p-donor comparison, both q-donor shielding equalities, genuine reflection/periodicity, and genuine quarter-turn identification.
