from pathlib import Path
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review')
exec((P/'policy_square_geometry.py').read_text().split('\nrows=[]\n')[0])
s=(P/'policy_square_geometry.py').read_text();s=s[s.index('def polygon(n,d):'):s.index('def policy(')];s=s.replace('def polygon(n,d):','def poly(n,d,mu=1):').replace('U=(d,n);','U=(mu*d,mu*n);').replace('edges((d-n)//2,n)','edges(mu*(d-n)//2,mu*n)');exec(s)
rows=[]
for w in ['1','23','32','12','21','123','321','3232','111','112','33332','22223']:
 _,fr,p,q=O.getFracs(w);n,d=fr.numerator,fr.denominator;N,D=p.numerator,p.denominator;nq,dq=q.numerator,q.denominator;W=w.count('1')%2;lv=((1-W)*dq,(1-W)*nq);qu=(W*2*D,W*2*N)
 Ep=poly(N,D,2)[0];Eq=poly(nq,dq)[0];cover={add(v,lv) for v in Ep}|{add(v,qu)for v in Eq};E=poly(n,d)[0];miss=[]
 for t in range(1-d,(n+d)//2+1):
  if t%2:continue
  x=(pow(n,-1,d)*t)%d;x=x or d;y=(n*x-t)//d;z=(x,y)
  if z not in cover:miss.append(dict(t=t,z=z,in_child=z in E,junction_x=(2*D if W else dq)))
 rows.append(dict(word=w,n=n,d=d,p=str(p),q=str(q),W=W,miss=miss));print(w,miss[:12],len(miss))
Path('/tmp/stripdonor.json').write_text(json.dumps(rows,indent=2))
