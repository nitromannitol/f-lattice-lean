import sympy as s
D,N,e,f=s.symbols('D N e f',integer=True)
r=s.Matrix([D,N]);q=s.Matrix([e,f]);Vr=s.Matrix([N-D,D+N]);Vq=s.Matrix([f-e,e+f]);ar=s.Matrix([N,-D]);aq=s.Matrix([f,-e]);I=s.Matrix([1,-1]);R=q+Vq+I
T=lambda v:v[0]**2+2*v[0]*v[1]-v[1]**2
L=lambda v:sum(v)
eta=(L(q)-T(q))/2
for W,kind in [(1,3),(1,1),(0,1),(0,3)]:
 eps=2*W-1;eo=eps if kind==3 else -eps
 p=r if kind==3 else q-r; co=(T(p)-L(p))/2+2*(1-W);c0=(T(r)-eo*L(r))/2
 wp=eo*(2*r-Vr);wm=eo*(-2*r-Vr)
 C=co if (W,kind)==(1,3) else co-aq.dot(wp)+eta if W else co+eta-ar.dot(R) if kind==1 else co-aq.dot(wm)+ar.dot(R)
 expected=c0+{(1,3):0,(1,1):2,(0,1):1,(0,3):-1}[W,kind]
 diff=s.factor(C-expected); print(W,kind,diff, 'det-reduced',s.simplify(diff.subs(f,(N*e-eo)/D)))
# step k increment using delta_p=-Vp+eps2p, delta+=eps2q-Vq
# F(x+delta+eps2q-Vq)-F(x+delta)= -aq.(x+delta+eps2q)+eta
# aq.q=0; co increment = bilinear(p,q)+Tq/2-Lq/2
for eps in [-1,1]:
 p=s.Matrix(s.symbols('a b'));delta=-(s.Matrix([p[1]-p[0],sum(p)]))+eps*2*p
 inc=s.expand(-aq.dot(delta)+(T(p+q)-T(p))/2-L(q)/2+eta)
 print('inc',eps,s.factor(inc))
