# Odd zero / even h0 strip: exact next reduction and donor obligations

The all-parity even-child cover is proved in section5 of NEAR_BOTTOM_TWO_DONOR_COVER.md. The following records the precise next geometry/height gate; it is NOT yet a proof of the odd cover.

## Quarter turn fixes the exact interval

For an even fraction n/d, its odd conjugate is a/b=(d-n)/(d+n), reduced by2: a=(d-n)/2, b=(d+n)/2. Let K(x,y)=(y+1,-x). The genuine native V path maps to the entire odd conjugate H path, with endpoints (1,0) and (d+n,d-n-1). Its transverse coordinate is

 t_odd(Kz)=(s_even(z)+d-n)/2.

Since s_even is even on all physical integer sites, the even h0 strip 1-2d<=s<=2(d+n)-1 is EXACTLY equivalent to the ordinary odd zero strip

 1-b <= t_odd <= a+2b-1.

The actual value identity is F_even(z)-h0(z)=F_odd(Kz), because h0(Kz)=-h0(z). Therefore an authenticated simultaneous constructor conjugacy plus the odd zero strip pays the even h0 strip, but simply quoting this equality cannot remove the need to establish one side independently. It is an exact interval and value reduction, not a proof of native recognition.

## Natural three-donor odd cover

For odd child p0=p(+)q, its genuine primary is Up+2Uq. The consecutive horizontal donor blocks are

 E(p)+2(1-W)Uq,
 E(q)+WUp,
 E(q)+WUp+Uq.

In W1 they occur p,q,q; in W0 they occur q,q,p. A complete near-bottom cover would put each physical-parity representative of every t in[1-d0,(d0+n0)/2] inside their union AND inside E(p0). There are two representatives modulo the doubled primary: x in[1,2d0] with n0*x=t mod d0; their physical parities are opposite. Both must be treated.

The actual older-height premises would be:
 * previous recurrent comparison identifies the p donor on E(p)+2(1-W)Uq with its true old Fp;
 * actual A-branch shielding identifies both q donors with Fq(z-WUp), using genuine Uq periodicity for the second copy;
 * each donor query lies in its independently established ordinary zero strip.

These are equality/shielding assertions on actual donor sites, not consequences of donor geometry alone. The pinned proof mentions the dual recurrent comparison at lines1490-1492 but this note does not certify that argument's boundary premises.

## Current verification limit

The identical near-bottom three-donor membership test passes twelve varied actual words (both parity representatives). A direct transplant of the even-child upper-bound proof is not enough: for the p-first block it initially only yields tp<= (Lp+3)/2, which need not be <=D when D-N=1. Additional lattice rounding, actual H parity thresholds, or an overlap/junction argument is required. No all-parameter odd cover is claimed here from this finite check.
