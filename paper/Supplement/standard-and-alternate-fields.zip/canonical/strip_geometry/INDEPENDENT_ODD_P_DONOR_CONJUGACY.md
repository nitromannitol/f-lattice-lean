# Odd standard p-donor equality from the swapped even basic donor

2026-11-19. Independent algebra/geometry audit: PASS, with ZERO source scalar and ZERO affine tilt in the indicated native gauge. This is a statement on the full abstract donor E(p)+2(1−W)Uq. Its application to a literal source requires the separately established actual old native containment in E(p) and original scalar calibration.

Write p=(D,N), q=(e,r), Up=2p, Uq=q, and J(x,y)=(-y,x), Z(x)=Jx+(0,-1), I=(1,-1). The swapped creation pair is

 p'=((e+r)/2,(e-r)/2), q'=(D+N,D-N).

It has the same word phase W. Let Uq'=q', Up'=2p', Uc'=Up'+Uq', Vc'=2Vp'+Vq'. Thus

 JUp=Vq', JVp=-Uq', J(2Uq)=2Vp'.

Use the genuine old global standard identity

 Fp(u)=Fq'(Z(u))+h0(u),

and the independently algebraic preperiodization minimum identity

 Mo(z)=Me'(Z(z)+Uc')+h0(z).

This does not assume any new odd native source identification or odd recurrence.

## Exact donor geometry

The canonical closed polygons obey Z(E(p))+Uq'=E(q'). This is an exact polygon map, not a hull relaxation: the odd H arc maps to the even V arc, while its V arc maps to the even H arc translated by−Uq'; their opposite translates map by JUp=Vq', JVp=−Uq'. The unit connectors rotate to the corresponding unit connectors, and interiors map by the invertible affine quarter-turn. Thus, for u in E(p),

 v=Z(u)+Uq' belongs to E(q').

Only this old-polygon conjugacy is used. No current donor-polygon nesting is needed.

## W1: direct basic donor

Now z=u, and

 Z(z)+Uc'=v+Up'.

The already proved even C0 comparison on E(q')+Up' gives Me'(v+Up')=Fq'(v). Its genuine Uq' character is zero, so Fq'(v)=Fq'(Z(u)). Hence

                         Mo(u)=Fp(u).

## W0: child reflection onto the basic donor

Now z=u+2Uq and let y=Z(z)+Uc'=Z(u)+2Vp'+Up'+Uq'. With Rc'=Uc'+Vc'+I,

 Rc'−y=Vq'+I−Z(u)=Rq'−v belongs to E(q').

The last membership uses the true old q' polygon reflection, not an assumption that y itself lies on a basic donor. The W0 basic comparison therefore gives

 Me'(Rc'−y)=Fq'(Rq'−v)
             =Fq'(Z(u))−aq'·Z(u)−eta(q').

Use current MINIMUM reflection (already algebraic, not current field periodicity):

 Me'(y)=Me'(Rc'−y)+ac'·y+eta(c').

Combining with Mo and old conjugacy shows Mo(z)−Fp(u) equals

 h0(u+2q)−h0(u)+2ap'·Z(u)
 +ac'·(2Vp'+Up'+Uq')+eta(c')−eta(q').

This expression is IDENTICALLY ZERO. The u-linear coefficient cancels because the harmonic increment has gradient Up', while 2ap'·J(u) has gradient−Up'. The remaining constant cancels exactly after eta(v)=(T(v)−v_x−v_y)/2. Direct independent expansion gives0 even without using the Farey determinant. The harmonic floor correction is unchanged by2q, so this is an identity of the genuine integer h0, on both physical parities, not merely its quadratic part.

Therefore

              Mo(u+2Uq)=Fp(u) for every u in E(p).

## Gauge, endpoints, and scope

Together both phases give

 Mo(u+2(1−W)Uq)=Fp(u) on ALL E(p), including its boundary and all endpoints.

This agrees with original getOddTileOffSets/getOddTileAffine: the near p occurrence is at2Uq with zero primary slope for W0, and at0 with zero slope for W1. No +1, eta, or parity-dependent constant remains. Its true scalar is0 once this candidate is bound to the ordinary source chronology by actual touching; mere agreement of spatial offsets does not independently prove that chronology.

For the reflected far p occurrence, with child odd reflection R=Up+2Uq+Vp+Vq+I and old Rp=Up+Vp+I, its origin is Vq+2W Uq. Reflection gives the actual candidate

 Fp(z−[Vq+2W Uq])+aq·z+eta(p+q)−eta(p)+ap·[Vq+2W Uq].

This is supplied only as the exact reflected gauge, not a new verification of its touching constant.

The proof is independent of the current ordinary strip conclusion: it uses the swapped EVEN donor equality already established before strip propagation, old standard conjugacy/deck/reflection, exact closed-polygon conjugacy, and algebraic minimum reflection/conjugacy. It does not use the odd strip it is intended to prove. Literal native application is licensed on Dp when Dp subset E(p); it must not be extended to an arbitrary larger actual support without that separate support theorem.
