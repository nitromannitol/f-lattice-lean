from pathlib import Path
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review')
exec((P/'policy_square_geometry.py').read_text().split('\nrows=[]\n')[0])
for w in ['1','11','12','13','21','23','31','32','123','3232']:
 mats,_=O.get_odometers(w);fo,fe,p,q=O.getFracs(w);D,N=p.denominator,p.numerator;dq,nq=q.denominator,q.numerator;eps=N*dq-D*nq;W=(1+eps)//2;U=(2*D,2*N);V=N-D,N+D;te=(V[0]-eps*U[0],V[1]-eps*U[1]);F=ext(O.export_tile(mats[3]),q,1);co=(D*D+2*D*N-N*N-D-N)//2+2*(1-W); gap=lambda x: F(sub(x,te))-F(x)+N*x[0]-D*x[1]+co;E,_,_,_=polygon(nq,dq);sample=[gap(z)for z in E]; bottom=[gap((x,y))for x in range(1,dq+1)for y in range(nq+2) if (x,y)in E and 1-dq<=nq*x-dq*y<=dq];print(w,eps,min(sample),min(bottom),flush=True)
