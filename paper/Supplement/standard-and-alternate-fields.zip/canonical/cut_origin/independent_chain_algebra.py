import sympy as s,json,hashlib
from pathlib import Path
O=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/cut_origin')
D,N,e,r,k,x,y=s.symbols('D N e r k x y');p=s.Matrix([D,N]);qo=s.Matrix([e,r]);B=lambda q:s.Matrix([(q[0]+q[1])/2,(q[0]-q[1])/2]);v=lambda q:s.Matrix([q[1]-q[0],q[1]+q[0]]);U=2*B(p);V=v(U);pp=B(qo);rows=[]
# h0 polynomial on a fixed physical parity: omitted floor correction is invariant under every even-sum displacement.
h0=lambda x,y:x*(x-1)/2-(y+1-x)**2/4
for ep0 in [-1,1]:
 for delta in [0,1]:
  ep=ep0*(-1)**delta;q=qo+2*k*p if not delta else (2+2*k)*p-qo;te=v(q)+ep*q;h=s.Matrix([te[1],-te[0]]);ww=2*ep*ep0*pp-ep0*v(pp);b=-ep*(k+delta)
  R=h-ww-b*V
  claims={'primary_parallel':s.expand(U[1]*R[0]-U[0]*R[1]),'balance_x':s.expand((-b*U-ep*B(q)+ep0*pp)[0]),'balance_y':s.expand((-b*U-ep*B(q)+ep0*pp)[1])}
  hdiff=s.expand(h0(x-te[0],y-te[1])-h0(x,y)+q[1]*x-q[0]*y)
  for i,z in enumerate([x,y]):claims['harmonic_gradient_'+str(i)]=s.expand(s.diff(hdiff,z)+ep*B(q)[i])
  assert all(vv==0 for vv in claims.values()),claims
  rows.append({'eps_creator':ep0,'last_is_1':delta,'identities':list(claims)})
import sys
sys.path.insert(0,'recovery_20261101_0745/f_lattice_original_tests');import original_port_core as C
chron=[]
for u in ['', '2','3','22','33','1','12','13','21','23','31','32','123']:
 f=C.getFracs(u);p,_,rr,qq=f;sw=u.translate(str.maketrans('23','32'));fp=C.getFracs(sw)
 assert fp[1].numerator==p.denominator-p.numerator and fp[1].denominator==p.denominator+p.numerator
 assert fp[2]==C.Fraction(qq.denominator-qq.numerator,qq.denominator+qq.numerator)
 for letter in '12':
  for kk in range(4):
   w=u+letter+'3'*kk;fw=C.getFracs(w);assert fw[2]==p
   nq,dq=qq.numerator,qq.denominator;nn,dd=p.numerator,p.denominator
   target=C.Fraction(nq+2*kk*nn,dq+2*kk*dd) if letter=='2' else C.Fraction((2+2*kk)*nn-nq,(2+2*kk)*dd-dq)
   assert fw[3]==target
 chron.append(u)
(O/'INDEPENDENT_CHAIN_ALGEBRA_RECEIPT.json').write_text(json.dumps({'symbolic':rows,'chronology_regression_words':chron,'scope':'symbolic identities universal; finite chronology regression supplements exact recurrence induction','audited_note_sha256':hashlib.sha256((O/'ACTUAL_CHAIN_CONJUGACY_ALL_CREATORS.md').read_bytes()).hexdigest()},indent=2))
print('PASS',len(rows),'symbolic branches; chronology',len(chron))
