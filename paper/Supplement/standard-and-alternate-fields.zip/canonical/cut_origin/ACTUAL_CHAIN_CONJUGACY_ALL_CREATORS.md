# Authentic earlier-chain price, including its constant and all trailing-run roles

For a proper nonbase even child, write its word w=u s 3^k with s the last 1 or 2. The odd donor p=(D,N) (vector order denominator,numerator) was CREATED as p=r+qold at u with r,qold the retained odd and even vectors then; the consumed even q=(dq,nq) equals qold+2kp if s=2, or (2+2k)p−qold if s=1. This is exactly the three-letter Farey rule. Retaining an endpoint at u is allowed. Put δ=1_{s=1}, ε'=2W(u)−1 and ε=2W(w)−1. Thus ε=ε' for s=2, −ε' for s=1.
Define B(b,a)=((b+a)/2,(b−a)/2), and (d',n')=(D+N,D−N). The genuine previous swapped even child q'=q0(swap(u)) has (d',n') and its generating odd donor p'=(d0,n0)=B(qold): swapping 2,3 exchanges the odd/even families under complementation, with the factor2 on un-reduced even vectors. This identity follows directly by induction from both root vectors and the rules (p'=B(qold), q'_old=2B(r); q'=2p'+q'_old); the letter flags and determinant signs transform correctly when the selected children replace one or both parents. For u empty this gives p'=0/1; for u=2^m it gives 0/1 on the reciprocal 3^m, and for u=3^m it gives m/(m+1) on 2^m. No fictitious proper endpoint is substituted.
Consequently
  ε B(q)−ε' p' = ε(k+δ)(d',n').
Let Z(x,y)=(−y,x−1), e=Vq+εUq, h=(e_y,−e_x), t'(X,Y)=n'X−d'Y, T'=d'^2+2d'n'−n'^2=2Tp, Tp=D²+2DN−N². The actual earlier chain shift is w'=ησ'−v', η=ε, σ'=2ε'p', v'=ε'(n0−d0,n0+d0). For b=−ε(k+δ), direct expansion gives
 t'(h)=−2ε+ε[D(dq+nq)+N(dq−nq)],
 t'(w')=−2η+2ε'(D d0+N n0).
Thus t'(h−w')=ε(k+δ)T'=−bT'. Since t'(V')=−T' and U'=(d',n') is primitive, h=w'+aU'+bV' for a genuine integer a. This licenses the earlier deck translation on the actual physical inputs, not just equality of two formal drifts.

Using Fp(x)=F'(Zx)+h0(x) with the true harmonic h0 and x=z−lv,
 Ψ(z)=F'(Zx+h)−F'(Zx)+h0(x−e)−h0(x)+aq·x+ce.
Since e has even physical parity, the last three terms have linear coefficient −ε B(q) in x (quadratic expansion). Add genuine Φ'_η(Zx)=F'(Zx)−F'(Zx+w')−ε'a'·Zx, a'=(n0,−d0). The only remaining field difference is b t'(Zx)+constant by the true earlier deck. Its x-gradient is −b(d',n'), and −ε'a'·Zx has x-gradient ε' p'. Therefore the total gradient is −b(d',n')−ε B(q)+ε'p'=0, by the exact vector relation above. No parity oscillation or residue term remains:
           Ψ(z)=K_w−Φ'_ε(Z(z−lv))   for EVERY physical z.
This proves a SINGLE constant; numerically matching deck increments would not have sufficed. The H/V collar arguments directly calibrate the two necessary source values and never require a guessed K_w. The geometric signed graph transport under Z is separate: the exact parity-reversing quarter-turn maps the earlier p canonical graph to the earlier q' graph, intrinsic nonfree by finite square forcing and free by the actual H/V arcs/endpoints.
