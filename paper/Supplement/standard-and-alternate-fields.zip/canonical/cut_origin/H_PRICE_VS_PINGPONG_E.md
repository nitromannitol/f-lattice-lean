# Exact relation of the incoming H price to the ping-pong E profile

Let p=N/D, q=nq/dq, child q0=2p(+)q, epsilon=2W-1. Set U=Uq0, I=(1,-1), cp=-(Tp+Lp)/2, Lp=N+D, c0=(Tp-epsilon Lp)/2. The deck offer is deckVp(z)=ap dot z+cp. Define the profile in section2.11 by

 E(p,q0;z)=Fq0(z+Vp)-ap dot z-cp.

Then the requested P(H) is EXACTLY equivalent to the outgoing E profile for the pair (p,q0), not merely related by an inequality.

## W0 (epsilon=-1)

For native child H, F(z)=0 and P(z)=F(z)-F(z+Vp)+ap dot z. Therefore

 P(z)=c0-E(p,q0;z),

since c0=-cp. Thus the desired P=[c0,c0-1,...,c0-1] is equivalent to E=[0,1,...,1].

## W1 (epsilon=+1)

Put w=U+I-z; this reverses actual native H. True reflection F(I-z)=F(z) and U-periodicity give F(z-Vp)=F(w+Vp). Also ap dot (w+z)=ap dot (U+I)=1+Lp. Consequently

 P(z)=-F(w+Vp)-ap dot z
     =c0-1-E(p,q0;w).

The desired P profile is equivalent to E=[0,...,0,-1], where the final E vertex corresponds to the initial P vertex. All affine constants and the endpoint reversal are retained.

## What is and is not an earlier-stage input

The active input pair for this constructor is (p,q). The needed E profile above is E(p,q0), with q0 the NEW even output. It is not E(p,q), the already-known input-pair profile. In the pinned proof, lines1457-1458 assert this outgoing profile at the '3'-step via the new fC source. That sentence is precisely an analytic producer obligation, not permission to regard this E profile as an inductive hypothesis.

At a subsequent digit2 the E invariant can retain an already-paid outgoing profile; at digit1 the explicit reflection identity transfers the intermediate outgoing (p,q0) profile to (p0,q0). Those algebraic transfers are useful, but neither establishes the first outgoing E(p,q0) profile.

The actual source calculation makes the missing obligation transparent. On native child H, A(z)=0 and

 E(p,q0;z)=(1-W)+min(0,Psi(z)-1).

Indeed A(z+Vp)=ap dot(z-lv)+cp, ap dot lv=-(1-W), and Psi(z+Vp)=Psi(z)-1. Thus in W0 the outgoing E profile requires Psi(H0)=0 and Psi>=1 at every other H point. In W1 it requires Psi(Hlast)=0 and Psi>=1 at every other H point. This is the same strict source inequality as the direct P argument, not a weaker existing theorem.

## Paid scope and noncircular continuation

The exact P/E equivalences, phase constants, and source reduction are proved here from height symmetry, deck and coherent minimum identities. The incoming pair E(p,q) profile plus its formal run invariance alone does not discharge the outgoing q0 obligation. One may instead price Psi along old p H by the genuine earlier qsw chain-Phi V trace, provided the source-to-chain affine normalization and actual old-deck lift are explicitly matched. That would be a valid triangular induction: earlier qsw D(V) derives from still-earlier P(H); it must not use the current q0 raw-Phi table. This note does not certify that additional source/chain matching or replace it with the printed 'via fC' assertion.
