# Independent actual-chain conjugacy and H-transfer audit

2026-11-19. PASS for existence of one GLOBAL constant and the stated H-trace transfer, under the explicitly earlier field/trace hypotheses. No current recurrence or current raw-Phi profile is used. No V full-star computation is repeated here.

## Creator chronology and endpoint cases

In w=u s 3^k, s is the last1 or2, and p is the odd child created at u, not the odd child created at w. If that creation used (r,qold), then p=r+qold. At s=2 the selected current pair is (p,qold), whereas s=1 selects (p,2p−qold). Each following3 fixes p and adds2p to q. This proves the two displayed q formulas for every k. The phase sign is unchanged at2/3 and reversed at1.

The complement map B(d,n)=((d+n)/2,(d−n)/2) has integral values on every even-type qold, including1/1. Swapping2/3 transforms the generator pair to (B(qold),2B(r)), and transforms p to the even child2B(p). These are exact vector identities, not fitted reduced fractions. Since p is odd type and reduced, D±N are relatively prime and both odd, so U'=(D+N,D−N) is primitive and parity preserving.

At u empty the creator is r=0/1,qold=1/1: p'=B(qold)=(1,0), exactly the genuine0/1 endpoint generator of root1/3. At u=2^m, qold=1/1 and again p'=0/1. At u=3^m, qold=(2m+1,1), giving p'=(m+1,m), exactly m/(m+1). Thus no proper-field theorem is applied to a fictitious endpoint. Any use of *canonical trace properties* for these pure conjugates still needs their literal pure trace theorem, as H_SOURCE_ANCESTRAL_CLOSURE.md correctly says; the algebraic deck identity itself includes them.

## Algebra and physical pinning

Independently expanded all four (epsilon_old, s) branches with symbolic D,N,dqold,nqold,k. With b=-epsilon(k+delta),

 h-w'-bV' is parallel to U',
 -bU'−epsilon B(q)+epsilon_old B(qold)=0,
 gradient_x[h0(x-te)−h0(x)+aq·x]=−epsilon B(q).

All identities are exact polynomials, recorded in INDEPENDENT_CHAIN_ALGEBRA_RECEIPT.json. In fact the parallelism and cancellation identities require no determinant reduction after the chronological q substitution. Since all displacements are integral and U' is primitive, h=w'+aU'+bV' with integer a. They are all parity preserving. The floor correction in h0 is unchanged under te, so the polynomial harmonic computation leaves NO physical-parity residual.

The genuine earlier deck law therefore makes F'(Zx+h)−F'(Zx+w') equal b t'(Zx) plus one scalar, including the evaluation-point and cross-deck constants. These constants need not be guessed or equal Carbon's printed normalization. The displayed vector balance cancels every remaining linear term. Hence Psi(z)+Phi'_epsilon(Z(z-lv)) is ONE constant on the entire physical lattice, not separate constants per parity, residue, tile or H index. This uses genuine global standard conjugacy with its actual h0 pinning and the true earlier deck law; matching drifts alone would not prove it.

## H-trace transfer

The physical index is fixed by the ordinate of Z, not by choosing a convenient quotient representative. On child H_j it is j-dq in W0, and d-1-j after the genuine H reversal in W1. The exceptional W0 parent class I+bUp maps to H0'+bV', in place of V0'+bV'. W1 needs no such replacement.

Given the earlier nominal V trace f with drift2eta and monotonicity in sign eta, the possible actual V0 values are controlled by precisely the earlier canonical paths written in H_SOURCE_ANCESTRAL_CLOSURE.md:

 eta+: f(0)<=Phi(V0)<=f(1),
 eta-: f(0)<=Phi(V0)<=f(-1).

For eta- the actual two-edge path is V_{-1}=(1,-1) -> (0,-1) -> V0, so its orientation gives the stated upper bound. These inequalities place V0 between its neighboring values. Replacing V0 by H0=f(0) also preserves monotonicity. No H0=V0 equality is required. The word 'periodic' for f should mean periodic increments: f(j+L')=f(j)+2eta, not literally f(j+L')=f(j).

Now W0 has eta=- and increasing j'; W1 has eta=+ and decreasing j'. In both cases K-Phi at the actual queried points is nondecreasing in original child j. Thus the independently calibrated first two source values0,1 imply the exceptional endpoint value0 and all other H-root values>=1. This transfer uses the *same* constant from the algebra above, so no hidden index-dependent adjustment is possible.

The subsequent full H-halo deduction remains conditional on the independently proved old full-star zero strips, source unit-edge bound, and tied-endpoint direct evaluations already enumerated in that note. This audit does not replace those premises by canonical chosen-edge monotonicity.

## Scope and receipt

No substantive sign, phase, creator, or gauge defect found. The only wording correction is 'periodic increments' for the drifting nominal V trace. The symbolic check covers four universal algebra branches; finite Farey chronology checks on13 creator words supplement, rather than prove, the exact recurrence argument above. Script: independent_chain_algebra.py. Receipt pins the reviewed conjugacy note SHA. No uploads.
