# Ancestral primitive-price producer of the exact V cut

This closes the residual in V_CUT_ORIGIN_RESIDUAL.md under the strictly earlier authentic primitive-price H trace, quarter-turn identity, and ordinary strips. It does not consume the current raw-Phi profiles, current ranks, or the current D cut.

Let p=N/D be the proper odd parent, r=D+N, cp=D-N, Up=2(D,N), Vp=(-cp,r). For the child n/d=2p(+)q put epsilon=Nd-Dn and a=epsilon Uq. Define psi_minus(x)=Fp(x+a)-Fp(x). Its a is the genuine intrinsic creator displacement modulo Up, not an arbitrary Bezout gauge. The established creator/reflection identities give psi_minus(x)=psi_plus(Rp-x)+1 and psi_plus(x+Vp)=psi_plus(x)-1; hence psi_minus has Vp drift +1 and Up drift zero.

## 1. Native old-parent boundary profiles from the earlier standard price

Let qsw=(D-N)/(D+N) be the genuine complementary even standard and Z(x,y)=(-y,x-1). The authentic identity is

 psi_plus(x)=-P_qsw(Zx)+c0_qsw.

The actual native p V path, traversed in reverse, maps under Z to the actual qsw H path translated by -Uqsw. Its endpoints verify the translation: Z(0)=(0,-1)=Hlast_qsw-Uqsw, and Z(Vp+(1,-1))=(1-r,-cp)=H0_qsw-Uqsw. The interior steps transform to the same reversed horizontal paired word. Also Z(x+Up)=Z(x)+Vqsw.

For x on p V, Rp-x=Up+(Vp+(1,-1)-x); the bracket reverses the actual p V. Thus the earlier price P, whose Vqsw character is zero and whose -Uqsw character is +1, is evaluated on Hqsw-Uqsw in the forward correspondence. Its value is c0+1 exactly at x=0 and c0 at every other p V vertex, by the genuinely earlier H trace (H0 has c0, all other H have c0-1). Therefore

 psi_minus(Vp_0)=0, and psi_minus(Vp_k)=1 for 1<=k<=r-1.

On native p H, reflection sends x to its reversed H point plus Vp. The earlier psi_plus=0 on native H and its Vp drift -1 give psi_minus=0 on the WHOLE native H. In particular psi_minus(H0)=psi_minus(Hlast-Up)=0. All these are old-stage price/height identities. Base p with a separate creator convention needs the same explicit seed identities, not an invented creator; direct pure-parent formulas supply that separate input.

## 2. Exact class lifts of the child V roots

Use the already-proved exact source classification in CANONICAL_V_RAW_SLIP_MONOTONICITY.md section1. At EVERY nonfinal native child V root v_j, it is one of:

 (i) vp_k+bVp, 0<=k<=r-1;
 (ii) H0+bVp (only epsilon=-1);
 (iii) Hlast-Up+bVp (only epsilon=+1).

No Up translate is present. This is the actual physical classification from the parent s spectra, not an unlabeled congruence. It includes V0 and the genuine exceptional core classes. The only floating root not covered is child Vend in epsilon=-1, which is paid separately below.

Since EVERY arc step raises y by exactly one, y(v_j)=j, y(vp_k)=k, y(Vp)=r. Thus the actual integer b, including at each exceptional root, is fixed by the physical ordinate:

 (i) j=k+br;
 (ii) j=br;
 (iii) j=br-1.

This is the exact quotient lift; no ambiguous primary character or winding can be discarded. From section1 and the +1 Vp character, in case(i) psi_minus(v_j)=b+1_{k>0}; in cases(ii),(iii) it equals b. In ALL cases this is exactly ceil(j/r). In particular the first r nonzero roots have value1 and every later nonfinal root has value at least2. The result is stronger than the clipped obstacle but does not require asserting that late values remain2.

## 3. Convert the old price into the child cut

The ordinary old-parent h0 strip gives Fp(v_j)=h0(v_j) at every child V root: the exact parent s spectra include the possible floating final value2N+2, still within [1-2D,2(D+N)-1]. Therefore the residual g_j=Fp(v_j+a)-h0(v_j) is exactly psi_minus(v_j).

The independently established actual-source identity gives

 Dminus(v_j)=-min(g_j,2).

For all nonfinal roots sections1-2 prove g_j=ceil(j/r). The final root has Dminus=-2 by genuine child zero-strip and V-deck endpoint evaluation, including the floating epsilon=-1 case. Hence

 Dminus(V_j)=0, (-1)^r, (-2)^(r+s-1), where s=nq+dq and L=2r+s.

True reflection and V reversal then give

 Dplus(V_j)=0^(r+s-1), 1^r, 2.

## Audit boundary

The new ingredient is analytic: the strictly earlier primitive P trace produces the native odd-parent psi-minus profile, and the exact physical lift turns it into ceil(j/r). Thus no current raw-Phi plateau is assumed. The constructor geometry/source classification and the genuine creator/conjugacy normalization remain necessary independently paid inputs; the proof does not establish them by the desired cut. Pure creator exceptions retain their actual seed conventions. No inference from numerical samples is used.
