# Audit of the origin of the signed V cut

## Verdict

The saved Christoffel/two-scalar calculation is a correct REINDEXING CONDITIONAL ON the four raw-Phi boundary profiles. It is not an independent analytic producer of those profiles. I do not certify that the complete nonbase V cut is paid merely by citing that calculation or the pinned projection paragraph.

The cut can instead be reduced exactly to the following earlier-parent obstacle inequalities, using coherent E=min(A,C) and ordinary strips only. This identifies a sharp remaining analytic obligation, without current raw-Phi cut tables, current canonical ranks, or current raw-slip monotonicity.

## Exact earlier-parent reduction

Let p=N/D be the proper consumed odd parent, q=nq/dq the consumed even parent, n=2N+nq, d=2D+dq, epsilon=Nd-Dn. Put r=N+D, s=nq+dq, L=2r+s, Up=2(D,N), Uq=(dq,nq). Let v_0,...,v_(L-1) be the actual native child V vertices, in ascending order. Define

 g_j = Fp(v_j+epsilon Uq)-h0(v_j).

Then the source-level result V_STAR_CLIPPED_PARENT_REDUCTION.md gives, at EVERY root v_j,

 Dminus(v_j) = -min(g_j,2).

Its proof evaluates F(v_j-epsilon Up) on actual E after shifting by Up (epsilon=-1) or Uq (epsilon=+1). The two actual offers are Fp(v_j+epsilon Uq) and h0(v_j)+2. The latter equality follows from the genuine parent strip at v_j-Vq; no parent recurrence of a merged helper and no current cut profile occurs. Native F(v_j)=h0(v_j). Thus this identity is an analytic reduction, not a numerical observation.

Consequently the requested minus cut

 0, (-1)^r, (-2)^(r+s-1)

is EQUIVALENT to these three exact assertions:

 g_0=0;
 g_j=1 for 1<=j<=r;
 g_j>=2 for r+1<=j<=L-1.

In particular proving only a span bound, sign, or monotonicity does not establish the location of the jump. The equality g_j=1 is required on the entire first block, but beyond it ONLY the lower obstacle inequality is needed. Replacing that inequality by equality 2 would be unnecessarily strong.

The first assertion is paid directly: tp(epsilon Uq)=1, physical parity is even, so the genuine earlier odd-parent zero strip gives Fp(epsilon Uq)=0=h0(0). The terminal value can separately be obtained from genuine child zero-strip/deck endpoint evaluation, without the interior cut. The unproved core is therefore exactly j=1,...,r equality and j=r+1,...,L-2 lower bound, unless a separate authenticated ancestral producer is supplied.

## Reflection supplies the other sign, without new profiles

Actual standard central reflection and native V reversal give

 Dplus(v_(L-1-j))=2+Dminus(v_j).

Hence the preceding minus cut yields exactly

 Dplus(v_j)=0^(r+s-1), 1^r, 2.

This implication uses actual height reflection and the zero primary character of D, not current ranks or a raw-Phi boundary profile. It is enough to prove the single earlier-parent obstacle above; the two signs are not independent analytic gates.

## Why the existing pinned paragraph is not a replacement proof

PROOF_212715.txt lines2429-2438 (part3.10(b)(ii)) asserts that shifted t crosses 'exact plateau endpoints' and thereby obtains the raw profiles. Sturmian geometry can locate crossings of a KNOWN plateau; it cannot itself prove that the scalar height difference has that plateau. The paragraph supplies no additional analytic formula for G on the needed shifted interval. Its following part(iii) lines2443 onward derives some bounds by source comparisons, but a bound is not the missing exact plateau equality/jump location.

NONBASE_EXACT_TWO_SCALAR_LIFT.md explicitly assumes those four raw profiles at its start. Its two-defect Christoffel reindexing and exceptional-site reflection are useful and do not introduce a cross-corner calibration assumption, but they retain that analytic hypothesis. Using its output to justify the input profiles would be circular.

## Potential reusable route, not a completed theorem

For a nonbase p, epsilon Uq modulo Up is its genuine fixed creator displacement epsilon_creation Uq_creation. Thus g is an intrinsic earlier-parent field minus h0, independent of how long the current adjacent run is. This is a promising induction datum: an obstacle certificate on the moving child V path, with a unit plateau through index r and a lower bound thereafter. It must be proved from the actual earlier constructor, source contacts and deck shifts. The ordinary parent strip used for the SECOND offer does not by itself evaluate the FIRST offer at v_j+epsilon Uq. No such new universal obstacle certificate is proved in this audit.
