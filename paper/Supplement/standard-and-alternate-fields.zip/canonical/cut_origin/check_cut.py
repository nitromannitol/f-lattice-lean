from pathlib import Path
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review')
exec((P/'policy_square_geometry.py').read_text().split('\nrows=[]\n')[0])
h0=lambda z:(z[0]*z[0]+2*z[0]*z[1]-z[1]*z[1]-2*z[1]-(sum(z)%2))//4
out=[]
for word in ['1','11','12','13','21','23','31','32','123','3232','2323','33332','22223','2312']:
 mats,_=O.get_odometers(word);_,fr,p,q=O.getFracs(word);n,d=fr.numerator,fr.denominator;pn,pd=p.numerator,p.denominator;qn,qd=q.numerator,q.denominator;eps=2*(word.count('1')%2)-1;r=pn+pd;l=n+d;Up=(2*pd,2*pn);Uq=(qd,qn)
 F=ext(O.export_tile(mats[1]),fr,1);Fp=ext(O.export_tile(mats[2]),p,0);E,bd,H,V=polygon(n,d)
 for j,z in enumerate(V):
  g=Fp(add(z,(eps*qd,eps*qn)))-h0(z)
  DM=F(z)-F(sub(z,(eps*Up[0],eps*Up[1])));DP=F(z)-F(add(z,(eps*Up[0],eps*Up[1])))
  if j<l-1: assert g==(j+r-1)//r,(word,j,g,r,z)
  assert DM==-min(2,(j+r-1)//r)and DP==2-min(2,(l-1-j+r-1)//r),(word,j)
 out.append(dict(word=word,p=str(p),r=r,vertices=l,main_identity_checked=l-1,full_cut_checked=l))
print(json.dumps(dict(passed=True,cut_vertices=sum(u['vertices']for u in out),rows=out),indent=2))
