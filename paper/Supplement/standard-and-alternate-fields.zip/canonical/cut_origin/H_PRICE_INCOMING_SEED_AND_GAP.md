# Incoming H-price profile: independent seed and exact remaining issue

This note does NOT certify the all-H profile from mere canonical monotonicity.

Write delta=epsilon Vp, s(delta)=2, L=d+n, and
P(z)=F(z)-F(z-delta)-epsilon ap,2 dot z.
The genuine h0 quadratic identity is h0(z)-h0(z-delta)-epsilon ap,2 dot z=c0.

## Two endpoint-adjacent values paid without the H-price profile

At H0=(1,0), s=L and s(H0-delta)=L-2. Both are in the ordinary child h0 strip, so P(H0)=c0.

At H1=(2,0), F(H1)=0 by the ordinary zero strip, while h0(H1)=1. Its shifted point has s=2L-2, inside the ordinary h0 strip [1-2d,2L-1]. Therefore

 P(H1)=F(H1)-h0(H1)+c0=c0-1.

This is valid in BOTH phases, using the physical delta rather than replacing it by a signless vector. It uses no current rank, current raw-Phi profile, current native span, or earlier ping-pong O-profile.

More generally any H point z for which z-delta lies in that ordinary h0 strip has P(z)=c0-h0(z), since F(z)=0. This directly prices the initial points whose s fits, but it is not a formula for the whole growing H arc.

## Remaining source inequality

In the properly reflected phase frame, the known authentic source formula has the form

 P(z)=(c0-1)-min(0,Psi(w)-1)

on native H (with the correctly paired reflected frame in the other phase). Since coherent boundary agreement gives Psi(w)>=0, the desired low value at each noninitial H vertex is exactly the strict source inequality Psi(w)>=1. The seed above independently gives that strict inequality at H1's corresponding source query. It does not establish it at all later queries.

Monotonicity on the prescribed canonical input of each H vertex is insufficient by itself to propagate along the geometrical H path. A diagonal requires an intermediate chosen direction; an odd horizontal midpoint requires a dogleg rather than its next horizontal neighbor. If those intermediate paths are proved to be actual canonical paths independently of the desired H trace/native span, they could propagate the seed, with a separately paid lower bound. A geometric staircase or a path merely legal for a true fort is not automatically such a canonical path.

Similarly the native two-level P span cannot be invoked here without auditing its boundary input: its standard comparison proof already uses the full H trace. Nor can the V-cut producer ANCESTRAL_PSI_V_CUT_PROOF.md supply this same-level missing input; it expressly consumes a STRICTLY EARLIER H trace.

## Status

The two initial H values and the phase-independent h0 computation are proved. The universal all-H result still requires an independently authenticated strict source inequality on the remaining H queries, or a genuinely noncircular directed sweep with lower bounds. The printed mutual ping-pong profile, if used instead, needs its own source-level all-constructor proof and cannot be counted as a consequence of the projection/reindexing calculation.
