# H-source closure from the strictly earlier chain, before the current extension

This audits the proposed triangular closure. Inputs are the strictly earlier even conjugate's actual D cut, P(V)=c0, raw-chain canonical monotonicity, genuine zero/core strips, exact Christoffel shift and actual source-to-conjugate-chain identity. No current F, P, native P span or current rank is used to prove the source boundary and halo below.

Notation: odd p=N/D, Up=2(D,N), Vp=(N-D,N+D), even q=nq/dq, epsilon=2W-1, child (n,d)=2(N,D)+(nq,dq), U=(d,n). Set lv=(1-W)Uq, te=Vq+epsilon Uq, ce=(Tq-Lq)/2+2W,
 A(z)=Fp(z-lv), C(z)=Fp(z-lv-te)+aq dot(z-lv)+ce, Psi=C-A.
Let Q=(D-N)/(D+N) be the genuine strictly earlier even conjugate and Z(x,y)=(-y,x-1).

## 1. The earlier chain V trace is monotone without equating its core values

Use its own creator sign epsilon_old and r_old. Christoffel reindexing plus its ALREADY-PAID D cut produces a nominal periodic V trace f(j), nondecreasing for chain sign eta=+ and nonincreasing for eta=-. For every j not congruent0 modulo its V period, the actual chain value equals f(j). The secondary Christoffel exception is the physical (0,-1) core; the needed D value agrees with the paired endpoint by the earlier zero strip and deck. At j=0, the SAME formula instead evaluates the actual H0: Phi(H0)=f(0). Do not assume Phi(V0)=Phi(H0).

The earlier canonical edges supply precisely the bounds needed:
 * V0 chooses east to H0 in both signs, hence Phi(V0)>=f(0).
 * eta=+: V1=(0,1) chooses south to V0, hence Phi(V0)<=f(1).
 * eta=-: V_{-1}=(1,-1) chooses west to (0,-1)=Hlast-U; that odd H endpoint chooses north to V0. Hence Phi(V0)<=f(-1).

Thus the actual V trace remains monotone in the stated sign. Replacing any V0 lift by its H0 lift also preserves monotonicity because f(0) lies between the adjacent nominal values. All lifts retain the genuine V character2eta. These inequalities establish the required order, not an unnecessary H0/V0 equality. Pure earlier conjugates use their separately checked literal signed trace/order; no nonbase creator is invented for them.

## 2. Actual child H queries, including the exceptional core

Number child H_j by j=0,...,d-1; its x coordinate is j+1. For W0 put w=H_j; for W1 put w=U+(1,-1)-H_j (actual H reversal). Set x=w-lv.

The already-audited parent t/parity classification puts x on actual old p H modulo Up, except W0's possible even class I=(1,-1)+bUp. The quarter turn maps p H_k EXACTLY to Q V_k, and Z(x+bUp)=Z(x)+bV_Q. Therefore Z(x) lies on the actual extended old V sequence at the exact index

 j'=j-dq (W0),      j'=d-1-j (W1).

There is no guessed deck representative: the y coordinate of Z(x) is x_1-1 and EVERY V step raises y by1, which fixes the integer lift. W0's exceptional I+bUp maps instead to H0_Q+bV_Q, at precisely the nominal V0 index. Section1 explicitly permits that replacement. W1 has no alias.

Under the authentic source-to-chain identity,

 Psi(w)=K-Phi_old,epsilon(Z(x)),

with one constant K for this entire physical sequence. The actual source displacement in Q coordinates is Z_linear(-te)=(te_y,-te_x); source matching must use this displacement and its affine slope, not merely compare characters. The exact transformed characters are (+1,-2epsilon) for Psi on (U_Q,V_Q), consistent with the displayed sign. Changing an equivalent physical representative changes both sides by the same character; K cannot vary with j.

For W0, j' increases and the old eta=- trace decreases. For W1, j' decreases and the old eta=+ trace increases. Hence in BOTH phases Psi(w(H_j)) is nondecreasing in the ORIGINAL child index j. The value of K is unnecessary once the first two values are calibrated directly.

## 3. Direct calibration from old strips, without current F or P

W0: at z=H0,H1, the C offer simplifies to
 C(z)=Fp(z-Vq)+aq dot z+(Tq-Lq)/2=h0(z).
The old h0 strip licenses the substitution. The A offer is zero. Thus Psi(H0)=0 and Psi(H1)=1.

W1: w(H0)=Hlast and w(H1)=H_{d-2}. Write v=w-U, respectively (0,-1),(-1,-1). Modulo Up the C argument is v-Vq, and aq dot Up=-2 cancels the phase bonus2 in ce. Hence C(w)=h0(v), equal to0,1 respectively; again A=0. Thus the same calibration holds in the reflected enumeration.

For the old strip guards, sp(Vq)=-2epsilon. W0 queries at H0,H1 have sp Lp-2 and2Lp-2; W1 queries have sp2N+2 and2-Lp. All lie in [1-2D,2Lp-1] for proper p. Therefore these are genuine old-field evaluations, not formal quadratic extrapolations.

Sections2-3 prove Psi=0 at the exceptional endpoint and Psi>=1 at EVERY other child H root, with exceptional endpoint H0 in W0 and Hlast in W1.

## 4. Whole H input halos before the periodic extension

A is zero on ALL root/input stars by the old parity strips. Precisely the parent root classes are even tp in[1,Lp] for W0 and[1,Lp-1] for W1; odd tp in[N+1,D] for W0 and[N,D] for W1. Even roots' odd inputs lie in[1-N,D+2N], contained in the ordinary old zero strip[1-D,N+2D-1]. Odd roots' even inputs lie in[N-D,2D], contained in the already-paid expanded EVEN strip[1-Lp,2Lp-1]. These are full-star bounds, not just chosen-input bounds.

At every nontied root Psi>=1, earlier global unit-edge control |delta Psi|<=1 implies Psi>=0 at BOTH actual inputs. Thus C=A+Psi>=0 on that entire star, and M=min(A,C)=0 there.

At the tied root the two inputs are paid directly, not by unit-edge control:
 * W0 H0 inputs (1,1),(1,-1): the same C=h0 computation gives0 at both. Old shifted sp values are2D-2 and2N-2.
 * W1 Hlast inputs U+(0,0),U+(0,-2): after subtracting U, h0 is0 at both; old shifted sp values are2 and2-2(D-N).
All these lie in the ordinary old h0 strip. A=0 there as above. Therefore M=0 on EVERY physical H root and BOTH inputs, including the tied endpoint.

## Consequence and exact induction boundary

This gives the current H-source positivity and zero halo before defining its global extension. Once genuine F=M on the closed polygon is assembled, the source/deck identities in H_PRICE_VS_PINGPONG_E.md yield the incoming primitive P(H) trace. The argument is triangular: current H consumes earlier chain order; earlier D cut consumes still-earlier P(H). It does NOT cite the current raw-Phi table.

The source-to-chain identity and its genuine normalization in section2 are an essential independently authenticated algebraic input. Character agreement alone is not a proof of it. This note audits the exact geometry, sign order, exceptional V0 bounds, direct strip calibration and halo deduction given that identity. No recurrence of the not-yet-built current extension is used.
