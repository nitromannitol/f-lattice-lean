# Uniform parent-web near-contact lemma and canonical core returns

This gives parameter-uniform parts of the Wave1 reduction; it does not certify all child collar coordinate guards or all zero-Psi exclusions.

## 1. Different-family near-contacts occur only at endpoints or their immediate neighbors

For a proper ODD parent N/D, put L=D+N, c=D-N, T=D²+2DN-N², U=2(D,N), V=(N-D,L), t=Nx-Dy, s=Lx+cy. The genuine periodic free web has exact spectra:

 H, even physical parity: t=1,...,L-1 modulo T;
 H, odd physical parity:  t=N,...,D modulo T;
 V, even physical parity: s=0,2,...,2N modulo 2T;
 V, odd physical parity:  s=2-c,4-c,...,L-2 modulo 2T.

Each t together with physical parity is one U orbit; each s is one V orbit. These are consequences of the actual central-word residues, not empirical lists.

Choose an H representative on its finite native arc. Its s rises from L at H0 to 2T-c at Hlast, by L or2D at each arc step. If a V-free site lies within Chebyshev distance1, s changes by at most L+c=2D. The V spectrum lies inside [2-c,L-1] modulo2T. For every proper odd parent except1/2, T>3L: for D>=4, T-3L=D(D-3)+N(2D-N-3)>0; D=3,N=2 also gives2. Thus only the V sheets near0 and2T can be close to this H arc.

Near0, s(H)<=L-1+2D, so its distance from H0 in s is <=2D-1<2L. Near2T, s(H)>=2T+2-c-2D, so its distance from Hlast is <=2D-2<2L. Every H step changes s by at least L, so H is an endpoint or its IMMEDIATE arc neighbor.

Conversely, on a native V arc t decreases from0 to -T+L by at least D per step. An H site within Chebyshev distance1 allows t(V) in [1-L,2L-1] modulo T. The same separation excludes all except the neighboring H sheets. Its t distance from V0 or Vlast is at most L-1<2D. Hence V is likewise an endpoint or immediate neighbor. For parent1/2 every H/V vertex already is an endpoint or immediate neighbor, so the conclusion holds directly.

The same spectral gaps exclude a radius-one meeting with a DIFFERENT translate of the SAME arc family away from these small-base cases. Thus away from translated endpoint/immediate-neighbor neighborhoods the local free web is a single parent arc. This is an exact explanation of the observed core-neighborhood phenomenon for different-family intersections. It does NOT yet rule out a child boundary turning away from that same parent arc through a zero-Psi vertex: protected boundary-free status on Sigma does not imply free status for its neighbors outside Sigma.

## 2. Two canonical core roots use the same upper-left square

Consider the two parent canonical policies (epsilon,+1), epsilon=+-1. Both H0=(1,0) and V0=(0,0) have the same selected inputs for these policies: H0 down, V0 right. Likewise V1=(0,1) selects down. These statements include the true reflected endpoint conventions, not a guessed sign reversal at V0.

For H0, the rejected input is (1,1). The upper-left square has return

 (1,1) -> (0,1) -> (0,0) -> (1,0).

The first root is universally black: its height and east input are0 by the zero strip, while its west input is h0(0,1)=-1. The two remaining arrows are the stated canonical free choices. Therefore this return is unconditional from the normalized strips and free policy.

For V0, the rejected input is(-1,0), universally black by the analogous strip calculation. The upper-left return is

 (-1,0) -> (-1,1) -> (0,1) -> (0,0).

Only the middle arrow (-1,1)->(0,1) needs a producer. It follows from the earlier parent FREE-return-square theorem for policy(+1,+1): the other, lower square cannot return because its last vertex Hlast-U=(0,-1) selects DOWN rather than up. Therefore the upper square must be the promised return. The vertex(-1,1) is not a free class (check the exact spectra above; 1/2 directly), so this atom is either a black allowed edge or the intrinsic unit-forced edge and remains valid under policy(-1,+1). This does not derive the earlier free-square theorem from a rank; it reduces the current required atom to that explicitly stated producer.

Both returns occupy the SAME upper-left square relative to their respective roots. Their deck translates therefore need only one child-geometric placement test.

## 3. A uniform inward placement test for the bottom child collar

Let child E be the even n/d polygon. Suppose a root z is strict interior, 2<=z_x<=d-1, and 0<=z_y<=n. Then its upper-left square is wholly strict interior:

* both x coordinates are >=1, strictly right of Vleft whose x<=0;
* at each of these x coordinates the lower H ordinate is no larger than at z_x, and z lies strictly above it; moving left/up stays strictly above H;
* all vertices have x<=d-1 and y<=n+1; the right V arc starts at(d,n), takes its first vertical step to(d,n+1), and is not reached in this rectangle;
* the upper H arc starts at y=n+d>n+1.

Thus once the actual endpoint arithmetic supplies these coordinate guards for a bottom-collar core root, the desired canonical return is inward without any further policy choice. If a root fails a guard, its exclusion or alternative placement still requires genuine price/phase arithmetic; no claim that every translated source endpoint automatically meets these guards is made.

## 4. Aligned vertical collars: exact rightward squares

For W=1 the active parent policy is (+1,+1). The parent's terminal V vertex, translated by -V, is (1,-1), with rejected right input(2,-1). Its UPPER-RIGHT return is

 (2,-1) [black] -> (2,0)=H1 -> (1,0)=H0 -> (1,-1).

The H1 arrow is left and H0 down. The first black follows from central reflection of the universal black(-1,0), with the actual deck translate. This is an entirely black/free-core certificate.

For the other root H0, its UPPER-RIGHT return is

 (1,1) [black] -> (2,1) -> (2,0)=H1 -> H0.

The only nontrivial atom is (2,1) downward. Under genuine quarter-turn J(x,y)=(-y,x-1), this is exactly the conjugate EVEN standard's intrinsic atom(-1,1) rightward. That atom follows from the earlier conjugate field's V0(+1,+1) free-square producer as in section2: its lower candidate cannot return. The conjugate site(-1,1) is nonfree by its own exact web spectra, so the atom transports independently of the selected free policy. This argument does NOT assert a reflection symmetry about the rejected edge.

These two upper-right squares also hold for parent policy(+1,-1): H0 and H1 choices in these squares are unchanged, and their nonfree atom is intrinsic. Genuine parent central reflection therefore gives the required LOWER-LEFT squares for W=0 policy(-1,+1), at V0 and Hlast respectively. Thus all four aligned-V core cases are reduced to a black/free certificate plus one precise previously-stage intrinsic core atom (or its conjugate), not the full boundary path catalogue.

## 5. Aligned-V geometric guards and excluded extreme rows

Let the CHILD be a proper nonbase even n/d, so n>=3 and d-n>=4, L=n+d. An interior root in the radius-one LEFT V collar has x<=1. If 1<=y<=L-2, its UPPER-RIGHT unit square is wholly strict interior:

* Vleft has a nonincreasing integer x-coordinate as y increases. Both vertices at root x remain strictly to its right; adding1 to x preserves that.
* Hbottom near x<=2 has height0, whereas the square's y>=1.
* Htop has y>=L, whereas the square's y<=L-1.
* Vright has x>=n+1>=4, whereas the square's x<=2.

At collar row y=0, the possible lattice sites are boundary or exterior. At row y=L, the possible sites are boundary or exterior, using the last vertical V step and first horizontal Htop step. At row y=L-1, the only possible STRICT interior collar site is

 V+(2,-1)=(n-d+2,L-1).

It is universally child-black: it is R_child-(-1,0)-U_child, with(-1,0) universally black by the normalized strips. Therefore it cannot be a Wave1 child-white root. This is a color exclusion, not an unstated omission of the endpoint p*.

Reflecting the actual child polygon and these exclusions gives the RIGHT V collar test: lower-left square is strict when x>=n and n+1<=y<=d+2n-2. Its one possible strict exceptional bottom-collar site is(d-1,n), the reflection of V+(2,-1), also black. Other extreme-row candidates are boundary or exterior. This reflection is used only for polygon membership/colors; the parent policy directions were checked separately in section4.

Consequently the parent's supplied spectral classification of W1-left collar roots as Vend/H0 and W0-right roots as V0/Hlast, together with the active-chart price choice, combines with sections4–5 to pay every aligned-V collar Wave1 return. At Psi=0, it is enough to choose the genuinely active inward chart; there is no claim that both charts must be inward. The spectral classification and active-chart price choice are external inputs to this note, not reproved here.
