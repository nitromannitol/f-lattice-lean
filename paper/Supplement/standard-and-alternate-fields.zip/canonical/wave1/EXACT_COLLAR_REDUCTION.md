# Exact collar reduction of the Wave1 inward-square gate

This is a reduction with explicit remaining parameterized checks, NOT a proof that the checks hold for every constructor. Source: pinned3.11(b)(iv),2755–2770. The earlier independent square scripts are used only for falsifying shortcuts and diagnosing local cases.

## 1. Remove Psi from the placement problem

Let z be a child-white interior point in Sigma_A that is parent-free; let e be its canonical parent input and u its rejected input. Assume the already-required minimum-crease lemma gives Psi(u)>=0, and Psi is nondecreasing on every parent policy edge. For ANY genuine three-edge parent return u→w2→w1→z,

 0<=Psi(u)<=Psi(w2)<=Psi(w1)<=Psi(z).

Therefore EVERY such return square is already wholly in Sigma_A. No new source heights, child recurrence, alternate helper or four-corner ownership are needed to check Sigma placement. Only strict CHILD POLYGON placement remains. This separates the potential producer from the geometric producer.

## 2. The exact remaining region is a one-pixel collar

Write u=z+a, with a a physical unit input vector, and choose a perpendicular unit vector b. There are exactly two squares:

 Q_+=(z,z+a,z+a+b,z+b), Q_-=(z,z+a,z+a-b,z-b).

Every vertex lies in z+[-1,1]^2. Thus if the whole nine-point window lies in strict child interior, ANY parent return-square producer suffices. A placement issue can occur only at interior z whose radius-one window meets child boundary/exterior. On the actual unit-step polygon, a unit square containing an interior point and an exterior point has boundary vertices; hence these sites lie in the radius-one collar of the four actual child arcs, including their unit corner cores.

This is not a test on the entire child tile. For a paired-arc proof one need only classify the parent FREE web in this child collar. In particular, interior seam segments farther than one pixel from child boundary require NO new inward-placement argument whatsoever.

## 3. Three precise producer checks

For each oriented paired-arc occurrence in that collar, let g_+,g_- record whether Q_+,Q_- lie entirely in strict child interior. These bits are determined solely by child geometry. Let r_+,r_- record the three actual parent edge tests for the corresponding return.

G1. Exclude g_+=g_-=0 at every parent-free child-white Sigma root. Equivalently: the rejected input u must be strict interior, and at least one of the two adjacent two-point flanks z±b,u±b must both be strict interior. This is a purely geometric/exposure claim once the root's actual parent-free arc and phase are specified.

G2. If g_+=g_-=1, use the separately established parent free-square producer r_+ OR r_-. No further constructor case is needed.

G3. If exactly one geometric side, say +, is inward, prove the THREE local atoms

 u→u+b, u+b→z+b, z+b→z

in the parent canonical graph. This is the only genuinely one-sided policy obligation. The corresponding child Psi inequalities have already been paid in section1. A parent atom holds either because its root is black or because its actual canonical/finite-unit-forced input is the displayed neighbor.

For an actual Sturmian concatenation proof, G1/G3 require only the consecutive arc letters intersecting the radius-one window, the parent H/V/corner tag, the true deck translate and W phase. Adjacent letters alone without these tags are not sufficient: the free corner choices differ, and a deck translate changes which child arc is nearby. The task is to derive the allowed PAIRED occurrences from the Farey concatenation law, then prove their G3 atoms using already-paid parent local strip/forcing lemmas. Do not substitute a finite word sample for that allowed-occurrence derivation.

This reduction does not assert a fixed list of ten or any other number of universal paired types. Arbitrary lattice masks would give a finite over-approximation, but most lack any authentic constructor realization and some would violate G1/G3; checking an unproved list would hide rather than close the gate.

## 4. A verified shortcut failure

Actual word1, z=(-1,6), has parent chosen input(-1,5), rejected u=(-1,7), Psi(z)=1. BOTH three-edge parent return squares exist. The left square has vertices(-2,6),(-2,7),(-1,6),(-1,7); its two x=-2 vertices are on the child boundary. The right square with x=-1,0 is wholly strict interior. Thus 'choose a parent return square; monotonicity makes it inward' is false even at the first word. Monotonicity makes it Sigma-admissible, NOT interior.

The correct desired conclusion still holds in this example. Likewise actual23 z=(5,3) and actual32 z=(3,1) have both a boundary-touching return and a good inward return. Reflection of the bad square through the shared edge cannot be assumed to preserve the parent policy; it must be justified by G3.

## 5. Limited diagnostic outcome and exact outstanding gate

The independent probe reconstructs full parent physical square-unit closure and finds boundary-near Wave1 roots at1,23,31,32,123,3232. Counts are7,11,8,6,12,6 respectively. All have exactly one inward geometric candidate, and it is a true return. Several also have the boundary-touching return. The ten observed local masks are NOT asserted to be exhaustive or propagated.

No general paired-arc classification has been proved in this note. The remaining universal gate is G1 plus the one-sided parent-policy atoms G3 for authenticated paired arcs. A proof of parent free return squares alone pays G2, but does not pay G3. This is the precise distinction the pinned Wave1 paragraph needs to retain.
