from pathlib import Path
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review');s=(P/'wave_square_geometry.py').read_text();s=s.replace("for w in ['1','12','13','21','23','31','32','11','123','212','3232']:","for w in ['1','23','31','32','123','3232']:")
s=s.replace("badboundary=[z", "patterns=[]\n badboundary=[z")
s=s.replace("if not any(Q<=S", "if not assigned(zz) and any(not Q <= E-bd for Q in squares if other in Q):\n   patterns.append(dict(z=z,chosen=chosen,other=other,psi=psi(z),candidates=[dict(local=sorted((a-x,b-y)for a,b in Q),inside=Q<=E-bd,returns=Q in qs,boundary=sorted((a-x,b-y)for a,b in Q&bd)) for Q in squares if other in Q]))\n  if not any(Q<=S")
s=s.replace("row=dict(word=w,", "row=dict(patterns=patterns,word=w,")
s=s.replace("print(row,flush=True)","print(w,'NEAR',len(patterns),flush=True)")
s=s.replace("Path(__file__).with_name('WAVE_SQUARE_GEOMETRY.json')","Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/allslopes/dependencies/wave1/LOCAL_COLLAR_DIAGNOSTIC.json')")
exec(compile(s,str(P/'wave_square_geometry.py'),'exec'))
