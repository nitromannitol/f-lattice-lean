from pathlib import Path
import collections,json
D=Path(__file__).resolve().parent; rows=json.loads(next((d/'scalar_native_inputs.json' for d in (D,D.parent,D.parent.parent) if (d/'scalar_native_inputs.json').exists())).read_text())
def xy(z,v,j=1):return tuple(m+j*n for m,n in zip(z,v))
def inp(z):return [xy(z,d)for d in ([(-1,0),(1,0)]if sum(z)%2==0 else [(0,-1),(0,1)])]
def eg(a,b):
 if not b:return 1,0
 u,v=eg(b,a%b);return v,u-(a//b)*v
def arc(z,a,b,A,B):
 curve=[z]; ee=[0]+[v for j in range(1,A+B-1) for v in ([1]if B*(j+1)//(A+B)-B*j//(A+B)else[0,0])]+[0]
 for v in ee:curve.append(xy(xy(curve[-1],a),b,v))
 return curve
ports=arrows=sites=cts=0;results=[]
for row in rows:
 if not row['word'] or set(row['word']) in ({'2'},{'3'}): continue
 n,d,G=row['n'],row['d'],row['G'];L=n+d;T=len(G);U=(d,n);V=(n-d,L);c=-(T+n+d)//2;a,b=eg(n,d)
 def f(z):
  t=n*z[0]-d*z[1];u=t%T;j=(u-t)//T;return G[u]+j*(u+c)-T*j*(j-1)//2
 def key(z):return(n*z[0]-d*z[1])%T
 reps=[(a*t,-b*t)for t in range(T)]
 white=[sum(f(u)for u in inp(z))==2*f(z)for z in reps]; force={};cs=[]
 for z in reps:
  q=[xy(z,v)for v in [(0,0),(1,0),(1,1),(0,1)]]
  cs.append([(key(p),next(i for i,u in enumerate(inp(p))if u not in q))for p in q if white[key(p)]])
 while True:
  old=len(force)
  for cl in cs:
   if any(force.get(k)==i for k,i in cl):continue
   rest=[(k,i)for k,i in cl if k not in force];assert rest
   if len(rest)==1:force.update(rest)
  if old==len(force):break
 H=arc((1,0),(1,0),(0,1),(d-n)//2,n); Vs=arc((0,0),(0,1),(-1,0),n,d-n)
 assert {key(x)for x in H+Vs}=={i for i,w in enumerate(white)if w and i not in force}
 for eta in [-1,1]:
  pol=dict(force)
  for i,z in enumerate(H):pol[key(z)]= (0 if eta==1 else 1)if i==0 else 1
  for i,z in enumerate(Vs):pol[key(z)]=1 if i==0 else (1 if eta==1 else 0)if sum(z)%2==0 else (0 if eta==1 else 1)
  def opts(z):
   q=inp(z);return [q[pol[key(z)]]]if white[key(z)]else q
  num=0
  for z in H+Vs:
   u=next(x for x in inp(z)if x not in opts(z))
   assert any(z in opts(w)for v in opts(u) for w in opts(v))
   num+=1
  # Independent exact finite difference constraints, NOT the halfspace Bellman proof.
  # h(z)=m*ell(z)+off([z]), ell=(alpha*x+beta*y)/T, ell(U)=-1,ell(V)=2*eta.
  alpha=-L-2*eta*n;beta=n-d+2*eta*d;m=T+1
  assert alpha*d+beta*n==-T and alpha*(n-d)+beta*L==2*eta*T
  pred=[[]for z in reps];ne=0
  for k,z in enumerate(reps):
   for v in opts(z):
    h=key(v); w=T+m*(alpha*(v[0]-z[0])+beta*(v[1]-z[1])); pred[h].append((k,w));ne+=1
  off=[0]*T;q=collections.deque(range(T));inq=set(q);updates=0
  while q:
   j=q.popleft();inq.remove(j)
   for k,w in pred[j]:
    if off[k]<off[j]+w:
     off[k]=off[j]+w; updates+=1
     assert updates<T*T*4
     if k not in inq:inq.add(k);q.append(k)
  def R(z):return m*(alpha*z[0]+beta*z[1])+off[key(z)]
  W=xy(V,U,2*eta)
  assert all(R(xy(z,W))==R(z)and all(R(z)-R(v)>=T for v in opts(z))for z in reps)
  eps=1 if row['word'].count('1')%2 else -1
  prs=[(N,B)for B in range(2,d//2+1) for N in range(1,B)if N*d-B*n==eps and (B+N)%2]
  assert len(prs)==1,(row['word'],eps,prs)
  N,B=prs[0];sig=(eps*2*B,eps*2*N);v=(eps*(N-B),eps*(N+B))
  def P(z):return f(z)-f(xy(z,v,-1))-eps*(N*z[0]-B*z[1])
  def DD(z):return f(z)-f(xy(z,sig,eta))
  def PH(z):return DD(z)+P(xy(z,sig,eta))
  def hh(z):return f(z)-DD(z)//2
  def dg(h,z):return sum(h(u)-h(z)for u in inp(z))
  for z in reps:
   for h in (P,DD,PH):
    a=h(z);a0,a1=[h(u)-a for u in inp(z)]
    if h!=PH:assert max(abs(a0),abs(a1))<=1,(row['word'],z,h.__name__,a0,a1)
    if h==P or (h==DD and a%2==0):assert {a0,a1}!={-1,1},(row['word'],z,h.__name__,a0,a1)
    assert all(h(u)<=a for u in opts(z)),(row['word'],eta,z,h.__name__)
   ph=PH(z)
   for j in range(min(PH(u)for u in inp(z)+[z])-1,max(PH(u)for u in inp(z)+[z])+2):
    def band(u):return min(f(u),f(u)-PH(u)+j)
    assert dg(band,z)in (-1,0),(row['word'],eta,z,ph,j)
   if eta==1:
    assert dg(hh,z)in(-1,0)
    def rank(u):return (DD(u)%2,R(u))
    assert sum(rank(u)<rank(z)for u in inp(z))>=1-dg(hh,z)
  ports+=num;arrows+=ne;sites+=T;cts+=1
  results.append(dict(word=row['word'],eta=eta,classes=T,ports=num,arrows=ne,pitch_scale=m))
print(json.dumps(dict(result='PASS',field_signs=cts,total_classes=sites,free_roots=ports,selected_physical_edges=arrows,rows=results),indent=2))
