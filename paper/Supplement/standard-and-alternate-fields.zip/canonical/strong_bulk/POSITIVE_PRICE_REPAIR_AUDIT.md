# Positive-sheet bounded-drop repair: scope and policy audit

Source context: wave1close/SHORT_SLIP_COMMON_CHART.md, the authentic parent minimum fA/fC, and the proposed exact price identity bC-bA=Psi+gamma. This audits the implication from that identity; it does not replace the source derivation of bA,bC or certify the separate negative-chart gate.

## 1. The scalar bounded-drop lemma

Fix a physical parity of the odd parent. Suppose psi on its integer transverse coordinate has

    psi(t+Tp)=psi(t)+1

and its values on ONE genuine consecutive Tp-integer interval have span at most one. Then for every integer a>=0 and every t,

    psi(t+a)-psi(t)>=-1.

Proof: write t=t0+i+jTp and t+a=t0+i'+j'Tp with 0<=i,i'<Tp. Since a>=0, j'>=j. The difference is (j'-j)+psi(t0+i')-psi(t0+i)>=-1. This works separately for each physical parity; one must not combine the two parity profiles into an unsupported common span. The translate in the proposed gamma preserves parity.

More precisely, if a=mTp+r, 0<r<Tp, the elementary bound is m-1<=difference<=m+2. If r=0 it is exactly m. No parameter-independent upper bound is justified when a may contain many periods. In particular, a nonnegative shift shorter than Tp does NOT imply a nonnegative difference.

With a=Cq-1>=0 and the stated correct positive drift, this proves gamma=psi_+(x-te)-psi_+(x)>=-1. The scalar shift tp(x-te)-tp(x)=Cq-1 must be verified with the actual consumed frame; its sign is not interchangeable with the sign of the physical secondary vector.

## 2. Only target dominance is required

Let the desired positive-sheet increment be represented at both endpoints of ONE actual common chart by B(v)=min(bA(v),bC(v)). Suppose at the target u

    bC(u)-bA(u)=Psi(u)+gamma(u), Psi(u)>=1.

Then B(u)=bA(u). If the already proved matched parent inequality gives bA(u)>=bA(z), then

    B(u)=bA(u)>=bA(z)>=min(bA(z),bC(z))=B(z).

No dominance statement at z is needed. This removes the earlier false inference of everywhere bC>=bA from nonnegative displacement. The root can even have the other shifted branch active.

At Psi(u)=0, this proof only gives bC(u)>=bA(u)-1, which is insufficient for the unrounded monotonicity conclusion. Rounded monotonicity may hide exactly this one-unit loss and cannot be substituted. The tie-target case is a genuinely remaining gate.

## 3. When is the actual child edge a canonical parent edge?

Choose a parent active at the target. It is NOT generally legitimate to infer parent-policy membership just from target activity or from parent recurrence. The following case analysis licenses the inference under the already-established regional W1/contact and comparison monotonicity gates.

* If the parent is black at the root, both actual inputs are allowed in its canonical graph.
* If the child is white and its bulk input is unit-forced, regional W1 has to identify that actual forced direction with the active parent's direction on its contact region. Equivalently use a separately valid finite unit-contact transfer. Mere existence of some parent strict rank is insufficient.
* If the child is black but the active parent is white at the root, the minimum deficit came from a noncontact input. In the one-unit binary case the other, contact input is unique. Parent comparison monotonicity forces the parent's chosen input to remain in its active contact side, hence it is this input. Thus an edge aimed at that contact target is canonical.
* If the target's parent is strictly inactive at the root, an edge directly crossing between the two strict regions must first be excluded by the genuine absorbing/contact lemma. One cannot apply the previous cases until root contact is known. At a tie root either active parent can be selected, but the appropriate unique contact-input argument or regional transfer still applies.

These are actual color/contact arguments, not a license to pick a favorable parent edge after observing the target. Free CHILD edges are outside a claim about the intrinsic bulk graph and need their own policy rule if the claim includes them.

## 4. Both signs and reflection

For the canonical child reflection R and the genuine slip identity

    Dplus(z)=2+Dminus(R-z),

an inequality Dplus(u)<=Dplus(z) is exactly equivalent to Dminus(R-u)<=Dminus(R-z). The reflected physical edge has the same direction of traversal (root R-z to input R-u); the inequality does not reverse. Reflection swaps the relevant active chart and the positive/negative primary-chart representation, with the true offsets retained.

Thus an A tie-to-tie positive case may be paid by the independently proved reflected negative-adjacent-chart gate. This is noncircular only if that negative gate does not itself invoke the positive tie-to-tie case. A directed dependency list should state: old-parent matched monotonicity + two-level span -> strict-target positive cases; independent negative-adjacent gate -> positive tie cases by reflection. Reflected strict-target cases are then consequences, not additional hypotheses.

The bounded-drop estimate alone does NOT prove negative-sheet monotonicity: a negative displacement can lose entire periods. Nor does it pay arbitrary cross-crease cases without the actual one-unit bonus/individual-price bounds. Those remain separate entries in the full strong-bulk proof.

## Verdict

The proposed repair of STRICT-positive-target dominance is sound and needs no global bC>=bA assertion. Its scalar lower bound is exactly -1, not 0. Complete strong raw monotonicity still requires the independently authenticated price identity, true common-chart endpoint coverage, parent-edge licensing above, the existing cross-crease estimates, and the separate negative/tie gates. Current-child strong monotonicity is not used to justify any of these prerequisite policy cases.

## Authenticated definitions and sign check (parent clarification)

Here v=-epsilon Uq, psi_+(x)=Fp(x+v)-Fp(x), and te=Vq+epsilon Uq. With tp(Uq)=epsilon and Cq=D(dq+nq)+N(dq-nq), one has

    tp(v)=-1, tp(Vq)=-Cq, tp(-te)=Cq-1>0.

Both v and te preserve physical parity. The actual parent Vp cocycle gives psi_+(x+Vp)=psi_+(x)+ap.v=psi_+(x)-1. Since tp(Vp)=-Tp, the scalar drift is indeed psi_+(t+Tp)=psi_+(t)+1, not its negative.

On the positive primary common chart, the two residual prices are exactly

    bA(z)=psi_+(x), bC(z)=Psi(z)+psi_+(x-te).

Thus the price difference used above is authenticated, with no omitted affine constant. On an A-contact edge with nondecreasing Psi, a strict-positive target is paid by §2. If the A target is tied, monotonicity and A contact at both endpoints force a tie-to-tie edge; this is precisely the remaining reflected negative-chart case, not a further strict-target case. Choosing the target's active chart does not remove the parent-edge prerequisites in §3.
