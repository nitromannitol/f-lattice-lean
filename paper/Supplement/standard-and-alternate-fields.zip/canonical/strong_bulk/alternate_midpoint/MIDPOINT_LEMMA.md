# Midpoint alternate: complete local proof and physical recurrence

**Verdict: PASS.** The proposed hypotheses suffice. No recurrence or policy of g is required. The parity below is parity of the INTEGER GAP D, not physical checkerboard parity.

Let F,g be integer-valued on the F-lattice, with Laplacians in {-1,0}. Write D=F-g and H=F-floor(D/2)=ceil((F+g)/2). Suppose:
1. Every actual input edge has |D(u)-D(z)|<=1.
2. At every even-D root its two input increments are not {-1,+1}.
3. A genuine physical strict-rank policy of F keeps both inputs at black roots and one at white roots; D is nonincreasing on every kept edge.

Then H is globally binary and has a physical acyclic policy with strict lexicographic rank (D mod 2,R_F). Consequently H has no finite nonempty fort and is recurrent. This is an abstract implication; applying it to a literal alternate additionally requires its genuine height identity with H and the stated global hypotheses.

## Exact star formula
At a root put r=D(z) mod 2 in {0,1}, e_i=D(u_i)-D(z), and l=Delta F(z). Then
  Delta g = l-e_1-e_2,
  Delta H = l-floor((r+e_1)/2)-floor((r+e_2)/2).
These formulas hold equally for negative D because floor, not truncation toward zero, is used. Both input directions are the actual two inputs of the root's physical parity.

## Exhaustive unordered table
Permuting the two inputs is allowed. B/W denote black/white, i.e. Laplacian -1/0.

 gap parity | F | increments | g | H | H choices
 even | B | (-1,0) | W | W | choose the zero increment
 even | B | (0,0)  | B | B | keep both ties
 even | W | (0,0)  | W | W | keep F's chosen input
 even | W | (0,+1) | B | W | F necessarily chooses the tie; keep it
 odd  | B | (-1,0) | W | B | keep both
 odd  | B | (0,0)  | B | B | keep both ties
 odd  | W | (-1,+1)| W | B | keep both (both lead to even gap)
 odd  | W | (0,0)  | W | W | keep F's chosen input
 odd  | W | (0,+1) | B | B | keep both; tie is F's chosen input

There are no other cases. Binary F,g restrict the sum of the increments; at F-black both increments must be <=0; at F-white at least the chosen increment must be <=0. The sole remaining even-gap case is F-white with (-1,+1), which hypothesis 2 excludes. In that excluded case Delta H=+1, so the exclusion is genuinely needed for this proof and for H admission in that local signature.

The independent executable `exhaust.py` enumerates all 2*2*3*3 parity/color/increment possibilities and every possible kept F-white input. It checks admission and the exact rank-allowed edges. All 16 ordered retained-policy cases pass; exactly two ordered even saddles are excluded. `EXHAUST.json` contains every case, not sampled geometry.

## Rank proof
At even-gap H-black roots both inputs tie and F is black, so R_F strictly decreases on both. At even-gap H-white roots the table supplies a retained F input with zero gap increment. Choose it; the parity stays zero and R_F decreases.

At odd-gap H-black roots every non-tie input has even gap, so the first coordinate strictly decreases, independently of R_F. Every tied input is retained by F: this is immediate for F-black, and for F-white in the (0,+1) case monotonicity excludes the positive input and forces the tie. Thus every kept edge decreases the lexicographic rank.

At odd-gap H-white roots the exhaustive table is stronger than the proposed statement: BOTH inputs tie and F is white. Keep F's chosen input and use its strict rank. There is no additional odd-gap H-white case needing an arbitrary even input.

A finite H-fort would have a lexicographically minimum vertex. If black, either inside input contradicts strict decrease on both; if white, the fort must contain the selected input, again a contradiction. This proves physical recurrence without a quotient argument or a claim that recurrence is preserved by arbitrary rounding.

## Local max/min normalization
At an even-gap root D(z)=2a, throughout its unit star,
  H = max(F-a,g+a).
At an odd-gap root D(z)=2a+1, throughout its unit star,
  H = min(F-a,g+a+1).
These identities use |edge D|<=1 and the root's fixed integer a. They are local identities, not global normalized max/min decompositions. In particular global admission is not inferred from max closure, which would be invalid; it is proved by the table. The even no-saddle condition removes exactly the offending local max signature.

If R_F has uniformly bounded edge increments, the lexicographic rank can additionally be replaced by R_F+C*(D mod 2) for C larger than every positive edge increment of R_F. Without that bound, the lexicographic rank alone already proves the claimed recurrence. No prescribed deck character for the resulting rank is asserted without checking the parity cocycle of D.
