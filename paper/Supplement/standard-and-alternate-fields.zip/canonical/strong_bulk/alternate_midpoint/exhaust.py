from pathlib import Path
import itertools,json,hashlib
P=Path(__file__).resolve().parent
rows=[];excluded=[]
for parity,lap,a,b in itertools.product(range(2),(-1,0),(-1,0,1),(-1,0,1)):
 ds=(a,b);lg=lap-a-b
 if lg not in(-1,0):continue
 choices=[(0,1)]if lap==-1 else[(0,),(1,)]
 for keep in choices:
  if any(ds[i]>0 for i in keep):continue
  if parity==0 and min(ds)<0<max(ds):
   excluded.append(dict(parity=parity,lapF=lap,lapG=lg,ds=ds,keepF=keep));continue
  lh=lap-sum((parity+t)//2 for t in ds)
  assert lh in(-1,0)
  # Allowed edge iff it strictly lowers parity, or preserves parity and is F retained.
  good=[i for i,t in enumerate(ds)if (parity+t)%2<parity or ((parity+t)%2==parity and i in keep)]
  if lh==-1:assert len(good)==2
  else:assert good
  if parity==0 and lh==-1:assert ds==(0,0)and lap==-1
  if parity==0 and lh==0:assert any(ds[i]==0 and i in keep for i in good)
  if parity==1 and lh==0:assert ds==(0,0)and lap==0
  rows.append(dict(parity=parity,lapF=lap,lapG=lg,ds=ds,keepF=keep,lapH=lh,rank_allowed=good))
report=dict(status='PASS',cases=len(rows),excluded_even_saddles=excluded,rows=rows)
(P/'EXHAUST.json').write_text(json.dumps(report,indent=2)+'\n')
print(len(rows),len(excluded))
