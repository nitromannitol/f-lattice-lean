# Chain admission and strict physical band audit

Write h for the ACTUAL second chain sheet, Phi=F-h=D+P_shift. Require F,h binary, |delta D|,|delta P_shift|<=1 on every actual input edge, and no star of P_shift with increments {-1,+1}. Require Phi nonincreasing on F's true policy and nondecreasing on the true h policy. Reflection can supply the latter only after proving the exact field/policy conjugacy and sign of Phi; a matched graph for the intermediate shifted F is not automatically the h graph.

## Unit increments
An increment +2 of Phi forces F-white, since F-black retains both inputs. If h-black, both Phi increments would be >=0 by h-policy monotonicity, contradicting their sum Delta F-Delta h=1. Hence both fields are white, the other increment is -2, and the two D increments and two P_shift increments are each {+1,-1}. This contradicts primitive no-X. The -2 case is symmetric. Thus |delta Phi|<=1. This does NOT follow merely by adding two unit bounds.

A local signature illustrating the missing-premise risk is Delta F=0, Delta h=-1, delta D=(1,-1), delta P_shift=(1,0), hence delta Phi=(2,-1). F may select the negative edge, and primitive P has no X. The genuine h-black matched monotonicity is what excludes it. This is a local logical obstruction, not a constructed authentic global counterexample.

## Admission and black-X distinction
For every integer k, m_k=min(F,h+k) is binary by the already audited two-sheet star lemma. At strict winners the unit increment bound fixes the whole star; at ties F-black or h-black monotonicity prevents excess loss; white-white opposite increments produce exactly one loss.

An X star of Phi cannot be F-black (the +1 edge would be retained), nor h-black (the -1 edge would be retained). It CAN occur at an m_k-black tie, with both original sheets white. Thus 'no black X' must refer to an original sheet, not to the minimum. In particular do not remove legitimate X sites from the minimum's band table.

## Exact band firing quota
On B={Phi=k}, put e_i=Phi(u_i)-k, off=#{i:e_i!=0}. Let s_m=Delta m_k+1 (white1, black0). Paying all off-band inputs, the number of additional burned on-band inputs needed is
  need=2-s_m-off=1-Delta m_k-off.
This is a BURN threshold, not the fort quota 2+Delta m_k. They are complementary thresholds and must not be interchanged.

The complete unordered band table under the above hypotheses is:
 F | increments | h | m_k | need | rank justification
 B | (-1,0) | W | B | 1 | tied edge retained by F
 B | (0,0)  | B | B | 2 | both edges retained by F
 W | (0,0)  | W | W | 1 | F's chosen tied edge
 W | (0,+1) | B | B | 1 | F monotonicity forces tied choice
 W | (-1,+1)| W | B | 0 | both inputs already off-band
Every on-band input needed by this table has strictly smaller R_F. In the last case no on-band rank requirement remains.

## Clean finite-period band and recurrence
Assume the physical band has finitely many classes under its period w, all colors and band edges are w-periodic, and R_F has ZERO drift under w on B. Then its restriction descends to a genuine finite-valued strict rank for all required on-band edges above. Induction on increasing rank burns every band class, with no fictitious representative-edge comparisons. The same periodic burn times give a physical band rank. Mere physical strictness with nonzero w drift would not prove quotient burning.

Global recurrence of m_k also follows directly from the two-sheet lexicographic rank (-|Phi-k|,piecewise parent rank), assuming both original strict policies. The band proof is stronger in a different direction: it certifies the finite-period clean band and a periodic band firing order. Recovering global ranks from this band alone additionally requires the authenticated unit-level translation preserving colors and all local labels, not just a numerical unit drift of Phi.

W1/private squares are not needed in the quota calculation. They are needed for downstream claims that tie-white arrows are unit-forced or that rejected-input returns give a three-step gap in the intrinsic band firing rank. Those uses require genuine physical return squares; monotonicity then keeps the full return on B.

Verdict: conditional PASS with the explicit h-policy/reflection and zero-pitch premises. The raw sum/unit bounds, or recurrence of summands without those matched policies, do not alone close the chain. This audit does not re-prove the authentic source conjugacy.
