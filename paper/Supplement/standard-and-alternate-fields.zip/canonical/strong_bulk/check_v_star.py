from pathlib import Path
import json
D=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review/terminal_repair/pre_rank/port_package')
s=(D/'replay_ports.py').read_text().split('if __name__')[0];s=s.replace('D=Path(__file__).resolve().parent','D=Path("'+str(D)+'")');a=s.index('  s=mul(2*e*eta');b=s.index('  # Statewise',a)
s=s[:a]+'''  s=mul(2*e*eta,(pd,pn));DD=lambda z:f(z)-f(add(z,s));rr=[]
  for j,z in enumerate(Y):
   delta=(1,0)if j==0 else(eta,0)if sum(z)%2==0 else(0,-eta)
   u=add(z,delta)
   rr.append(dict(j=j,z=z,parity=sum(z)%2,D=DD(z),Du=DD(u),delta=delta,onarc=u in Y,otherD=DD(sub(z,delta))))
  yield dict(word=w,n=n,d=d,r=r,L=L,W=(e+1)//2,eta=eta,rows=rr)
''' +s[s.index("if __name__"):]if False else s[:a]+'''  s=mul(2*e*eta,(pd,pn));DD=lambda z:f(z)-f(add(z,s));rr=[]
  for j,z in enumerate(Y):
   delta=(1,0)if j==0 else(eta,0)if sum(z)%2==0 else(0,-eta)
   u=add(z,delta)
   rr.append(dict(j=j,z=z,parity=sum(z)%2,D=DD(z),Du=DD(u),delta=delta,onarc=u in Y,otherD=DD(sub(z,delta))))
  yield dict(word=w,n=n,d=d,r=r,L=L,W=(e+1)//2,eta=eta,rows=rr)
'''
exec(compile(s,str(D/'replay_ports.py'),'exec'))
out=[v for a in json.loads((D/'scalar_native_inputs.json').read_text())for v in run(a)]
O=D.parent/'allslopes/dependencies/strong_bulk';(O/'V_STAR_ROWS.json').write_text(json.dumps(out,indent=2))
for r in out:
 if r['word']in ['1','23','32','123','3232']:
  print(r['word'],'r',r['r'],'L',r['L'],'W',r['W'],'eta',r['eta']);print([(v['j'],v['parity'],v['D'],v['Du'],v['otherD'])for v in r['rows']if not v['onarc']])
