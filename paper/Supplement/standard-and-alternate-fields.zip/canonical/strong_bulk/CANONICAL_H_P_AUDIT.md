# Independent audit of P on canonical H edges

**PASS under the authentic pre-W1 strip/geometry/deck inputs and strictly prior parent Psi monotonicity.** The child policy here is the reflected (-1,eta) policy: internal H roots go EAST (even) or NORTH (odd), independently of eta. Native H0 is exceptional and goes DOWN. Confusing this with the (+1,eta) H convention reverses the proof.

Let child n/d=2P+Q, parent P=N/D, L=d+n, Lp=D+N, c=d-n, epsilon=2W-1, lv=(1-W)Uq. Put w=z for W0, and w=Uchild+I-z for W1, I=(1,-1). The latter reverses the native H arc and preserves parity. After true reflection/deck normalization, P has the stated form

    constant+F(w)-F(w+Vp)+ap.w.

The actual child edge becomes E/N for W0 and W/S for W1, apart from the excluded child H0.

## 1. Exact parent free classes and endpoint directions

At a child central even endpoint, x+y=2k and t=2nk mod L, k=1,...,L/2-1. At an odd horizontal midpoint, n<=t<=d and 1<=x+y<=L-1. The determinant gives the exact formula

    tp(w)=(Lp*t(w)+epsilon*(w_x+w_y))/L.

Subtract tp(lv)=(1-W)epsilon. Integer bounds yield:

 W0 actual parent w-lv: even tp in [1,Lp], odd tp in [N+1,D];
 W1 actual parent w:    even tp in [1,Lp-1], odd tp in [N,D].

These bounds also include the H endpoint classes after their literal endpoint formulas are inserted. For the odd midpoint bounds, use Lp*n=N*L-epsilon and Lp*d=D*L+epsilon. A transverse class AND parity determine the true primary orbit, since Up=2(D,N).

Ordinary classes are parent H classes. W0's possible extra even class tp=Lp is exactly Vend-Vp=(1,-1), whose canonical (-1,+1) input is EAST. The odd class tp=D includes Hlast-Up=(0,-1), whose input is NORTH. W0's troublesome parent H0 class tp=N is excluded by the strict lower bound N+1; it cannot be silently assigned NORTH.

For W1 the parent policy is (+1,+1), with WEST at internal even H roots and SOUTH at all odd H roots, including both H0 and Hlast (and their Up translates). Hence there is no upward endpoint exception in this phase. In particular the actual CHILD Hlast maps to w=H0=(1,0), whose parent SOUTH edge is exactly the transformed child NORTH edge. The CHILD H0 maps to child Hlast and does not obey this sweep; it remains a standalone endpoint.

Thus every non-H0 canonical child H edge, in these actual parent coordinates, is an edge of the required parent canonical graph. No parent choice is inferred from recurrence alone.

## 2. Full-star zero prices

At even parent roots in the displayed ranges, odd inputs have tp between 1-N and D+2N. These are inside the old full zero strip [1-D,N+2D-1], since D-N>=1. At odd roots, even inputs lie between N-D and 2D, inside the expanded even-parity interval [1-Lp,2Lp-1]. Thus the whole actual parent star is zero, including the two exceptional translated core classes. The child full H star is zero by its corresponding parity strips.

In particular F(w)=Fp(w-lv)=0 and the same holds at w'. These are full-star statements with the correct parity, not an unsupported identification of native parent domains.

## 3. The Vp-shifted endpoints are genuinely in E

Use C=D*L+N*c, so t(Vp)=-C and s(Vp)=2epsilon. The earlier positivity gives C>max(c+2,2n-2) and T-C>max(c+2,2n-2). The whole H input-star t bounds are even [n-d,2d] and odd [2-n,L+n-2]. Subtracting C places them in the actual closed parity t ranges [2-T,L-2] and [n-T,d].

For the chosen edges, rather than arbitrary input stars, the s bounds are also supported. In W0, traversal from H except H0 by E/N has even s<=T and odd s<=T-c; its lower s is positive by at least 2. Subtracting2 puts both endpoints in the closed native s ranges, even [0,T+2n], odd [2-c,T+L-2]. In W1, w ranges over H except Hlast and the W/S input decreases s; the lowest possible endpoint is H0's SOUTH input with s=2n. The highest root lies at or before the predecessor of Hlast, with s<=T-c-L. Adding2 again lies in both closed parity ranges. Therefore w+Vp and w'+Vp belong to E by the already established CLOSED lattice-point rectangle theorem. No independent per-vertex folding is used.

## 4. Monotonicity and H0

The parent Vp cocycle gives

 F(w+Vp)=ap.(w-lv)+cp+min(0,Psi(w+Vp)).

In the normalized expression for P, the affine term cancels, leaving a constant minus min(0,Psi(w+Vp)). The genuine comparison satisfies Psi(w+Vp)=Psi(w)-1. Since the edge in §1 is the actual parent canonical edge, strictly prior Psi monotonicity gives Psi(w'+Vp)>=Psi(w+Vp), hence the desired P nonincrease. This uses no current raw-slip monotonicity or alternate admission.

At CHILD H0 the actual input is down, outside the swept E/N pattern. Its genuine trace gives P(H0)=c0, and the separately established bound at that actual input (or the explicit core trace) is <=c0. It must be paid by that endpoint fact, not the parent-direction argument above. No claim is made that a mere native P<=c0 bound automatically applies to an exterior input; the physical core trace or an authentic translated bound must be used.

## Scope

This audit identifies and pays the non-H0 parent direction, every parent endpoint/adjacent residue, zero-star prices and supported shifted endpoint chart. H0 uses its separate actual maximum/core trace. All hypotheses can be ordered before current strong bulk/alternate closure: current true geometry and parity strips, native two-sheet values/deck, and earlier parent canonical Psi monotonicity. Current W1 is not used to identify a free H arrow; that arrow is the specified canonical boundary choice.

For the standard nonbase core trace the last endpoint is explicit: H0's down input is I=(1,-1)=Vend-V. Since P has zero V drift and P(Vend)=c0 on the genuine V boundary, P(I)=c0=P(H0). This is the physical exterior-input payment needed in §4; it uses no native-only inequality outside its domain.
