# Canonical FREE V-star raw-slip monotonicity, both signs

**Conditional theorem.** For a proper nonbase even standard child F of proper odd p=N/D and even q=nq/dq, assume authentic F=M=min(A,C) on closed E, genuine deck/reflection, ordinary child/parent h0 strips, native D+<=2, known V/H traces, and strictly prior Psi=C-A nondecrease on the actual canonical A-parent graph of sign(epsilon,+1). Then D+ is nonincreasing on every canonical(-1,+1) free V edge, and Dminus on every canonical(-1,-1) free V edge. No current bulk raw-slip monotonicity, printed star-jump inference, or alternate recurrence is used.

Write n/d=2p(+)q, epsilon=Nd-Dn, W=(1+epsilon)/2, Up=2(D,N), Uq=(dq,nq), sigma=epsilon Up, L=d+n, Lp=D+N, cp=D-N. Native child V endpoints are V0=(0,0) and Vend=V+(1,-1).

## 1. Correct exact parent-frame free classes

At a native odd child V vertex, parent sp is 2f-cp. For W1, f ranges0,...,D-1; for W0, f ranges1,...,D. At internal even doubled-zero vertices sp ranges[0,2N-2] in W1, [2,2N] in W0, in steps2. Initial sp=0. Crucially the FINAL value is

 sp_p(Vend)=sp_p(V)+sp_p(1,-1)=-2epsilon+2N.

It is2N-2 in W1 and2N+2 in W0. The latter endpoint is the only exempt root below.

Every other vertex lies on a genuine parent V arc translated by an integer multiple of Vp, or is the exceptional parent Hlast-Up=(0,-1) class (W1, odd sp=-cp) or H0=(1,0) class (W0, odd sp=Lp), again translated only by Vp. This uses exact sp, not a quotient that permits an unnoticed Up shift.

The child's eta+ choices are EAST at even roots, SOUTH at odd roots, and EAST at V0 and Vend. They agree with the parent's (epsilon,+1) canonical choices on every nonexempt root: interior V even roots go east, odd roots south, V0 east; parent Vend goes west at epsilon+ but its sp=2N is ABSENT from W1's list, whereas it goes east at epsilon-. The W1 exceptional Hlast-Up selects south for(+1,+1), and W0 H0 selects south for(-1,+1). Thus the actual edge, not just its direction in an unlabelled model, belongs to the parent graph.

## 2. Both source heights on each edge are genuinely h0

Let w be any nonexempt root and u its prescribed input. Parent h0 equality for w follows from the preceding exact spectra. It also holds for u by the ORDINARY strip[1-2D,2Lp-1]:

* an even root's east input has sp=sp(w)+Lp. At W1 its maximum is D+3N-2; at W0 its maximum is D+3N. Both are <=2Lp-1 since D-N>=1;
* an odd root's south input has sp=sp(w)-cp. Its minimum is -2cp at W1 and2-2cp at W0, both >=1-2D;
* initial V0's east input has sp=Lp.

The remaining upper/lower endpoints are inside the same strip. No 'full stars coincide' assertion is needed. The child F also equals h0 on its entire V input star by its own ordinary strip: even star s lies in[2-2(d-n),2d-2], odd star s in[-L,d+3n], all within[1-2d,2L-1].

## 3. The shifted child comparisons lie in the actual E

For W1 put X=Up; for W0 put X=Uq. Then F(z+sigma)=F(z+X), t(X)=-2, and A(z+X)=Fp(z) exactly (using its zero-character Up period in W1 and lv=Uq in W0).

The WHOLE child V input star shifted by X is in closed E. Its unshifted parity t bounds are even[-T+L,0], odd[-T+d,n]. Both s(X) and T-s(X) exceed4d, since s(Up)=2[D L+N(d-n)]>4d and s(Uq)>=3L+(d-n)>4d. Therefore the shifted s remains strictly between the V side bands. Geometric coverage fixes its s representative uniquely. The only possible t alias is the actual paired bottom/top H representative: after shift-2 the even t interval is[-T+L-2,-2], odd[-T+d-2,n-2]. If a representative needs t+T, that point lies on bottom H and its genuine paired top H point is the target. Thus the target really belongs to E, including any H boundary case. This is not a rectangular approximation.

For y=w+X and y'=u+X the two minimum evaluations are now licensed, and the h0 equalities give

 D+(w)=-min(0,Psi(y)),  D+(u)=-min(0,Psi(y')).

The actual A-parent coordinates are w,u, and section1 proves they form the required canonical parent edge. Strictly prior Psi nondecrease implies Psi(y')>=Psi(y), hence D+(u)<=D+(w).

## 4. The exempt endpoint and eta-minus reflection

At Vend the known trace is D+=2. Its prescribed east input is V+(2,-1), a strict-interior point of E. The already-paid native bound D+<=2 therefore proves the edge inequality. No parent class or cap-source identity at this floating endpoint is assumed.

Let K(z)=V+(1,-1)-z. It reverses the actual native V arc. True height reflection F(I-z)=F(z), I=(1,-1), and the Dminus V-character give

 Dminus(Kz)=D+(z)-2.

K carries each eta+ east/south edge to the eta-minus west/north edge, including Vend's desired west edge as the image of V0's east edge. The ONLY mismatch is at native V0: reflection of eta+ Vend's east edge points west there, whereas its actual eta-minus canonical input is EAST. Pay this separately by V0→H0 and the genuine trace Dminus(V0)=Dminus(H0)=0. This proves every actual eta-minus V edge.

## Independence and correction record

The parent supplied the D+ source idea; this audit independently checked the two phase shifts, all root/input spectra, parent canonical endpoint choices, native E license and the eta-minus endpoint mismatch. It also corrected my earlier endpoint audit: sp_p(Vchild,last)=2N-2epsilon, not2N. The earlier W1 protection result survives because the corrected reflected values still lie in its free spectra. This theorem closes FREE V raw-slip edges only; it does not assert a bulk theorem or an all-word native realization.
