exec(open('/tmp/threecover.py').read().split("for w in")[0])
rows=[]
for w in ['1','11','12','23','31','32']:
 mats=O.get_odometers(w)[0];frs=O.getFracs(w);fr,p,q=frs[1:];n,d=fr.numerator,fr.denominator;pn,pd=p.numerator,p.denominator;qn,qd=q.numerator,q.denominator;W=w.count('1')%2;eps=2*W-1;U=(d,n);Up=(2*pd,2*pn);Vp=(pn-pd,pn+pd);qv=(qd,qn);E,bd,H,V=polygon(n,d);F,*_=field(O.export_tile(mats[1]),fr);P,*_=field(O.export_tile(mats[2]),p);lv=times(1-W,qv);out=[]; opt,free=policy(fr,1,F,-1,-1)
 for z in E-bd:
  x=minus(z,lv); y=plus(z,times(eps,qv))
  if y not in E or F(z)!=P(x):continue
  for e in ([(-1,0),(1,0)] if sum(z)%2==0 else [(0,-1),(0,1)]):
   u=plus(z,e);xu=minus(u,lv);yu=plus(u,times(eps,qv))
   if yu not in E or F(u)!=P(xu):continue
   aa=[P(plus(xx,times(eps,qv)))-P(xx) for xx in [x,xu]]
   if aa!=[1,0]:continue
   S=[F(yy)-P(xx) for yy,xx in [(y,x),(yu,xu)]]
   out.append(dict(z=z,u=u,x=x,y=y,a=aa,S=S,child_lap=2*F(z)-sum(F(plus(z,e0))for e0 in ([(-1,0),(1,0)]if sum(z)%2==0 else[(0,-1),(0,1)])),retained=u in opt(z),free=free(z)))
 rows.append(dict(word=w,falling_A_prices=out)); print(w,len(out),flush=True)

import json
Path(__file__).with_name("NEGATIVE_REGRESSION.json").write_text(json.dumps(rows,indent=2))
