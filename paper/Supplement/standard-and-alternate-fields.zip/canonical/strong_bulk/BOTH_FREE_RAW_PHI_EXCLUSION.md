# Both-free exclusion for a raw Phi rise

Scope: proper nonbase even standard child, genuine deck-periodic free policy and true H/V spectra. This supplies the geometric last step of TWO_RANK_RAW_PHI_AUDIT.md; all binary, raw-D, unit-forcing and earlier P-monotonicity hypotheses of that reduction remain explicit prerequisites. It is not a fresh proof of those prerequisites or of native identification.

Put L=d+n, c=d-n, T=d²+2dn-n², t=nx-dy, U=(d,n), V=(n-d,L). The shift is eta sigma, with t(sigma)=-2; U,V,sigma have even parity. Write z'=z+eta sigma and u'=u+eta sigma. A hypothetical rise has D(u)=D(z), F and its shift both white, both root inputs tied, and opposite original (-1,eta) and shifted (-1,-eta) choices. The two actual acyclic tie assignments plus finite unit transfer exclude either root being W1-nonfree. Thus only the following genuinely free possibilities remain.

## 1. Shifted V roots: pay the WHOLE input star, not just the arc

A constant trace on V alone would NOT suffice for an off-arc rejected input. Here the genuine h0 strip pays that extra point. The native V star has even s in [2-2c,2d-2], odd s in [-L,d+3n], where s=Lx+cy. The price shift delta=epsilon Vp has s(delta)=2 and even parity. Both this whole star and its translate by -delta lie inside the ordinary h0 strip [1-2d,2L-1]: for the odd extrema use c>=3; all even extrema follow from n>=1. In a proper nonbase constructor c>=4. Consequently substituting h0 in

 P(v)=F(v)-F(v-delta)-epsilon(ap,2 dot v)

shows P=c0 on the ENTIRE native V input star, by the same quadratic cancellation that gives the genuine V trace. In particular P(u')-P(z')=0. For a V+kU+lV lift both values acquire the same character -k; equality of their difference remains exact. Thus shifted V is impossible at a rise. No inference from an unshifted representative's absolute price is made.

## 2. Original H and shifted H

On every lifted H, the exact physical-parity spectra modulo T are:
 even: 2,4,...,L-2;
 odd: n,n+2,...,d.
Each class of a fixed parity corresponds to a unique H vertex modulo the full deck lattice. Native t changes under our shift by -2eta. There is no wraparound between the two H intervals because T>L+2 for this proper scope. (A common deck translate merely changes t by a multiple of T.)

Even roots always select east for both signs. Odd roots always select north except H0, which selects -eta north under the original sign. Hlast always selects north. If the original root is H0, eta=+ sends t=n to n-2, not an H class; eta=- sends it to n+2, and the original choice is north. If the shifted root is H0, then the original t=n+2eta: eta=- is outside H, while eta=+ is an ordinary H vertex (possibly Hlast), whose north choice agrees with the shifted sign -eta=- at H0. Thus every actual H/H pair has agreeing choices, including both endpoint cases. It cannot be the opposite-choice pair required by a rise.

## 3. Original V and shifted H

The first odd V point is (0,1), with t=-d; the last odd point is Vend-(0,1), with t=-T+L+d. The arc decreases strictly in t, so every odd V vertex lies in [-T+L+d,-d]. After either shift of size2 it cannot meet the odd H bands [n,d] or [-T+n,-T+d]: the two separating gaps are L-2>0. Thus original odd V never shifts to H.

For even V vertices t decreases along the actual arc from 0 to -T+L. Distinct successive even vertices are separated in t by at least min(2d,L)=L, because the paired arc steps are (0,2) or (-1,1). Every nonendpoint even V vertex therefore has t in [-T+2L,-L]. After +/-2 this cannot meet the even H bands [2,L-2] modulo T. The only endpoint intersections are:

* V0 with eta=-: t'=2, an even H vertex; original V0 chooses east for either sign.
* Vend with eta=+: t'=-T+L-2, an even H vertex modulo T; original Vend chooses east at eta=+.

The shifted even H choice is east in both cases. Other endpoint/sign combinations miss H. Again choices agree, contradicting the necessary opposite choices.

## Conclusion and audit boundary

Every both-free possibility is excluded, uniformly over all physical deck lifts. Together with the independently proved two-rank/unit-transfer reduction, this proves the desired raw-Phi nonincrease. The full-star price argument in section1 is necessary: replacing it by 'P is constant on V' would leave a real logical gap. Pure/base c<3 cases are not covered by that strip estimate and retain their separate literal seed checks.
