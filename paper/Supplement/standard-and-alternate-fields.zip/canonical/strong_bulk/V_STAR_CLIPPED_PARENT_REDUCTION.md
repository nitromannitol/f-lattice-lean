# Canonical V-star reduction to one clipped earlier-parent field

This is a uniform source identity, not yet the desired monotonicity theorem. Let the proper nonbase even child be n/d=2(N/D)(+)nq/dq, epsilon=N*d-D*n, W=(1+epsilon)/2. Set Up=2(D,N), Uq=(dq,nq), Vq=(nq-dq,nq+dq), Lp=D+N. Assume genuine coherent F=M on E, authentic parent deck and ordinary zero/h0 strips.

Let Sminus contain every native child V_j and its ACTUAL canonical (-1,-1) input:

 V0 -> V0+ex;
 every other even V_j -> V_j-ex;
 every odd V_j -> V_j+ey.

Then throughout Sminus,

 Dminus(z) = F(z)-F(z-epsilon Up)
           = -min(g(z),2),
 g(z) = Fp(z+epsilon Uq)-h0(z).

## True child-domain license

Put X=Up when W0, X=Uq when W1. Primary periodicity gives F(z-epsilon Up)=F(z+X), and t(X)=2 in both cases. In fact the WHOLE V input star translated by X lies in true E, not a guessed rectangle.

The star's parity bounds are
 even: -T+L<=t<=0,  2-2(d-n)<=s<=2d-2;
 odd:  -T+d<=t<=n, -L<=s<=d+3n.

Both positive vectors X and U-X are actual parent primaries, and their child s values exceed4d: s(Up)=2[D L+N(d-n)]>4d; s(Uq)>=3L+(d-n)=4d+2n>4d. Hence translated s lies strictly between the two V boundary bands in each parity. Translated t ranges from -T+L+2 to2 (even), or -T+d+2 to n+2 (odd). Geometric coverage gives a representative in E with the same s; no s±T translate can occur because of the strict V-side margins. Its t cannot be the target+T (above E's maximum). If it is target-T, it lies on the top H free band, and its actual paired lower-H representative has exactly the target t and s. Otherwise it already is the target. Thus z+X is in the genuine closed E, including any H-boundary case.

Also F(z)=h0(z) on the whole original V star by the ordinary CHILD h0 strip: all displayed s bounds lie within[1-2d,2L-1] since d-n>=4.

## Exact two offers and parent strip guard

The first offer at z+X reduces modulo Up to Fp(z+epsilon Uq). The second reduces to

 Fp(z-Vq)+aq·z+(Tq-Lq)/2+2.

The +2 is aq·Up=2 in W0 and the explicit phase constant in W1. The ordinary h0 deck identity converts the second offer to h0(z)+2 whenever Fp(z-Vq)=h0(z-Vq).

This equality holds on Sminus using ONLY the ordinary parent h0 strip [1-2D,2Lp-1]. Native odd V vertices have sp in[-(D-N),Lp-2] at W1 and[2-D+N,Lp] at W0. Native even INTERNAL ones have sp in[0,2N-2] at W1 and[2,2N] at W0; the initial value is0, and the final value is2N-2epsilon. These are exact residual-f refinements. Subtracting Vq changes sp by2epsilon. Together with the prescribed inputs, safe query bounds are:

 W0 even: [-2(D-N),2D-2];  odd: [-Lp,Lp-2];
 W1 even: [2-2(D-N),2D];  odd: [2-Lp,Lp+2].

All are inside[1-2D,2Lp-1], including the smallest parent1/2. For W0 odd lower bound the only potential worse query comes from V0-ex, but V0 actually chooses EAST. For W1 the potentially excessive upper query comes from Vlast+ex, but Vlast actually chooses WEST. These excluded inputs are material; do not claim an unqualified whole-star cap-source equality. At actual23, the rejected query z=(-1,0) indeed fails Fp(z-Vq)=h0(z-Vq), although the final clipped identity happens still to hold there.

Taking the minimum of these two authenticated offers proves the displayed identity throughout Sminus.

## Intrinsic smaller-stage query and exact remaining obligation

When p is nonbase, write its genuine creation p=pold(+)qold, epsilon0=det(pold,qold). Every subsequent adjacent even q has either Uq=Uqold modulo Up and epsilon=epsilon0, or Uq=-Uqold modulo Up and epsilon=-epsilon0. Therefore epsilon Uq=epsilon0 Uqold modulo Up. The query g is independent of the trailing neighboring run and its side: it is a fixed intrinsic earlier-parent field minus h0. Pure parent cases require their actual explicit creator convention rather than an invented empty creator.

The desired canonical V monotonicity is now EXACTLY

 min(g(u),2) >= min(g(V_j),2)

for the prescribed input u. On-arc choices are paid by the known V trace. Off-arc samples show equality after clipping, but this note does NOT derive that equality from the trace. A direct earlier-parent strip/creation comparison, or a valid path sandwich, remains needed.

## Independent numerical check, limited scope

check_v_source.py recomputes actual child and consumed-parent global extensions and checks the clipped formula and E licensing on the WHOLE V input star of1,23,32,123,3232,33332,213. All pass; V_SOURCE_CHECK.json records no mismatch/outside target. The proof above claims only the precisely licensed canonical Sminus subset. check_v_star.py rebuilds actual scalar fields and records every canonical V input for17 stored words/both signs; V_STAR_ROWS.json distinguishes on-arc from off-arc. Those finite equalities are not asserted as the missing universal monotonicity proof.
