# Independent V-block and floating-endpoint check

Let the proper odd parent be N/D, 0<N<D, gcd(N,D)=1, N+D odd, and child n/d=(2N+r)/(2D+e), with Ne-Dr=epsilon=2W-1. Put L=d+n, c=d-n, T=d²+2dn-n², Up=2(D,N), q=(e,r), U=Up+q. All statements concern the actual Sturmian boundary construction, not a rectangular approximation to a source height.

## 1. Exact initial boundary word
For each integer 1<=l<D,

 (d-n)l/d = (D-N)l/D + epsilon*l/(D*d).

The nonintegral parent fractional part is an integer multiple of1/D, between1/D and1-1/D. Since d>D and l<D, the perturbation has magnitude strictly less than1/D. Floors therefore agree for EVERY such l. At l=D the parent expression is the integer D-N, while the child expression is D-N+epsilon/d. Its floor is D-N-1 for epsilon=-1 and D-N for epsilon=+1. The former retains the final vertical half-step; the latter replaces it by the diagonal. This verifies the actual final half-step separately instead of extending the interior floor identity to an integer endpoint.

In the expanded vertical word (a vertical0 is doubled, a diagonal1 is not), the first parent block therefore agrees with the child left V boundary, with just one exception: for W1 the artificial parent terminal

 v_end=(N-D+1,N+D-1)

lies one horizontal unit to the right of the child's diagonal terminal. This derivation remains valid for D-N=1, where the proper odd parent is nearest1. It excludes the degenerate parent1/1, which is not a proper odd parent and requires its base rule.

## 2. Translated copies a=0,1 and the excluded right endpoint
Use s(x,y)=Lx+cy. Genuine child left-V spectra are [0,2n] in even parity and [2-c,L-2] in odd parity, at the appropriate even-valued lattice points. Write their lower/upper bounds c_p,h_p. Their widths are 2n or2d-4, both strictly smaller than B=s(Up)=2(DL+Nc). Indeed D>=2 gives B>=4L, whereas both widths+2 are less than4L.

For x=v+aUp, both z=x+(1-W)q and y=z+epsilon q must lie in E. In either W these are exactly x and x+q, in opposite order. Since s(q)=T-B, their two genuine s intervals intersect to require

 c_p-s(v) <= aB <= h_p+B-s(v).

For every ordinary parent-V vertex, s(v) lies in [c_p,h_p] by part1. Width<B implies the ONLY possible integers are a=0,1. The floating even endpoint satisfies

 s(v_end)=2(dN-nD)+2n=2n+2epsilon.

For W1 this is h_even+2. The same intersection still forces a>=0, but its upper end is B-2, forcing a=0. Equivalently v_end+U has s=T+2n+2 and fails the true even upper bound T+2n. Thus the floating right copy cannot be an admissible negative common-chart edge; no height formula is evaluated there.

For W0, a=1 puts the original root z=v+U on the genuine right V boundary, excluded by strict interior, while a=0 gives shifted y=v and the already authenticated zero-price shielding. For W1, a=0 is on genuine left V except v_end; a=1 gives shifted y=v+U and the corresponding boundary shielding. These conclusions use actual V traces for the height0 statement, separately from the geometric proof here.

## 3. Floating W1 selected west edge
Let Vp=(N-D,N+D), I=(1,-1), R_p=Up+Vp+I. Then v_end=Vp+I,

 R_p-v_end=Up,
 R_p-(v_end-ex)=Up+ex.

Define psi_minus(x)=P(x+q)-P(x), psi_plus(x)=P(x-q)-P(x), since W1 has epsilon=+1. The genuine parent native reflection P(R_p-x)=P(x)-a_p dot x+constant, with a_p=(N,-D), gives

 psi_minus(R_p-x)=psi_plus(x)+a_p dot q=psi_plus(x)+1.

Primary periodicity reduces Up and Up+ex to0 and H0=ex. Therefore the previously authenticated endpoint equalities psi_plus(0)=psi_plus(H0)=0 give

 psi_minus(v_end)=psi_minus(v_end-ex)=1.

The parent canonical horizontal sign is west; v_end is even and is that actual parent free endpoint. Thus its selected west edge cannot be the exceptional1→0 drop. If an argument uses the east edge instead, this calculation does not apply: its eligibility must first be resolved by the target-active edge assignment.

## Verdict and dependency scope
The floor geometry, index pinning, exclusion of the floating right copy, and reflection signs all pass uniformly for every proper odd parent, including D-N=1. Together with the separately verified target-active matching, true prior halo range, H-star endpoint ties, and boundary shielding, these close the proposed negative-chart exceptional V cases. This note does not manufacture those inherited height/policy inputs; it identifies exactly where they enter. No finite census, current-child rank, or current-child raw monotonicity is used in this proof.
