from pathlib import Path
P=Path('astra_twocell_induction_20261118/outer_reorder/followup2035/carbon_review')
exec((P/'policy_square_geometry.py').read_text().split('\nrows=[]\n')[0])
h0=lambda z:(z[0]*z[0]+2*z[0]*z[1]-z[1]*z[1]-2*z[1]-(sum(z)%2))//4
out=[]
for word in ['1','23','32','123','3232','33332','213']:
 mats,_=O.get_odometers(word);_,fr,p,q=O.getFracs(word);n,d=fr.numerator,fr.denominator;pn,pd=p.numerator,p.denominator;qn,qd=q.numerator,q.denominator;eps=2*(word.count('1')%2)-1;Up=2*pd,2*pn;Uq=qd,qn
 F=ext(O.export_tile(mats[1]),fr,1);FP=ext(O.export_tile(mats[2]),p,0);E,bd,H,V=polygon(n,d);bad=[];outside=[]
 for j,z in enumerate(V):
  inp=[add(z,v)for v in([(-1,0),(1,0)]if sum(z)%2==0 else[(0,-1),(0,1)])]
  for x in [z]+inp:
   g=FP(add(x,(eps*qd,eps*qn)))-h0(x);DD=F(x)-F(sub(x,(eps*Up[0],eps*Up[1])));pred=-min(g,2)
   target=add(x,Up if eps==-1 else Uq)
   if target not in E:outside.append((j,x,target))
   if DD!=pred:bad.append((j,x,DD,pred,F(x),h0(x),g,target in E))
 out.append(dict(word=word,bad=bad,outside=outside));print(word,'bad',bad[:5],'outside',outside[:4],flush=True)
(P/'terminal_repair/pre_rank/allslopes/dependencies/strong_bulk/V_SOURCE_CHECK.json').write_text(json.dumps(out,indent=2))
