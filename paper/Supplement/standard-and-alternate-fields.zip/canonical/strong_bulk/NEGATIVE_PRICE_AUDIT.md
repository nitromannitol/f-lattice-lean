# Negative-chart price gate: independent audit

## Exact sign and frame calculation
Let eps=2W-1, lv=(1-W)q, x=z-lv, y=z+eps q. On the negative common child chart, z-eps Up+eps U=y because U=Up+q. Child primary character is zero, so the relevant shifted height is F(y), with no omitted primary gauge. At an A-contact root A(z)=P(x), and its two native prices are

 a(z)=P(x+eps q)-P(x)=psi_minus(x),
 b(z)=P(x-Vq)-P(x)+a_q dot x+eta_q.

The latter follows from te=Vq+eps q and a_q dot q=0. Thus b is exactly the complementary translated-parent difference, not the same psi evaluated at an unguarded point. Its conjugacy to const-D_eps(qsw)(Zx) remains an inherited identity to authenticate, including transport of the particular edge.

## Scalar reduction: PASS with its explicit hypotheses
At two A contacts S=F(y)-A(z)=min(a,b). Suppose S(z)=1,S(u)=0, b(u)>=b(z), and |a(u)-a(z)|<=1. Then b(z)>=1 and b(u)>=1, so a(u)=0; a(z)>=1 and Lipschitz imply a(z)=1. If both old endpoint values lie in the SAME translated V-halo range {j,j+1}, their values1,0 force j=0. The sign of vertical drift is positive: psi_minus(x+Vp)-psi_minus(x)=a_p dot(eps q)=1, using a_p dot q=eps. The letter j here is the Vp deck coefficient, not an extra scalar calibration.

## Proposed free-boundary case split
Given independently verified old-edge matching and the genuine V-block containment, the proposed cases have the correct frames:
- W0: lv=q,eps=-1, so y=x. If x=Vi+iUp, i=0 puts shifted y=Vi on native left V, where the old C price shields the minimum at0. If i=1 puts z on the corresponding right boundary, strict interior excludes it.
- W1: lv=0,eps=+1, so z=x and y=x+q. If i=0 puts z on native left V it is excluded by strict interior, apart from the explicitly floating final endpoint. If i=1 then y=Vi+Up+q=Vi+U, the right copy of the same boundary; the same exact boundary value gives S=0. A final endpoint outside the genuine E guard must be discarded, not evaluated by a sheet formula.
These are correct algebraic implications. This review has NOT independently established the all-word V-block geometric containment or the floating endpoint's actual selected west arrow. Those require the authentic boundary concatenation / endpoint strip proof and cannot be replaced by scalar ranges alone.

## Important edge-quantifier obligation
An A-contact child root and one A-contact input do not imply equal parent/child colors. The other input can be a C crease: if parent P is white and the other child input is lowered by1, the child is black. It then retains BOTH inputs although the parent retained only its selected white input. Thus 'already matched old edge' must cover this situation, or an independent crease/geometry argument must exclude it. Only when the WHOLE star is A-contact do the quotas coincide automatically. The proposed V/H endpoint argument is sufficient if proved for every relevant direction, not merely the parent's selected one.

## Exact finite diagnostic, not a uniform proof
The accompanying script uses genuine original native fields for words1,11,12,23,31,32, and EVERY A-contact interior root/input whose shifted pair has the negative common chart. It records all a=1→0 instances. With canonical child policy (-1,-1), every observed S=1→0 edge is REJECTED, and all retained falling-a edges are shielded by S=0→0. All recorded child roots happen to be white. This supports the mechanism but does not discharge the all-word edge-quantifier or geometry obligations.

For example at word1 z=(4,3),u=(4,2),x=z,y=(7,4), a=(1,0) but S=(0,0), and the edge is retained. At z=(0,2),u=(1,2),y=(3,3), both a and S fall1→0, but the edge is rejected. Thus an unrestricted statement about all directed A-contact input edges is actually false; the policy/black distinction is essential.

Verdict: frame/sign, minimum reduction, vertical j=0 pinning, and conditional four geometric cases pass. Universal negative gate remains conditional on actual V-block/floating endpoint geometry and the exact old-edge coverage noted above. No new-child rank or unproved raw monotonicity was used.

## Target-active assignment addendum
The parent supplied the missing edge assignment. At a root tie, sum Psi(inputs)=lapA-lapC. With input gaps in {-1,0,1}: Awhite/Cblack forces the unordered pair(-1,0), so there is no strict-A target; its canonical A edge must be the tie by already-paid incoming Psi monotonicity. Awhite/Cwhite permits(-1,+1), in which case M is black and the strict-A target is necessarily A's canonical edge. For (0,0) both inputs tie and source quota agrees. If A is black it retains both. The both-black mixed pair(-1,+1) would give lapM=2 and is excluded by independent admission of M. Assigning a strict target to its active chart, and reflecting when necessary, therefore resolves the white-parent/black-child locality concern. This is not a deduction from mere contact: it explicitly uses incoming Psi monotonicity and independent M binary admission. Under those inputs the edge-quantifier issue is closed; the outstanding independent check in this audit is the all-word V-block/floating-endpoint geometry, not local color algebra.
